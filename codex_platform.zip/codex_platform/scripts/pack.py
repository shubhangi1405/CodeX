import os
import shutil
import zipfile
from pathlib import Path

src = Path(__file__).resolve().parent.parent
dest = Path(r"C:\Users\SHUBHANGI\.gemini\antigravity\scratch\ghostwriter.zip")
artifact_dest = Path(
    r"C:\Users\SHUBHANGI\.gemini\antigravity\brain\85736784-0def-46b3-a62f-d2f8c6a90b25\ghostwriter.zip"
)

exclude_dirs = {
    ".venv",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".git",
    "dist",
}

print(f"Creating zip from {src}...")
with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.endswith(".egg-info")]
        for f in files:
            fp = Path(root) / f
            # Exclude zip itself and temp files
            if fp.suffix == ".zip" or fp.name.endswith(".pyc"):
                continue
            arcname = Path("ghostwriter") / fp.relative_to(src)
            zf.write(fp, arcname)

shutil.copy2(dest, artifact_dest)
print(f"Zip successfully created at: {dest} ({dest.stat().st_size / 1024:.1f} KB)")
print(f"Artifact copy created at: {artifact_dest}")
