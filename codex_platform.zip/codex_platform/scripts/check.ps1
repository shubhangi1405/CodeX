# Run full CI quality check
python scripts/runner.py check
exit $LASTEXITCODE
