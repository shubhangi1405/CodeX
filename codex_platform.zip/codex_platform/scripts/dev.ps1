# Run development server
python scripts/runner.py dev
