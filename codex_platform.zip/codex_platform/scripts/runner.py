"""
Cross-platform command runner for CodeX.
Operates identically across Windows (PowerShell/CMD), macOS, and Linux.
"""

import re
import subprocess
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent

# Detect venv python
if (ROOT_DIR / ".venv" / "Scripts" / "python.exe").exists():
    PY_BIN = str(ROOT_DIR / ".venv" / "Scripts" / "python.exe")
elif (ROOT_DIR / ".venv" / "bin" / "python").exists():
    PY_BIN = str(ROOT_DIR / ".venv" / "bin" / "python")
else:
    PY_BIN = sys.executable

NPM_BIN = "npm.cmd" if sys.platform == "win32" else "npm"

SECRET_PATTERNS = [
    re.compile(r"AIza[0-9A-Za-z_-]{30,}"),
    re.compile(r"AQ\.[0-9A-Za-z_-]{20,}"),
    re.compile(r"sk-[0-9A-Za-z]{25,}"),
]


def run_cmd(cmd: list[str], cwd: Path | None = None) -> int:
    print(f"\n[RUN] {' '.join(cmd)} (cwd: {cwd or ROOT_DIR})")
    res = subprocess.run(cmd, cwd=cwd or ROOT_DIR)
    return res.returncode


def cmd_secret_scan() -> int:
    print("=== Running Secret Hygiene Scan ===")
    scan_dirs = [
        ROOT_DIR / "apps" / "api",
        ROOT_DIR / "apps" / "web" / "src",
        ROOT_DIR / "apps" / "generated",
        ROOT_DIR / "engine",
        ROOT_DIR / "generators",
        ROOT_DIR / "docs",
    ]
    violations: list[str] = []
    for sdir in scan_dirs:
        if not sdir.exists():
            continue
        for fpath in sdir.rglob("*"):
            if not fpath.is_file():
                continue
            if any(
                part in fpath.parts for part in ("__pycache__", "node_modules", ".venv", "dist")
            ):
                continue
            if fpath.suffix.lower() in (".png", ".jpg", ".ico", ".db", ".sqlite", ".woff2"):
                continue
            try:
                content = fpath.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for pat in SECRET_PATTERNS:
                if pat.search(content):
                    violations.append(
                        f"Leaked secret pattern '{pat.pattern}' in {fpath.relative_to(ROOT_DIR)}"
                    )
    if violations:
        for v in violations:
            print(f"[SECRET VIOLATION] {v}")
        return 1
    print("[OK] Zero secret patterns detected in source or generated apps.")
    return 0


def cmd_lint() -> int:
    print("=== Running Linters ===")
    py_lint = run_cmd([PY_BIN, "-m", "ruff", "check", "."])
    web_lint = run_cmd([NPM_BIN, "run", "lint"], cwd=ROOT_DIR / "apps" / "web")
    return py_lint or web_lint


def cmd_typecheck() -> int:
    print("=== Running Type Checks ===")
    py_types = run_cmd([PY_BIN, "-m", "mypy", "apps/api", "engine", "generators"])
    web_types = run_cmd([NPM_BIN, "run", "typecheck"], cwd=ROOT_DIR / "apps" / "web")
    return py_types or web_types


def cmd_test() -> int:
    print("=== Running Test Suites ===")
    py_tests = run_cmd([PY_BIN, "-m", "pytest", "-v"])
    web_tests = run_cmd([NPM_BIN, "run", "test"], cwd=ROOT_DIR / "apps" / "web")
    return py_tests or web_tests


def cmd_check() -> int:
    print("\n=============================================")
    print("   CodeX Full CI / Quality Check           ")
    print("=============================================\n")
    if cmd_secret_scan() != 0:
        print("\n[FAILED] Secret hygiene scan failed.")
        return 1
    if cmd_lint() != 0:
        print("\n[FAILED] Lint check failed.")
        return 1
    if cmd_typecheck() != 0:
        print("\n[FAILED] Type check failed.")
        return 1
    if cmd_test() != 0:
        print("\n[FAILED] Test suite failed.")
        return 1
    print("\n[SUCCESS] All secret, lint, type, and test gates passed cleanly!")
    return 0


def cmd_dev() -> int:
    print("=== Starting CodeX Development Environment ===")
    api_proc = subprocess.Popen(
        [PY_BIN, "-m", "uvicorn", "apps.api.main:app", "--reload", "--port", "8000"], cwd=ROOT_DIR
    )
    web_proc = subprocess.Popen([NPM_BIN, "run", "dev"], cwd=ROOT_DIR / "apps" / "web")
    try:
        api_proc.wait()
        web_proc.wait()
    except KeyboardInterrupt:
        api_proc.terminate()
        web_proc.terminate()
    return 0


if __name__ == "__main__":
    action = sys.argv[1] if len(sys.argv) > 1 else "check"
    actions = {
        "secret-scan": cmd_secret_scan,
        "lint": cmd_lint,
        "typecheck": cmd_typecheck,
        "test": cmd_test,
        "check": cmd_check,
        "dev": cmd_dev,
    }
    if action not in actions:
        print(f"Unknown action: {action}. Available: {list(actions.keys())}")
        sys.exit(1)
    sys.exit(actions[action]())
