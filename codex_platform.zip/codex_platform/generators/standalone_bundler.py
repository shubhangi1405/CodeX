"""Stage E Standalone HTML Bundler: Zero-CDN interactive bundle from Blueprint & Direction."""

import json
from typing import Any

from generators.blueprint.schemas import AppBlueprint
from generators.design.schemas import DesignDirection
from generators.design.token_writer import (
    generate_design_tokens_css,
    render_brand_mark_svg,
)


def compose_standalone_html(
    project_id: str,
    blueprint: AppBlueprint,
    direction: DesignDirection,
    sample_seed_data: dict[str, list[dict[str, Any]]],
    allow_opt_in_footer: bool = False,
) -> str:
    """
    Produces a zero-CDN, offline-ready standalone_app.html driven by the exact
    AppBlueprint, DesignDirection tokens, navigation shell, and 17 layout archetypes.
    """
    tokens_css = generate_design_tokens_css(direction)
    brand_svg = render_brand_mark_svg(direction, blueprint.app_name)
    bp_json = json.dumps(blueprint.model_dump())
    dir_json = json.dumps(direction.model_dump())
    seed_json = json.dumps(sample_seed_data)
    mode = direction.color_mode.value
    dens = direction.density.value
    dir_id = direction.direction_id
    footer_html = (
        '<footer class="gw-opt-footer">Built with CodeX</footer>' if allow_opt_in_footer else ""
    )

    return f"""<!DOCTYPE html>
<html lang="en" data-color-mode="{mode}" data-density="{dens}" data-direction="{dir_id}">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{blueprint.app_name} — {blueprint.product_tagline}</title>
  <style>
{tokens_css}

    :root {{
      --color-primary-foreground: var(--app-primary-fg);
      --color-focus-ring: var(--app-focus-ring);
      --shape-radius: var(--app-radius-card);
      --shape-border-width: 1px;
      --shape-shadow: var(--app-shadow-card);
      --density-pad: var(--app-pad-card);
      --density-gap: var(--app-gap-grid);
      --motion-duration: var(--app-motion-duration);
    }}
    *, *::before, *::after {{
      box-sizing: border-box;
    }}
    body {{
      margin: 0;
      min-height: 100vh;
      background-color: var(--color-surface);
      color: var(--color-text);
      font-family: var(--font-body);
      line-height: 1.5;
      -webkit-font-smoothing: antialiased;
    }}
    h1, h2, h3, h4 {{
      font-family: var(--font-heading);
      margin: 0;
      line-height: 1.2;
    }}
    code, pre, .mono {{
      font-family: var(--font-mono);
      font-variant-numeric: tabular-nums;
    }}
    button, input, select, textarea {{
      font-family: inherit;
      font-size: 0.875rem;
    }}
    .btn {{
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.45rem;
      padding: 0.55rem 1rem;
      border-radius: var(--shape-radius);
      font-weight: 600;
      cursor: pointer;
      transition: transform var(--motion-duration) ease, opacity var(--motion-duration) ease;
      border: var(--shape-border-width) solid transparent;
    }}
    .btn:focus-visible {{
      outline: 2px solid var(--color-focus-ring);
      outline-offset: 2px;
    }}
    .btn-primary {{
      background-color: var(--color-primary);
      color: var(--color-primary-foreground);
    }}
    .btn-secondary {{
      background-color: var(--color-surface-elevated);
      color: var(--color-text);
      border-color: var(--color-border);
    }}
    .btn-danger {{
      background-color: var(--color-danger);
      color: var(--color-primary-foreground);
    }}
    .surface-card {{
      background-color: var(--color-surface-elevated);
      border: var(--shape-border-width) solid var(--color-border);
      border-radius: var(--shape-radius);
      box-shadow: var(--shape-shadow);
      padding: var(--density-pad);
    }}
    .badge {{
      display: inline-flex;
      align-items: center;
      padding: 0.15rem 0.6rem;
      border-radius: var(--shape-radius);
      font-size: 0.75rem;
      font-weight: 600;
      border: 1px solid var(--color-border);
      background-color: var(--color-surface);
      color: var(--color-text);
    }}
    .badge-primary {{
      background-color: var(--color-primary);
      color: var(--color-primary-foreground);
      border-color: var(--color-primary);
    }}
    .badge-success {{
      background-color: var(--color-success);
      color: var(--color-primary-foreground);
      border-color: var(--color-success);
    }}
    .badge-warning {{
      background-color: var(--color-warning);
      color: var(--color-primary-foreground);
      border-color: var(--color-warning);
    }}
    .badge-danger {{
      background-color: var(--color-danger);
      color: var(--color-primary-foreground);
      border-color: var(--color-danger);
    }}
    .brand-lockup {{
      display: inline-flex;
      align-items: center;
      gap: 0.6rem;
      font-family: var(--font-heading);
      font-weight: 700;
      font-size: 1.05rem;
      color: var(--color-text);
    }}
    .brand-icon {{
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 34px;
      height: 34px;
      border-radius: var(--shape-radius);
      background-color: var(--color-primary);
      color: var(--color-primary-foreground);
    }}
    /* Shell layouts */
    .shell-sidebar {{
      display: grid;
      grid-template-columns: 260px 1fr;
      min-height: 100vh;
    }}
    .shell-sidebar-aside {{
      background-color: var(--color-surface-elevated);
      border-right: var(--shape-border-width) solid var(--color-border);
      padding: var(--density-pad);
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }}
    .shell-top-bar {{
      background-color: var(--color-surface-elevated);
      border-bottom: var(--shape-border-width) solid var(--color-border);
      padding: 0.85rem 1.5rem;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
    }}
    .shell-split {{
      display: grid;
      grid-template-columns: 300px 1fr;
      min-height: 100vh;
    }}
    .shell-bottom-bar {{
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      background-color: var(--color-surface-elevated);
      border-top: var(--shape-border-width) solid var(--color-border);
      display: flex;
      justify-content: space-around;
      padding: 0.6rem 1rem;
      z-index: 20;
    }}
    .nav-item {{
      display: inline-flex;
      align-items: center;
      gap: 0.55rem;
      padding: 0.55rem 0.85rem;
      border-radius: var(--shape-radius);
      font-weight: 600;
      font-size: 0.875rem;
      cursor: pointer;
      border: 1px solid transparent;
      background: transparent;
      color: var(--color-text-muted);
      text-align: left;
    }}
    .nav-item.active {{
      background-color: var(--color-primary);
      color: var(--color-primary-foreground);
    }}
    .main-container {{
      padding: 1.5rem 2rem 5rem 2rem;
      max-width: 1280px;
      width: 100%;
      margin: 0 auto;
    }}
    .page-header {{
      display: flex;
      flex-wrap: wrap;
      align-items: flex-end;
      justify-content: space-between;
      gap: 1rem;
      padding-bottom: 1rem;
      margin-bottom: 1.25rem;
      border-bottom: var(--shape-border-width) solid var(--color-border);
    }}
    .grid-cards {{
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(290px, 1fr));
      gap: var(--density-gap);
    }}
    .grid-stats {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
      gap: var(--density-gap);
      margin-bottom: 1.25rem;
    }}
    .grid-kanban {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: var(--density-gap);
    }}
    .data-table {{
      width: 100%;
      border-collapse: collapse;
      font-size: 0.875rem;
    }}
    .data-table th, .data-table td {{
      padding: 0.75rem 0.9rem;
      border-bottom: 1px solid var(--color-border);
      text-align: left;
    }}
    .data-table th {{
      color: var(--color-text-muted);
      font-weight: 600;
      background-color: var(--color-surface);
    }}
    .modal-backdrop {{
      position: fixed;
      inset: 0;
      background-color: rgba(10, 14, 23, 0.62);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1rem;
      z-index: 50;
    }}
    .modal-panel {{
      width: 100%;
      max-width: 480px;
    }}
    .form-field {{
      display: flex;
      flex-direction: column;
      gap: 0.35rem;
      margin-bottom: 0.85rem;
    }}
    .form-input {{
      padding: 0.55rem 0.75rem;
      border-radius: var(--shape-radius);
      border: var(--shape-border-width) solid var(--color-border);
      background-color: var(--color-surface);
      color: var(--color-text);
    }}
    .empty-box {{
      text-align: center;
      padding: 2.75rem 1.5rem;
      border-style: dashed;
    }}
    .gw-opt-footer {{
      padding: 0.75rem;
      text-align: center;
      font-size: 0.75rem;
      color: var(--color-text-muted);
      border-top: 1px solid var(--color-border);
    }}
  </style>
</head>
<body>
  <div id="app-mount"></div>
  {footer_html}

  <script>
    const PROJECT_ID = {json.dumps(project_id)};
    const BLUEPRINT = {bp_json};
    const DIRECTION = {dir_json};
    const SAMPLE_SEED = {seed_json};
    const BRAND_SVG = {json.dumps(brand_svg)};
    const STORAGE_KEY = "adaptive_app_records_" + PROJECT_ID;
    const NUM_TYPES = new Set(["currency", "float", "integer"]);

    let activePageId = BLUEPRINT.home_page_id;
    let isModalOpen = false;
    let searchFilter = "";
    let selectedDetailIdx = 0;
    let recordsByEntity = loadInitialRecords();
    let isTouched = false;

    function renderBrandLockup() {{
      return `
        <div class="brand-lockup">
          <span class="brand-icon">${{BRAND_SVG}}</span>
          <span>${{esc(BLUEPRINT.app_name)}}</span>
        </div>
      `;
    }}

    function loadInitialRecords() {{
      const params = new URLSearchParams(window.location.search);
      if (params.get("seed") === "1") {{
        return JSON.parse(JSON.stringify(SAMPLE_SEED));
      }}
      try {{
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {{
          return JSON.parse(saved);
        }}
      }} catch (err) {{
        // Ignore storage errors on restricted file:// origins
      }}
      const emptyState = {{}};
      for (const ent of BLUEPRINT.entities) {{
        emptyState[ent.name] = [];
      }}
      return emptyState;
    }}

    function persistRecords() {{
      try {{
        localStorage.setItem(STORAGE_KEY, JSON.stringify(recordsByEntity));
      }} catch (err) {{
        // Ignore storage errors
      }}
    }}

    function esc(val) {{
      return String(val === undefined || val === null ? "" : val)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
    }}

    function getActivePage() {{
      return BLUEPRINT.pages.find((p) => p.id === activePageId) || BLUEPRINT.pages[0];
    }}

    function getActiveEntity(page) {{
      const entName = (page.entities_used && page.entities_used[0]) || BLUEPRINT.entities[0].name;
      return BLUEPRINT.entities.find((e) => e.name === entName) || BLUEPRINT.entities[0];
    }}

    function renderEmptyState(page, entity) {{
      const es = page.empty_state;
      return `
        <div class="surface-card empty-box" data-testid="blueprint-empty-state">
          <div style="margin-bottom:0.65rem;">
            <span class="badge badge-primary">${{esc(entity.plural_label)}}</span>
          </div>
          <h2 style="font-size:1.35rem; margin-bottom:0.5rem;">${{esc(es.headline)}}</h2>
          <p style="color:var(--color-text-muted); max-width:520px; margin:0 auto 1.25rem auto;">
            ${{esc(es.body)}}
          </p>
          <div style="display:flex; justify-content:center; gap:0.75rem; flex-wrap:wrap;">
            <button
              class="btn btn-primary"
              data-testid="empty-state-create-btn"
              onclick="openCreateModal()"
            >
              + ${{esc(es.cta_label)}}
            </button>
            <button
              class="btn btn-secondary"
              data-testid="load-sample-seed-btn"
              onclick="loadSampleSeedData()"
            >
              Load Sample ${{esc(entity.plural_label)}}
            </button>
          </div>
        </div>
      `;
    }}

    function renderLayoutBody(page, entity, records) {{
      const layout = page.layout;
      const fields = entity.fields;
      const titleField = fields[0];
      const subtitleField = fields[1] || fields[0];
      const numField = fields.find((f) => NUM_TYPES.has(f.field_type));
      const boolField = fields.find((f) => f.field_type === "boolean");
      const enumField = fields.find((f) => f.field_type === "enum");

      if (records.length === 0 && layout !== "single_form" && layout !== "form_wizard") {{
        return renderEmptyState(page, entity);
      }}

      if (layout === "stat_tiles_with_charts") {{
        const totalVal = numField
          ? records.reduce((acc, r) => acc + (Number(r[numField.name]) || 0), 0)
          : records.length;
        const maxVal = Math.max(
          1,
          ...records.map((r) => (numField ? Number(r[numField.name]) || 1 : 1))
        );
        const metricLabel = numField ? numField.label : "Cumulative Metric";
        return `
          <div data-testid="layout-stat_tiles_with_charts">
            <div class="grid-stats">
              <div class="surface-card">
                <div style="font-size:0.78rem; color:var(--color-text-muted);">
                  Total ${{esc(entity.plural_label)}}
                </div>
                <div class="mono" style="font-size:1.75rem; font-weight:700; margin-top:0.25rem;">
                  ${{records.length}}
                </div>
              </div>
              <div class="surface-card">
                <div style="font-size:0.78rem; color:var(--color-text-muted);">
                  ${{esc(metricLabel)}}
                </div>
                <div class="mono" style="font-size:1.75rem; font-weight:700; margin-top:0.25rem;">
                  ${{totalVal.toLocaleString()}}
                </div>
              </div>
              <div class="surface-card">
                <div style="font-size:0.78rem; color:var(--color-text-muted);">
                  Active Archetype
                </div>
                <div style="font-size:1.1rem; font-weight:700; margin-top:0.45rem;">
                  ${{esc(BLUEPRINT.domain.product_kind)}}
                </div>
              </div>
            </div>
            <div class="surface-card">
              <h3 style="margin-bottom:0.85rem; font-size:1rem;">
                ${{esc(entity.plural_label)}} Distribution
              </h3>
              <div style="display:flex; flex-direction:column; gap:0.65rem;">
                ${{records.map((r) => {{
                  const val = numField ? Number(r[numField.name]) || 0 : 1;
                  const pct = Math.min(100, Math.max(10, Math.round((val / maxVal) * 100)));
                  const barTrack = [
                    "height:9px",
                    "background:var(--color-surface)",
                    "border:1px solid var(--color-border)",
                    "border-radius:var(--shape-radius)",
                    "overflow:hidden",
                  ].join(";");
                  return `
                    <div>
                      <div style="display:flex; justify-content:space-between; font-size:0.82rem;">
                        <span style="font-weight:600;">${{esc(r[titleField.name])}}</span>
                        <span class="mono">${{val.toLocaleString()}}</span>
                      </div>
                      <div style="${{barTrack}}">
                        <div style="height:100%; width:${{pct}}%; background:var(--color-primary);">
                        </div>
                      </div>
                    </div>
                  `;
                }}).join("")}}
              </div>
            </div>
          </div>
        `;
      }}

      if (layout === "checklist_today" || layout === "heatmap_streaks") {{
        const completedCount = boolField
          ? records.filter((r) => Boolean(r[boolField.name])).length
          : records.length;
        const pctConsistency = Math.round(
          (completedCount / Math.max(1, records.length)) * 100
        );
        const colStyle = "display:flex; flex-direction:column; gap:0.85rem;";
        const rowBetween = "display:flex; justify-content:space-between; align-items:center;";
        return `
          <div data-testid="layout-${{esc(layout)}}" style="${{colStyle}}">
            <div class="surface-card" style="${{rowBetween}}">
              <div>
                <div style="font-size:0.78rem; color:var(--color-text-muted);">
                  Daily Ritual Momentum
                </div>
                <h3 style="font-size:1.25rem; margin-top:0.15rem;">
                  ${{completedCount}} of ${{records.length}} ${{esc(entity.plural_label)}} Complete
                </h3>
              </div>
              <span class="badge badge-success">${{pctConsistency}}% Consistency</span>
            </div>
            ${{records.map((r, idx) => {{
              const isDone = boolField ? Boolean(r[boolField.name]) : false;
              const streakVal = numField ? Number(r[numField.name]) || 1 : idx + 3;
              const bfName = boolField ? boolField.name : "completed";
              const strike = isDone ? "text-decoration:line-through; opacity:0.72;" : "";
              const pips = Array.from({{ length: 7 }}).map((_, d) => {{
                const bg = d < (streakVal % 8) ? "var(--color-primary)" : "var(--color-surface)";
                const pipStyle = [
                  "width:14px",
                  "height:14px",
                  "border-radius:3px",
                  "border:1px solid var(--color-border)",
                  "background:" + bg,
                ].join(";");
                return `<span style="${{pipStyle}}"></span>`;
              }}).join("");
              return `
                <div class="surface-card" style="${{rowBetween}} gap:1rem;">
                  <div style="display:flex; align-items:center; gap:0.85rem;">
                    <input
                      type="checkbox"
                      ${{isDone ? "checked" : ""}}
                      onchange="toggleBooleanField('${{esc(r.id)}}', '${{esc(bfName)}}')"
                      style="width:1.2rem; height:1.2rem; cursor:pointer;"
                    />
                    <div>
                      <div style="font-weight:700; ${{strike}}">
                        ${{esc(r[titleField.name])}}
                      </div>
                      <div style="font-size:0.8rem; color:var(--color-text-muted);">
                        ${{esc(r[subtitleField.name])}}
                      </div>
                    </div>
                  </div>
                  <div style="display:flex; align-items:center; gap:0.45rem;">
                    ${{pips}}
                    <span class="badge badge-primary mono">${{streakVal}}d streak</span>
                  </div>
                </div>
              `;
            }}).join("")}}
          </div>
        `;
      }}

      if (layout === "log_stream") {{
        const hdrStyle = [
          "display:flex",
          "justify-content:space-between",
          "align-items:center",
          "padding-bottom:0.75rem",
          "margin-bottom:0.75rem",
          "border-bottom:1px solid var(--color-border)",
        ].join(";");
        const rowStyle = [
          "display:flex",
          "align-items:center",
          "justify-content:space-between",
          "gap:0.75rem",
          "padding:0.55rem 0.75rem",
          "background:var(--color-surface)",
          "border:1px solid var(--color-border)",
          "border-radius:var(--shape-radius)",
          "font-size:0.8rem",
        ].join(";");
        return `
          <div class="surface-card mono" data-testid="layout-log_stream">
            <div style="${{hdrStyle}}">
              <span style="font-weight:700; font-size:0.82rem;">
                LIVE STREAM // ${{esc(entity.plural_label.toUpperCase())}}
              </span>
              <span class="badge badge-primary">${{records.length}} EVENTS</span>
            </div>
            <div style="display:flex; flex-direction:column; gap:0.45rem;">
              ${{records.map((r) => {{
                const sev = String(enumField ? r[enumField.name] : "INFO").toUpperCase();
                const badgeCls = sev.includes("CRIT") || sev.includes("ERR")
                  ? "badge-danger"
                  : sev.includes("WARN") || sev.includes("HIGH")
                    ? "badge-warning"
                    : "badge-primary";
                const metaText = fields.slice(1).map((f) => esc(r[f.name])).join(" · ");
                return `
                  <div style="${{rowStyle}}">
                    <div style="display:flex; align-items:center; gap:0.65rem; flex-wrap:wrap;">
                      <span class="badge ${{badgeCls}}">${{esc(sev)}}</span>
                      <span style="color:var(--color-text-muted);">
                        ${{esc(r[titleField.name])}}
                      </span>
                      <span style="font-weight:600;">${{metaText}}</span>
                    </div>
                    <button
                      class="btn btn-secondary"
                      style="padding:0.2rem 0.55rem; font-size:0.72rem;"
                      onclick="deleteRecord('${{esc(r.id)}}')"
                    >
                      Ack
                    </button>
                  </div>
                `;
              }}).join("")}}
            </div>
          </div>
        `;
      }}

      if (layout === "calendar_week_agenda" || layout === "calendar_month") {{
        const cardStyle = [
          "display:flex",
          "flex-direction:column",
          "justify-content:space-between",
          "gap:0.75rem",
        ].join(";");
        return `
          <div data-testid="layout-${{esc(layout)}}">
            <div class="grid-cards">
              ${{records.map((r) => {{
                const priceTag = numField
                  ? `<span class="mono" style="font-weight:700;">$`
                    + Number(r[numField.name] || 0).toFixed(2)
                    + `</span>`
                  : "";
                const extraRows = fields.slice(2).map(
                  (f) => `<div><strong>${{esc(f.label)}}:</strong> ${{esc(r[f.name])}}</div>`
                ).join("");
                return `
                  <div class="surface-card" style="${{cardStyle}}">
                    <div>
                      <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
                        <span class="badge badge-primary mono">
                          ${{esc(r[subtitleField.name])}}
                        </span>
                        ${{priceTag}}
                      </div>
                      <h3 style="font-size:1.05rem; margin-bottom:0.35rem;">
                        ${{esc(r[titleField.name])}}
                      </h3>
                      <div style="font-size:0.82rem; color:var(--color-text-muted);">
                        ${{extraRows}}
                      </div>
                    </div>
                    <div style="display:flex; justify-content:flex-end;">
                      <button class="btn btn-secondary" onclick="deleteRecord('${{esc(r.id)}}')">
                        Cancel Slot
                      </button>
                    </div>
                  </div>
                `;
              }}).join("")}}
            </div>
          </div>
        `;
      }}

      if (layout === "kanban_board") {{
        const lanes = enumField && enumField.enum_values && enumField.enum_values.length > 0
          ? enumField.enum_values
          : ["Backlog", "Active", "Completed"];
        return `
          <div class="grid-kanban" data-testid="layout-kanban_board">
            ${{lanes.map((lane) => {{
              const laneItems = enumField
                ? records.filter((r) => String(r[enumField.name]) === lane)
                : records;
              return `
                <div class="surface-card" style="background:var(--color-surface);">
                  <div style="display:flex; justify-content:space-between; margin-bottom:0.75rem;">
                    <h3 style="font-size:0.92rem;">${{esc(lane)}}</h3>
                    <span class="badge badge-primary">${{laneItems.length}}</span>
                  </div>
                  <div style="display:flex; flex-direction:column; gap:0.6rem;">
                    ${{laneItems.map((r) => {{
                      const subMeta = fields.slice(1, 4).map(
                        (f) => `${{esc(f.label)}}: ${{esc(r[f.name])}}`
                      ).join(" · ");
                      return `
                        <div class="surface-card">
                          <div style="font-weight:700; font-size:0.9rem; margin-bottom:0.25rem;">
                            ${{esc(r[titleField.name])}}
                          </div>
                          <div style="font-size:0.78rem; color:var(--color-text-muted);">
                            ${{subMeta}}
                          </div>
                        </div>
                      `;
                    }}).join("")}}
                  </div>
                </div>
              `;
            }}).join("")}}
          </div>
        `;
      }}

      if (layout === "master_detail") {{
        const activeRec = records[selectedDetailIdx] || records[0];
        const splitGrid = "display:grid; grid-template-columns: 320px 1fr; gap:var(--density-gap);";
        const detailHdr = [
          "display:flex",
          "justify-content:space-between",
          "align-items:flex-start",
          "margin-bottom:1rem",
          "padding-bottom:0.75rem",
          "border-bottom:1px solid var(--color-border)",
        ].join(";");
        const cellStyle = [
          "padding:0.75rem",
          "background:var(--color-surface)",
          "border:1px solid var(--color-border)",
          "border-radius:var(--shape-radius)",
        ].join(";");
        return `
          <div data-testid="layout-master_detail" style="${{splitGrid}}">
            <div class="surface-card" style="display:flex; flex-direction:column; gap:0.45rem;">
              <div style="font-size:0.78rem; font-weight:700; color:var(--color-text-muted);">
                ${{esc(entity.plural_label.toUpperCase())}} (${{records.length}})
              </div>
              ${{records.map((r, idx) => `
                <button
                  class="nav-item ${{idx === selectedDetailIdx ? "active" : ""}}"
                  style="width:100%; justify-content:space-between;"
                  onclick="selectDetail(${{idx}})"
                >
                  <span>${{esc(r[titleField.name])}}</span>
                  <span class="mono" style="font-size:0.75rem;">
                    ${{esc(r[subtitleField.name])}}
                  </span>
                </button>
              `).join("")}}
            </div>
            <div class="surface-card">
              <div style="${{detailHdr}}">
                <div>
                  <span class="badge badge-primary">${{esc(entity.singular_label)}} Inspector</span>
                  <h3 style="font-size:1.35rem; margin-top:0.35rem;">
                    ${{esc(activeRec[titleField.name])}}
                  </h3>
                </div>
                <button class="btn btn-danger" onclick="deleteRecord('${{esc(activeRec.id)}}')">
                  Remove
                </button>
              </div>
              <div class="grid-stats">
                ${{fields.map((f) => `
                  <div style="${{cellStyle}}">
                    <div style="font-size:0.74rem; color:var(--color-text-muted);">
                      ${{esc(f.label)}}
                    </div>
                    <div class="mono" style="font-weight:700; font-size:0.95rem; margin-top:4px;">
                      ${{esc(activeRec[f.name])}}
                    </div>
                  </div>
                `).join("")}}
              </div>
            </div>
          </div>
        `;
      }}

      if (layout === "timeline" || layout === "feed" || layout === "leaderboard") {{
        const cardLeftBorder = [
          "display:flex",
          "justify-content:space-between",
          "align-items:flex-start",
          "gap:1rem",
          "border-left:4px solid var(--color-primary)",
        ].join(";");
        return `
          <div
            data-testid="layout-${{esc(layout)}}"
            style="display:flex; flex-direction:column; gap:0.85rem;"
          >
            ${{records.map((r, idx) => {{
              const extraMeta = fields.slice(2).map(
                (f) => `<span><strong>${{esc(f.label)}}:</strong> ${{esc(r[f.name])}}</span>`
              ).join(" · ");
              return `
                <div class="surface-card" style="${{cardLeftBorder}}">
                  <div>
                    <div style="display:flex; align-items:center; gap:0.5rem; margin-bottom:4px;">
                      <span class="badge badge-primary mono">#${{idx + 1}}</span>
                      <span style="font-size:0.8rem; color:var(--color-text-muted);">
                        ${{esc(r[subtitleField.name])}}
                      </span>
                    </div>
                    <h3 style="font-size:1.1rem; margin-bottom:0.35rem;">
                      ${{esc(r[titleField.name])}}
                    </h3>
                    <div style="display:flex; flex-wrap:wrap; gap:0.75rem; font-size:0.84rem;">
                      ${{extraMeta}}
                    </div>
                  </div>
                  <button class="btn btn-secondary" onclick="deleteRecord('${{esc(r.id)}}')">
                    Archive
                  </button>
                </div>
              `;
            }}).join("")}}
          </div>
        `;
      }}

      if (layout === "report_document") {{
        const docHdr = [
          "display:flex",
          "justify-content:space-between",
          "align-items:flex-start",
          "padding-bottom:1rem",
          "margin-bottom:1rem",
          "border-bottom:2px solid var(--color-border)",
        ].join(";");
        return `
          <div
            data-testid="layout-report_document"
            style="display:flex; flex-direction:column; gap:1rem;"
          >
            ${{records.map((r) => `
              <article class="surface-card" style="padding:1.75rem;">
                <div style="${{docHdr}}">
                  <div>
                    <div style="font-size:0.75rem; text-transform:uppercase; letter-spacing:.08em;">
                      Official ${{esc(entity.singular_label)}} Statement
                    </div>
                    <h3 style="font-size:1.4rem; margin-top:0.25rem;">
                      ${{esc(r[titleField.name])}}
                    </h3>
                  </div>
                  <span class="badge badge-primary mono">${{esc(r[subtitleField.name])}}</span>
                </div>
                <div class="grid-stats">
                  ${{fields.map((f) => `
                    <div>
                      <div style="font-size:0.75rem; color:var(--color-text-muted);">
                        ${{esc(f.label)}}
                      </div>
                      <div class="mono" style="font-weight:700; font-size:0.95rem;">
                        ${{esc(r[f.name])}}
                      </div>
                    </div>
                  `).join("")}}
                </div>
              </article>
            `).join("")}}
          </div>
        `;
      }}

      if (layout === "data_table_with_filters") {{
        const filtered = records.filter((r) =>
          !searchFilter || JSON.stringify(r).toLowerCase().includes(searchFilter.toLowerCase())
        );
        const barStyle = [
          "display:flex",
          "justify-content:space-between",
          "align-items:center",
          "margin-bottom:0.85rem",
          "gap:1rem",
        ].join(";");
        return `
          <div class="surface-card" data-testid="layout-data_table_with_filters">
            <div style="${{barStyle}}">
              <input
                class="form-input"
                style="max-width:320px; width:100%;"
                placeholder="Filter ${{esc(entity.plural_label)}}..."
                value="${{esc(searchFilter)}}"
                oninput="updateSearch(this.value)"
              />
              <span class="badge">${{filtered.length}} records</span>
            </div>
            <div style="overflow-x:auto;">
              <table class="data-table">
                <thead>
                  <tr>
                    ${{fields.map((f) => `<th>${{esc(f.label)}}</th>`).join("")}}
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  ${{filtered.map((r) => {{
                    const cells = fields.map((f) => {{
                      const cls = NUM_TYPES.has(f.field_type) ? "mono" : "";
                      return `<td class="${{cls}}">${{esc(r[f.name])}}</td>`;
                    }}).join("");
                    return `
                      <tr>
                        ${{cells}}
                        <td>
                          <button
                            class="btn btn-secondary"
                            style="padding:0.25rem 0.6rem; font-size:0.75rem;"
                            onclick="deleteRecord('${{esc(r.id)}}')"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    `;
                  }}).join("")}}
                </tbody>
              </table>
            </div>
          </div>
        `;
      }}

      // Default card_grid / map_or_location_list / form layouts
      const defCardStyle = [
        "display:flex",
        "flex-direction:column",
        "justify-content:space-between",
        "gap:0.85rem",
      ].join(";");
      return `
        <div class="grid-cards" data-testid="layout-${{esc(layout)}}">
          ${{records.map((r) => {{
            const subRows = fields.slice(2).map(
              (f) => `<div><strong>${{esc(f.label)}}:</strong> ${{esc(r[f.name])}}</div>`
            ).join("");
            return `
              <div class="surface-card" style="${{defCardStyle}}">
                <div>
                  <div style="display:flex; justify-content:space-between; margin-bottom:0.4rem;">
                    <span class="badge badge-primary">${{esc(r[subtitleField.name])}}</span>
                  </div>
                  <h3 style="font-size:1.1rem; margin-bottom:0.4rem;">
                    ${{esc(r[titleField.name])}}
                  </h3>
                  <div style="font-size:0.83rem; color:var(--color-text-muted);">
                    ${{subRows}}
                  </div>
                </div>
                <div style="display:flex; justify-content:flex-end;">
                  <button class="btn btn-secondary" onclick="deleteRecord('${{esc(r.id)}}')">
                    Remove
                  </button>
                </div>
              </div>
            `;
          }}).join("")}}
        </div>
      `;
    }}

    function renderModal(entity) {{
      if (!isModalOpen) return "";
      const hdrStyle = [
        "display:flex",
        "justify-content:space-between",
        "align-items:center",
        "margin-bottom:1rem",
      ].join(";");
      return `
        <div class="modal-backdrop" data-testid="create-entity-modal">
          <div class="surface-card modal-panel">
            <div style="${{hdrStyle}}">
              <h3 style="font-size:1.15rem;">New ${{esc(entity.singular_label)}}</h3>
              <button class="btn btn-secondary" onclick="closeCreateModal()">Close</button>
            </div>
            <form onsubmit="submitCreateForm(event)">
              ${{entity.fields.map((fld) => {{
                if (fld.field_type === "enum" && fld.enum_values && fld.enum_values.length > 0) {{
                  const opts = fld.enum_values.map(
                    (v) => `<option value="${{esc(v)}}">${{esc(v)}}</option>`
                  ).join("");
                  return `
                    <div class="form-field">
                      <label style="font-weight:600; font-size:0.8rem;">${{esc(fld.label)}}</label>
                      <select class="form-input" name="${{esc(fld.name)}}">
                        ${{opts}}
                      </select>
                    </div>
                  `;
                }}
                const inputType = NUM_TYPES.has(fld.field_type)
                  ? "number"
                  : fld.field_type === "date"
                    ? "date"
                    : "text";
                return `
                  <div class="form-field">
                    <label style="font-weight:600; font-size:0.8rem;">${{esc(fld.label)}}</label>
                    <input
                      class="form-input"
                      name="${{esc(fld.name)}}"
                      type="${{inputType}}"
                      step="any"
                      required="${{fld.required ? "required" : ""}}"
                      placeholder="Enter ${{esc(fld.label)}}"
                    />
                  </div>
                `;
              }}).join("")}}
              <div style="display:flex; justify-content:flex-end; gap:0.6rem; margin-top:1rem;">
                <button type="button" class="btn btn-secondary" onclick="closeCreateModal()">
                  Cancel
                </button>
                <button type="submit" class="btn btn-primary" data-testid="submit-entity-btn">
                  Save ${{esc(entity.singular_label)}}
                </button>
              </div>
            </form>
          </div>
        </div>
      `;
    }}

    function renderApp() {{
      const page = getActivePage();
      const entity = getActiveEntity(page);
      const records = recordsByEntity[entity.name] || [];
      const navPattern = BLUEPRINT.navigation.pattern;
      const primaryCta =
        (page.primary_actions && page.primary_actions[0]) || ("New " + entity.singular_label);

      const navButtons = BLUEPRINT.navigation.items.map((item) => `
        <button
          class="nav-item ${{item.page_id === page.id ? "active" : ""}}"
          data-testid="nav-item-${{esc(item.page_id)}}"
          onclick="selectPage('${{esc(item.page_id)}}')"
        >
          <span>${{esc(item.label)}}</span>
        </button>
      `).join("");

      const seedBtn = records.length === 0
        ? `<button class="btn btn-secondary" onclick="loadSampleSeedData()">`
          + `Load Sample Data</button>`
        : "";

      const dataModeBadge = isTouched
        ? `<span class="badge badge-success" data-testid="data-mode-badge">Live Data</span>`
        : (records.length > 0 ? `<span class="badge badge-warning" data-testid="data-mode-badge">Demo Seed Data</span>` : "");

      const exportBtn = records.length > 0
        ? `<button class="btn btn-secondary" onclick="exportWorkspaceData()" data-testid="export-data-btn">Export Data</button>`
        : "";

      const mainContent = `
        <main class="main-container">
          <header class="page-header">
            <div>
              <div style="font-size:0.75rem; text-transform:uppercase; letter-spacing:0.06em;">
                ${{esc(BLUEPRINT.product_tagline)}}
              </div>
              <h1 style="font-size:1.65rem; margin-top:0.2rem;">${{esc(page.title)}}</h1>
            </div>
            <div style="display:flex; gap:0.6rem; align-items:center;">
              ${{dataModeBadge}}
              ${{seedBtn}}
              ${{exportBtn}}
              <button
                class="btn btn-primary"
                data-testid="header-primary-action-btn"
                onclick="openCreateModal()"
              >
                + ${{esc(primaryCta)}}
              </button>
            </div>
          </header>
          ${{renderLayoutBody(page, entity, records)}}
        </main>
      `;

      const brandHtml = renderBrandLockup();
      let shellHtml = "";
      if (navPattern === "sidebar") {{
        shellHtml = `
          <div class="shell-sidebar" data-testid="shell-sidebar">
            <aside class="shell-sidebar-aside">
              <div>
                <div style="margin-bottom:1.5rem;">${{brandHtml}}</div>
                <nav style="display:flex; flex-direction:column; gap:0.35rem;">${{navButtons}}</nav>
              </div>
              <div style="font-size:0.75rem; color:var(--color-text-muted);">
                ${{esc(BLUEPRINT.domain.product_kind)}}
              </div>
            </aside>
            <div>${{mainContent}}</div>
          </div>
        `;
      }} else if (navPattern === "split_master_detail") {{
        shellHtml = `
          <div class="shell-split" data-testid="shell-split_master_detail">
            <aside class="shell-sidebar-aside">
              <div>
                <div style="margin-bottom:1.25rem;">${{brandHtml}}</div>
                <div style="font-size:0.74rem; color:var(--color-text-muted); margin-bottom:10px;">
                  WORKSPACE VIEWS
                </div>
                <nav style="display:flex; flex-direction:column; gap:0.35rem;">${{navButtons}}</nav>
              </div>
              <div style="font-size:0.75rem; color:var(--color-text-muted);">
                ${{esc(entity.plural_label)}}: ${{records.length}}
              </div>
            </aside>
            <div>${{mainContent}}</div>
          </div>
        `;
      }} else if (navPattern === "bottom_tabs") {{
        shellHtml = `
          <div data-testid="shell-bottom_tabs">
            <header class="shell-top-bar">
              <div>${{brandHtml}}</div>
              <span class="badge badge-primary">${{esc(BLUEPRINT.domain.tone)}}</span>
            </header>
            ${{mainContent}}
            <nav class="shell-bottom-bar">${{navButtons}}</nav>
          </div>
        `;
      }} else if (navPattern === "command_palette_plus_minimal_top") {{
        shellHtml = `
          <div data-testid="shell-command_palette_plus_minimal_top">
            <header class="shell-top-bar">
              <div style="display:flex; align-items:center; gap:1rem;">
                <div>${{brandHtml}}</div>
                <span class="badge mono">CMD+K // ${{esc(page.route)}}</span>
              </div>
              <nav style="display:flex; gap:0.4rem; flex-wrap:wrap;">${{navButtons}}</nav>
            </header>
            ${{mainContent}}
          </div>
        `;
      }} else {{
        shellHtml = `
          <div data-testid="shell-top_tabs">
            <header class="shell-top-bar">
              <div>${{brandHtml}}</div>
              <nav style="display:flex; gap:0.4rem; flex-wrap:wrap;">${{navButtons}}</nav>
            </header>
            ${{mainContent}}
          </div>
        `;
      }}

      document.getElementById("app-mount").innerHTML = shellHtml + renderModal(entity);
    }}

    window.selectPage = function(pageId) {{
      activePageId = pageId;
      selectedDetailIdx = 0;
      renderApp();
    }};

    window.selectDetail = function(idx) {{
      selectedDetailIdx = idx;
      renderApp();
    }};

    window.updateSearch = function(val) {{
      searchFilter = val;
      renderApp();
    }};

    window.openCreateModal = function() {{
      isModalOpen = true;
      renderApp();
    }};

    window.closeCreateModal = function() {{
      isModalOpen = false;
      renderApp();
    }};

    window.loadSampleSeedData = function() {{
      recordsByEntity = JSON.parse(JSON.stringify(SAMPLE_SEED));
      persistRecords();
      renderApp();
    }};

    window.exportWorkspaceData = function() {{
      const jsonStr = JSON.stringify(recordsByEntity, null, 2);
      const blob = new Blob([jsonStr], {{ type: "application/json" }});
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = (BLUEPRINT.app_name.toLowerCase().replace(/[^a-z0-9]/g, "_")) + "_export.json";
      a.click();
      URL.revokeObjectURL(url);
    }};

    window.deleteRecord = function(recordId) {{
      isTouched = true;
      const page = getActivePage();
      const entity = getActiveEntity(page);
      recordsByEntity[entity.name] = (recordsByEntity[entity.name] || []).filter(
        (r) => String(r.id) !== String(recordId)
      );
      persistRecords();
      renderApp();
    }};

    window.toggleBooleanField = function(recordId, fieldName) {{
      isTouched = true;
      const page = getActivePage();
      const entity = getActiveEntity(page);
      recordsByEntity[entity.name] = (recordsByEntity[entity.name] || []).map((r) =>
        String(r.id) === String(recordId)
          ? Object.assign({{}}, r, {{ [fieldName]: !r[fieldName] }})
          : r
      );
      persistRecords();
      renderApp();
    }};

    window.submitCreateForm = function(ev) {{
      ev.preventDefault();
      isTouched = true;
      const page = getActivePage();
      const entity = getActiveEntity(page);
      const formData = new FormData(ev.target);
      const newRec = {{ id: entity.name + "-" + Date.now() }};
      for (const fld of entity.fields) {{
        const raw = formData.get(fld.name);
        if (NUM_TYPES.has(fld.field_type)) {{
          newRec[fld.name] = Number(raw || 0);
        }} else if (fld.field_type === "boolean") {{
          newRec[fld.name] = Boolean(raw);
        }} else {{
          newRec[fld.name] = String(raw || "");
        }}
      }}
      recordsByEntity[entity.name] = [newRec].concat(recordsByEntity[entity.name] || []);
      isModalOpen = false;
      persistRecords();
      renderApp();
    }};

    renderApp();
  </script>
</body>
</html>
"""
