import csv
import hashlib
import io
import json
from typing import Any

WORKFLOW_SPEC = __WORKFLOW_SPEC_JSON__


class EmbeddedWorkflowEngine:
    @staticmethod
    def execute(csv_data: str) -> dict[str, Any]:
        reader = csv.DictReader(io.StringIO(csv_data))
        raw_rows = list(reader)
        valid_rows = []
        rejected_rows = []

        for idx, row in enumerate(raw_rows):
            date = row.get("date", "").strip()
            amt_str = row.get("amount", "").strip()
            cat = row.get("category", "").strip()
            if not date or not amt_str:
                rejected_rows.append({
                    "row_index": idx + 1,
                    "reason": "Missing required date or amount",
                    "data": row,
                })
                continue
            try:
                amt = float(amt_str.replace("$", "").replace(",", ""))
                if amt <= 0:
                    rejected_rows.append({
                        "row_index": idx + 1,
                        "reason": "Amount must be strictly positive (> 0)",
                        "data": row,
                    })
                    continue
                valid_rows.append({"date": date, "amount": amt, "category": cat})
            except ValueError:
                rejected_rows.append({
                    "row_index": idx + 1,
                    "reason": f"Invalid numeric amount format: {amt_str}",
                    "data": row,
                })

        monthly = {}
        for r in valid_rows:
            month = r["date"][:7]
            if month not in monthly:
                monthly[month] = {"month": month, "total_amount": 0.0, "record_count": 0}
            monthly[month]["total_amount"] += r["amount"]
            monthly[month]["record_count"] += 1

        monthly_list = sorted(monthly.values(), key=lambda x: x["month"])
        for m in monthly_list:
            m["total_amount"] = round(m["total_amount"], 2)

        total_revenue = round(sum(m["total_amount"] for m in monthly_list), 2)
        out_bytes = json.dumps(monthly_list, sort_keys=True).encode("utf-8")
        out_hash = hashlib.sha256(out_bytes).hexdigest()

        return {
            "status": "success",
            "total_rows_in": len(raw_rows),
            "valid_count": len(valid_rows),
            "rejected_count": len(rejected_rows),
            "total_revenue": total_revenue,
            "monthly_breakdown": monthly_list,
            "rejected_rows": rejected_rows,
            "output_hash": out_hash,
        }
