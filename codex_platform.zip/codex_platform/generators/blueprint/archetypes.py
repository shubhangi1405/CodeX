"""Canonical domain analyses, blueprints, design directions, and seed data for 8+ domains."""

from typing import Any

from pydantic import BaseModel

from generators.blueprint.schemas import (
    AppBlueprint,
    AudienceProfile,
    AutomationRef,
    DataShape,
    DomainAnalysis,
    EmptyStateSpec,
    EntitySpec,
    FieldSpec,
    FieldType,
    LayoutArchetype,
    NavigationSpec,
    NavItemSpec,
    NavPattern,
    PageSpec,
    ProductArchetype,
    RelationshipSpec,
)
from generators.design.contrast import validate_and_adjust_palette
from generators.design.directions import apply_bounded_adjustments, get_curated_direction
from generators.design.schemas import (
    ColorMode,
    DensityClass,
    DesignDirection,
    RadiusClass,
)


class BenchmarkArchetypeBundle(BaseModel):
    benchmark_key: str
    benchmark_prompt: str
    domain_analysis: DomainAnalysis
    blueprint: AppBlueprint
    primary_direction: DesignDirection
    direction_proposals: list[DesignDirection]
    sample_seed_data: dict[str, list[dict[str, Any]]]


def _customize_direction(
    direction_id: str,
    primary_hex: str,
    monogram: str,
    rationale: str,
    radius_override: RadiusClass | None = None,
    density_override: DensityClass | None = None,
    color_mode_override: ColorMode | None = None,
) -> DesignDirection:
    base = get_curated_direction(direction_id)
    palette = base.palette.model_copy(
        update={
            "primary": primary_hex,
            "focus_ring": primary_hex,
        }
    )
    adjusted_palette, _, _ = validate_and_adjust_palette(palette)
    updated = base.model_copy(
        update={
            "palette": adjusted_palette,
        }
    )
    return apply_bounded_adjustments(
        updated,
        hue_shift_deg=0.0,
        radius_override=radius_override,
        density_override=density_override,
        color_mode_override=color_mode_override,
        monogram_override=monogram,
        rationale_override=rationale,
    )


def _build_csv_monthly_totals_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="Tabular File Ingestion & Monthly Revenue Reconciliation",
        archetype=ProductArchetype.ANALYTICS_DASHBOARD,
        audience=AudienceProfile(
            who="Finance analysts and revenue operations controllers",
            context_of_use="Desktop reconciliation workstation during monthly close",
            device_likely_used="desktop",
            tech_comfort="high",
        ),
        core_jobs=[
            "Review monthly aggregated revenue totals and batch KPIs",
            "Import tabular transaction batches and inspect validation rules",
            "Audit rejected transaction rows for missing dates or negative amounts",
        ],
        primary_object="transaction_batch",
        tone="analytical",
        data_shape=DataShape.TABULAR,
        needs_automation=True,
        rationale=(
            "This product is explicitly an automated tabular CSV ingestion and monthly "
            "aggregation pipeline for finance analysts who need high-density KPI charts "
            "and deterministic batch validation."
        ),
    )

    blueprint = AppBlueprint(
        app_name="LedgerFlow Monthly Totals",
        product_tagline=(
            "Deterministic CSV batch ingestion, validation, and monthly revenue aggregation"
        ),
        domain=domain,
        entities=[
            EntitySpec(
                name="transaction_batch",
                singular_label="Transaction Batch",
                plural_label="Transaction Batches",
                fields=[
                    FieldSpec(
                        name="batch_code",
                        label="Batch Code",
                        field_type=FieldType.STRING,
                        required=True,
                        unique=True,
                    ),
                    FieldSpec(
                        name="reporting_month",
                        label="Reporting Month",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="source_csv_file",
                        label="Source CSV File",
                        field_type=FieldType.FILE_INGEST,
                        required=True,
                    ),
                    FieldSpec(
                        name="total_amount",
                        label="Total Verified Revenue",
                        field_type=FieldType.CURRENCY,
                        required=True,
                    ),
                    FieldSpec(
                        name="valid_rows",
                        label="Valid Rows",
                        field_type=FieldType.INTEGER,
                        required=True,
                    ),
                    FieldSpec(
                        name="status",
                        label="Reconciliation Status",
                        field_type=FieldType.ENUM,
                        enum_values=["Verified", "Pending Review", "Quarantined"],
                    ),
                ],
            ),
            EntitySpec(
                name="rejected_record",
                singular_label="Rejected Record",
                plural_label="Rejected Records",
                fields=[
                    FieldSpec(
                        name="row_number",
                        label="CSV Row Number",
                        field_type=FieldType.INTEGER,
                        required=True,
                    ),
                    FieldSpec(
                        name="rejection_reason",
                        label="Validation Rule Failure",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="raw_payload",
                        label="Raw Row Values",
                        field_type=FieldType.TEXT,
                        required=True,
                    ),
                    FieldSpec(
                        name="batch_id",
                        label="Parent Batch",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                ],
                relationships=[
                    RelationshipSpec(
                        target_entity="transaction_batch",
                        kind="many_to_one",
                        foreign_key="batch_id",
                    )
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="monthly-kpis",
                title="Monthly Revenue KPIs",
                route="/monthly-kpis",
                layout=LayoutArchetype.STAT_TILES_WITH_CHARTS,
                entities_used=["transaction_batch"],
                primary_actions=["Import CSV Batch", "Export Reconciled Summary"],
                empty_state=EmptyStateSpec(
                    headline="No Monthly Transaction Batches Reconciled Yet",
                    body=(
                        "Import your first CSV transaction batch to compute verified monthly "
                        "revenue totals and inspect row-level validation metrics."
                    ),
                    cta_label="Import First CSV Batch",
                    cta_action_id="create_transaction_batch",
                ),
            ),
            PageSpec(
                id="batch-ledger",
                title="Batch Ledger Table",
                route="/batch-ledger",
                layout=LayoutArchetype.DATA_TABLE_WITH_FILTERS,
                entities_used=["transaction_batch"],
                primary_actions=["Filter by Reporting Month", "Import CSV Batch"],
                empty_state=EmptyStateSpec(
                    headline="Ledger Table Is Empty",
                    body="Add a transaction batch record to inspect monthly reconciliation rows.",
                    cta_label="Add Batch Record",
                    cta_action_id="create_transaction_batch",
                ),
            ),
            PageSpec(
                id="rejected-quarantine",
                title="Rejected Row Quarantine",
                route="/rejected-quarantine",
                layout=LayoutArchetype.DATA_TABLE_WITH_FILTERS,
                entities_used=["rejected_record"],
                primary_actions=["Log Quarantined Row", "Clear Resolved Exceptions"],
                empty_state=EmptyStateSpec(
                    headline="Zero Quarantined Rows",
                    body="All imported CSV rows passed required-field and numeric type validation.",
                    cta_label="Log Exception Sample",
                    cta_action_id="create_rejected_record",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.TOP_TABS,
            items=[
                NavItemSpec(
                    page_id="monthly-kpis",
                    label="Monthly Revenue KPIs",
                    icon="bar-chart-2",
                ),
                NavItemSpec(
                    page_id="batch-ledger",
                    label="Batch Ledger Table",
                    icon="upload",
                ),
                NavItemSpec(
                    page_id="rejected-quarantine",
                    label="Rejected Quarantine",
                    icon="alert-triangle",
                ),
            ],
        ),
        home_page_id="monthly-kpis",
        automations=[
            AutomationRef(
                id="auto-monthly-csv",
                name="CSV Validation & Monthly Aggregation Pipeline",
                workflow_id="wf-canonical-csv",
                trigger_entity="transaction_batch",
            )
        ],
    )

    primary = _customize_direction(
        direction_id="ledger_precision",
        primary_hex="#0F3D5E",  # Hue ~205 deg -> bucket 6
        monogram="LF",
        rationale=(
            "Finance analysts reconciling monthly CSV exports work in bright spreadsheets "
            "and need IBM Plex Sans tabular numerals, compact tables, and deep navy contrast."
        ),
        radius_override=RadiusClass.SHARP,
        density_override=DensityClass.COMPACT,
        color_mode_override=ColorMode.LIGHT,
    )
    alt1 = _customize_direction(
        direction_id="civic_formal",
        primary_hex="#1E3A8A",
        monogram="LF",
        rationale="Formal institutional hierarchy for audited monthly financial reports.",
    )
    alt2 = _customize_direction(
        direction_id="console_dark",
        primary_hex="#38BDF8",
        monogram="LF",
        rationale="High-contrast dark terminal view for continuous batch ingestion monitoring.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "transaction_batch": [
            {
                "id": "batch-2026-01",
                "batch_code": "BATCH-2026-01-NA",
                "reporting_month": "2026-01",
                "source_csv_file": "january_NorthAmerica_ledger.csv",
                "total_amount": 48290.50,
                "valid_rows": 312,
                "status": "Verified",
            },
            {
                "id": "batch-2026-02",
                "batch_code": "BATCH-2026-02-NA",
                "reporting_month": "2026-02",
                "source_csv_file": "february_NorthAmerica_ledger.csv",
                "total_amount": 53910.00,
                "valid_rows": 348,
                "status": "Verified",
            },
            {
                "id": "batch-2026-03",
                "batch_code": "BATCH-2026-03-EU",
                "reporting_month": "2026-03",
                "source_csv_file": "march_EMEA_settlements.csv",
                "total_amount": 61450.75,
                "valid_rows": 405,
                "status": "Pending Review",
            },
        ],
        "rejected_record": [
            {
                "id": "rej-101",
                "row_number": 42,
                "rejection_reason": "Missing required column: date",
                "raw_payload": ",1450.00,USD,Enterprise Renewal",
                "batch_id": "BATCH-2026-03-EU",
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="csv_ingestion_monthly_totals",
        benchmark_prompt="CSV ingestion with monthly totals",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_daily_habit_tracker_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="Personal Daily Habit & Ritual Consistency Tracker",
        archetype=ProductArchetype.HABIT_OR_GOAL_TRACKER,
        audience=AudienceProfile(
            who="Mindful individuals building sustainable morning and evening routines",
            context_of_use="Calm morning check-in on laptop or phone with coffee",
            device_likely_used="hybrid",
            tech_comfort="medium",
        ),
        core_jobs=[
            "Check off today's rituals in one click from the daily checklist",
            "Review multi-week streak momentum and consistency heatmaps",
            "Reflect on ritual cues, target cadence, and personal notes",
        ],
        primary_object="habit_ritual",
        tone="calm",
        data_shape=DataShape.TIME_SERIES,
        needs_automation=False,
        rationale=(
            "A personal habit tracker revolves around a frictionless daily ritual checklist "
            "and visual streak momentum rather than file uploads or enterprise tables."
        ),
    )

    blueprint = AppBlueprint(
        app_name="SteadyCadence Rituals",
        product_tagline="Unhurried daily habit check-ins, streak heatmaps, and mindful reflection",
        domain=domain,
        entities=[
            EntitySpec(
                name="habit_ritual",
                singular_label="Habit Ritual",
                plural_label="Habit Rituals",
                fields=[
                    FieldSpec(
                        name="ritual_name",
                        label="Ritual Title",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="time_of_day",
                        label="Time of Day",
                        field_type=FieldType.ENUM,
                        enum_values=["Morning", "Midday", "Evening", "Anytime"],
                    ),
                    FieldSpec(
                        name="current_streak",
                        label="Current Streak (Days)",
                        field_type=FieldType.INTEGER,
                        required=True,
                        default_value=1,
                    ),
                    FieldSpec(
                        name="completed_today",
                        label="Completed Today",
                        field_type=FieldType.BOOLEAN,
                        required=True,
                        default_value=False,
                    ),
                    FieldSpec(
                        name="cue_prompt",
                        label="Trigger Cue",
                        field_type=FieldType.STRING,
                        required=False,
                    ),
                ],
            ),
            EntitySpec(
                name="reflection_note",
                singular_label="Reflection Note",
                plural_label="Reflection Notes",
                fields=[
                    FieldSpec(
                        name="entry_date",
                        label="Reflection Date",
                        field_type=FieldType.DATE,
                        required=True,
                    ),
                    FieldSpec(
                        name="energy_level",
                        label="Focus & Energy Level",
                        field_type=FieldType.ENUM,
                        enum_values=["Rested", "Steady", "Stretched", "Recharging"],
                    ),
                    FieldSpec(
                        name="gratitude_takeaway",
                        label="Daily Takeaway",
                        field_type=FieldType.TEXT,
                        required=True,
                    ),
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="today-rituals",
                title="Today's Ritual Checklist",
                route="/today-rituals",
                layout=LayoutArchetype.CHECKLIST_TODAY,
                entities_used=["habit_ritual"],
                primary_actions=["Complete Ritual", "Add New Ritual"],
                empty_state=EmptyStateSpec(
                    headline="Your Daily Ritual Canvas Is Quiet",
                    body=(
                        "Start small with one anchor habit for your morning or evening routine "
                        "and check it off with a single tap each day."
                    ),
                    cta_label="Create First Habit Ritual",
                    cta_action_id="create_habit_ritual",
                ),
            ),
            PageSpec(
                id="streak-heatmap",
                title="Consistency Heatmap & Streaks",
                route="/streak-heatmap",
                layout=LayoutArchetype.HEATMAP_STREAKS,
                entities_used=["habit_ritual"],
                primary_actions=["Log Ritual Check-In", "Adjust Cadence"],
                empty_state=EmptyStateSpec(
                    headline="No Streak Cells Logged Yet",
                    body="Complete your first daily ritual to light up your consistency grid.",
                    cta_label="Add Habit to Track",
                    cta_action_id="create_habit_ritual",
                ),
            ),
            PageSpec(
                id="mindful-journal",
                title="Mindful Reflections",
                route="/mindful-journal",
                layout=LayoutArchetype.FEED,
                entities_used=["reflection_note"],
                primary_actions=["Write Evening Reflection"],
                empty_state=EmptyStateSpec(
                    headline="No Reflection Notes Written Yet",
                    body="Capture a two-sentence note on what helped you stay consistent today.",
                    cta_label="Write First Reflection",
                    cta_action_id="create_reflection_note",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.SIDEBAR,
            items=[
                NavItemSpec(
                    page_id="today-rituals",
                    label="Today's Rituals",
                    icon="check-square",
                ),
                NavItemSpec(
                    page_id="streak-heatmap",
                    label="Streak Heatmap",
                    icon="flame",
                ),
                NavItemSpec(
                    page_id="mindful-journal",
                    label="Reflections",
                    icon="book-open",
                ),
            ],
        ),
        home_page_id="today-rituals",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="editorial_calm",
        primary_hex="#245436",  # Hue ~142 deg -> bucket 4
        monogram="SC",
        rationale=(
            "Warm paper tones, Fraunces literary serif headings, and forest green accents "
            "turn daily habit tracking into a calm, judgment-free ritual."
        ),
        radius_override=RadiusClass.SOFT,
        density_override=DensityClass.SPACIOUS,
        color_mode_override=ColorMode.LIGHT,
    )
    alt1 = _customize_direction(
        direction_id="playful_momentum",
        primary_hex="#C2381E",
        monogram="SC",
        rationale="Energetic coral pills and celebratory streak badges for high-momentum routines.",
    )
    alt2 = _customize_direction(
        direction_id="studio_craft",
        primary_hex="#82361B",
        monogram="SC",
        rationale="Tactile warm sand cards with artisanal typography for analog journal lovers.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "habit_ritual": [
            {
                "id": "hab-1",
                "ritual_name": "20 Minutes Morning Reading (No Screens)",
                "time_of_day": "Morning",
                "current_streak": 14,
                "completed_today": True,
                "cue_prompt": "Right after pouring morning coffee",
            },
            {
                "id": "hab-2",
                "ritual_name": "Outdoor Mobility & Sunlight Walk",
                "time_of_day": "Midday",
                "current_streak": 9,
                "completed_today": False,
                "cue_prompt": "Before opening afternoon messages",
            },
            {
                "id": "hab-3",
                "ritual_name": "Evening Digital Sunset & Gratitude Note",
                "time_of_day": "Evening",
                "current_streak": 21,
                "completed_today": True,
                "cue_prompt": "At 9:30 PM lamp dimming",
            },
        ],
        "reflection_note": [
            {
                "id": "ref-1",
                "entry_date": "2026-10-12",
                "energy_level": "Rested",
                "gratitude_takeaway": (
                    "Leaving the phone in the hallway made morning reading effortless."
                ),
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="daily_habit_tracker",
        benchmark_prompt="daily habit tracker",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_security_event_log_viewer_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="Real-Time Security Telemetry & SIEM Event Log Viewer",
        archetype=ProductArchetype.OPS_MONITORING,
        audience=AudienceProfile(
            who="SOC analysts, incident responders, and infrastructure security engineers",
            context_of_use="Low-light security operations center with keyboard-driven triage",
            device_likely_used="desktop",
            tech_comfort="high",
        ),
        core_jobs=[
            "Tail and filter live security event streams by severity and source host",
            "Investigate suspicious authentication or firewall anomalies in real time",
            "Escalate and track active containment rules across production clusters",
        ],
        primary_object="security_event",
        tone="technical",
        data_shape=DataShape.TIME_SERIES,
        needs_automation=False,
        rationale=(
            "Security operators triaging live threats in a SOC require a dark, low-glare "
            "monospace log stream with command-palette navigation and severity filtering."
        ),
    )

    blueprint = AppBlueprint(
        app_name="BastionPulse SIEM",
        product_tagline=(
            "Low-latency security telemetry stream, anomaly triage, and rule containment"
        ),
        domain=domain,
        entities=[
            EntitySpec(
                name="security_event",
                singular_label="Security Event",
                plural_label="Security Events",
                fields=[
                    FieldSpec(
                        name="timestamp_utc",
                        label="Timestamp (UTC)",
                        field_type=FieldType.DATETIME,
                        required=True,
                    ),
                    FieldSpec(
                        name="severity",
                        label="Severity",
                        field_type=FieldType.ENUM,
                        enum_values=["CRITICAL", "HIGH", "WARN", "INFO"],
                    ),
                    FieldSpec(
                        name="source_service",
                        label="Source Host / Service",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="event_signature",
                        label="Event Signature",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="source_ip",
                        label="Origin IP Address",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                ],
            ),
            EntitySpec(
                name="detection_rule",
                singular_label="Detection Rule",
                plural_label="Detection Rules",
                fields=[
                    FieldSpec(
                        name="rule_code",
                        label="Rule Identifier",
                        field_type=FieldType.STRING,
                        required=True,
                        unique=True,
                    ),
                    FieldSpec(
                        name="mitre_tactic",
                        label="MITRE ATT&CK Tactic",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "Initial Access",
                            "Privilege Escalation",
                            "Credential Access",
                            "Exfiltration",
                        ],
                    ),
                    FieldSpec(
                        name="enforcement_mode",
                        label="Enforcement Mode",
                        field_type=FieldType.ENUM,
                        enum_values=["Block & Page", "Alert Only", "Shadow Audit"],
                    ),
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="live-telemetry-stream",
                title="Live Telemetry Stream",
                route="/live-telemetry-stream",
                layout=LayoutArchetype.LOG_STREAM,
                entities_used=["security_event"],
                primary_actions=["Ingest Telemetry Event", "Isolate Host"],
                empty_state=EmptyStateSpec(
                    headline="Telemetry Stream Listening on All Collectors",
                    body=(
                        "No security events match the active severity filter. Emit a test "
                        "event or broaden your query window."
                    ),
                    cta_label="Emit Test Security Event",
                    cta_action_id="create_security_event",
                ),
            ),
            PageSpec(
                id="incident-timeline",
                title="Attack Chain Timeline",
                route="/incident-timeline",
                layout=LayoutArchetype.TIMELINE,
                entities_used=["security_event"],
                primary_actions=["Correlate IOCs", "Log Incident Event"],
                empty_state=EmptyStateSpec(
                    headline="No Active Incident Chains",
                    body="Correlated high-severity events will appear chronologically here.",
                    cta_label="Record Incident Event",
                    cta_action_id="create_security_event",
                ),
            ),
            PageSpec(
                id="detection-rules",
                title="Detection Rules Matrix",
                route="/detection-rules",
                layout=LayoutArchetype.DATA_TABLE_WITH_FILTERS,
                entities_used=["detection_rule"],
                primary_actions=["Deploy Detection Rule"],
                empty_state=EmptyStateSpec(
                    headline="No Custom Detection Rules Armed",
                    body="Author a MITRE ATT&CK rule to flag anomalous authentication patterns.",
                    cta_label="Author Detection Rule",
                    cta_action_id="create_detection_rule",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.COMMAND_PALETTE_PLUS_MINIMAL_TOP,
            items=[
                NavItemSpec(
                    page_id="live-telemetry-stream",
                    label="Telemetry Stream",
                    icon="terminal",
                ),
                NavItemSpec(
                    page_id="incident-timeline",
                    label="Attack Timeline",
                    icon="activity",
                ),
                NavItemSpec(
                    page_id="detection-rules",
                    label="Detection Rules",
                    icon="shield",
                ),
            ],
        ),
        home_page_id="live-telemetry-stream",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="console_dark",
        primary_hex="#14B8A6",  # Hue ~173 deg -> bucket 5
        monogram="BP",
        rationale=(
            "Near-black carbon surfaces, JetBrains Mono timestamps, and high-visibility "
            "teal/amber severity badges prevent eye strain in 24/7 SOC rooms."
        ),
        radius_override=RadiusClass.SHARP,
        density_override=DensityClass.COMPACT,
        color_mode_override=ColorMode.DARK,
    )
    alt1 = _customize_direction(
        direction_id="ledger_precision",
        primary_hex="#0F3D5E",
        monogram="BP",
        rationale="Daylight compliance audit view with compact tabular inspection.",
    )
    alt2 = _customize_direction(
        direction_id="kanban_focus",
        primary_hex="#312E81",
        monogram="BP",
        rationale="Incident triage board layout for collaborative SOC shift handoffs.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "security_event": [
            {
                "id": "evt-901",
                "timestamp_utc": "2026-10-13T04:12:09Z",
                "severity": "CRITICAL",
                "source_service": "auth-gateway-prod-02",
                "event_signature": "SSH brute-force burst (48 failed root attempts in 10s)",
                "source_ip": "198.51.100.74",
            },
            {
                "id": "evt-902",
                "timestamp_utc": "2026-10-13T04:14:22Z",
                "severity": "HIGH",
                "source_service": "k8s-ingress-us-east",
                "event_signature": "WAF blocked SQL union injection payload on /v2/checkout",
                "source_ip": "203.0.113.19",
            },
            {
                "id": "evt-903",
                "timestamp_utc": "2026-10-13T04:15:01Z",
                "severity": "WARN",
                "source_service": "iam-token-issuer",
                "event_signature": "Unusual cross-region OAuth refresh token rotation",
                "source_ip": "192.0.2.118",
            },
        ],
        "detection_rule": [
            {
                "id": "rule-01",
                "rule_code": "SIG-AUTH-409",
                "mitre_tactic": "Credential Access",
                "enforcement_mode": "Block & Page",
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="security_event_log_viewer",
        benchmark_prompt="security event log viewer",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_sports_court_booking_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="Athletic Club & Community Sports Court Booking Scheduler",
        archetype=ProductArchetype.BOOKING_SCHEDULER,
        audience=AudienceProfile(
            who="Tennis, pickleball, and padel players booking courts on mobile or kiosk",
            context_of_use="On-the-go court reservation between matches or at club desk",
            device_likely_used="mobile",
            tech_comfort="medium",
        ),
        core_jobs=[
            "Scan weekly court slot availability and reserve a court in seconds",
            "Browse club court surfaces, lighting, and indoor/outdoor amenities",
            "Manage upcoming player reservations and partner split bookings",
        ],
        primary_object="court_reservation",
        tone="energetic",
        data_shape=DataShape.CALENDAR,
        needs_automation=False,
        rationale=(
            "Players opening a court booking app want an immediate weekly agenda calendar "
            "and venue cards with mobile bottom tabs, not data pipelines."
        ),
    )

    blueprint = AppBlueprint(
        app_name="RallySlot Courts",
        product_tagline="Instant tennis, pickleball, and padel court reservations & club directory",
        domain=domain,
        entities=[
            EntitySpec(
                name="court_reservation",
                singular_label="Court Reservation",
                plural_label="Court Reservations",
                fields=[
                    FieldSpec(
                        name="court_name",
                        label="Court Name",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "Court 1 - Championship Clay",
                            "Court 2 - Hardcourt LED",
                            "Court 3 - Covered Padel",
                            "Court 4 - Pickleball Show",
                        ],
                    ),
                    FieldSpec(
                        name="booking_date",
                        label="Match Date",
                        field_type=FieldType.DATE,
                        required=True,
                    ),
                    FieldSpec(
                        name="time_slot",
                        label="Time Slot",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "07:00 - 08:30",
                            "09:00 - 10:30",
                            "17:30 - 19:00",
                            "19:30 - 21:00",
                        ],
                    ),
                    FieldSpec(
                        name="player_captain",
                        label="Lead Player",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="court_fee",
                        label="Court Fee",
                        field_type=FieldType.CURRENCY,
                        required=True,
                        default_value=36.0,
                    ),
                ],
            ),
            EntitySpec(
                name="court_venue",
                singular_label="Court Venue",
                plural_label="Court Venues",
                fields=[
                    FieldSpec(
                        name="venue_title",
                        label="Court Title",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="surface_type",
                        label="Surface Type",
                        field_type=FieldType.ENUM,
                        enum_values=["Red Clay", "Cushioned Acrylic", "Panoramic Turf"],
                    ),
                    FieldSpec(
                        name="lighting_status",
                        label="Floodlights & Roof",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="hourly_rate",
                        label="Hourly Rate",
                        field_type=FieldType.CURRENCY,
                        required=True,
                    ),
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="weekly-court-agenda",
                title="Weekly Court Agenda",
                route="/weekly-court-agenda",
                layout=LayoutArchetype.CALENDAR_WEEK_AGENDA,
                entities_used=["court_reservation"],
                primary_actions=["Reserve Time Slot", "Filter by Surface"],
                empty_state=EmptyStateSpec(
                    headline="All Courts Open for This Week",
                    body=(
                        "Pick a morning rally or evening floodlit slot to lock in your "
                        "next match reservation."
                    ),
                    cta_label="Book First Court Slot",
                    cta_action_id="create_court_reservation",
                ),
            ),
            PageSpec(
                id="court-directory",
                title="Courts & Surfaces",
                route="/court-directory",
                layout=LayoutArchetype.CARD_GRID,
                entities_used=["court_venue"],
                primary_actions=["Add Club Court"],
                empty_state=EmptyStateSpec(
                    headline="No Club Courts Listed Yet",
                    body="Add your club's clay, hard, or padel courts with surface details.",
                    cta_label="Add Club Court",
                    cta_action_id="create_court_venue",
                ),
            ),
            PageSpec(
                id="monthly-tournaments",
                title="Monthly Match Calendar",
                route="/monthly-tournaments",
                layout=LayoutArchetype.CALENDAR_MONTH,
                entities_used=["court_reservation"],
                primary_actions=["Schedule Match Slot"],
                empty_state=EmptyStateSpec(
                    headline="No Monthly Bookings Scheduled",
                    body="Reserve a court slot to populate the monthly club calendar.",
                    cta_label="Reserve Match Slot",
                    cta_action_id="create_court_reservation",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.BOTTOM_TABS,
            items=[
                NavItemSpec(
                    page_id="weekly-court-agenda",
                    label="Court Agenda",
                    icon="calendar",
                ),
                NavItemSpec(
                    page_id="court-directory",
                    label="Club Courts",
                    icon="map-pin",
                ),
                NavItemSpec(
                    page_id="monthly-tournaments",
                    label="Month View",
                    icon="trophy",
                ),
            ],
        ),
        home_page_id="weekly-court-agenda",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="marketplace_warm",
        primary_hex="#B45309",  # Hue ~32 deg -> bucket 1
        monogram="RS",
        rationale=(
            "Clay-court burnt amber accents, warm alabaster cards, and Sora geometric headings "
            "give players instant slot legibility on bright outdoor mobile screens."
        ),
        radius_override=RadiusClass.ROUND,
        density_override=DensityClass.COMFORTABLE,
        color_mode_override=ColorMode.LIGHT,
    )
    alt1 = _customize_direction(
        direction_id="playful_momentum",
        primary_hex="#C2381E",
        monogram="RS",
        rationale="High-energy pill buttons and bold sporty touch targets for rapid booking.",
    )
    alt2 = _customize_direction(
        direction_id="clinical_clean",
        primary_hex="#025E8D",
        monogram="RS",
        rationale="Crisp cerulean schedule grid optimized for front-desk reception kiosks.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "court_reservation": [
            {
                "id": "res-1",
                "court_name": "Court 1 - Championship Clay",
                "booking_date": "2026-10-14",
                "time_slot": "07:00 - 08:30",
                "player_captain": "Elena Rostova (Doubles)",
                "court_fee": 42.0,
            },
            {
                "id": "res-2",
                "court_name": "Court 3 - Covered Padel",
                "booking_date": "2026-10-14",
                "time_slot": "17:30 - 19:00",
                "player_captain": "Marcus Vance & Team",
                "court_fee": 48.0,
            },
            {
                "id": "res-3",
                "court_name": "Court 4 - Pickleball Show",
                "booking_date": "2026-10-15",
                "time_slot": "19:30 - 21:00",
                "player_captain": "Priya Nair (Ladder Match)",
                "court_fee": 32.0,
            },
        ],
        "court_venue": [
            {
                "id": "ven-1",
                "venue_title": "Court 1 - Championship Clay",
                "surface_type": "Red Clay",
                "lighting_status": "Outdoor + 800 Lux LED",
                "hourly_rate": 28.0,
            },
            {
                "id": "ven-2",
                "venue_title": "Court 3 - Covered Padel",
                "surface_type": "Panoramic Turf",
                "lighting_status": "Covered Canopy + Glass Walls",
                "hourly_rate": 32.0,
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="sports_court_booking",
        benchmark_prompt="sports court booking",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_hackathon_team_finder_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="University Hackathon Team Discovery & Project Pitch Feed",
        archetype=ProductArchetype.COMMUNITY_FEED,
        audience=AudienceProfile(
            who="Student hackers, designers, and ML builders forming 48-hour sprint teams",
            context_of_use="High-energy campus hacking hall on laptops and phones",
            device_likely_used="hybrid",
            tech_comfort="high",
        ),
        core_jobs=[
            "Post and browse live 48-hour hackathon project pitches seeking teammates",
            "Filter student builders by role (Frontend, Rust, ML, Product Design) and track",
            "Check the live hackathon track leaderboard and demo submission countdown",
        ],
        primary_object="team_pitch",
        tone="playful",
        data_shape=DataShape.FEED,
        needs_automation=False,
        rationale=(
            "Hackathon team formation thrives on a social pitch feed, skill-badge directory "
            "cards, and a live prize-track leaderboard with bold campus energy."
        ),
    )

    blueprint = AppBlueprint(
        app_name="ShipMate Hackers",
        product_tagline=(
            "Find your 48-hour hackathon squad, pitch bold prototypes, and claim bounties"
        ),
        domain=domain,
        entities=[
            EntitySpec(
                name="team_pitch",
                singular_label="Team Pitch",
                plural_label="Team Pitches",
                fields=[
                    FieldSpec(
                        name="project_title",
                        label="Project Pitch Name",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="prize_track",
                        label="Prize Track",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "AI Agents & Tooling",
                            "Climate & Hardware",
                            "Creative Web & Spatial",
                            "Open Source Infrastructure",
                        ],
                    ),
                    FieldSpec(
                        name="needed_role",
                        label="Seeking Teammate Role",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "Full-Stack TypeScript",
                            "PyTorch / Systems ML",
                            "UI/UX & Motion Designer",
                            "Embedded / Rust",
                        ],
                    ),
                    FieldSpec(
                        name="open_spots",
                        label="Open Squad Spots",
                        field_type=FieldType.INTEGER,
                        required=True,
                        default_value=2,
                    ),
                    FieldSpec(
                        name="discord_handle",
                        label="Table / Discord Tag",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                ],
            ),
            EntitySpec(
                name="hacker_profile",
                singular_label="Hacker Profile",
                plural_label="Hacker Profiles",
                fields=[
                    FieldSpec(
                        name="hacker_name",
                        label="Builder Name",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="university",
                        label="Campus / School",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="primary_stack",
                        label="Superpower Stack",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="bounty_points",
                        label="Hackathon Rep Score",
                        field_type=FieldType.INTEGER,
                        required=True,
                        default_value=120,
                    ),
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="live-pitch-feed",
                title="Live Squad Pitch Feed",
                route="/live-pitch-feed",
                layout=LayoutArchetype.FEED,
                entities_used=["team_pitch"],
                primary_actions=["Post Squad Pitch", "Filter by Prize Track"],
                empty_state=EmptyStateSpec(
                    headline="No Hackathon Pitches Posted Yet",
                    body=(
                        "Drop a 60-second pitch for what you're building this weekend and "
                        "tag the roles your squad needs."
                    ),
                    cta_label="Post First Squad Pitch",
                    cta_action_id="create_team_pitch",
                ),
            ),
            PageSpec(
                id="hacker-directory",
                title="Free-Agent Builders",
                route="/hacker-directory",
                layout=LayoutArchetype.CARD_GRID,
                entities_used=["hacker_profile"],
                primary_actions=["Create Builder Card"],
                empty_state=EmptyStateSpec(
                    headline="No Free-Agent Hackers Listed",
                    body="Add your builder card so teams can invite you to their table.",
                    cta_label="Join Builder Directory",
                    cta_action_id="create_hacker_profile",
                ),
            ),
            PageSpec(
                id="bounty-leaderboard",
                title="Track Leaderboard",
                route="/bounty-leaderboard",
                layout=LayoutArchetype.LEADERBOARD,
                entities_used=["hacker_profile"],
                primary_actions=["Award Mentor Upvote"],
                empty_state=EmptyStateSpec(
                    headline="Leaderboard Opens at Kickoff",
                    body="Register builders and ship checkpoints to climb the campus ranks.",
                    cta_label="Register Builder",
                    cta_action_id="create_hacker_profile",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.TOP_TABS,
            items=[
                NavItemSpec(
                    page_id="live-pitch-feed",
                    label="Squad Pitch Feed",
                    icon="zap",
                ),
                NavItemSpec(
                    page_id="hacker-directory",
                    label="Builder Directory",
                    icon="users",
                ),
                NavItemSpec(
                    page_id="bounty-leaderboard",
                    label="Leaderboard",
                    icon="award",
                ),
            ],
        ),
        home_page_id="live-pitch-feed",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="campus_energy",
        primary_hex="#1D4ED8",  # Hue ~224 deg -> bucket 7
        monogram="SM",
        rationale=(
            "Electric cobalt primaries, Outfit display type, and pill badges capture the "
            "collaborative urgency of a university hackathon pitch floor."
        ),
        radius_override=RadiusClass.PILL,
        density_override=DensityClass.COMFORTABLE,
        color_mode_override=ColorMode.BOTH,
    )
    alt1 = _customize_direction(
        direction_id="playful_momentum",
        primary_hex="#C2381E",
        monogram="SM",
        rationale="Warm coral cards and lively transitions for social community discovery.",
    )
    alt2 = _customize_direction(
        direction_id="console_dark",
        primary_hex="#22D3EE",
        monogram="SM",
        rationale="Late-night dark terminal aesthetic for 3 AM hardware and systems hackers.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "team_pitch": [
            {
                "id": "pitch-1",
                "project_title": "EchoBraille: Real-Time Haptic Lecture Notes",
                "prize_track": "Climate & Hardware",
                "needed_role": "Embedded / Rust",
                "open_spots": 1,
                "discord_handle": "Table B14 · @maya_hw",
            },
            {
                "id": "pitch-2",
                "project_title": "PatchGraph: Autonomous PR Root-Cause Visualizer",
                "prize_track": "AI Agents & Tooling",
                "needed_role": "UI/UX & Motion Designer",
                "open_spots": 2,
                "discord_handle": "Table A04 · @devon_ml",
            },
            {
                "id": "pitch-3",
                "project_title": "MeshDrop: Zero-Server Local Campus AirDrop",
                "prize_track": "Open Source Infrastructure",
                "needed_role": "Full-Stack TypeScript",
                "open_spots": 1,
                "discord_handle": "Table C09 · @sara_net",
            },
        ],
        "hacker_profile": [
            {
                "id": "hk-1",
                "hacker_name": "Maya Lin",
                "university": "Waterloo Engineering",
                "primary_stack": "Rust, STM32, WebAudio",
                "bounty_points": 340,
            },
            {
                "id": "hk-2",
                "hacker_name": "Devon Brooks",
                "university": "Georgia Tech CS",
                "primary_stack": "PyTorch, GraphQL, React",
                "bounty_points": 295,
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="hackathon_team_finder",
        benchmark_prompt="hackathon team finder for students",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_restaurant_inventory_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="Restaurant Kitchen Pantry, Cold-Storage & Purveyor Stock Manager",
        archetype=ProductArchetype.INVENTORY_STOCK,
        audience=AudienceProfile(
            who="Executive chefs, sous chefs, and kitchen purchasing managers",
            context_of_use="Walk-in cooler par checks and prep-line restock ordering",
            device_likely_used="tablet",
            tech_comfort="medium",
        ),
        core_jobs=[
            "Inspect ingredient par levels, cold-storage stations, and lot freshness in split view",
            "Flag low-stock perishables and place next-morning purveyor restock orders",
            "Track station prep depletion across produce, butcher, and dry pantry",
        ],
        primary_object="pantry_ingredient",
        tone="crafted",
        data_shape=DataShape.RELATIONAL,
        needs_automation=False,
        rationale=(
            "Chefs walking the line with a tablet need a split master-detail pantry inspector "
            "and restock kanban board in warm culinary earth tones."
        ),
    )

    blueprint = AppBlueprint(
        app_name="MiseEnPlace Larder",
        product_tagline=(
            "Kitchen par-level tracking, walk-in cooler lots, and purveyor restock orders"
        ),
        domain=domain,
        entities=[
            EntitySpec(
                name="pantry_ingredient",
                singular_label="Pantry Ingredient",
                plural_label="Pantry Ingredients",
                fields=[
                    FieldSpec(
                        name="ingredient_name",
                        label="Ingredient Name",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="kitchen_station",
                        label="Storage Station",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "Walk-In Produce",
                            "Butcher & Seafood",
                            "Dairy & Pastry Cooler",
                            "Dry Larder",
                        ],
                    ),
                    FieldSpec(
                        name="on_hand_qty",
                        label="On-Hand Quantity",
                        field_type=FieldType.FLOAT,
                        required=True,
                    ),
                    FieldSpec(
                        name="par_target",
                        label="Par Target",
                        field_type=FieldType.FLOAT,
                        required=True,
                    ),
                    FieldSpec(
                        name="stock_status",
                        label="Stock Status",
                        field_type=FieldType.ENUM,
                        enum_values=["At Par", "Order Tonight", "Critical 86 Risk"],
                    ),
                ],
            ),
            EntitySpec(
                name="purveyor_order",
                singular_label="Purveyor Order",
                plural_label="Purveyor Orders",
                fields=[
                    FieldSpec(
                        name="purveyor_name",
                        label="Farm / Purveyor",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="delivery_window",
                        label="Delivery Dock Window",
                        field_type=FieldType.ENUM,
                        enum_values=["05:30 AM Dock", "08:00 AM Produce", "11:00 AM Specialty"],
                    ),
                    FieldSpec(
                        name="order_total",
                        label="Estimated Invoice",
                        field_type=FieldType.CURRENCY,
                        required=True,
                    ),
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="larder-inspector",
                title="Walk-In Larder Inspector",
                route="/larder-inspector",
                layout=LayoutArchetype.MASTER_DETAIL,
                entities_used=["pantry_ingredient"],
                primary_actions=["Log Par Count", "Flag 86 Risk"],
                empty_state=EmptyStateSpec(
                    headline="Walk-In Larder Sheet Is Empty",
                    body=(
                        "Add your first produce, butcher, or dry-larder ingredient with its "
                        "daily par target to start pre-service stock checks."
                    ),
                    cta_label="Add First Ingredient",
                    cta_action_id="create_pantry_ingredient",
                ),
            ),
            PageSpec(
                id="restock-board",
                title="Nightly Restock Board",
                route="/restock-board",
                layout=LayoutArchetype.KANBAN_BOARD,
                entities_used=["pantry_ingredient"],
                primary_actions=["Move to Tonight's Order"],
                empty_state=EmptyStateSpec(
                    headline="All Kitchen Stations Are At Par",
                    body="Items below par target automatically appear in the nightly order lane.",
                    cta_label="Record Ingredient Count",
                    cta_action_id="create_pantry_ingredient",
                ),
            ),
            PageSpec(
                id="purveyor-deliveries",
                title="Purveyor Dock Schedule",
                route="/purveyor-deliveries",
                layout=LayoutArchetype.DATA_TABLE_WITH_FILTERS,
                entities_used=["purveyor_order"],
                primary_actions=["Schedule Purveyor PO"],
                empty_state=EmptyStateSpec(
                    headline="No Morning Dock Deliveries Scheduled",
                    body=(
                        "Create a purveyor purchase order for tomorrow's 5:30 AM kitchen receiving."
                    ),
                    cta_label="Create Purveyor PO",
                    cta_action_id="create_purveyor_order",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.SPLIT_MASTER_DETAIL,
            items=[
                NavItemSpec(
                    page_id="larder-inspector",
                    label="Larder Inspector",
                    icon="utensils",
                ),
                NavItemSpec(
                    page_id="restock-board",
                    label="Restock Lanes",
                    icon="kanban",
                ),
                NavItemSpec(
                    page_id="purveyor-deliveries",
                    label="Purveyor Dock",
                    icon="truck",
                ),
            ],
        ),
        home_page_id="larder-inspector",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="studio_craft",
        primary_hex="#4D6B14",  # Hue ~81 deg -> bucket 2
        monogram="MP",
        rationale=(
            "Herb-olive and terracotta tones paired with Playfair Display headings and "
            "split master-detail inspection fit a culinary larder and prep kitchen."
        ),
        radius_override=RadiusClass.ROUND,
        density_override=DensityClass.SPACIOUS,
        color_mode_override=ColorMode.LIGHT,
    )
    alt1 = _customize_direction(
        direction_id="kanban_focus",
        primary_hex="#312E81",
        monogram="MP",
        rationale="Compact multi-lane restock board for high-volume commissary kitchens.",
    )
    alt2 = _customize_direction(
        direction_id="marketplace_warm",
        primary_hex="#9A3412",
        monogram="MP",
        rationale="Warm supplier catalog cards for farm-to-table purveyor ordering.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "pantry_ingredient": [
            {
                "id": "ing-1",
                "ingredient_name": "San Marzano DOP Tomatoes (#10 Can)",
                "kitchen_station": "Dry Larder",
                "on_hand_qty": 6.0,
                "par_target": 18.0,
                "stock_status": "Order Tonight",
            },
            {
                "id": "ing-2",
                "ingredient_name": "Wild Halibut Fillet (Portioned 180g)",
                "kitchen_station": "Butcher & Seafood",
                "on_hand_qty": 4.0,
                "par_target": 24.0,
                "stock_status": "Critical 86 Risk",
            },
            {
                "id": "ing-3",
                "ingredient_name": "Cultured Normandy Unsalted Butter (kg)",
                "kitchen_station": "Dairy & Pastry Cooler",
                "on_hand_qty": 15.0,
                "par_target": 14.0,
                "stock_status": "At Par",
            },
        ],
        "purveyor_order": [
            {
                "id": "po-1",
                "purveyor_name": "Harbor Dayboat Fishery",
                "delivery_window": "05:30 AM Dock",
                "order_total": 685.00,
            },
            {
                "id": "po-2",
                "purveyor_name": "Valle Verde Organic Growers",
                "delivery_window": "08:00 AM Produce",
                "order_total": 412.50,
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="restaurant_inventory",
        benchmark_prompt="restaurant inventory",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_clinic_appointment_scheduling_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="Outpatient Medical Clinic Patient Intake & Appointment Flow",
        archetype=ProductArchetype.HEALTH_LOG,
        audience=AudienceProfile(
            who="Clinic care coordinators, triage nurses, and attending physicians",
            context_of_use="Bright clinical nursing station and exam-room tablet check-in",
            device_likely_used="desktop",
            tech_comfort="medium",
        ),
        core_jobs=[
            "Track patient arrival, vitals triage, and exam room flow on a live timeline",
            "Register new patient visit intake with chief complaint and clinician assignment",
            "Coordinate weekly physician consultation slots across exam rooms",
        ],
        primary_object="patient_visit",
        tone="clinical",
        data_shape=DataShape.CALENDAR,
        needs_automation=False,
        rationale=(
            "Care coordinators managing exam rooms need a calm, high-legibility patient flow "
            "timeline and guided intake wizard with zero visual clutter."
        ),
    )

    blueprint = AppBlueprint(
        app_name="VitalsPath Clinic",
        product_tagline="Outpatient visit timeline, exam-room triage, and guided patient intake",
        domain=domain,
        entities=[
            EntitySpec(
                name="patient_visit",
                singular_label="Patient Visit",
                plural_label="Patient Visits",
                fields=[
                    FieldSpec(
                        name="patient_full_name",
                        label="Patient Name",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="appointment_slot",
                        label="Scheduled Time",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="attending_clinician",
                        label="Attending Clinician",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "Dr. Amara Okafor (Internal Med)",
                            "Dr. Henrik Lindqvist (Cardiology)",
                            "NP Sofia Reyes (Primary Care)",
                        ],
                    ),
                    FieldSpec(
                        name="visit_stage",
                        label="Exam Room Stage",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "Checked In - Waiting",
                            "Vitals & Triage (Room B)",
                            "With Physician",
                            "Discharge Complete",
                        ],
                    ),
                    FieldSpec(
                        name="chief_complaint",
                        label="Chief Clinical Reason",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                ],
            ),
            EntitySpec(
                name="exam_room",
                singular_label="Exam Room",
                plural_label="Exam Rooms",
                fields=[
                    FieldSpec(
                        name="room_code",
                        label="Room Identifier",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="wing_floor",
                        label="Clinic Wing",
                        field_type=FieldType.ENUM,
                        enum_values=["North Primary Wing", "Cardio Diagnostics", "Pediatric Suite"],
                    ),
                    FieldSpec(
                        name="sanitation_state",
                        label="Room Readiness",
                        field_type=FieldType.ENUM,
                        enum_values=["Ready for Patient", "Occupied", "Sanitizing"],
                    ),
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="patient-flow-timeline",
                title="Live Patient Flow Timeline",
                route="/patient-flow-timeline",
                layout=LayoutArchetype.TIMELINE,
                entities_used=["patient_visit"],
                primary_actions=["Check In Patient", "Advance Room Stage"],
                empty_state=EmptyStateSpec(
                    headline="No Patients Checked In for Current Clinic Session",
                    body=(
                        "Register the first arriving patient to start tracking vitals triage "
                        "and exam room assignment."
                    ),
                    cta_label="Register Patient Visit",
                    cta_action_id="create_patient_visit",
                ),
            ),
            PageSpec(
                id="intake-wizard",
                title="Patient Intake Registration",
                route="/intake-wizard",
                layout=LayoutArchetype.FORM_WIZARD,
                entities_used=["patient_visit"],
                primary_actions=["Complete Intake Step"],
                empty_state=EmptyStateSpec(
                    headline="Guided Patient Check-In Ready",
                    body="Walk through demographics, attending clinician, and chief complaint.",
                    cta_label="Start Patient Intake",
                    cta_action_id="create_patient_visit",
                ),
            ),
            PageSpec(
                id="exam-room-status",
                title="Exam Room Readiness",
                route="/exam-room-status",
                layout=LayoutArchetype.CARD_GRID,
                entities_used=["exam_room"],
                primary_actions=["Update Room Readiness"],
                empty_state=EmptyStateSpec(
                    headline="No Exam Rooms Configured",
                    body="Add your clinic's exam rooms to coordinate sanitation and rooming.",
                    cta_label="Add Exam Room",
                    cta_action_id="create_exam_room",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.SIDEBAR,
            items=[
                NavItemSpec(
                    page_id="patient-flow-timeline",
                    label="Patient Timeline",
                    icon="stethoscope",
                ),
                NavItemSpec(
                    page_id="intake-wizard",
                    label="Intake Wizard",
                    icon="check-circle",
                ),
                NavItemSpec(
                    page_id="exam-room-status",
                    label="Exam Rooms",
                    icon="heart",
                ),
            ],
        ),
        home_page_id="patient-flow-timeline",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="clinical_clean",
        primary_hex="#86198F",  # Hue ~295 deg -> bucket 9
        monogram="VP",
        rationale=(
            "High-legibility Public Sans typography, cool hygienic surfaces, and calm plum-orchid "
            "clinical badges give triage nurses instant clarity across exam rooms."
        ),
        radius_override=RadiusClass.SOFT,
        density_override=DensityClass.COMFORTABLE,
        color_mode_override=ColorMode.LIGHT,
    )
    alt1 = _customize_direction(
        direction_id="editorial_calm",
        primary_hex="#245436",
        monogram="VP",
        rationale="Warm, soothing patient-facing waiting room aesthetic with generous spacing.",
    )
    alt2 = _customize_direction(
        direction_id="civic_formal",
        primary_hex="#1E3A8A",
        monogram="VP",
        rationale="High-contrast hospital compliance layout with zero decorative distraction.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "patient_visit": [
            {
                "id": "vis-101",
                "patient_full_name": "Arthur Pendelton",
                "appointment_slot": "09:15 AM",
                "attending_clinician": "Dr. Henrik Lindqvist (Cardiology)",
                "visit_stage": "With Physician",
                "chief_complaint": "Quarterly hypertension follow-up & ECG review",
            },
            {
                "id": "vis-102",
                "patient_full_name": "Nadia Al-Mansoor",
                "appointment_slot": "09:30 AM",
                "attending_clinician": "Dr. Amara Okafor (Internal Med)",
                "visit_stage": "Vitals & Triage (Room B)",
                "chief_complaint": "Persistent seasonal cough and spirometry check",
            },
            {
                "id": "vis-103",
                "patient_full_name": "Lucas Meyer",
                "appointment_slot": "09:45 AM",
                "attending_clinician": "NP Sofia Reyes (Primary Care)",
                "visit_stage": "Checked In - Waiting",
                "chief_complaint": "Annual preventive wellness lab review",
            },
        ],
        "exam_room": [
            {
                "id": "rm-1",
                "room_code": "Exam Suite N-204",
                "wing_floor": "Cardio Diagnostics",
                "sanitation_state": "Occupied",
            },
            {
                "id": "rm-2",
                "room_code": "Exam Suite N-108",
                "wing_floor": "North Primary Wing",
                "sanitation_state": "Ready for Patient",
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="clinic_appointment_scheduling",
        benchmark_prompt="clinic appointment scheduling",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_freelance_invoice_tracker_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="Independent Consultant & Freelance Client Invoice Ledger",
        archetype=ProductArchetype.FINANCE_LEDGER,
        audience=AudienceProfile(
            who="Independent designers, software consultants, and boutique studio principals",
            context_of_use="Desktop billing review and client statement dispatch",
            device_likely_used="desktop",
            tech_comfort="high",
        ),
        core_jobs=[
            "Draft and inspect itemized client invoice documents ready for dispatch",
            "Track overdue retainers, paid milestones, and tax withholding in the ledger",
            "Log billable project retainers and client payment terms",
        ],
        primary_object="client_invoice",
        tone="authoritative",
        data_shape=DataShape.DOCUMENT,
        needs_automation=False,
        rationale=(
            "Freelancers issuing formal client statements need a document-first invoice "
            "composer and crisp aging ledger rather than a generic chart dashboard."
        ),
    )

    blueprint = AppBlueprint(
        app_name="FolioNote Billing",
        product_tagline=(
            "Formal client invoice statements, retainer milestones, and aging receivables"
        ),
        domain=domain,
        entities=[
            EntitySpec(
                name="client_invoice",
                singular_label="Client Invoice",
                plural_label="Client Invoices",
                fields=[
                    FieldSpec(
                        name="invoice_number",
                        label="Invoice Number",
                        field_type=FieldType.STRING,
                        required=True,
                        unique=True,
                    ),
                    FieldSpec(
                        name="client_organization",
                        label="Client Organization",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="engagement_scope",
                        label="Milestone / Deliverable Scope",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="due_date",
                        label="Payment Due Date",
                        field_type=FieldType.DATE,
                        required=True,
                    ),
                    FieldSpec(
                        name="invoice_amount",
                        label="Invoice Total",
                        field_type=FieldType.CURRENCY,
                        required=True,
                    ),
                    FieldSpec(
                        name="payment_state",
                        label="Settlement Status",
                        field_type=FieldType.ENUM,
                        enum_values=["Paid in Full", "Sent - Net 15", "Overdue Follow-Up", "Draft"],
                    ),
                ],
            ),
            EntitySpec(
                name="client_retainer",
                singular_label="Client Retainer",
                plural_label="Client Retainers",
                fields=[
                    FieldSpec(
                        name="client_name",
                        label="Client Account",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="billing_cadence",
                        label="Billing Cadence",
                        field_type=FieldType.ENUM,
                        enum_values=["Monthly Retainer", "Fixed Milestone", "Hourly Advisory"],
                    ),
                    FieldSpec(
                        name="monthly_cap",
                        label="Contract Value",
                        field_type=FieldType.CURRENCY,
                        required=True,
                    ),
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="invoice-statements",
                title="Client Invoice Statements",
                route="/invoice-statements",
                layout=LayoutArchetype.REPORT_DOCUMENT,
                entities_used=["client_invoice"],
                primary_actions=["Issue New Invoice", "Mark Paid in Full"],
                empty_state=EmptyStateSpec(
                    headline="No Client Invoices Issued Yet",
                    body=(
                        "Draft your first formal milestone or retainer invoice with Net-15 "
                        "payment terms and itemized scope."
                    ),
                    cta_label="Draft First Client Invoice",
                    cta_action_id="create_client_invoice",
                ),
            ),
            PageSpec(
                id="receivables-ledger",
                title="Receivables Aging Ledger",
                route="/receivables-ledger",
                layout=LayoutArchetype.DATA_TABLE_WITH_FILTERS,
                entities_used=["client_invoice"],
                primary_actions=["Filter Overdue", "Issue New Invoice"],
                empty_state=EmptyStateSpec(
                    headline="Receivables Ledger Is Clear",
                    body="Issued invoices and settlement dates will be tracked in this table.",
                    cta_label="Add Invoice Entry",
                    cta_action_id="create_client_invoice",
                ),
            ),
            PageSpec(
                id="active-retainers",
                title="Client Retainer Agreements",
                route="/active-retainers",
                layout=LayoutArchetype.SINGLE_FORM,
                entities_used=["client_retainer"],
                primary_actions=["Register Retainer Agreement"],
                empty_state=EmptyStateSpec(
                    headline="No Active Retainer Contracts",
                    body="Record a recurring client retainer or fixed-fee advisory agreement.",
                    cta_label="Add Client Retainer",
                    cta_action_id="create_client_retainer",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.SPLIT_MASTER_DETAIL,
            items=[
                NavItemSpec(
                    page_id="invoice-statements",
                    label="Invoice Statements",
                    icon="file-text",
                ),
                NavItemSpec(
                    page_id="receivables-ledger",
                    label="Aging Ledger",
                    icon="dollar-sign",
                ),
                NavItemSpec(
                    page_id="active-retainers",
                    label="Retainers",
                    icon="briefcase",
                ),
            ],
        ),
        home_page_id="invoice-statements",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="civic_formal",
        primary_hex="#7F1D1D",  # Hue ~0 deg -> bucket 0
        monogram="FN",
        rationale=(
            "Authoritative Merriweather serif headings, sharp document borders, and deep "
            "crimson seals make freelance invoices look like institutional legal statements."
        ),
        radius_override=RadiusClass.SHARP,
        density_override=DensityClass.SPACIOUS,
        color_mode_override=ColorMode.BOTH,
    )
    alt1 = _customize_direction(
        direction_id="ledger_precision",
        primary_hex="#0F3D5E",
        monogram="FN",
        rationale="Compact accounting grid with IBM Plex Mono numerals for rapid bookkeeping.",
    )
    alt2 = _customize_direction(
        direction_id="studio_craft",
        primary_hex="#82361B",
        monogram="FN",
        rationale="Boutique design-studio statement aesthetic on warm archival paper.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "client_invoice": [
            {
                "id": "inv-2041",
                "invoice_number": "INV-2026-041",
                "client_organization": "Kestrel Robotics Corp.",
                "engagement_scope": "Phase 2 Design System & Telemetry UI Architecture",
                "due_date": "2026-10-28",
                "invoice_amount": 12500.00,
                "payment_state": "Sent - Net 15",
            },
            {
                "id": "inv-2039",
                "invoice_number": "INV-2026-039",
                "client_organization": "Northstar BioLabs",
                "engagement_scope": "September Advisory Retainer & Assay Portal Audit",
                "due_date": "2026-10-05",
                "invoice_amount": 6800.00,
                "payment_state": "Paid in Full",
            },
            {
                "id": "inv-2036",
                "invoice_number": "INV-2026-036",
                "client_organization": "Vellum Publishing House",
                "engagement_scope": "Editorial Search & Typography Migration Milestone",
                "due_date": "2026-09-30",
                "invoice_amount": 4200.00,
                "payment_state": "Overdue Follow-Up",
            },
        ],
        "client_retainer": [
            {
                "id": "ret-1",
                "client_name": "Kestrel Robotics Corp.",
                "billing_cadence": "Monthly Retainer",
                "monthly_cap": 10000.00,
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="freelance_invoice_tracker",
        benchmark_prompt="freelance invoice tracker",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_crm_sales_pipeline_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="B2B Sales Pipeline & Deal Revenue Tracking",
        archetype=ProductArchetype.CRM_PIPELINE,
        audience=AudienceProfile(
            who="Account executives, sales directors, and revenue ops leads",
            context_of_use="Daily sales pipeline reviews and revenue forecasting",
            device_likely_used="desktop",
            tech_comfort="high",
        ),
        core_jobs=[
            "Advance opportunities across qualification and proposal stages",
            "Track deal revenue forecasts and quarterly conversion velocity",
            "Log customer interactions and scheduled executive demos",
        ],
        primary_object="sales_deal",
        tone="authoritative, revenue-focused, clear",
        data_shape=DataShape.KANBAN,
        needs_automation=False,
        rationale=(
            "Sales teams require a kanban pipeline view to drag deals through stages, "
            "paired with funnel conversion analytics and detailed account records."
        ),
    )

    blueprint = AppBlueprint(
        app_name="PipelineOps CRM",
        product_tagline="Opportunity pipeline stages, revenue forecasting, and deal conversion",
        domain=domain,
        entities=[
            EntitySpec(
                name="sales_deal",
                singular_label="Sales Deal",
                plural_label="Sales Deals",
                fields=[
                    FieldSpec(
                        name="deal_name",
                        label="Opportunity Title",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="account_name",
                        label="Target Account",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="deal_value",
                        label="Contract Value",
                        field_type=FieldType.CURRENCY,
                        required=True,
                    ),
                    FieldSpec(
                        name="stage",
                        label="Pipeline Stage",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "Prospect",
                            "Qualified",
                            "Proposal Sent",
                            "Contract Review",
                            "Closed Won",
                            "Closed Lost",
                        ],
                    ),
                    FieldSpec(
                        name="contact_email",
                        label="Executive Contact",
                        field_type=FieldType.EMAIL,
                        required=True,
                    ),
                    FieldSpec(
                        name="close_date",
                        label="Target Close Date",
                        field_type=FieldType.DATE,
                        required=True,
                    ),
                ],
            ),
            EntitySpec(
                name="deal_activity",
                singular_label="Deal Activity",
                plural_label="Deal Activities",
                fields=[
                    FieldSpec(
                        name="activity_type",
                        label="Interaction Type",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "Discovery Call",
                            "Product Demo",
                            "Proposal Review",
                            "Legal Follow-up",
                        ],
                    ),
                    FieldSpec(
                        name="summary",
                        label="Meeting Summary",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="deal_id",
                        label="Parent Deal",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="is_completed",
                        label="Completed",
                        field_type=FieldType.BOOLEAN,
                        default_value=True,
                    ),
                ],
                relationships=[
                    RelationshipSpec(
                        target_entity="sales_deal",
                        kind="many_to_one",
                        foreign_key="deal_id",
                    )
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="pipeline-kanban",
                title="Deal Pipeline Board",
                route="/pipeline-kanban",
                layout=LayoutArchetype.KANBAN_BOARD,
                entities_used=["sales_deal"],
                primary_actions=["Create Opportunity", "Filter by Stage"],
                empty_state=EmptyStateSpec(
                    headline="No Active Deals in Pipeline",
                    body="Create your first enterprise sales opportunity to track stage progression.",
                    cta_label="New Opportunity",
                    cta_action_id="create_sales_deal",
                ),
            ),
            PageSpec(
                id="funnel-analytics",
                title="Revenue Funnel & Conversion",
                route="/funnel-analytics",
                layout=LayoutArchetype.STAT_TILES_WITH_CHARTS,
                entities_used=["sales_deal"],
                primary_actions=["Refresh Forecast", "Export Summary"],
                empty_state=EmptyStateSpec(
                    headline="Insufficient Deal Data for Funnel Analytics",
                    body="Populate active opportunities to view conversion rates across pipeline stages.",
                    cta_label="Add First Opportunity",
                    cta_action_id="create_sales_deal",
                ),
            ),
            PageSpec(
                id="account-directory",
                title="Account & Deal Directory",
                route="/account-directory",
                layout=LayoutArchetype.MASTER_DETAIL,
                entities_used=["sales_deal"],
                primary_actions=["Log Customer Activity", "Create Deal"],
                empty_state=EmptyStateSpec(
                    headline="Account Directory Is Empty",
                    body="All committed client relationships and deal notes will appear here.",
                    cta_label="Add Account Record",
                    cta_action_id="create_sales_deal",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.SIDEBAR,
            items=[
                NavItemSpec(
                    page_id="pipeline-kanban",
                    label="Pipeline Board",
                    icon="kanban",
                ),
                NavItemSpec(
                    page_id="funnel-analytics",
                    label="Funnel Analytics",
                    icon="bar-chart-2",
                ),
                NavItemSpec(
                    page_id="account-directory",
                    label="Account Directory",
                    icon="briefcase",
                ),
            ],
        ),
        home_page_id="pipeline-kanban",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="kanban_focus",
        primary_hex="#047857",
        monogram="PO",
        rationale=(
            "Executive enterprise CRM aesthetic with deep emerald pipeline accents, high "
            "information density, and clear contrast for high-stakes deal tracking."
        ),
        radius_override=RadiusClass.ROUND,
        density_override=DensityClass.COMPACT,
        color_mode_override=ColorMode.LIGHT,
    )
    alt1 = _customize_direction(
        direction_id="console_dark",
        primary_hex="#0F766E",
        monogram="PO",
        rationale="High-energy dark mode revenue command center with bold typography.",
    )
    alt2 = _customize_direction(
        direction_id="ledger_precision",
        primary_hex="#1E3A8A",
        monogram="PO",
        rationale="Structured financial precision theme for strict enterprise sales controls.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "sales_deal": [
            {
                "id": "deal-101",
                "deal_name": "Acme Cloud Infrastructure Migration",
                "account_name": "Acme Industrial Holdings",
                "deal_value": 85000.00,
                "stage": "Proposal Sent",
                "contact_email": "r.chen@acme-holdings.example",
                "close_date": "2026-11-15",
            },
            {
                "id": "deal-102",
                "deal_name": "Globex Security Audit & SOC Platform",
                "account_name": "Globex Systems International",
                "deal_value": 42000.00,
                "stage": "Qualified",
                "contact_email": "s.miller@globex.example",
                "close_date": "2026-11-30",
            },
            {
                "id": "deal-103",
                "deal_name": "Stark Enterprise Telemetry Suite",
                "account_name": "Stark Logistics Group",
                "deal_value": 120000.00,
                "stage": "Contract Review",
                "contact_email": "p.potts@starklogistics.example",
                "close_date": "2026-10-31",
            },
            {
                "id": "deal-104",
                "deal_name": "Initech Automated Billing Integration",
                "account_name": "Initech Software Corp",
                "deal_value": 28000.00,
                "stage": "Prospect",
                "contact_email": "b.gibbons@initech.example",
                "close_date": "2026-12-10",
            },
        ],
        "deal_activity": [
            {
                "id": "act-1",
                "activity_type": "Product Demo",
                "summary": "Demonstrated multi-tenant pipeline controls to VP of Engineering.",
                "deal_id": "deal-101",
                "is_completed": True,
            },
            {
                "id": "act-2",
                "activity_type": "Legal Follow-up",
                "summary": "Shared data security compliance pack and redlined SLA terms.",
                "deal_id": "deal-103",
                "is_completed": False,
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="crm_sales_pipeline",
        benchmark_prompt="CRM sales pipeline",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_online_learning_platform_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="Online Learning & Interactive Course Academy",
        archetype=ProductArchetype.LEARNING_COURSE,
        audience=AudienceProfile(
            who="Students, software engineers, and continuing education professionals",
            context_of_use="Self-paced technical learning and curriculum mastery",
            device_likely_used="hybrid",
            tech_comfort="medium",
        ),
        core_jobs=[
            "Browse interactive technical modules and enroll in learning paths",
            "Complete daily checklist lessons and earn module mastery badges",
            "Review progress rings and quiz assessments across enrolled topics",
        ],
        primary_object="learning_course",
        tone="motivating, educational, structured",
        data_shape=DataShape.FEED,
        needs_automation=False,
        rationale=(
            "Modern technical learners need a visual course catalog, a focused daily "
            "lesson checklist, and mastery progress rings to sustain study habits."
        ),
    )

    blueprint = AppBlueprint(
        app_name="MasteryPath Academy",
        product_tagline="Structured technical curriculum, interactive lessons, and skill mastery",
        domain=domain,
        entities=[
            EntitySpec(
                name="learning_course",
                singular_label="Course Module",
                plural_label="Course Modules",
                fields=[
                    FieldSpec(
                        name="course_title",
                        label="Course Title",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="instructor_name",
                        label="Lead Instructor",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="difficulty_level",
                        label="Difficulty Level",
                        field_type=FieldType.ENUM,
                        enum_values=["Foundational", "Intermediate", "Advanced Mastery"],
                    ),
                    FieldSpec(
                        name="duration_weeks",
                        label="Estimated Duration (Weeks)",
                        field_type=FieldType.INTEGER,
                        required=True,
                    ),
                    FieldSpec(
                        name="enrolled_students",
                        label="Active Students",
                        field_type=FieldType.INTEGER,
                        required=True,
                    ),
                    FieldSpec(
                        name="completion_rate",
                        label="Completion Rate (%)",
                        field_type=FieldType.INTEGER,
                        required=True,
                    ),
                ],
            ),
            EntitySpec(
                name="course_lesson",
                singular_label="Course Lesson",
                plural_label="Course Lessons",
                fields=[
                    FieldSpec(
                        name="lesson_title",
                        label="Lesson Title",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="module_number",
                        label="Module Number",
                        field_type=FieldType.INTEGER,
                        required=True,
                    ),
                    FieldSpec(
                        name="course_id",
                        label="Parent Course",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="is_completed",
                        label="Completed",
                        field_type=FieldType.BOOLEAN,
                        default_value=False,
                    ),
                ],
                relationships=[
                    RelationshipSpec(
                        target_entity="learning_course",
                        kind="many_to_one",
                        foreign_key="course_id",
                    )
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="course-catalog",
                title="Curated Academy Catalog",
                route="/course-catalog",
                layout=LayoutArchetype.CARD_GRID,
                entities_used=["learning_course"],
                primary_actions=["Enroll in Course", "Filter by Level"],
                empty_state=EmptyStateSpec(
                    headline="No Courses Published Yet",
                    body="Publish your first curriculum course module with interactive lessons.",
                    cta_label="Publish Course",
                    cta_action_id="create_learning_course",
                ),
            ),
            PageSpec(
                id="daily-lessons",
                title="My Daily Study Checklist",
                route="/daily-lessons",
                layout=LayoutArchetype.CHECKLIST_TODAY,
                entities_used=["course_lesson"],
                primary_actions=["Mark Lesson Done", "Next Lesson"],
                empty_state=EmptyStateSpec(
                    headline="No Pending Lessons for Today",
                    body="You are all caught up on your scheduled lesson modules.",
                    cta_label="Add Next Lesson",
                    cta_action_id="create_course_lesson",
                ),
            ),
            PageSpec(
                id="mastery-analytics",
                title="Skill Mastery & Progress Rings",
                route="/mastery-analytics",
                layout=LayoutArchetype.STAT_TILES_WITH_CHARTS,
                entities_used=["learning_course"],
                primary_actions=["View Certificate", "Review Quiz Scores"],
                empty_state=EmptyStateSpec(
                    headline="No Study Progress Recorded",
                    body="Complete your first lesson module to start tracking your completion rate.",
                    cta_label="Start Studying",
                    cta_action_id="create_learning_course",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.TOP_TABS,
            items=[
                NavItemSpec(
                    page_id="course-catalog",
                    label="Course Catalog",
                    icon="book-open",
                ),
                NavItemSpec(
                    page_id="daily-lessons",
                    label="Today Lessons",
                    icon="check-square",
                ),
                NavItemSpec(
                    page_id="mastery-analytics",
                    label="Mastery Progress",
                    icon="award",
                ),
            ],
        ),
        home_page_id="course-catalog",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="playful_momentum",
        primary_hex="#2563EB",
        monogram="MP",
        rationale=(
            "Vibrant modern educational academy theme with motivating indigo tones, clear "
            "lesson cards, and interactive progress checklists."
        ),
        radius_override=RadiusClass.SOFT,
        density_override=DensityClass.COMFORTABLE,
        color_mode_override=ColorMode.LIGHT,
    )
    alt1 = _customize_direction(
        direction_id="campus_energy",
        primary_hex="#7C3AED",
        monogram="MP",
        rationale="Engaging collegiate aesthetic with purple gradients and energetic badges.",
    )
    alt2 = _customize_direction(
        direction_id="clinical_clean",
        primary_hex="#0284C7",
        monogram="MP",
        rationale="Calm focused learning workspace with refreshing sky blue accents.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "learning_course": [
            {
                "id": "crs-201",
                "course_title": "Distributed Systems Architecture",
                "instructor_name": "Dr. Elena Vance",
                "difficulty_level": "Advanced Mastery",
                "duration_weeks": 8,
                "enrolled_students": 420,
                "completion_rate": 84,
            },
            {
                "id": "crs-202",
                "course_title": "Full-Stack TypeScript & Reactive Web",
                "instructor_name": "Marcus Aurelius Thorne",
                "difficulty_level": "Intermediate",
                "duration_weeks": 6,
                "enrolled_students": 680,
                "completion_rate": 91,
            },
            {
                "id": "crs-203",
                "course_title": "Pragmatic Data Pipelines & Analytics",
                "instructor_name": "Kavita Rao",
                "difficulty_level": "Foundational",
                "duration_weeks": 4,
                "enrolled_students": 310,
                "completion_rate": 78,
            },
        ],
        "course_lesson": [
            {
                "id": "lsn-1",
                "lesson_title": "Consensus Protocols & Raft Mechanics",
                "module_number": 1,
                "course_id": "crs-201",
                "is_completed": True,
            },
            {
                "id": "lsn-2",
                "lesson_title": "Vector Clocks & State Replication",
                "module_number": 2,
                "course_id": "crs-201",
                "is_completed": False,
            },
            {
                "id": "lsn-3",
                "lesson_title": "Vite Bundling & Production Tree Shaking",
                "module_number": 1,
                "course_id": "crs-202",
                "is_completed": True,
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="online_learning_platform",
        benchmark_prompt="online learning platform",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_community_event_directory_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="Neighborhood & Civic Community Event Directory",
        archetype=ProductArchetype.COMMUNITY_FEED,
        audience=AudienceProfile(
            who="Local residents, workshop leaders, and community organizers",
            context_of_use="Discovering nearby weekend gatherings and civic meetups",
            device_likely_used="hybrid",
            tech_comfort="medium",
        ),
        core_jobs=[
            "Explore nearby workshops, volunteer days, and cultural gatherings",
            "Reserve attendee spots and track neighborhood venue capacities",
            "Filter upcoming events by neighborhood zone and weekly agenda",
        ],
        primary_object="community_event",
        tone="welcoming, vibrant, community-spirited",
        data_shape=DataShape.CALENDAR,
        needs_automation=False,
        rationale=(
            "Community members need a friendly venue map list, weekly calendar agenda, "
            "and live bulletin feed to stay connected to neighborhood happenings."
        ),
    )

    blueprint = AppBlueprint(
        app_name="CivicPulse Events",
        product_tagline="Local community gatherings, workshops, and neighborhood meetups",
        domain=domain,
        entities=[
            EntitySpec(
                name="community_event",
                singular_label="Community Event",
                plural_label="Community Events",
                fields=[
                    FieldSpec(
                        name="event_title",
                        label="Event Title",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="category",
                        label="Event Category",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "Workshop",
                            "Community Meeting",
                            "Outdoor & Park",
                            "Arts & Culture",
                        ],
                    ),
                    FieldSpec(
                        name="neighborhood_zone",
                        label="Neighborhood Zone",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="event_date",
                        label="Event Date",
                        field_type=FieldType.DATE,
                        required=True,
                    ),
                    FieldSpec(
                        name="max_capacity",
                        label="Attendee Limit",
                        field_type=FieldType.INTEGER,
                        required=True,
                    ),
                    FieldSpec(
                        name="rsvp_count",
                        label="Confirmed RSVPs",
                        field_type=FieldType.INTEGER,
                        required=True,
                    ),
                ],
            ),
            EntitySpec(
                name="event_rsvp",
                singular_label="Event RSVP",
                plural_label="Event RSVPs",
                fields=[
                    FieldSpec(
                        name="attendee_name",
                        label="Resident Name",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="contact_email",
                        label="Email Address",
                        field_type=FieldType.EMAIL,
                        required=True,
                    ),
                    FieldSpec(
                        name="event_id",
                        label="Reserved Event",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="tickets_count",
                        label="Passes Reserved",
                        field_type=FieldType.INTEGER,
                        required=True,
                        default_value=1,
                    ),
                ],
                relationships=[
                    RelationshipSpec(
                        target_entity="community_event",
                        kind="many_to_one",
                        foreign_key="event_id",
                    )
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="venue-explorer",
                title="Local Venues & Events",
                route="/venue-explorer",
                layout=LayoutArchetype.MAP_OR_LOCATION_LIST,
                entities_used=["community_event"],
                primary_actions=["Host Event", "Find by Neighborhood"],
                empty_state=EmptyStateSpec(
                    headline="No Community Events Scheduled",
                    body="Be the first to create a local workshop or neighborhood gathering.",
                    cta_label="Host First Event",
                    cta_action_id="create_community_event",
                ),
            ),
            PageSpec(
                id="weekly-agenda",
                title="Weekly Schedule Agenda",
                route="/weekly-agenda",
                layout=LayoutArchetype.CALENDAR_WEEK_AGENDA,
                entities_used=["community_event"],
                primary_actions=["Reserve RSVP", "Filter This Week"],
                empty_state=EmptyStateSpec(
                    headline="Agenda Is Clear for This Week",
                    body="Upcoming community sessions will be arranged by date and time.",
                    cta_label="Schedule Event",
                    cta_action_id="create_community_event",
                ),
            ),
            PageSpec(
                id="community-bulletin",
                title="Community Bulletin Feed",
                route="/community-bulletin",
                layout=LayoutArchetype.FEED,
                entities_used=["community_event"],
                primary_actions=["Post Announcement", "Browse Recent"],
                empty_state=EmptyStateSpec(
                    headline="No Recent Community Notices",
                    body="Local notices and event updates appear in real time on this feed.",
                    cta_label="Add First Notice",
                    cta_action_id="create_community_event",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.BOTTOM_TABS,
            items=[
                NavItemSpec(
                    page_id="venue-explorer",
                    label="Venues & Map",
                    icon="map-pin",
                ),
                NavItemSpec(
                    page_id="weekly-agenda",
                    label="Weekly Agenda",
                    icon="calendar",
                ),
                NavItemSpec(
                    page_id="community-bulletin",
                    label="Community Feed",
                    icon="message-square",
                ),
            ],
        ),
        home_page_id="venue-explorer",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="marketplace_warm",
        primary_hex="#0284C7",
        monogram="CP",
        rationale=(
            "Approachable civic platform with cheerful sky blue highlights, clean location "
            "cards, and accessible neighborhood agenda views."
        ),
        radius_override=RadiusClass.ROUND,
        density_override=DensityClass.SPACIOUS,
        color_mode_override=ColorMode.LIGHT,
    )
    alt1 = _customize_direction(
        direction_id="studio_craft",
        primary_hex="#B45309",
        monogram="CP",
        rationale="Warm artisanal community bulletin with earthy amber tones.",
    )
    alt2 = _customize_direction(
        direction_id="civic_formal",
        primary_hex="#059669",
        monogram="CP",
        rationale="Fresh green botanical park gathering theme with high clarity.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "community_event": [
            {
                "id": "evt-301",
                "event_title": "Civic Center Tech & Code Meetup",
                "category": "Workshop",
                "neighborhood_zone": "Downtown Innovation Hub",
                "event_date": "2026-10-24",
                "max_capacity": 60,
                "rsvp_count": 48,
            },
            {
                "id": "evt-302",
                "event_title": "Riverside Community Garden Harvest Day",
                "category": "Outdoor & Park",
                "neighborhood_zone": "Greenwood District",
                "event_date": "2026-10-25",
                "max_capacity": 100,
                "rsvp_count": 76,
            },
            {
                "id": "evt-303",
                "event_title": "Neighborhood Artists Open Studio Night",
                "category": "Arts & Culture",
                "neighborhood_zone": "Old Mill Arts Quarter",
                "event_date": "2026-10-30",
                "max_capacity": 85,
                "rsvp_count": 52,
            },
        ],
        "event_rsvp": [
            {
                "id": "rsvp-1",
                "attendee_name": "Aria Montgomery",
                "contact_email": "aria.m@example.org",
                "event_id": "evt-301",
                "tickets_count": 2,
            },
            {
                "id": "rsvp-2",
                "attendee_name": "Julian Vance",
                "contact_email": "j.vance@example.org",
                "event_id": "evt-302",
                "tickets_count": 1,
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="community_event_directory",
        benchmark_prompt="community event directory",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_calendar_reminder_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="Calendar Event Scheduling & Priority Reminders Workspace",
        archetype=ProductArchetype.BOOKING_SCHEDULER,
        audience=AudienceProfile(
            who="Professionals, coordinators, and students organizing daily agendas",
            context_of_use="Everyday schedule planning, event timeblocking, and reminder checklist tracking",
            device_likely_used="hybrid",
            tech_comfort="medium",
        ),
        core_jobs=[
            "Schedule and manage calendar events with dates, times, and categories",
            "Set priority reminders with due dates, repeat rules, and completion status",
            "Review weekly schedule agenda and upcoming chronological timeline",
        ],
        primary_object="calendar_event",
        tone="calm, punctual, organized, reliable",
        data_shape=DataShape.CALENDAR,
        needs_automation=False,
        rationale=(
            "Dedicated calendar and reminder platform tailored for weekly schedule timeblocking, "
            "due date notifications, and priority task checklists."
        ),
    )

    blueprint = AppBlueprint(
        app_name="TimeFlow Calendar & Reminders",
        product_tagline="Punctual schedule management, weekly calendar agenda, and priority task reminders",
        domain=domain,
        entities=[
            EntitySpec(
                name="calendar_event",
                singular_label="Calendar Event",
                plural_label="Calendar Events",
                fields=[
                    FieldSpec(
                        name="event_title",
                        label="Event Title",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="event_date",
                        label="Event Date",
                        field_type=FieldType.DATE,
                        required=True,
                    ),
                    FieldSpec(
                        name="time_slot",
                        label="Time Slot",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="category",
                        label="Event Category",
                        field_type=FieldType.ENUM,
                        enum_values=["Work", "Personal", "Meeting", "Important", "Health"],
                    ),
                    FieldSpec(
                        name="location",
                        label="Location",
                        field_type=FieldType.STRING,
                    ),
                    FieldSpec(
                        name="notes",
                        label="Event Notes",
                        field_type=FieldType.STRING,
                    ),
                ],
            ),
            EntitySpec(
                name="reminder_task",
                singular_label="Reminder Task",
                plural_label="Reminder Tasks",
                fields=[
                    FieldSpec(
                        name="task_title",
                        label="Reminder Title",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="due_date",
                        label="Due Date",
                        field_type=FieldType.DATE,
                        required=True,
                    ),
                    FieldSpec(
                        name="priority",
                        label="Priority Level",
                        field_type=FieldType.ENUM,
                        enum_values=["High", "Medium", "Low"],
                    ),
                    FieldSpec(
                        name="status",
                        label="Status",
                        field_type=FieldType.ENUM,
                        enum_values=["Pending", "Completed", "Snoozed"],
                    ),
                    FieldSpec(
                        name="reminder_time",
                        label="Reminder Time",
                        field_type=FieldType.STRING,
                    ),
                    FieldSpec(
                        name="repeat_frequency",
                        label="Repeat Frequency",
                        field_type=FieldType.ENUM,
                        enum_values=["None", "Daily", "Weekly", "Monthly"],
                    ),
                    FieldSpec(
                        name="event_id",
                        label="Linked Event",
                        field_type=FieldType.STRING,
                    ),
                ],
                relationships=[
                    RelationshipSpec(
                        target_entity="calendar_event",
                        kind="many_to_one",
                        foreign_key="event_id",
                    )
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="weekly-agenda",
                title="Weekly Calendar & Schedule",
                route="/weekly-agenda",
                layout=LayoutArchetype.CALENDAR_WEEK_AGENDA,
                entities_used=["calendar_event"],
                primary_actions=["New Event", "View Today"],
                empty_state=EmptyStateSpec(
                    headline="No Scheduled Calendar Events",
                    body="Your calendar is completely open. Schedule your first appointment or meeting.",
                    cta_label="Schedule Event",
                    cta_action_id="create_calendar_event",
                ),
            ),
            PageSpec(
                id="reminders-checklist",
                title="Priority Reminders & Checklist",
                route="/reminders-checklist",
                layout=LayoutArchetype.CHECKLIST_TODAY,
                entities_used=["reminder_task"],
                primary_actions=["Add Reminder", "Filter Pending"],
                empty_state=EmptyStateSpec(
                    headline="All Reminders Completed",
                    body="No pending reminders! Add a reminder for tasks and commitments you cannot miss.",
                    cta_label="New Reminder",
                    cta_action_id="create_reminder_task",
                ),
            ),
            PageSpec(
                id="schedule-timeline",
                title="Upcoming Schedule Timeline",
                route="/upcoming-timeline",
                layout=LayoutArchetype.TIMELINE,
                entities_used=["calendar_event", "reminder_task"],
                primary_actions=["Filter Category", "Next 7 Days"],
                empty_state=EmptyStateSpec(
                    headline="Timeline Is Clear",
                    body="Upcoming calendar events and active reminders will appear chronologically here.",
                    cta_label="Add Event",
                    cta_action_id="create_calendar_event",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.TOP_TABS,
            items=[
                NavItemSpec(
                    page_id="weekly-agenda",
                    label="Weekly Calendar",
                    icon="calendar",
                ),
                NavItemSpec(
                    page_id="reminders-checklist",
                    label="Reminders",
                    icon="check-square",
                ),
                NavItemSpec(
                    page_id="schedule-timeline",
                    label="Timeline",
                    icon="clock",
                ),
            ],
        ),
        home_page_id="weekly-agenda",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="editorial_calm",
        primary_hex="#0D9488",
        monogram="TF",
        rationale=(
            "Serene, high-focus productivity interface with calming teal tones, clear typography, "
            "and distinct schedule blocks."
        ),
        radius_override=RadiusClass.SOFT,
        density_override=DensityClass.COMFORTABLE,
        color_mode_override=ColorMode.LIGHT,
    )
    alt1 = _customize_direction(
        direction_id="clinical_clean",
        primary_hex="#2563EB",
        monogram="TF",
        rationale="Crisp sapphire corporate calendar theme with high-contrast event slots.",
    )
    alt2 = _customize_direction(
        direction_id="playful_momentum",
        primary_hex="#D97706",
        monogram="TF",
        rationale="Energetic amber theme for daily motivation and reminder checklists.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "calendar_event": [
            {
                "id": "evt-01",
                "event_title": "Sprint Planning & Roadmap Review",
                "event_date": "2026-10-15",
                "time_slot": "09:30 - 11:00",
                "category": "Work",
                "location": "Design Studio 3B",
                "notes": "Align on Q4 milestones and user experience priorities.",
            },
            {
                "id": "evt-02",
                "event_title": "Dentist Consultation & Checkup",
                "event_date": "2026-10-16",
                "time_slot": "14:00 - 15:00",
                "category": "Health",
                "location": "Downtown Health Pavilion",
                "notes": "Semi-annual dental cleaning and checkup.",
            },
            {
                "id": "evt-03",
                "event_title": "Product Architecture Review",
                "event_date": "2026-10-18",
                "time_slot": "15:00 - 16:30",
                "category": "Meeting",
                "location": "Virtual Video Bridge",
                "notes": "Walkthrough of adaptive generator components.",
            },
        ],
        "reminder_task": [
            {
                "id": "rem-01",
                "task_title": "Submit quarterly estimated tax filing",
                "due_date": "2026-10-15",
                "priority": "High",
                "status": "Pending",
                "reminder_time": "10:00",
                "repeat_frequency": "Monthly",
                "event_id": "evt-01",
            },
            {
                "id": "rem-02",
                "task_title": "Confirm dinner reservation for anniversary",
                "due_date": "2026-10-16",
                "priority": "Medium",
                "status": "Pending",
                "reminder_time": "12:00",
                "repeat_frequency": "None",
                "event_id": "evt-02",
            },
            {
                "id": "rem-03",
                "task_title": "Drink 2L water and take daily vitamins",
                "due_date": "2026-10-14",
                "priority": "Low",
                "status": "Completed",
                "reminder_time": "08:30",
                "repeat_frequency": "Daily",
                "event_id": "evt-03",
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="calendar_and_reminder",
        benchmark_prompt="calendar and reminder schedule planner",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _build_personal_expense_tracker_bundle() -> BenchmarkArchetypeBundle:
    domain = DomainAnalysis(
        product_kind="Personal Expense, Budget & Cashflow Tracker",
        archetype=ProductArchetype.FINANCE_LEDGER,
        audience=AudienceProfile(
            who="Individuals, households, and professionals managing personal finances and monthly budgets",
            context_of_use="Daily expense entry, budget threshold monitoring, and spending analytics",
            device_likely_used="hybrid",
            tech_comfort="medium",
        ),
        core_jobs=[
            "Record daily income and expense transactions with category and payment method tags",
            "Monitor monthly budget limits, current category spending, and threshold alerts",
            "Inspect spending distribution charts and monthly cashflow summaries",
        ],
        primary_object="expense_transaction",
        tone="reassuring, meticulous, clear",
        data_shape=DataShape.TIME_SERIES,
        needs_automation=False,
        rationale=(
            "Personal money management requires an instant ledger of expenses and income, "
            "visual monthly budget utilization gauges, and category breakdown analytics."
        ),
    )

    blueprint = AppBlueprint(
        app_name="SpendCraft Finance",
        product_tagline="Personal expense tracking, monthly category budgets, and cashflow analytics",
        domain=domain,
        entities=[
            EntitySpec(
                name="expense_transaction",
                singular_label="Expense Transaction",
                plural_label="Expense Transactions",
                fields=[
                    FieldSpec(
                        name="title",
                        label="Transaction Description",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="amount",
                        label="Transaction Amount",
                        field_type=FieldType.CURRENCY,
                        required=True,
                    ),
                    FieldSpec(
                        name="transaction_date",
                        label="Transaction Date",
                        field_type=FieldType.DATE,
                        required=True,
                    ),
                    FieldSpec(
                        name="category",
                        label="Spending Category",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "Groceries",
                            "Utilities",
                            "Dining Out",
                            "Transportation",
                            "Entertainment",
                            "Healthcare",
                            "Salary & Income",
                            "General",
                        ],
                    ),
                    FieldSpec(
                        name="transaction_type",
                        label="Type",
                        field_type=FieldType.ENUM,
                        enum_values=["Expense", "Income"],
                    ),
                    FieldSpec(
                        name="payment_method",
                        label="Payment Method",
                        field_type=FieldType.ENUM,
                        enum_values=[
                            "Credit Card",
                            "Debit Card",
                            "Bank Transfer",
                            "Cash",
                            "Mobile Payment",
                        ],
                    ),
                    FieldSpec(
                        name="notes",
                        label="Notes & Tags",
                        field_type=FieldType.STRING,
                        required=False,
                        default_value="",
                    ),
                    FieldSpec(
                        name="budget_category_id",
                        label="Linked Budget Category",
                        field_type=FieldType.STRING,
                        required=False,
                        default_value="",
                    ),
                ],
                relationships=[
                    RelationshipSpec(
                        target_entity="budget_category",
                        kind="many_to_one",
                        foreign_key="budget_category_id",
                    )
                ],
            ),
            EntitySpec(
                name="budget_category",
                singular_label="Budget Category",
                plural_label="Budget Categories",
                fields=[
                    FieldSpec(
                        name="category_name",
                        label="Category Name",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="monthly_limit",
                        label="Monthly Spending Limit",
                        field_type=FieldType.CURRENCY,
                        required=True,
                    ),
                    FieldSpec(
                        name="current_spend",
                        label="Current Month Spending",
                        field_type=FieldType.CURRENCY,
                        required=True,
                        default_value=0.0,
                    ),
                    FieldSpec(
                        name="period_month",
                        label="Budget Period (YYYY-MM)",
                        field_type=FieldType.STRING,
                        required=True,
                        default_value="2026-10",
                    ),
                    FieldSpec(
                        name="alert_threshold",
                        label="Alert Threshold (%)",
                        field_type=FieldType.INTEGER,
                        required=True,
                        default_value=85,
                    ),
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="expense-dashboard",
                title="Expense & Cashflow Dashboard",
                route="/expense-dashboard",
                layout=LayoutArchetype.STAT_TILES_WITH_CHARTS,
                entities_used=["expense_transaction", "budget_category"],
                primary_actions=["Log Expense", "Add Income"],
                empty_state=EmptyStateSpec(
                    headline="No Financial Activity Logged",
                    body="Start by recording your first expense transaction or monthly budget limit.",
                    cta_label="Log Transaction",
                    cta_action_id="create_expense_transaction",
                ),
            ),
            PageSpec(
                id="transaction-ledger",
                title="Transaction Ledger & Spending History",
                route="/transaction-ledger",
                layout=LayoutArchetype.DATA_TABLE_WITH_FILTERS,
                entities_used=["expense_transaction"],
                primary_actions=["New Transaction", "Export Transactions"],
                empty_state=EmptyStateSpec(
                    headline="Transaction Ledger Is Clean",
                    body="Your recorded income and expense transactions will appear here with multi-column filtering.",
                    cta_label="Add Transaction",
                    cta_action_id="create_expense_transaction",
                ),
            ),
            PageSpec(
                id="budget-limits",
                title="Monthly Budget Limits & Caps",
                route="/budget-limits",
                layout=LayoutArchetype.CARD_GRID,
                entities_used=["budget_category"],
                primary_actions=["Set Budget Cap", "Adjust Limits"],
                empty_state=EmptyStateSpec(
                    headline="No Budget Categories Defined",
                    body="Set monthly spending limits for categories like Groceries, Utilities, and Dining.",
                    cta_label="Create Budget Limit",
                    cta_action_id="create_budget_category",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.SIDEBAR,
            items=[
                NavItemSpec(
                    page_id="expense-dashboard",
                    label="Cashflow Overview",
                    icon="bar-chart-2",
                ),
                NavItemSpec(
                    page_id="transaction-ledger",
                    label="Transaction Ledger",
                    icon="credit-card",
                ),
                NavItemSpec(
                    page_id="budget-limits",
                    label="Budget Caps",
                    icon="check-square",
                ),
            ],
        ),
        home_page_id="expense-dashboard",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="ledger_precision",
        primary_hex="#047857",
        monogram="SC",
        rationale=(
            "Meticulous financial ledger aesthetic with emerald accents, high data density, "
            "and clean numerical alignment for personal budgeting."
        ),
        radius_override=RadiusClass.SOFT,
        density_override=DensityClass.COMPACT,
        color_mode_override=ColorMode.LIGHT,
    )
    alt1 = _customize_direction(
        direction_id="editorial_calm",
        primary_hex="#0D9488",
        monogram="SC",
        rationale="Calming teal theme with clear typography for mindful spending reviews.",
    )
    alt2 = _customize_direction(
        direction_id="clinical_clean",
        primary_hex="#2563EB",
        monogram="SC",
        rationale="Modern crisp sapphire theme with sharp contrast for financial auditing.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        "expense_transaction": [
            {
                "id": "tx-101",
                "title": "Fresh Market Organic Groceries",
                "amount": 128.45,
                "transaction_date": "2026-10-10",
                "category": "Groceries",
                "transaction_type": "Expense",
                "payment_method": "Credit Card",
                "notes": "Weekly produce, dairy, and household essentials",
                "budget_category_id": "cat-01",
            },
            {
                "id": "tx-102",
                "title": "Monthly High-Speed Fiber Internet",
                "amount": 79.99,
                "transaction_date": "2026-10-08",
                "category": "Utilities",
                "transaction_type": "Expense",
                "payment_method": "Debit Card",
                "notes": "Home office fiber connection utility bill",
                "budget_category_id": "cat-02",
            },
            {
                "id": "tx-103",
                "title": "Artisan Bistro Dinner with Team",
                "amount": 64.50,
                "transaction_date": "2026-10-11",
                "category": "Dining Out",
                "transaction_type": "Expense",
                "payment_method": "Credit Card",
                "notes": "Dinner celebration with project collaborators",
                "budget_category_id": "cat-03",
            },
            {
                "id": "tx-104",
                "title": "Monthly Direct Deposit Salary",
                "amount": 4250.00,
                "transaction_date": "2026-10-01",
                "category": "Salary & Income",
                "transaction_type": "Income",
                "payment_method": "Bank Transfer",
                "notes": "Primary software engineering payroll deposit",
                "budget_category_id": "cat-04",
            },
        ],
        "budget_category": [
            {
                "id": "cat-01",
                "category_name": "Groceries",
                "monthly_limit": 600.00,
                "current_spend": 384.20,
                "period_month": "2026-10",
                "alert_threshold": 80,
            },
            {
                "id": "cat-02",
                "category_name": "Utilities",
                "monthly_limit": 250.00,
                "current_spend": 195.40,
                "period_month": "2026-10",
                "alert_threshold": 90,
            },
            {
                "id": "cat-03",
                "category_name": "Dining Out",
                "monthly_limit": 300.00,
                "current_spend": 210.50,
                "period_month": "2026-10",
                "alert_threshold": 85,
            },
            {
                "id": "cat-04",
                "category_name": "Transportation",
                "monthly_limit": 200.00,
                "current_spend": 85.00,
                "period_month": "2026-10",
                "alert_threshold": 75,
            },
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key="personal_expense_tracker",
        benchmark_prompt="personal expense tracker budget spending finances",
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


def _synthesize_custom_prompt_bundle(prompt: str) -> BenchmarkArchetypeBundle:
    """Dynamically synthesizes a domain-authentic blueprint bundle for arbitrary user prompts."""
    words = [w.strip() for w in prompt.lower().split() if len(w.strip()) > 2]
    lead_word = words[0].capitalize() if words else "Custom"
    subject = words[-1] if words else "item"

    # Normalize entity and class identifiers
    clean_ent = "".join(c for c in subject if c.isalnum() or c == "_")
    if not clean_ent or clean_ent[0].isdigit():
        clean_ent = "item"
    ent_plural = f"{clean_ent}s"
    ent_title = clean_ent.capitalize()

    domain = DomainAnalysis(
        product_kind=f"{lead_word} {ent_title} Management Workspace",
        archetype=ProductArchetype.GENERIC_CRUD,
        audience=AudienceProfile(
            who="Specialized practitioners and operations coordinators",
            context_of_use="Everyday workstation operations and tracking",
            device_likely_used="hybrid",
            tech_comfort="medium",
        ),
        core_jobs=[
            f"Record and organize daily {clean_ent} updates with validation",
            f"Filter active {ent_plural} by status and priority",
            "Review performance trends and operational KPI metrics",
        ],
        primary_object=clean_ent,
        tone="focused, organized, responsive",
        data_shape=DataShape.TABULAR,
        needs_automation=False,
        rationale=f"Custom operational workspace tailored to managing {ent_plural} without generic collapse.",
    )

    blueprint = AppBlueprint(
        app_name=f"{lead_word}{ent_title} Pro",
        product_tagline=f"Specialized {clean_ent} tracking, operational records, and visual status metrics",
        domain=domain,
        entities=[
            EntitySpec(
                name=clean_ent,
                singular_label=ent_title,
                plural_label=f"{ent_title}s",
                fields=[
                    FieldSpec(
                        name="title",
                        label=f"{ent_title} Title",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="status",
                        label="Operational Status",
                        field_type=FieldType.ENUM,
                        enum_values=["Active", "In Progress", "Verified", "Archived"],
                    ),
                    FieldSpec(
                        name="priority",
                        label="Priority Level",
                        field_type=FieldType.ENUM,
                        enum_values=["High", "Normal", "Low"],
                    ),
                    FieldSpec(
                        name="metric_score",
                        label="Activity Score",
                        field_type=FieldType.INTEGER,
                        required=True,
                        default_value=10,
                    ),
                ],
            ),
            EntitySpec(
                name=f"{clean_ent}_log",
                singular_label=f"{ent_title} Log",
                plural_label=f"{ent_title} Logs",
                fields=[
                    FieldSpec(
                        name="note",
                        label="Log Entry",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                    FieldSpec(
                        name="logged_on",
                        label="Timestamp",
                        field_type=FieldType.DATE,
                        required=True,
                    ),
                    FieldSpec(
                        name=f"{clean_ent}_id",
                        label=f"Parent {ent_title}",
                        field_type=FieldType.STRING,
                        required=True,
                    ),
                ],
                relationships=[
                    RelationshipSpec(
                        target_entity=clean_ent,
                        kind="many_to_one",
                        foreign_key=f"{clean_ent}_id",
                    )
                ],
            ),
        ],
        pages=[
            PageSpec(
                id=f"{clean_ent}-dashboard",
                title=f"{ent_title} Overview & KPIs",
                route=f"/{clean_ent}-dashboard",
                layout=LayoutArchetype.STAT_TILES_WITH_CHARTS,
                entities_used=[clean_ent],
                primary_actions=[f"Add {ent_title}", "Filter Records"],
                empty_state=EmptyStateSpec(
                    headline=f"No {ent_title} Records Added Yet",
                    body=f"Get started by logging your first verified {clean_ent}.",
                    cta_label=f"Add {ent_title}",
                    cta_action_id=f"create_{clean_ent}",
                ),
            ),
            PageSpec(
                id=f"{clean_ent}-directory",
                title=f"{ent_title} Table Directory",
                route=f"/{clean_ent}-directory",
                layout=LayoutArchetype.DATA_TABLE_WITH_FILTERS,
                entities_used=[clean_ent],
                primary_actions=[f"New {ent_title}", "Filter Status"],
                empty_state=EmptyStateSpec(
                    headline="Directory Table Is Empty",
                    body=f"Active {ent_plural} will be listed here with multi-column filtering.",
                    cta_label=f"Create {ent_title}",
                    cta_action_id=f"create_{clean_ent}",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.SIDEBAR,
            items=[
                NavItemSpec(
                    page_id=f"{clean_ent}-dashboard",
                    label=f"{ent_title} Overview",
                    icon="layout",
                ),
                NavItemSpec(
                    page_id=f"{clean_ent}-directory",
                    label="Directory Table",
                    icon="list",
                ),
            ],
        ),
        home_page_id=f"{clean_ent}-dashboard",
        automations=[],
    )

    primary = _customize_direction(
        direction_id="ledger_precision",
        primary_hex="#1E293B",
        monogram=lead_word[:2].upper(),
        rationale=f"Clean modern design direction customized for {clean_ent} operations.",
        radius_override=RadiusClass.SOFT,
        density_override=DensityClass.COMFORTABLE,
    )
    alt1 = _customize_direction(
        direction_id="clinical_clean",
        primary_hex="#3B82F6",
        monogram=lead_word[:2].upper(),
        rationale="Crisp blue theme with high readability.",
    )
    alt2 = _customize_direction(
        direction_id="console_dark",
        primary_hex="#334155",
        monogram=lead_word[:2].upper(),
        rationale="Dark slate aesthetic for dense operational monitoring.",
    )

    seed: dict[str, list[dict[str, Any]]] = {
        clean_ent: [
            {
                "id": f"{clean_ent}-01",
                "title": f"Initial {ent_title} Project Alpha",
                "status": "Active",
                "priority": "High",
                "metric_score": 45,
            },
            {
                "id": f"{clean_ent}-02",
                "title": f"Secondary {ent_title} Beta Review",
                "status": "In Progress",
                "priority": "Normal",
                "metric_score": 30,
            },
        ],
        f"{clean_ent}_log": [
            {
                "id": "log-01",
                "note": "Initial operational milestone completed with zero validation warnings.",
                "logged_on": "2026-10-12",
                f"{clean_ent}_id": f"{clean_ent}-01",
            }
        ],
    }

    return BenchmarkArchetypeBundle(
        benchmark_key=f"custom_{clean_ent}",
        benchmark_prompt=prompt,
        domain_analysis=domain,
        blueprint=blueprint,
        primary_direction=primary,
        direction_proposals=[primary, alt1, alt2],
        sample_seed_data=seed,
    )


BENCHMARK_BUNDLES: dict[str, BenchmarkArchetypeBundle] = {
    "csv_ingestion_monthly_totals": _build_csv_monthly_totals_bundle(),
    "daily_habit_tracker": _build_daily_habit_tracker_bundle(),
    "security_event_log_viewer": _build_security_event_log_viewer_bundle(),
    "sports_court_booking": _build_sports_court_booking_bundle(),
    "hackathon_team_finder": _build_hackathon_team_finder_bundle(),
    "restaurant_inventory": _build_restaurant_inventory_bundle(),
    "clinic_appointment_scheduling": _build_clinic_appointment_scheduling_bundle(),
    "freelance_invoice_tracker": _build_freelance_invoice_tracker_bundle(),
}

EXTENDED_DOMAIN_BUNDLES: dict[str, BenchmarkArchetypeBundle] = {
    "crm_sales_pipeline": _build_crm_sales_pipeline_bundle(),
    "online_learning_platform": _build_online_learning_platform_bundle(),
    "community_event_directory": _build_community_event_directory_bundle(),
    "calendar_and_reminder": _build_calendar_reminder_bundle(),
    "personal_expense_tracker": _build_personal_expense_tracker_bundle(),
}


def resolve_benchmark_bundle(prompt: str) -> BenchmarkArchetypeBundle:
    """Matches a user prompt to the closest domain-authentic archetype bundle."""
    p = prompt.lower()
    # 1. Exact / primary benchmark bundles (must resolve accurately for benchmark suite)
    if any(k in p for k in ("csv", "monthly total", "ingestion", "reconcil")):
        return BENCHMARK_BUNDLES["csv_ingestion_monthly_totals"].model_copy(deep=True)
    if any(k in p for k in ("security", "siem", "log viewer", "event log", "soc", "telemetry")):
        return BENCHMARK_BUNDLES["security_event_log_viewer"].model_copy(deep=True)
    if any(k in p for k in ("court", "tennis", "pickleball", "padel", "sports", "venue booking")):
        return BENCHMARK_BUNDLES["sports_court_booking"].model_copy(deep=True)
    if any(k in p for k in ("hackathon", "team finder", "student", "squad", "campus")):
        return BENCHMARK_BUNDLES["hackathon_team_finder"].model_copy(deep=True)
    if any(k in p for k in ("restaurant", "inventory", "pantry", "larder", "kitchen", "stock")):
        return BENCHMARK_BUNDLES["restaurant_inventory"].model_copy(deep=True)
    if any(k in p for k in ("clinic", "patient", "appointment", "medical", "doctor", "triage")):
        return BENCHMARK_BUNDLES["clinic_appointment_scheduling"].model_copy(deep=True)
    if any(k in p for k in ("invoice", "freelance", "billing", "retainer", "receivable")):
        return BENCHMARK_BUNDLES["freelance_invoice_tracker"].model_copy(deep=True)
    if any(k in p for k in ("habit", "ritual", "streak", "routine", "wellness")):
        return BENCHMARK_BUNDLES["daily_habit_tracker"].model_copy(deep=True)

    # 2. Extended domain bundles (Personal Expense, Calendar, CRM, Learning, Community)
    if any(
        k in p
        for k in (
            "expense",
            "budget",
            "spending",
            "personal finance",
            "receipt audit",
            "money tracker",
            "expenditure",
            "cashflow",
            "wallet",
        )
    ):
        return EXTENDED_DOMAIN_BUNDLES["personal_expense_tracker"].model_copy(deep=True)
    if any(
        k in p
        for k in (
            "calendar",
            "claendar",
            "calender",
            "reminder",
            "remind",
            "agenda",
            "planner",
            "schedule",
            "timeblock",
            "todo",
            "event planner",
        )
    ):
        return EXTENDED_DOMAIN_BUNDLES["calendar_and_reminder"].model_copy(deep=True)
    if any(
        k in p
        for k in (
            "crm",
            "sales pipeline",
            "deal pipeline",
            "sales deal",
            "sales lead",
            "lead pipeline",
            "opportunity pipeline",
            "pipelineops",
            "sales ops",
            "prospect stage",
        )
    ):
        return EXTENDED_DOMAIN_BUNDLES["crm_sales_pipeline"].model_copy(deep=True)
    if any(k in p for k in ("learning", "course", "curriculum", "academy", "lesson", "education")):
        return EXTENDED_DOMAIN_BUNDLES["online_learning_platform"].model_copy(deep=True)
    if any(
        k in p
        for k in ("community", "meetup", "gathering", "bulletin", "neighborhood", "event directory")
    ):
        return EXTENDED_DOMAIN_BUNDLES["community_event_directory"].model_copy(deep=True)

    # 3. Dynamic custom prompt synthesis to prevent any arbitrary prompt from collapsing into habit tracker
    return _synthesize_custom_prompt_bundle(prompt)


def list_all_benchmark_bundles() -> list[BenchmarkArchetypeBundle]:
    return [b.model_copy(deep=True) for b in BENCHMARK_BUNDLES.values()]
