"""Stage A -> B -> C -> D Adaptive Application Compiler with bounded retries and restyling."""

import json
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel, Field

from engine.compiler.providers import MockProvider, ModelProvider
from generators.blueprint.archetypes import resolve_benchmark_bundle
from generators.blueprint.schemas import AppBlueprint, DomainAnalysis
from generators.design.contrast import validate_and_adjust_palette
from generators.design.directions import (
    CURATED_DIRECTION_PROFILES,
    apply_bounded_adjustments,
    get_curated_direction,
    list_curated_directions,
)
from generators.design.fingerprint import (
    resolve_diversity_with_retries,
    validate_stage_d,
)
from generators.design.schemas import (
    ColorMode,
    DensityClass,
    DesignDirection,
    LookFingerprint,
    RadiusClass,
    StageDValidationReport,
)

DESIGN_PROMPT_PATH = (
    Path(__file__).resolve().parent.parent.parent / "engine" / "compiler" / "prompts" / "design.md"
)


def load_design_system_prompt() -> str:
    if DESIGN_PROMPT_PATH.exists():
        return DESIGN_PROMPT_PATH.read_text(encoding="utf-8").strip()
    raise FileNotFoundError(f"Missing required design prompt file: {DESIGN_PROMPT_PATH}")


class StageRepairRecord(BaseModel):
    stage: str
    attempt: int
    errors: list[str]
    resolved: bool


class AdaptiveCompilationBundle(BaseModel):
    prompt: str
    domain_analysis: DomainAnalysis
    blueprint: AppBlueprint
    design_direction: DesignDirection
    direction_proposals: list[DesignDirection] = Field(..., min_length=3, max_length=3)
    validation_report: StageDValidationReport
    repair_log: list[StageRepairRecord] = Field(default_factory=list)
    telemetry: list[dict[str, Any]] = Field(default_factory=list)


def compile_domain_analysis(
    prompt: str,
    provider: ModelProvider,
    max_retries: int = 3,
    repair_log: Optional[list[StageRepairRecord]] = None,
) -> DomainAnalysis:
    """Stage A: Compile and validate DomainAnalysis with bounded non-identical retries."""
    base_sys_prompt = load_design_system_prompt()
    stage_sys_prompt = (
        f"{base_sys_prompt}\n\n"
        "STAGE A (DomainAnalysis): Analyze the user's product idea, audience, context of use, "
        "top 3-5 daily jobs, primary domain object, tone, data shape, and whether an automated "
        "ETL/workflow pipeline actually belongs in this product (needs_automation)."
    )

    last_errors: list[str] = []
    previous_payload: dict[str, Any] = {}

    for attempt in range(max_retries + 1):
        try:
            if attempt == 0:
                domain = provider.generate_structured(
                    prompt=prompt,
                    system_prompt=stage_sys_prompt,
                    schema_class=DomainAnalysis,
                )
            else:
                fb_prompt = f"{prompt}\nAttempt {attempt} feedback: {'; '.join(last_errors)}"
                domain = provider.repair_structured(
                    original_prompt=fb_prompt,
                    previous_output=previous_payload,
                    errors=last_errors,
                    schema_class=DomainAnalysis,
                )
            if repair_log is not None and attempt > 0:
                repair_log.append(
                    StageRepairRecord(
                        stage="StageA_DomainAnalysis",
                        attempt=attempt,
                        errors=list(last_errors),
                        resolved=True,
                    )
                )
            return domain
        except Exception as exc:
            err_msg = f"Stage A attempt {attempt + 1} validation error: {exc}"
            last_errors = [err_msg]
            previous_payload = {"attempt": attempt + 1, "error": str(exc)}
            if repair_log is not None and attempt > 0:
                repair_log.append(
                    StageRepairRecord(
                        stage="StageA_DomainAnalysis",
                        attempt=attempt,
                        errors=list(last_errors),
                        resolved=False,
                    )
                )

    return resolve_benchmark_bundle(prompt).domain_analysis


def _check_blueprint_domain_hygiene(blueprint: AppBlueprint) -> list[str]:
    """Ensures non-CSV blueprints do not contain leaked CSV or CodeX/Ghostwriter template copy."""
    errors: list[str] = []
    has_ingest = blueprint.has_file_ingest_entity()
    serialized = json.dumps(blueprint.model_dump())

    for forbidden in ("Execution Runs", "Quality Audit Log", "Production Verified", "Bit-for-Bit"):
        if forbidden.lower() in serialized.lower():
            errors.append(f"Blueprint contains forbidden legacy template copy: '{forbidden}'")

    if not has_ingest:
        for page in blueprint.pages:
            actions_str = " ".join(page.primary_actions)
            es = page.empty_state
            combined_page = f"{page.title} {actions_str} {es.headline} {es.cta_label}"
            if "csv" in combined_page.lower():
                errors.append(f"Page '{page.id}' contains 'CSV' copy in a non-file-ingest product.")
    return errors


def compile_app_blueprint(
    prompt: str,
    domain: DomainAnalysis,
    provider: ModelProvider,
    max_retries: int = 3,
    repair_log: Optional[list[StageRepairRecord]] = None,
) -> AppBlueprint:
    """Stage B: Compile and validate AppBlueprint with bounded non-identical retries."""
    base_sys_prompt = load_design_system_prompt()
    stage_prompt = (
        f"User Product Request: {prompt}\n\n"
        f"Approved Stage A DomainAnalysis:\n{json.dumps(domain.model_dump(), indent=2)}\n\n"
        "Design the complete Stage B AppBlueprint (entities, pages from the closed layout library, "
        "navigation pattern and items from allowed icons, home_page_id for #1 daily job, "
        "and automations only if needs_automation is true)."
    )
    stage_sys_prompt = (
        f"{base_sys_prompt}\n\n"
        "STAGE B (AppBlueprint): Output a valid AppBlueprint JSON object whose `domain` field "
        "matches the approved DomainAnalysis."
    )

    last_errors: list[str] = []
    previous_payload: dict[str, Any] = {}

    for attempt in range(max_retries + 1):
        try:
            if attempt == 0:
                blueprint = provider.generate_structured(
                    prompt=stage_prompt,
                    system_prompt=stage_sys_prompt,
                    schema_class=AppBlueprint,
                )
            else:
                fb_prompt = f"{stage_prompt}\nAttempt {attempt} errors: {'; '.join(last_errors)}"
                blueprint = provider.repair_structured(
                    original_prompt=fb_prompt,
                    previous_output=previous_payload,
                    errors=last_errors,
                    schema_class=AppBlueprint,
                )

            # Ensure domain consistency
            if not domain.needs_automation and blueprint.automations:
                blueprint = blueprint.model_copy(update={"automations": []})
            blueprint = blueprint.model_copy(update={"domain": domain})

            hygiene_errors = _check_blueprint_domain_hygiene(blueprint)
            if hygiene_errors:
                previous_payload = blueprint.model_dump()
                last_errors = hygiene_errors
                if repair_log is not None and attempt > 0:
                    repair_log.append(
                        StageRepairRecord(
                            stage="StageB_AppBlueprint",
                            attempt=attempt,
                            errors=list(last_errors),
                            resolved=False,
                        )
                    )
                continue

            if repair_log is not None and attempt > 0:
                repair_log.append(
                    StageRepairRecord(
                        stage="StageB_AppBlueprint",
                        attempt=attempt,
                        errors=list(last_errors),
                        resolved=True,
                    )
                )
            return blueprint
        except Exception as exc:
            last_errors = [f"Stage B attempt {attempt + 1} error: {exc}"]
            previous_payload = {"attempt": attempt + 1, "error": str(exc)}
            if repair_log is not None and attempt > 0:
                repair_log.append(
                    StageRepairRecord(
                        stage="StageB_AppBlueprint",
                        attempt=attempt,
                        errors=list(last_errors),
                        resolved=False,
                    )
                )

    fallback = resolve_benchmark_bundle(prompt).blueprint
    return fallback.model_copy(update={"domain": domain})


def compile_design_direction(
    prompt: str,
    domain: DomainAnalysis,
    blueprint: AppBlueprint,
    provider: ModelProvider,
    existing_fingerprints: Optional[list[LookFingerprint]] = None,
    max_retries: int = 3,
    repair_log: Optional[list[StageRepairRecord]] = None,
) -> tuple[DesignDirection, StageDValidationReport]:
    """
    Stage C & Stage D: Compile DesignDirection, adjust WCAG AA contrast, and enforce
    8-tuple fingerprint diversity (distance >= 4) with bounded retries and curated fallback.
    """
    base_sys_prompt = load_design_system_prompt()
    curated_summary = "\n".join(
        f"- {did}: {prof.feel_summary} (heading_font={prof.direction.typography.heading_font})"
        for did, prof in CURATED_DIRECTION_PROFILES.items()
    )
    home_layout_val = blueprint.get_home_page().layout.value
    nav_val = blueprint.navigation.pattern.value
    stage_prompt = (
        f"User Product Request: {prompt}\n"
        f"Product Archetype: {domain.archetype.value} | Tone: {domain.tone}\n"
        f"Home Page Layout: {home_layout_val} | Nav: {nav_val}\n"
        f"Curated Directions:\n{curated_summary}\n"
    )
    stage_sys_prompt = (
        f"{base_sys_prompt}\n\n"
        "STAGE C (DesignDirection): Choose the best fitting direction_id from the curated library "
        "and customize tokens within WCAG AA bounds."
    )

    candidate: Optional[DesignDirection] = None
    last_errors: list[str] = []
    previous_payload: dict[str, Any] = {}

    for attempt in range(max_retries + 1):
        try:
            if attempt == 0:
                candidate = provider.generate_structured(
                    prompt=stage_prompt,
                    system_prompt=stage_sys_prompt,
                    schema_class=DesignDirection,
                )
            else:
                fb_prompt = f"{stage_prompt}\nAttempt {attempt} feedback: {'; '.join(last_errors)}"
                candidate = provider.repair_structured(
                    original_prompt=fb_prompt,
                    previous_output=previous_payload,
                    errors=last_errors,
                    schema_class=DesignDirection,
                )
            break
        except Exception as exc:
            last_errors = [f"Stage C attempt {attempt + 1} error: {exc}"]
            previous_payload = {"attempt": attempt + 1, "error": str(exc)}
            if repair_log is not None and attempt > 0:
                repair_log.append(
                    StageRepairRecord(
                        stage="StageC_DesignDirection",
                        attempt=attempt,
                        errors=list(last_errors),
                        resolved=False,
                    )
                )

    if candidate is None:
        candidate = resolve_benchmark_bundle(prompt).primary_direction

    # Stage D: WCAG AA contrast adjustment + Diversity Guard with bounded retry callback
    curated_pool = list_curated_directions()
    normalized_existing: list[tuple[str, LookFingerprint]] = [
        item if isinstance(item, tuple) else (f"prior-app-{idx + 1}", item)
        for idx, item in enumerate(existing_fingerprints or [])
    ]

    def _retry_on_collision(
        collision_diagnostics: list[str],
        attempt_num: int,
    ) -> DesignDirection:
        if repair_log is not None:
            repair_log.append(
                StageRepairRecord(
                    stage="StageD_DiversityGuard",
                    attempt=attempt_num,
                    errors=list(collision_diagnostics),
                    resolved=True,
                )
            )
        # Pick a curated direction not yet used and apply a distinct hue shift + radius/density/mode
        assert candidate is not None
        alt_idx = (attempt_num - 1) % len(curated_pool)
        alt = curated_pool[alt_idx]
        if alt.direction_id == candidate.direction_id:
            alt = curated_pool[(alt_idx + 1) % len(curated_pool)]
        return apply_bounded_adjustments(
            alt,
            hue_shift_deg=float((attempt_num * 45) % 60),
            radius_override=(
                RadiusClass.PILL
                if candidate.shape.radius_class != RadiusClass.PILL
                else RadiusClass.SHARP
            ),
            density_override=(
                DensityClass.SPACIOUS
                if candidate.density != DensityClass.SPACIOUS
                else DensityClass.COMPACT
            ),
            color_mode_override=(
                ColorMode.DARK if candidate.color_mode != ColorMode.DARK else ColorMode.LIGHT
            ),
        )

    final_direction, report, _ = resolve_diversity_with_retries(
        domain=domain,
        blueprint=blueprint,
        initial_direction=candidate,
        existing_fingerprints=normalized_existing,
        fallback_directions=curated_pool,
        retry_fn=_retry_on_collision,
        max_retries=max_retries,
    )
    return final_direction, report


def propose_three_directions(
    prompt: str,
    domain: DomainAnalysis,
    blueprint: AppBlueprint,
    primary_direction: DesignDirection,
    provider: Optional[ModelProvider] = None,
) -> list[DesignDirection]:
    """
    Returns 3 genuinely different, WCAG-verified DesignDirection options for the Build chooser.
    Option 0 is always the active/validated primary_direction.
    """
    proposals: list[DesignDirection] = [primary_direction.model_copy(deep=True)]
    seen_ids: set[str] = {primary_direction.direction_id}

    if provider is not None and isinstance(provider, MockProvider):
        bundle = resolve_benchmark_bundle(prompt)
        for p in bundle.direction_proposals:
            if p.direction_id not in seen_ids and len(proposals) < 3:
                adj_pal, _, _ = validate_and_adjust_palette(p.palette)
                proposals.append(p.model_copy(update={"palette": adj_pal}))
                seen_ids.add(p.direction_id)

    # Fill any remaining slots from curated library matching archetype or contrasting feel
    for prof in CURATED_DIRECTION_PROFILES.values():
        if len(proposals) >= 3:
            break
        if prof.direction.direction_id not in seen_ids:
            if domain.archetype in prof.typical_archetypes:
                proposals.append(prof.direction.model_copy(deep=True))
                seen_ids.add(prof.direction.direction_id)

    for prof in CURATED_DIRECTION_PROFILES.values():
        if len(proposals) >= 3:
            break
        if prof.direction.direction_id not in seen_ids:
            proposals.append(prof.direction.model_copy(deep=True))
            seen_ids.add(prof.direction.direction_id)

    return proposals[:3]


def apply_natural_language_restyle(
    current_direction: DesignDirection,
    instruction: str,
    blueprint: AppBlueprint,
    existing_fingerprints: Optional[list[LookFingerprint | tuple[str, LookFingerprint]]] = None,
) -> tuple[DesignDirection, StageDValidationReport]:
    """
    Applies a natural-language restyle prompt (e.g., 'make it darker', 'more playful',
    'denser tables', 'use green', 'editorial serif') and validates through Stage D.
    """
    text = instruction.lower().strip()
    base = current_direction.model_copy(deep=True)

    # Check if instruction asks for a specific curated personality
    if any(k in text for k in ("playful", "fun", "lively", "energetic", "bouncy")):
        base = get_curated_direction("playful_momentum")
    elif any(k in text for k in ("editorial", "calm", "serif", "warm paper", "literary")):
        base = get_curated_direction("editorial_calm")
    elif any(k in text for k in ("terminal", "console", "cyber", "hacker", "ops")):
        base = get_curated_direction("console_dark")
    elif any(k in text for k in ("clinical", "medical", "clean", "hospital")):
        base = get_curated_direction("clinical_clean")
    elif any(k in text for k in ("formal", "civic", "institutional", "government")):
        base = get_curated_direction("civic_formal")
    elif any(k in text for k in ("ledger", "accounting", "financial", "tabular")):
        base = get_curated_direction("ledger_precision")

    color_mode_override: Optional[ColorMode] = None
    if any(k in text for k in ("darker", "dark mode", "night", "dark theme", "carbon")):
        color_mode_override = ColorMode.DARK
    elif any(k in text for k in ("lighter", "light mode", "bright", "daylight")):
        color_mode_override = ColorMode.LIGHT

    density_override: Optional[DensityClass] = None
    if any(k in text for k in ("denser", "compact", "tight", "more rows", "high density")):
        density_override = DensityClass.COMPACT
    elif any(k in text for k in ("spacious", "airy", "roomy", "generous", "more space")):
        density_override = DensityClass.SPACIOUS
    elif "comfortable" in text:
        density_override = DensityClass.COMFORTABLE

    radius_override: Optional[RadiusClass] = None
    if any(k in text for k in ("pill", "rounded", "roundest")):
        radius_override = RadiusClass.PILL
    elif any(k in text for k in ("sharp", "square", "crisp corners", "brutalist")):
        radius_override = RadiusClass.SHARP
    elif "soft" in text:
        radius_override = RadiusClass.SOFT

    # Optional explicit color requests
    palette = base.palette.model_copy(deep=True)
    if "green" in text or "emerald" in text or "forest" in text:
        palette.primary = (
            "#166534" if (color_mode_override or base.color_mode) != ColorMode.DARK else "#34D399"
        )
        palette.focus_ring = palette.primary
    elif "blue" in text or "cobalt" in text or "navy" in text:
        palette.primary = (
            "#1D4ED8" if (color_mode_override or base.color_mode) != ColorMode.DARK else "#38BDF8"
        )
        palette.focus_ring = palette.primary
    elif "amber" in text or "orange" in text or "coral" in text:
        palette.primary = (
            "#B45309" if (color_mode_override or base.color_mode) != ColorMode.DARK else "#FBBF24"
        )
        palette.focus_ring = palette.primary
    elif "teal" in text or "cyan" in text:
        palette.primary = (
            "#0F766E" if (color_mode_override or base.color_mode) != ColorMode.DARK else "#2DD4BF"
        )
        palette.focus_ring = palette.primary
    elif "crimson" in text or "red" in text or "burgundy" in text:
        palette.primary = (
            "#991B1B" if (color_mode_override or base.color_mode) != ColorMode.DARK else "#F87171"
        )
        palette.focus_ring = palette.primary

    base = base.model_copy(update={"palette": palette})

    restyled = apply_bounded_adjustments(
        base,
        hue_shift_deg=0.0,
        radius_override=radius_override,
        density_override=density_override,
        color_mode_override=color_mode_override,
        monogram_override=current_direction.brand_mark.monogram_letters,
        rationale_override=f"{base.rationale} (Restyled: '{instruction.strip()}')",
    )

    normalized_existing: list[tuple[str, LookFingerprint]] = [
        item if isinstance(item, tuple) else (f"prior-app-{idx + 1}", item)
        for idx, item in enumerate(existing_fingerprints or [])
    ]

    validated_direction, report = validate_stage_d(
        domain=blueprint.domain,
        blueprint=blueprint,
        direction=restyled,
        existing_fingerprints=normalized_existing,
        generated_files=None,
        allow_opt_in_footer=False,
    )
    return validated_direction, report


def compile_adaptive_app(
    prompt: str,
    provider: Optional[ModelProvider] = None,
    existing_fingerprints: Optional[list[LookFingerprint]] = None,
    max_retries: int = 3,
) -> AdaptiveCompilationBundle:
    """
    Full Stage A -> Stage B -> Stage C -> Stage D compilation pipeline.
    Returns validated DomainAnalysis, AppBlueprint, DesignDirection, 3 proposals, and report.
    """
    active_provider = provider or MockProvider()
    repair_log: list[StageRepairRecord] = []

    domain = compile_domain_analysis(
        prompt=prompt,
        provider=active_provider,
        max_retries=max_retries,
        repair_log=repair_log,
    )
    blueprint = compile_app_blueprint(
        prompt=prompt,
        domain=domain,
        provider=active_provider,
        max_retries=max_retries,
        repair_log=repair_log,
    )
    direction, validation_report = compile_design_direction(
        prompt=prompt,
        domain=domain,
        blueprint=blueprint,
        provider=active_provider,
        existing_fingerprints=existing_fingerprints,
        max_retries=max_retries,
        repair_log=repair_log,
    )
    proposals = propose_three_directions(
        prompt=prompt,
        domain=domain,
        blueprint=blueprint,
        primary_direction=direction,
        provider=active_provider,
    )

    telemetry = list(getattr(active_provider, "telemetry_log", []))
    return AdaptiveCompilationBundle(
        prompt=prompt,
        domain_analysis=domain,
        blueprint=blueprint,
        design_direction=direction,
        direction_proposals=proposals,
        validation_report=validation_report,
        repair_log=repair_log,
        telemetry=telemetry,
    )
