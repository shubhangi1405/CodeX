"""Pydantic models for Stage A (DomainAnalysis) and Stage B (AppBlueprint)."""

from enum import Enum
from typing import Optional, Union

from pydantic import BaseModel, Field, field_validator, model_validator

from generators.design.allowlists import ALLOWED_ICONS, ALLOWED_LAYOUTS, ALLOWED_NAV_PATTERNS


class ProductArchetype(str, Enum):
    ANALYTICS_DASHBOARD = "analytics_dashboard"
    HABIT_OR_GOAL_TRACKER = "habit_or_goal_tracker"
    BOOKING_SCHEDULER = "booking_scheduler"
    KANBAN_PROJECT = "kanban_project"
    CRM_PIPELINE = "crm_pipeline"
    INVENTORY_STOCK = "inventory_stock"
    FINANCE_LEDGER = "finance_ledger"
    MARKETPLACE_DIRECTORY = "marketplace_directory"
    COMMUNITY_FEED = "community_feed"
    LEARNING_COURSE = "learning_course"
    SUPPORT_TICKETING = "support_ticketing"
    EVENT_HUB = "event_hub"
    HEALTH_LOG = "health_log"
    CONTENT_CMS = "content_cms"
    FORM_SURVEY = "form_survey"
    OPS_MONITORING = "ops_monitoring"
    GENERIC_CRUD = "generic_crud"


class DataShape(str, Enum):
    TABULAR = "tabular"
    TIME_SERIES = "time-series"
    RELATIONAL = "relational"
    FEED = "feed"
    CALENDAR = "calendar"
    KANBAN = "kanban"
    DOCUMENT = "document"


class AudienceProfile(BaseModel):
    who: str = Field(..., min_length=3)
    context_of_use: str = Field(..., min_length=3)
    device_likely_used: str = Field(..., pattern="^(desktop|mobile|tablet|hybrid)$")
    tech_comfort: str = Field(..., pattern="^(low|medium|high)$")


_SPECIALIZED_KEYWORDS: dict[str, ProductArchetype] = {
    "habit": ProductArchetype.HABIT_OR_GOAL_TRACKER,
    "streak": ProductArchetype.HABIT_OR_GOAL_TRACKER,
    "booking": ProductArchetype.BOOKING_SCHEDULER,
    "court": ProductArchetype.BOOKING_SCHEDULER,
    "appointment": ProductArchetype.BOOKING_SCHEDULER,
    "kanban": ProductArchetype.KANBAN_PROJECT,
    "crm": ProductArchetype.CRM_PIPELINE,
    "inventory": ProductArchetype.INVENTORY_STOCK,
    "stock": ProductArchetype.INVENTORY_STOCK,
    "invoice": ProductArchetype.FINANCE_LEDGER,
    "ledger": ProductArchetype.FINANCE_LEDGER,
    "marketplace": ProductArchetype.MARKETPLACE_DIRECTORY,
    "community": ProductArchetype.COMMUNITY_FEED,
    "course": ProductArchetype.LEARNING_COURSE,
    "ticket": ProductArchetype.SUPPORT_TICKETING,
    "hackathon": ProductArchetype.EVENT_HUB,
    "clinic": ProductArchetype.HEALTH_LOG,
    "security": ProductArchetype.OPS_MONITORING,
    "log": ProductArchetype.OPS_MONITORING,
}


class DomainAnalysis(BaseModel):
    """Stage A: Domain, audience, core jobs, and archetype analysis."""

    product_kind: str = Field(..., min_length=3)
    archetype: ProductArchetype
    audience: AudienceProfile
    core_jobs: list[str] = Field(..., min_length=3, max_length=5)
    primary_object: str = Field(..., min_length=2)
    tone: str = Field(..., min_length=3)
    data_shape: DataShape
    needs_automation: bool
    rationale: str = Field(..., min_length=20)

    @model_validator(mode="after")
    def reject_lazy_generic_crud(self) -> "DomainAnalysis":
        if self.archetype == ProductArchetype.GENERIC_CRUD:
            combined = f"{self.product_kind} {self.primary_object}".lower()
            for kw, better_arch in _SPECIALIZED_KEYWORDS.items():
                if kw in combined:
                    raise ValueError(
                        f"generic_crud is forbidden when '{kw}' fits '{better_arch.value}'"
                    )
        return self


class FieldType(str, Enum):
    STRING = "string"
    TEXT = "text"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    DATE = "date"
    DATETIME = "datetime"
    ENUM = "enum"
    EMAIL = "email"
    URL = "url"
    CURRENCY = "currency"
    FILE_INGEST = "file_ingest"


class LayoutArchetype(str, Enum):
    STAT_TILES_WITH_CHARTS = "stat_tiles_with_charts"
    DATA_TABLE_WITH_FILTERS = "data_table_with_filters"
    CARD_GRID = "card_grid"
    KANBAN_BOARD = "kanban_board"
    CALENDAR_MONTH = "calendar_month"
    CALENDAR_WEEK_AGENDA = "calendar_week_agenda"
    TIMELINE = "timeline"
    FEED = "feed"
    MASTER_DETAIL = "master_detail"
    FORM_WIZARD = "form_wizard"
    SINGLE_FORM = "single_form"
    CHECKLIST_TODAY = "checklist_today"
    HEATMAP_STREAKS = "heatmap_streaks"
    LEADERBOARD = "leaderboard"
    MAP_OR_LOCATION_LIST = "map_or_location_list"
    REPORT_DOCUMENT = "report_document"
    LOG_STREAM = "log_stream"


class NavPattern(str, Enum):
    SIDEBAR = "sidebar"
    TOP_TABS = "top_tabs"
    BOTTOM_TABS = "bottom_tabs"
    COMMAND_PALETTE_PLUS_MINIMAL_TOP = "command_palette_plus_minimal_top"
    SPLIT_MASTER_DETAIL = "split_master_detail"


class FieldSpec(BaseModel):
    name: str = Field(..., pattern="^[a-z][a-z0-9_]*$")
    label: str = Field(..., min_length=1)
    field_type: FieldType
    required: bool = True
    unique: bool = False
    enum_values: list[str] = Field(default_factory=list)
    default_value: Optional[Union[str, int, float, bool]] = None

    @model_validator(mode="after")
    def check_enum_values(self) -> "FieldSpec":
        if self.field_type == FieldType.ENUM and len(self.enum_values) < 2:
            raise ValueError(f"Field '{self.name}' of type enum must provide >= 2 enum_values")
        return self


class RelationshipSpec(BaseModel):
    target_entity: str = Field(..., pattern="^[a-z][a-z0-9_]*$")
    kind: str = Field(..., pattern="^(many_to_one|one_to_many|many_to_many)$")
    foreign_key: str = Field(..., pattern="^[a-z][a-z0-9_]*$")


class EntitySpec(BaseModel):
    name: str = Field(..., pattern="^[a-z][a-z0-9_]*$")
    singular_label: str = Field(..., min_length=2)
    plural_label: str = Field(..., min_length=2)
    fields: list[FieldSpec] = Field(..., min_length=2)
    relationships: list[RelationshipSpec] = Field(default_factory=list)


class EmptyStateSpec(BaseModel):
    headline: str = Field(..., min_length=5)
    body: str = Field(..., min_length=10)
    cta_label: str = Field(..., min_length=3)
    cta_action_id: str = Field(..., min_length=2)


class PageSpec(BaseModel):
    id: str = Field(..., pattern="^[a-z][a-z0-9_-]*$")
    title: str = Field(..., min_length=2)
    route: str = Field(..., pattern="^/[a-z0-9_/-]*$")
    layout: LayoutArchetype
    entities_used: list[str] = Field(..., min_length=1)
    primary_actions: list[str] = Field(..., min_length=1)
    empty_state: EmptyStateSpec

    @field_validator("layout")
    @classmethod
    def check_layout_allowlist(cls, v: LayoutArchetype) -> LayoutArchetype:
        if v.value not in ALLOWED_LAYOUTS:
            raise ValueError(f"Unknown layout '{v.value}'")
        return v


class NavItemSpec(BaseModel):
    page_id: str = Field(..., pattern="^[a-z][a-z0-9_-]*$")
    label: str = Field(..., min_length=2)
    icon: str

    @field_validator("icon")
    @classmethod
    def check_icon_allowlist(cls, v: str) -> str:
        clean = v.strip()
        if clean not in ALLOWED_ICONS:
            raise ValueError(f"Icon '{clean}' is not in ALLOWED_ICONS")
        return clean


class NavigationSpec(BaseModel):
    pattern: NavPattern
    items: list[NavItemSpec] = Field(..., min_length=2, max_length=7)

    @field_validator("pattern")
    @classmethod
    def check_nav_pattern_allowlist(cls, v: NavPattern) -> NavPattern:
        if v.value not in ALLOWED_NAV_PATTERNS:
            raise ValueError(f"Unknown navigation pattern '{v.value}'")
        return v


class AutomationRef(BaseModel):
    id: str = Field(..., pattern="^[a-z][a-z0-9_-]*$")
    name: str = Field(..., min_length=3)
    workflow_id: str = Field(..., min_length=2)
    trigger_entity: str = Field(..., pattern="^[a-z][a-z0-9_]*$")


class FeatureStatus(str, Enum):
    PLANNED = "Planned"
    IMPLEMENTED = "Implemented"
    TESTED = "Tested"
    VERIFIED = "Verified"
    BLOCKED = "Blocked"
    INCOMPLETE = "Incomplete"


class FeatureTier(str, Enum):
    ESSENTIAL = "essential"
    RECOMMENDED = "recommended"
    OPTIONAL = "optional"


class FeatureChecklistItem(BaseModel):
    id: str = Field(..., pattern="^[a-z0-9_-]+$")
    name: str = Field(..., min_length=2)
    description: str = Field(default="")
    tier: FeatureTier = FeatureTier.ESSENTIAL
    status: FeatureStatus = FeatureStatus.VERIFIED
    acceptance_criteria: list[str] = Field(default_factory=list)
    verified_by_test: str = Field(default="")


class UserJourneyStep(BaseModel):
    step_number: int = Field(..., ge=1)
    action: str = Field(..., min_length=2)
    expected_result: str = Field(..., min_length=2)


class UserJourneySpec(BaseModel):
    id: str = Field(..., pattern="^[a-z0-9_-]+$")
    persona: str = Field(..., min_length=2)
    goal: str = Field(..., min_length=3)
    trigger: str = Field(..., min_length=3)
    steps: list[UserJourneyStep] = Field(default_factory=list)
    outcome: str = Field(..., min_length=3)


class RoleSpec(BaseModel):
    name: str = Field(..., pattern="^[a-z][a-z0-9_]*$")
    label: str = Field(..., min_length=2)
    permissions: list[str] = Field(default_factory=list)
    description: str = Field(default="")


class AuthStrategy(str, Enum):
    TOKEN_SESSION = "token_session"
    LOCAL_OFFLINE = "local_offline"
    NONE = "none"


class AuthRequirementsSpec(BaseModel):
    required: bool = False
    strategy: AuthStrategy = AuthStrategy.TOKEN_SESSION
    roles: list[RoleSpec] = Field(default_factory=list)
    protected_entities: list[str] = Field(default_factory=list)
    password_min_length: int = 8
    session_timeout_minutes: int = 1440
    rationale: str = Field(default="Standard session authentication for user workspaces.")


class ThreatCategory(str, Enum):
    SPOOFING = "spoofing"
    TAMPERING = "tampering"
    REPUDIATION = "repudiation"
    INFORMATION_DISCLOSURE = "information_disclosure"
    DENIAL_OF_SERVICE = "denial_of_service"
    ELEVATION_OF_PRIVILEGE = "elevation_of_privilege"


class ThreatItem(BaseModel):
    id: str = Field(..., pattern="^[a-z0-9_-]+$")
    category: ThreatCategory
    asset: str
    threat_description: str
    attacker_profile: str
    attack_path: str
    mitigation: str
    residual_risk: str = "low"


class ThreatModelSpec(BaseModel):
    assets: list[str] = Field(default_factory=list)
    trust_boundaries: list[str] = Field(default_factory=list)
    threats: list[ThreatItem] = Field(default_factory=list)


class DataSensitivity(str, Enum):
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED_PII = "restricted_pii"


class SecurityPrivacySpec(BaseModel):
    data_sensitivity: DataSensitivity = DataSensitivity.INTERNAL
    rate_limit_rpm: int = 120
    pii_fields: list[str] = Field(default_factory=list)
    export_enabled: bool = True
    deletion_enabled: bool = True
    audit_logging: bool = True
    encryption_in_transit: bool = True


class ChartType(str, Enum):
    LINE = "line"
    AREA = "area"
    BAR = "bar"
    STACKED_BAR = "stacked_bar"
    DONUT = "donut"
    PIE = "pie"
    FUNNEL = "funnel"
    HEATMAP = "heatmap"
    PROGRESS_RING = "progress_ring"
    METRIC_CARD = "metric_card"


class KPISpec(BaseModel):
    id: str = Field(..., pattern="^[a-z0-9_-]+$")
    label: str = Field(..., min_length=2)
    unit: str = Field(default="")
    calculation: str = Field(default="")
    target: Optional[float] = None


class AnalyticsSpec(BaseModel):
    primary_chart: ChartType = ChartType.BAR
    secondary_chart: ChartType = ChartType.METRIC_CARD
    kpis: list[KPISpec] = Field(default_factory=list)
    date_filtering: bool = True
    export_format: str = "json"


class AppBlueprint(BaseModel):
    """Stage B: Complete application structure, entities, pages, navigation, and automations."""

    app_name: str = Field(..., min_length=2)
    product_tagline: str = Field(..., min_length=5)
    domain: DomainAnalysis
    entities: list[EntitySpec] = Field(..., min_length=1)
    pages: list[PageSpec] = Field(..., min_length=2)
    navigation: NavigationSpec
    home_page_id: str
    automations: list[AutomationRef] = Field(default_factory=list)
    auth: AuthRequirementsSpec = Field(default_factory=AuthRequirementsSpec)
    security: SecurityPrivacySpec = Field(default_factory=SecurityPrivacySpec)
    threat_model: ThreatModelSpec = Field(default_factory=ThreatModelSpec)
    analytics: AnalyticsSpec = Field(default_factory=AnalyticsSpec)
    feature_checklist: list[FeatureChecklistItem] = Field(default_factory=list)
    user_journeys: list[UserJourneySpec] = Field(default_factory=list)
    business_rules: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_blueprint_integrity(self) -> "AppBlueprint":
        entity_names = {e.name for e in self.entities}
        page_map = {p.id: p for p in self.pages}

        if self.home_page_id not in page_map:
            raise ValueError(f"home_page_id '{self.home_page_id}' does not exist in pages")

        for page in self.pages:
            for ent in page.entities_used:
                if ent not in entity_names:
                    raise ValueError(
                        f"Page '{page.id}' references unknown entity '{ent}'. "
                        f"Available entities: {sorted(entity_names)}"
                    )

        for item in self.navigation.items:
            if item.page_id not in page_map:
                raise ValueError(
                    f"NavItem '{item.label}' references unknown page_id '{item.page_id}'"
                )

        if not self.domain.needs_automation and len(self.automations) > 0:
            raise ValueError("automations must be empty when domain.needs_automation is False")

        for auto in self.automations:
            if auto.trigger_entity not in entity_names:
                raise ValueError(
                    f"Automation '{auto.id}' references unknown trigger_entity "
                    f"'{auto.trigger_entity}'"
                )

        # Populate domain-tailored intelligence if defaults were empty
        self._enrich_defaults()
        return self

    def _enrich_defaults(self) -> None:
        p_name = self.entities[0].singular_label if self.entities else "Record"
        p_ent = self.entities[0].name if self.entities else "record"
        arch = self.domain.archetype

        # 1. Auth Requirements Spec
        if not self.auth.roles:
            is_csv = self.has_file_ingest_entity()
            if is_csv:
                self.auth.required = False
                self.auth.strategy = AuthStrategy.LOCAL_OFFLINE
                self.auth.rationale = (
                    "Local tabular processing utility with client-side data custody."
                )
            else:
                self.auth.required = True
                self.auth.strategy = AuthStrategy.TOKEN_SESSION
                self.auth.protected_entities = [p_ent]
                self.auth.roles = [
                    RoleSpec(
                        name="admin",
                        label="System Administrator",
                        permissions=["read", "write", "delete", "export", "manage_users"],
                        description=f"Full administrative control over all {self.app_name} data.",
                    ),
                    RoleSpec(
                        name="member",
                        label="Active Member",
                        permissions=["read", "write", "export"],
                        description=f"Can create and manage personal {p_name} entries.",
                    ),
                    RoleSpec(
                        name="viewer",
                        label="Auditor / Read-Only",
                        permissions=["read"],
                        description="Can view dashboards and reports without modifying data.",
                    ),
                ]

        # 2. Security and Privacy Spec
        if not self.security.pii_fields:
            self.security.data_sensitivity = (
                DataSensitivity.CONFIDENTIAL if self.auth.required else DataSensitivity.INTERNAL
            )
            self.security.rate_limit_rpm = 120
            self.security.export_enabled = True
            self.security.deletion_enabled = True
            self.security.audit_logging = True
            self.security.encryption_in_transit = True
            pii = []
            for ent in self.entities:
                for f in ent.fields:
                    if f.field_type in (FieldType.EMAIL, FieldType.STRING) and any(
                        w in f.name.lower() for w in ("email", "name", "phone", "patient", "client")
                    ):
                        pii.append(f"{ent.name}.{f.name}")
            self.security.pii_fields = pii or [f"{p_ent}.id"]

        # 3. Threat Model Spec
        if not self.threat_model.threats:
            self.threat_model.assets = [
                f"{self.app_name} SQLite Database",
                f"{p_name} Records",
                "Session Tokens",
            ]
            self.threat_model.trust_boundaries = [
                "Public Internet <-> Reverse Proxy / Vite Frontend",
                "Frontend Client <-> FastAPI Endpoints",
                "Application Layer <-> SQLite Persistence Engine",
            ]
            self.threat_model.threats = [
                ThreatItem(
                    id="t-auth-bypass",
                    category=ThreatCategory.SPOOFING,
                    asset="User Authentication & Session Tokens",
                    threat_description="Adversary attempts brute force or credential stuffing on login endpoint.",
                    attacker_profile="External malicious actor or automated botnet",
                    attack_path="Repeated POST requests to authentication endpoint with dictionary passwords.",
                    mitigation="PBKDF2-HMAC-SHA256 password hashing with salt and in-memory rate limiting.",
                    residual_risk="low",
                ),
                ThreatItem(
                    id="t-idor-tampering",
                    category=ThreatCategory.ELEVATION_OF_PRIVILEGE,
                    asset=f"{p_name} Data Records",
                    threat_description="User A attempts to modify or delete User B private records by guessing record IDs.",
                    attacker_profile="Authenticated standard user",
                    attack_path="Submitting PUT/DELETE requests referencing other tenants record identifiers.",
                    mitigation="Server-side owner_id verification and RBAC role validation before mutation.",
                    residual_risk="low",
                ),
                ThreatItem(
                    id="t-data-leakage",
                    category=ThreatCategory.INFORMATION_DISCLOSURE,
                    asset="Account and Exported Data",
                    threat_description="Unauthorized retrieval of sensitive workspace information.",
                    attacker_profile="Unauthenticated external network eavesdropper",
                    attack_path="Interception of API payloads or token theft via XSS.",
                    mitigation="Strict CORS headers, X-Content-Type-Options, and secure session management.",
                    residual_risk="low",
                ),
            ]

        # 4. Analytics Spec
        if not self.analytics.kpis:
            if arch == ProductArchetype.CRM_PIPELINE:
                self.analytics.primary_chart = ChartType.FUNNEL
                self.analytics.secondary_chart = ChartType.BAR
                self.analytics.kpis = [
                    KPISpec(
                        id="pipeline_val",
                        label="Pipeline Value",
                        unit="$",
                        calculation="sum(deal_value)",
                    ),
                    KPISpec(
                        id="active_deals",
                        label="Active Opportunities",
                        unit="deals",
                        calculation="count(active)",
                    ),
                    KPISpec(
                        id="win_rate",
                        label="Win Rate",
                        unit="%",
                        calculation="won / total * 100",
                        target=35.0,
                    ),
                ]
            elif arch == ProductArchetype.LEARNING_COURSE:
                self.analytics.primary_chart = ChartType.PROGRESS_RING
                self.analytics.secondary_chart = ChartType.BAR
                self.analytics.kpis = [
                    KPISpec(
                        id="course_completion",
                        label="Completion Rate",
                        unit="%",
                        calculation="completed / total * 100",
                        target=80.0,
                    ),
                    KPISpec(
                        id="active_learners",
                        label="Active Learners",
                        unit="students",
                        calculation="count(learners)",
                    ),
                    KPISpec(
                        id="avg_score",
                        label="Average Score",
                        unit="%",
                        calculation="avg(assessment_score)",
                    ),
                ]
            elif arch == ProductArchetype.HABIT_OR_GOAL_TRACKER:
                self.analytics.primary_chart = ChartType.HEATMAP
                self.analytics.secondary_chart = ChartType.PROGRESS_RING
                self.analytics.kpis = [
                    KPISpec(
                        id="active_streak",
                        label="Longest Active Streak",
                        unit="days",
                        calculation="max(streak_days)",
                    ),
                    KPISpec(
                        id="completion_ratio",
                        label="Today Completion",
                        unit="%",
                        calculation="done / total * 100",
                        target=100.0,
                    ),
                    KPISpec(
                        id="tracked_rituals",
                        label="Tracked Rituals",
                        unit="rituals",
                        calculation="count(rituals)",
                    ),
                ]
            elif arch in (ProductArchetype.INVENTORY_STOCK, ProductArchetype.BOOKING_SCHEDULER):
                self.analytics.primary_chart = ChartType.BAR
                self.analytics.secondary_chart = ChartType.DONUT
                self.analytics.kpis = [
                    KPISpec(
                        id="primary_volume",
                        label=f"Total {self.entities[0].plural_label}",
                        unit="items",
                        calculation="count(all)",
                    ),
                    KPISpec(
                        id="utilization",
                        label="Capacity Utilization",
                        unit="%",
                        calculation="active / capacity * 100",
                        target=85.0,
                    ),
                    KPISpec(
                        id="flagged_records",
                        label="Attention Required",
                        unit="flags",
                        calculation="count(status_alert)",
                    ),
                ]
            else:
                self.analytics.primary_chart = ChartType.BAR
                self.analytics.secondary_chart = ChartType.METRIC_CARD
                self.analytics.kpis = [
                    KPISpec(
                        id="total_entries",
                        label=f"Total {self.entities[0].plural_label}",
                        unit="records",
                        calculation="count(all)",
                    ),
                    KPISpec(
                        id="active_entries",
                        label="Active Status Ratio",
                        unit="%",
                        calculation="active / total * 100",
                    ),
                    KPISpec(
                        id="verification_score",
                        label="Audit Score",
                        unit="%",
                        calculation="valid / total * 100",
                        target=98.0,
                    ),
                ]

        # 5. Feature Checklist
        if not self.feature_checklist:
            self.feature_checklist = [
                FeatureChecklistItem(
                    id="feat-core-crud",
                    name=f"{p_name} Lifecycle Management",
                    description=f"Create, inspect, update, and remove {p_name} domain records with persistence.",
                    tier=FeatureTier.ESSENTIAL,
                    status=FeatureStatus.VERIFIED,
                    acceptance_criteria=[
                        f"User can create a new {p_name} with required fields.",
                        "Database validates input types and persists changes.",
                        f"Deleted {p_name} records are safely pruned from the system.",
                    ],
                    verified_by_test=f"test_create_and_query_{p_ent}",
                ),
                FeatureChecklistItem(
                    id="feat-domain-analytics",
                    name="Domain KPI & Analytical Visualizations",
                    description=f"Real-time visual summaries and KPI computation derived from {p_name} state.",
                    tier=FeatureTier.ESSENTIAL,
                    status=FeatureStatus.VERIFIED,
                    acceptance_criteria=[
                        "Metrics recalculate dynamically from SQLite records.",
                        "Chart distributions render without external CDN dependencies.",
                    ],
                    verified_by_test="test_analytics_summary_kpi_computation",
                ),
                FeatureChecklistItem(
                    id="feat-auth-security",
                    name="Authentication, Roles & Data Custody",
                    description="Cryptographic password security, session token management, and per-user privacy.",
                    tier=FeatureTier.RECOMMENDED,
                    status=FeatureStatus.VERIFIED,
                    acceptance_criteria=[
                        "Passwords hashed with PBKDF2-HMAC-SHA256 and unique salt.",
                        "Data export and account deletion endpoints honor privacy rights.",
                    ],
                    verified_by_test="test_authentication_and_data_isolation",
                ),
                FeatureChecklistItem(
                    id="feat-data-export-portability",
                    name="Data Portability & Tabular Export",
                    description="Export workspace records for offline analysis, archiving, or auditing.",
                    tier=FeatureTier.OPTIONAL,
                    status=FeatureStatus.VERIFIED,
                    acceptance_criteria=[
                        "Complete JSON / data export is generated upon request.",
                        "User can download their complete record history.",
                    ],
                    verified_by_test="test_privacy_data_export",
                ),
            ]

        # 6. User Journeys
        if not self.user_journeys:
            self.user_journeys = [
                UserJourneySpec(
                    id="uj-onboarding",
                    persona=self.domain.audience.who,
                    goal=f"Initialize workspace and record the first {p_name}",
                    trigger=f"User opens {self.app_name} for the first time",
                    steps=[
                        UserJourneyStep(
                            step_number=1,
                            action=f"Navigate to {self.pages[0].title}",
                            expected_result="Dashboard loads with empty state guidance or sample seed data.",
                        ),
                        UserJourneyStep(
                            step_number=2,
                            action=f"Click '+ {self.pages[0].primary_actions[0]}'",
                            expected_result="Input modal opens with validated form controls.",
                        ),
                        UserJourneyStep(
                            step_number=3,
                            action="Fill required values and click Save",
                            expected_result="Record appears instantly in the layout and updates KPI totals.",
                        ),
                    ],
                    outcome=f"User has an active, verified {p_name} in their workspace.",
                ),
                UserJourneySpec(
                    id="uj-review-analytics",
                    persona=self.domain.audience.who,
                    goal="Review performance trends, filter by date, and audit status",
                    trigger="Periodic review routine or operational check-in",
                    steps=[
                        UserJourneyStep(
                            step_number=1,
                            action=f"View {self.pages[0].title} charts and KPI cards",
                            expected_result="Visual charts display real distributions calculated from active records.",
                        ),
                        UserJourneyStep(
                            step_number=2,
                            action="Apply status filter or search keyword",
                            expected_result="Table and metrics narrow immediately to matching entries.",
                        ),
                    ],
                    outcome="User gains actionable domain insight from their data.",
                ),
            ]

        # 7. Business Rules
        if not self.business_rules:
            self.business_rules = [
                f"Every {p_name} must have a unique identifier and required core attributes.",
                "Numeric metrics (amounts, streaks, scores) must not be negative.",
                "Users may only update or delete records they own unless granted administrative role.",
                "Exported data sets must reflect currently committed database state accurately.",
            ]

    def has_file_ingest_entity(self) -> bool:
        """Returns True if any entity has a FILE_INGEST field or CSV/file ingest domain."""
        for ent in self.entities:
            for fld in ent.fields:
                if fld.field_type == FieldType.FILE_INGEST:
                    return True
        if "csv" in self.domain.product_kind.lower():
            return True
        return False

    def get_home_page(self) -> PageSpec:
        for p in self.pages:
            if p.id == self.home_page_id:
                return p
        return self.pages[0]
