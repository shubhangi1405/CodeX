from datetime import datetime, timezone
from typing import Optional

from pydantic import BaseModel, Field

from generators.blueprint.schemas import AppBlueprint
from generators.design.schemas import DesignDirection, StageDValidationReport


class GeneratedFile(BaseModel):
    path: str
    content: str
    category: str  # "backend" | "frontend" | "config" | "docs"
    description: str
    size_bytes: int = 0

    def model_post_init(self, __context: object) -> None:
        if not self.size_bytes and self.content:
            self.size_bytes = len(self.content.encode("utf-8"))


class GeneratedAppManifest(BaseModel):
    project_id: str
    name: str
    version: int
    output_dir: str
    files: list[GeneratedFile] = Field(default_factory=list)
    routes: list[str] = Field(default_factory=list)
    models: list[str] = Field(default_factory=list)
    run_command_backend: str = "uvicorn main:app --reload --port 8000"
    run_command_frontend: str = "npm run dev"
    generated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    zip_path: Optional[str] = None
    blueprint: Optional[AppBlueprint] = None
    design_direction: Optional[DesignDirection] = None
    previous_design_direction: Optional[DesignDirection] = None
    direction_proposals: list[DesignDirection] = Field(default_factory=list)
    design_history_count: int = 0
    validation_report: Optional[StageDValidationReport] = None
