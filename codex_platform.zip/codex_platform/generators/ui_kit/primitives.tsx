import React from 'react';
import { AppIcon } from './icons';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  icon?: string;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  icon,
  children,
  style,
  ...rest
}) => {
  const variantStyles: Record<string, React.CSSProperties> = {
    primary: {
      backgroundColor: 'var(--app-primary)',
      color: 'var(--app-primary-fg)',
      border: '1px solid var(--app-primary)',
    },
    secondary: {
      backgroundColor: 'var(--app-surface-elevated)',
      color: 'var(--app-text)',
      border: '1px solid var(--app-border)',
    },
    ghost: {
      backgroundColor: 'transparent',
      color: 'var(--app-text-muted)',
      border: '1px solid transparent',
    },
    danger: {
      backgroundColor: 'var(--app-danger)',
      color: 'var(--app-surface-elevated)',
      border: '1px solid var(--app-danger)',
    },
  };

  return (
    <button
      type="button"
      style={{
        borderRadius: 'var(--app-radius-control)',
        padding: 'var(--app-pad-control)',
        fontFamily: 'var(--app-font-body)',
        fontWeight: 600,
        fontSize: '0.85rem',
        display: 'inline-flex',
        alignItems: 'center',
        gap: '0.45rem',
        cursor: 'pointer',
        transition: 'opacity var(--app-motion-duration) ease',
        ...variantStyles[variant],
        ...style,
      }}
      {...rest}
    >
      {icon && <AppIcon name={icon} size={15} />}
      <span>{children}</span>
    </button>
  );
};

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
}

export const Input: React.FC<InputProps> = ({ label, id, style, ...rest }) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
      {label && (
        <label
          htmlFor={id}
          style={{
            fontSize: '0.78rem',
            fontWeight: 600,
            color: 'var(--app-text)',
          }}
        >
          {label}
        </label>
      )}
      <input
        id={id}
        style={{
          backgroundColor: 'var(--app-surface-elevated)',
          color: 'var(--app-text)',
          border: '1px solid var(--app-border)',
          borderRadius: 'var(--app-radius-control)',
          padding: '0.45rem 0.75rem',
          fontSize: '0.85rem',
          fontFamily: 'var(--app-font-body)',
          ...style,
        }}
        {...rest}
      />
    </div>
  );
};

export interface SelectOption {
  value: string;
  label: string;
}

export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  options: SelectOption[];
}

export const Select: React.FC<SelectProps> = ({ label, id, options, style, ...rest }) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
      {label && (
        <label
          htmlFor={id}
          style={{
            fontSize: '0.78rem',
            fontWeight: 600,
            color: 'var(--app-text)',
          }}
        >
          {label}
        </label>
      )}
      <select
        id={id}
        style={{
          backgroundColor: 'var(--app-surface-elevated)',
          color: 'var(--app-text)',
          border: '1px solid var(--app-border)',
          borderRadius: 'var(--app-radius-control)',
          padding: '0.45rem 0.75rem',
          fontSize: '0.85rem',
          fontFamily: 'var(--app-font-body)',
          ...style,
        }}
        {...rest}
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
};

export interface DialogProps {
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}

export const Dialog: React.FC<DialogProps> = ({ open, title, onClose, children }) => {
  if (!open) return null;
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={title}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 50,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.45)',
        padding: '1rem',
      }}
    >
      <div
        style={{
          backgroundColor: 'var(--app-surface-elevated)',
          color: 'var(--app-text)',
          border: '1px solid var(--app-border)',
          borderRadius: 'var(--app-radius-card)',
          boxShadow: 'var(--app-shadow-card)',
          padding: 'var(--app-pad-card)',
          width: '100%',
          maxWidth: '30rem',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: '1rem',
            paddingBottom: '0.5rem',
            borderBottom: '1px solid var(--app-border)',
          }}
        >
          <h3 style={{ margin: 0, fontFamily: 'var(--app-font-heading)', fontSize: '1.05rem' }}>
            {title}
          </h3>
          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
        </div>
        {children}
      </div>
    </div>
  );
};

export interface DrawerProps {
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}

export const Drawer: React.FC<DrawerProps> = ({ open, title, onClose, children }) => {
  if (!open) return null;
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={title}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 50,
        display: 'flex',
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0, 0, 0, 0.35)',
      }}
    >
      <div
        style={{
          backgroundColor: 'var(--app-surface-elevated)',
          color: 'var(--app-text)',
          borderLeft: '1px solid var(--app-border)',
          padding: 'var(--app-pad-card)',
          width: '100%',
          maxWidth: '26rem',
          height: '100%',
          overflowY: 'auto',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: '1rem',
          }}
        >
          <h3 style={{ margin: 0, fontFamily: 'var(--app-font-heading)' }}>{title}</h3>
          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
        </div>
        {children}
      </div>
    </div>
  );
};

export interface TabItem {
  id: string;
  label: string;
  icon?: string;
}

export interface TabsProps {
  items: TabItem[];
  activeId: string;
  onSelect: (id: string) => void;
}

export const Tabs: React.FC<TabsProps> = ({ items, activeId, onSelect }) => {
  return (
    <div
      role="tablist"
      style={{
        display: 'flex',
        gap: '0.5rem',
        borderBottom: '1px solid var(--app-border)',
        paddingBottom: '0.25rem',
      }}
    >
      {items.map((item) => {
        const isActive = item.id === activeId;
        return (
          <button
            key={item.id}
            role="tab"
            aria-selected={isActive}
            onClick={() => onSelect(item.id)}
            style={{
              backgroundColor: isActive ? 'var(--app-primary)' : 'transparent',
              color: isActive ? 'var(--app-primary-fg)' : 'var(--app-text-muted)',
              borderRadius: 'var(--app-radius-control)',
              padding: '0.45rem 0.85rem',
              border: 'none',
              fontWeight: 600,
              fontSize: '0.82rem',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.4rem',
              cursor: 'pointer',
            }}
          >
            {item.icon && <AppIcon name={item.icon} size={14} />}
            <span>{item.label}</span>
          </button>
        );
      })}
    </div>
  );
};

export const Toast: React.FC<{ message: string; tone?: 'success' | 'warning' | 'danger' }> = ({
  message,
  tone = 'success',
}) => {
  const borderVar =
    tone === 'danger'
      ? 'var(--app-danger)'
      : tone === 'warning'
      ? 'var(--app-warning)'
      : 'var(--app-success)';
  return (
    <div
      role="status"
      style={{
        backgroundColor: 'var(--app-surface-elevated)',
        color: 'var(--app-text)',
        border: `2px solid ${borderVar}`,
        borderRadius: 'var(--app-radius-control)',
        padding: '0.6rem 1rem',
        fontSize: '0.82rem',
        fontWeight: 600,
        boxShadow: 'var(--app-shadow-card)',
      }}
    >
      {message}
    </div>
  );
};

export interface EmptyStateProps {
  headline: string;
  body: string;
  ctaLabel: string;
  onAction: () => void;
  secondaryLabel?: string;
  onSecondaryAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  headline,
  body,
  ctaLabel,
  onAction,
  secondaryLabel,
  onSecondaryAction,
}) => {
  return (
    <div
      style={{
        backgroundColor: 'var(--app-surface-elevated)',
        border: '1px dashed var(--app-border)',
        borderRadius: 'var(--app-radius-card)',
        padding: '2.5rem 1.5rem',
        textAlign: 'center',
        maxWidth: '34rem',
        margin: '1.5rem auto',
      }}
    >
      <h3
        style={{
          fontFamily: 'var(--app-font-heading)',
          fontSize: '1.15rem',
          color: 'var(--app-text)',
          margin: '0 0 0.5rem 0',
        }}
      >
        {headline}
      </h3>
      <p
        style={{
          color: 'var(--app-text-muted)',
          fontSize: '0.88rem',
          margin: '0 0 1.25rem 0',
          lineHeight: 1.5,
        }}
      >
        {body}
      </p>
      <div style={{ display: 'flex', justifyContent: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
        <Button variant="primary" icon="plus-circle" onClick={onAction}>
          {ctaLabel}
        </Button>
        {secondaryLabel && onSecondaryAction && (
          <Button variant="secondary" onClick={onSecondaryAction}>
            {secondaryLabel}
          </Button>
        )}
      </div>
    </div>
  );
};

export const Skeleton: React.FC<{ height?: string; width?: string }> = ({
  height = '1.25rem',
  width = '100%',
}) => (
  <div
    aria-hidden="true"
    style={{
      height,
      width,
      backgroundColor: 'var(--app-border)',
      opacity: 0.25,
      borderRadius: 'var(--app-radius-control)',
    }}
  />
);

export const Badge: React.FC<{
  children: React.ReactNode;
  tone?: 'default' | 'primary' | 'success' | 'warning' | 'danger';
}> = ({ children, tone = 'default' }) => {
  const colorMap: Record<string, { bg: string; fg: string; border: string }> = {
    default: {
      bg: 'var(--app-surface)',
      fg: 'var(--app-text)',
      border: 'var(--app-border)',
    },
    primary: {
      bg: 'var(--app-primary)',
      fg: 'var(--app-primary-fg)',
      border: 'var(--app-primary)',
    },
    success: {
      bg: 'var(--app-surface)',
      fg: 'var(--app-success)',
      border: 'var(--app-success)',
    },
    warning: {
      bg: 'var(--app-surface)',
      fg: 'var(--app-warning)',
      border: 'var(--app-warning)',
    },
    danger: {
      bg: 'var(--app-surface)',
      fg: 'var(--app-danger)',
      border: 'var(--app-danger)',
    },
  };
  const tok = colorMap[tone];

  return (
    <span
      style={{
        backgroundColor: tok.bg,
        color: tok.fg,
        border: `1px solid ${tok.border}`,
        borderRadius: 'var(--app-radius-control)',
        padding: '0.15rem 0.55rem',
        fontSize: '0.72rem',
        fontWeight: 600,
        fontFamily: 'var(--app-font-mono)',
        display: 'inline-flex',
        alignItems: 'center',
      }}
    >
      {children}
    </span>
  );
};

export const Avatar: React.FC<{ initials: string; size?: number }> = ({
  initials,
  size = 32,
}) => (
  <span
    style={{
      width: size,
      height: size,
      borderRadius: 'var(--app-radius-control)',
      backgroundColor: 'var(--app-primary)',
      color: 'var(--app-primary-fg)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontWeight: 700,
      fontSize: '0.75rem',
      fontFamily: 'var(--app-font-heading)',
    }}
  >
    {initials.slice(0, 2).toUpperCase()}
  </span>
);

export const Stat: React.FC<{
  label: string;
  value: string | number;
  detail?: string;
  icon?: string;
}> = ({ label, value, detail, icon }) => (
  <div
    style={{
      backgroundColor: 'var(--app-surface-elevated)',
      border: '1px solid var(--app-border)',
      borderRadius: 'var(--app-radius-card)',
      boxShadow: 'var(--app-shadow-card)',
      padding: 'var(--app-pad-card)',
    }}
  >
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <span style={{ fontSize: '0.78rem', color: 'var(--app-text-muted)', fontWeight: 600 }}>
        {label}
      </span>
      {icon && (
        <span style={{ color: 'var(--app-primary)' }}>
          <AppIcon name={icon} size={16} />
        </span>
      )}
    </div>
    <div
      style={{
        fontSize: '1.55rem',
        fontWeight: 700,
        fontFamily: 'var(--app-font-heading)',
        color: 'var(--app-text)',
        marginTop: '0.35rem',
      }}
    >
      {value}
    </div>
    {detail && (
      <div style={{ fontSize: '0.74rem', color: 'var(--app-text-muted)', marginTop: '0.25rem' }}>
        {detail}
      </div>
    )}
  </div>
);

export interface ChartBarDatum {
  label: string;
  value: number;
}

export const ChartWrapper: React.FC<{
  title: string;
  series: ChartBarDatum[];
  unit?: string;
}> = ({ title, series, unit = '' }) => {
  const maxVal = Math.max(1, ...series.map((s) => s.value));
  return (
    <div
      style={{
        backgroundColor: 'var(--app-surface-elevated)',
        border: '1px solid var(--app-border)',
        borderRadius: 'var(--app-radius-card)',
        boxShadow: 'var(--app-shadow-card)',
        padding: 'var(--app-pad-card)',
      }}
    >
      <h4
        style={{
          margin: '0 0 1rem 0',
          fontFamily: 'var(--app-font-heading)',
          fontSize: '0.92rem',
          color: 'var(--app-text)',
        }}
      >
        {title}
      </h4>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: `repeat(${Math.max(1, series.length)}, minmax(0, 1fr))`,
          gap: '0.75rem',
          alignItems: 'end',
          height: '9rem',
          paddingTop: '1rem',
        }}
      >
        {series.map((item) => {
          const pct = Math.max(12, Math.round((item.value / maxVal) * 100));
          return (
            <div
              key={item.label}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                height: '100%',
                justifyContent: 'flex-end',
                gap: '0.35rem',
              }}
            >
              <span style={{ fontSize: '0.72rem', fontFamily: 'var(--app-font-mono)' }}>
                {item.value}
                {unit}
              </span>
              <div
                style={{
                  width: '100%',
                  maxWidth: '2.75rem',
                  height: `${pct}%`,
                  backgroundColor: 'var(--app-primary)',
                  borderRadius: 'var(--app-radius-control)',
                }}
              />
              <span
                style={{
                  fontSize: '0.72rem',
                  color: 'var(--app-text-muted)',
                  textAlign: 'center',
                }}
              >
                {item.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
