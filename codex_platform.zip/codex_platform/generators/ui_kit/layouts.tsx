import React, { useState } from 'react';
import {
  Avatar,
  Badge,
  Button,
  ChartWrapper,
  EmptyState,
  Input,
  Select,
  Stat,
} from './primitives';

export interface FieldDef {
  name: string;
  label: string;
  fieldType: string;
  required?: boolean;
  enumValues?: string[];
}

export interface EntityDef {
  name: string;
  singularLabel: string;
  pluralLabel: string;
  fields: FieldDef[];
}

export interface EmptyStateDef {
  headline: string;
  body: string;
  ctaLabel: string;
  ctaActionId: string;
}

export type RecordItem = Record<string, string | number | boolean | null>;

export interface LayoutComponentProps {
  pageTitle: string;
  entity: EntityDef;
  records: RecordItem[];
  primaryActions: string[];
  emptyState: EmptyStateDef;
  onCreateRecord: (data: RecordItem) => void;
  onUpdateRecord?: (id: string | number, patch: Partial<RecordItem>) => void;
  onDeleteRecord?: (id: string | number) => void;
  onRequestCreateModal: () => void;
  onLoadSampleSeed?: () => void;
}

const cardStyle: React.CSSProperties = {
  backgroundColor: 'var(--app-surface-elevated)',
  border: '1px solid var(--app-border)',
  borderRadius: 'var(--app-radius-card)',
  boxShadow: 'var(--app-shadow-card)',
  padding: 'var(--app-pad-card)',
};

const PageHeader: React.FC<{
  title: string;
  subtitle: string;
  primaryActions: string[];
  onPrimaryClick: () => void;
}> = ({ title, subtitle, primaryActions, onPrimaryClick }) => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: '1.25rem',
      flexWrap: 'wrap',
      gap: '0.75rem',
    }}
  >
    <div>
      <h1
        style={{
          margin: 0,
          fontFamily: 'var(--app-font-heading)',
          fontSize: '1.4rem',
          color: 'var(--app-text)',
        }}
      >
        {title}
      </h1>
      <p style={{ margin: '0.2rem 0 0 0', fontSize: '0.82rem', color: 'var(--app-text-muted)' }}>
        {subtitle}
      </p>
    </div>
    <div style={{ display: 'flex', gap: '0.5rem' }}>
      {primaryActions.map((act, idx) => (
        <Button
          key={act}
          variant={idx === 0 ? 'primary' : 'secondary'}
          icon={idx === 0 ? 'plus-circle' : undefined}
          onClick={onPrimaryClick}
        >
          {act}
        </Button>
      ))}
    </div>
  </div>
);

function getPrimaryTextField(entity: EntityDef, rec: RecordItem): string {
  const firstStr = entity.fields.find((f) => f.fieldType === 'string' || f.fieldType === 'text');
  if (firstStr && rec[firstStr.name] !== undefined && rec[firstStr.name] !== null) {
    return String(rec[firstStr.name]);
  }
  const firstKey = entity.fields[0]?.name;
  return firstKey && rec[firstKey] !== undefined ? String(rec[firstKey]) : `Item ${rec.id ?? ''}`;
}

function getNumericValue(entity: EntityDef, rec: RecordItem): number {
  const numField = entity.fields.find(
    (f) =>
      f.fieldType === 'integer' || f.fieldType === 'float' || f.fieldType === 'currency'
  );
  if (numField) {
    const num = Number(rec[numField.name]);
    return Number.isFinite(num) ? num : 1;
  }
  return 1;
}

export const StatTilesWithChartsLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  if (records.length === 0) {
    return (
      <div data-layout="stat_tiles_with_charts">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  const totalNumeric = records.reduce((acc, r) => acc + getNumericValue(entity, r), 0);
  const series = records.slice(0, 6).map((r, i) => ({
    label: getPrimaryTextField(entity, r).slice(0, 12) || `#${i + 1}`,
    value: getNumericValue(entity, r),
  }));

  return (
    <div data-layout="stat_tiles_with_charts" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Real-time ${entity.pluralLabel.toLowerCase()} overview`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(14rem, 1fr))',
          gap: 'var(--app-gap-grid)',
        }}
      >
        <Stat
          label={`Total ${entity.pluralLabel}`}
          value={records.length}
          detail="Persisted records"
          icon="bar-chart-2"
        />
        <Stat
          label="Cumulative Metric"
          value={totalNumeric.toLocaleString()}
          detail={`Across ${records.length} ${entity.pluralLabel.toLowerCase()}`}
          icon="trending-up"
        />
        <Stat
          label="Average per Entry"
          value={(totalNumeric / Math.max(1, records.length)).toFixed(1)}
          detail="Live computed average"
          icon="activity"
        />
      </div>
      <ChartWrapper title={`${entity.pluralLabel} Distribution`} series={series} />
    </div>
  );
};

export const DataTableWithFiltersLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  const [query, setQuery] = useState('');

  if (records.length === 0) {
    return (
      <div data-layout="data_table_with_filters">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  const filtered = records.filter((rec) =>
    JSON.stringify(rec).toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div data-layout="data_table_with_filters" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Filter and inspect ${entity.pluralLabel.toLowerCase()}`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div style={cardStyle}>
        <div style={{ marginBottom: '1rem', maxWidth: '22rem' }}>
          <Input
            placeholder={`Filter ${entity.pluralLabel.toLowerCase()}...`}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.84rem' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--app-border)', textAlign: 'left' }}>
                {entity.fields.map((f) => (
                  <th key={f.name} style={{ padding: '0.6rem', color: 'var(--app-text-muted)' }}>
                    {f.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((rec, idx) => (
                <tr
                  key={String(rec.id ?? idx)}
                  style={{ borderBottom: '1px solid var(--app-border)' }}
                >
                  {entity.fields.map((f) => (
                    <td key={f.name} style={{ padding: '0.65rem', fontFamily: 'var(--app-font-body)' }}>
                      {String(rec[f.name] ?? '—')}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export const CardGridLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  if (records.length === 0) {
    return (
      <div data-layout="card_grid">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  return (
    <div data-layout="card_grid" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Browse ${entity.pluralLabel.toLowerCase()}`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(17rem, 1fr))',
          gap: 'var(--app-gap-grid)',
        }}
      >
        {records.map((rec, idx) => (
          <article key={String(rec.id ?? idx)} style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
              <strong style={{ fontFamily: 'var(--app-font-heading)', fontSize: '1rem' }}>
                {getPrimaryTextField(entity, rec)}
              </strong>
              <Badge tone="primary">{entity.singularLabel}</Badge>
            </div>
            <dl style={{ margin: 0, display: 'grid', gap: '0.3rem', fontSize: '0.8rem' }}>
              {entity.fields.slice(1).map((f) => (
                <div key={f.name} style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <dt style={{ color: 'var(--app-text-muted)' }}>{f.label}:</dt>
                  <dd style={{ margin: 0, fontWeight: 600 }}>{String(rec[f.name] ?? '—')}</dd>
                </div>
              ))}
            </dl>
          </article>
        ))}
      </div>
    </div>
  );
};

export const KanbanBoardLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  if (records.length === 0) {
    return (
      <div data-layout="kanban_board">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  const enumField = entity.fields.find((f) => f.fieldType === 'enum' && f.enumValues?.length);
  const lanes = enumField?.enumValues ?? ['Queued', 'Active', 'Completed'];

  return (
    <div data-layout="kanban_board" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Stage board for ${entity.pluralLabel.toLowerCase()}`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: `repeat(${lanes.length}, minmax(15rem, 1fr))`,
          gap: 'var(--app-gap-grid)',
        }}
      >
        {lanes.map((lane, laneIdx) => {
          const laneItems = records.filter((rec, i) =>
            enumField ? String(rec[enumField.name]) === lane : i % lanes.length === laneIdx
          );
          return (
            <div key={lane} style={cardStyle}>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '0.75rem',
                }}
              >
                <strong style={{ fontFamily: 'var(--app-font-heading)' }}>{lane}</strong>
                <Badge>{laneItems.length}</Badge>
              </div>
              <div style={{ display: 'grid', gap: '0.55rem' }}>
                {laneItems.map((item, idx) => (
                  <div
                    key={String(item.id ?? idx)}
                    style={{
                      backgroundColor: 'var(--app-surface)',
                      border: '1px solid var(--app-border)',
                      borderRadius: 'var(--app-radius-control)',
                      padding: '0.65rem',
                    }}
                  >
                    <div style={{ fontWeight: 600, fontSize: '0.85rem' }}>
                      {getPrimaryTextField(entity, item)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const CalendarMonthLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  if (records.length === 0) {
    return (
      <div data-layout="calendar_month">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  const days = Array.from({ length: 28 }, (_, i) => i + 1);
  return (
    <div data-layout="calendar_month" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Monthly schedule of ${entity.pluralLabel.toLowerCase()}`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(7, minmax(0, 1fr))',
          gap: '0.45rem',
        }}
      >
        {days.map((day) => {
          const dayRecs = records.filter((_, idx) => (idx % 28) + 1 === day);
          return (
            <div key={day} style={{ ...cardStyle, minHeight: '5.2rem', padding: '0.5rem' }}>
              <div style={{ fontSize: '0.72rem', color: 'var(--app-text-muted)', fontWeight: 700 }}>
                Day {day}
              </div>
              {dayRecs.map((r, i) => (
                <div key={i} style={{ marginTop: '0.25rem' }}>
                  <Badge tone="primary">{getPrimaryTextField(entity, r).slice(0, 12)}</Badge>
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const CalendarWeekAgendaLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  if (records.length === 0) {
    return (
      <div data-layout="calendar_week_agenda">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  return (
    <div data-layout="calendar_week_agenda" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Weekly appointment & slot agenda (${records.length} scheduled)`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div style={{ display: 'grid', gap: '0.65rem' }}>
        {records.map((rec, idx) => (
          <div
            key={String(rec.id ?? idx)}
            style={{
              ...cardStyle,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
              <Badge tone="primary">{String(rec[entity.fields[1]?.name ?? ''] ?? `0${idx + 8}:00`)}</Badge>
              <div>
                <div style={{ fontWeight: 700, fontFamily: 'var(--app-font-heading)' }}>
                  {getPrimaryTextField(entity, rec)}
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--app-text-muted)' }}>
                  {entity.fields
                    .slice(1)
                    .map((f) => `${f.label}: ${String(rec[f.name] ?? '—')}`)
                    .join(' • ')}
                </div>
              </div>
            </div>
            <Badge tone="success">Confirmed</Badge>
          </div>
        ))}
      </div>
    </div>
  );
};

export const TimelineLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  if (records.length === 0) {
    return (
      <div data-layout="timeline">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  return (
    <div data-layout="timeline" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Chronological ${entity.pluralLabel.toLowerCase()} stream`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div
        style={{
          borderLeft: '2px solid var(--app-primary)',
          paddingLeft: '1.25rem',
          display: 'grid',
          gap: '0.85rem',
        }}
      >
        {records.map((rec, idx) => (
          <div key={String(rec.id ?? idx)} style={cardStyle}>
            <div style={{ fontWeight: 700, fontFamily: 'var(--app-font-heading)' }}>
              {getPrimaryTextField(entity, rec)}
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--app-text-muted)', marginTop: '0.25rem' }}>
              {entity.fields
                .slice(1)
                .map((f) => `${f.label}: ${String(rec[f.name] ?? '—')}`)
                .join(' · ')}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const FeedLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  if (records.length === 0) {
    return (
      <div data-layout="feed">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  return (
    <div data-layout="feed" style={{ display: 'grid', gap: 'var(--app-gap-grid)', maxWidth: '48rem' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Live collaborative ${entity.pluralLabel.toLowerCase()} feed`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      {records.map((rec, idx) => {
        const title = getPrimaryTextField(entity, rec);
        return (
          <article key={String(rec.id ?? idx)} style={cardStyle}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.6rem' }}>
              <Avatar initials={title.slice(0, 2) || 'TM'} />
              <div>
                <div style={{ fontWeight: 700, fontFamily: 'var(--app-font-heading)' }}>{title}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--app-text-muted)' }}>
                  Active {entity.singularLabel}
                </div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '0.45rem', flexWrap: 'wrap', marginTop: '0.5rem' }}>
              {entity.fields.slice(1).map((f) => (
                <Badge key={f.name}>
                  {f.label}: {String(rec[f.name] ?? '—')}
                </Badge>
              ))}
            </div>
          </article>
        );
      })}
    </div>
  );
};

export const MasterDetailLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  const [selectedIndex, setSelectedIndex] = useState(0);

  if (records.length === 0) {
    return (
      <div data-layout="master_detail">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  const activeRec = records[Math.min(selectedIndex, records.length - 1)] ?? records[0];

  return (
    <div data-layout="master_detail" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Inspect ${entity.pluralLabel.toLowerCase()} in detail`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div style={{ display: 'grid', gridTemplateColumns: '18rem 1fr', gap: 'var(--app-gap-grid)' }}>
        <div style={{ ...cardStyle, display: 'grid', gap: '0.4rem', alignContent: 'start' }}>
          {records.map((rec, idx) => {
            const selected = idx === selectedIndex;
            return (
              <button
                key={String(rec.id ?? idx)}
                type="button"
                onClick={() => setSelectedIndex(idx)}
                style={{
                  backgroundColor: selected ? 'var(--app-primary)' : 'var(--app-surface)',
                  color: selected ? 'var(--app-primary-fg)' : 'var(--app-text)',
                  border: '1px solid var(--app-border)',
                  borderRadius: 'var(--app-radius-control)',
                  padding: '0.6rem 0.75rem',
                  textAlign: 'left',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                {getPrimaryTextField(entity, rec)}
              </button>
            );
          })}
        </div>
        <div style={cardStyle}>
          <h3 style={{ marginTop: 0, fontFamily: 'var(--app-font-heading)' }}>
            {getPrimaryTextField(entity, activeRec)}
          </h3>
          <dl style={{ display: 'grid', gap: '0.6rem', fontSize: '0.88rem' }}>
            {entity.fields.map((f) => (
              <div
                key={f.name}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  borderBottom: '1px solid var(--app-border)',
                  paddingBottom: '0.4rem',
                }}
              >
                <dt style={{ color: 'var(--app-text-muted)' }}>{f.label}</dt>
                <dd style={{ margin: 0, fontWeight: 600 }}>{String(activeRec[f.name] ?? '—')}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
};

export const FormWizardLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, onCreateRecord } = props;
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState<RecordItem>({});

  const mid = Math.max(1, Math.ceil(entity.fields.length / 2));
  const stepFields = step === 0 ? entity.fields.slice(0, mid) : entity.fields.slice(mid);

  return (
    <div data-layout="form_wizard" style={{ maxWidth: '38rem', margin: '0 auto' }}>
      <div style={cardStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
          <h2 style={{ margin: 0, fontFamily: 'var(--app-font-heading)' }}>{pageTitle}</h2>
          <Badge tone="primary">Step {step + 1} of 2</Badge>
        </div>
        <div style={{ display: 'grid', gap: '0.85rem', marginBottom: '1.25rem' }}>
          {stepFields.map((f) => (
            <Input
              key={f.name}
              id={`wiz-${f.name}`}
              label={f.label}
              value={String(draft[f.name] ?? '')}
              onChange={(e) => setDraft({ ...draft, [f.name]: e.target.value })}
            />
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <Button variant="secondary" disabled={step === 0} onClick={() => setStep(0)}>
            Previous
          </Button>
          {step === 0 ? (
            <Button variant="primary" onClick={() => setStep(1)}>
              Continue
            </Button>
          ) : (
            <Button
              variant="primary"
              onClick={() => {
                onCreateRecord(draft);
                setDraft({});
                setStep(0);
              }}
            >
              Submit {entity.singularLabel}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export const SingleFormLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, onCreateRecord } = props;
  const [draft, setDraft] = useState<RecordItem>({});

  return (
    <div data-layout="single_form" style={{ maxWidth: '36rem', margin: '0 auto' }}>
      <form
        style={cardStyle}
        onSubmit={(e) => {
          e.preventDefault();
          onCreateRecord(draft);
          setDraft({});
        }}
      >
        <h2 style={{ marginTop: 0, fontFamily: 'var(--app-font-heading)' }}>{pageTitle}</h2>
        <div style={{ display: 'grid', gap: '0.85rem', marginBottom: '1.25rem' }}>
          {entity.fields.map((f) =>
            f.fieldType === 'enum' && f.enumValues ? (
              <Select
                key={f.name}
                id={`form-${f.name}`}
                label={f.label}
                options={f.enumValues.map((v) => ({ value: v, label: v }))}
                value={String(draft[f.name] ?? f.enumValues[0] ?? '')}
                onChange={(e) => setDraft({ ...draft, [f.name]: e.target.value })}
              />
            ) : (
              <Input
                key={f.name}
                id={`form-${f.name}`}
                label={f.label}
                value={String(draft[f.name] ?? '')}
                onChange={(e) => setDraft({ ...draft, [f.name]: e.target.value })}
              />
            )
          )}
        </div>
        <Button type="submit" variant="primary" icon="check-circle">
          Save {entity.singularLabel}
        </Button>
      </form>
    </div>
  );
};

export const ChecklistTodayLayout: React.FC<LayoutComponentProps> = (props) => {
  const {
    pageTitle,
    entity,
    records,
    primaryActions,
    emptyState,
    onRequestCreateModal,
    onUpdateRecord,
  } = props;

  if (records.length === 0) {
    return (
      <div data-layout="checklist_today">
        <PageHeader
          title={pageTitle}
          subtitle={`Daily ${entity.pluralLabel.toLowerCase()} checklist`}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  return (
    <div data-layout="checklist_today" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Mark today's ${entity.pluralLabel.toLowerCase()} complete`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div style={{ display: 'grid', gap: '0.6rem' }}>
        {records.map((rec, idx) => {
          const done = Boolean(rec.completed);
          return (
            <div
              key={String(rec.id ?? idx)}
              style={{
                ...cardStyle,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}
            >
              <label style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={done}
                  onChange={() =>
                    onUpdateRecord?.(rec.id ? String(rec.id) : idx, { completed: !done })
                  }
                />
                <span style={{ fontWeight: 600, fontFamily: 'var(--app-font-heading)' }}>
                  {getPrimaryTextField(entity, rec)}
                </span>
              </label>
              <Badge tone={done ? 'success' : 'default'}>
                {done ? 'Completed' : `${getNumericValue(entity, rec)} streak`}
              </Badge>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const HeatmapStreaksLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  if (records.length === 0) {
    return (
      <div data-layout="heatmap_streaks">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  return (
    <div data-layout="heatmap_streaks" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Consistency & streak heatmap across ${records.length} ${entity.pluralLabel.toLowerCase()}`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div style={{ display: 'grid', gap: '0.75rem' }}>
        {records.map((rec, idx) => (
          <div key={String(rec.id ?? idx)} style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
              <strong style={{ fontFamily: 'var(--app-font-heading)' }}>
                {getPrimaryTextField(entity, rec)}
              </strong>
              <Badge tone="primary">{getNumericValue(entity, rec)} day streak</Badge>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(14, 1fr)', gap: '0.25rem' }}>
              {Array.from({ length: 14 }, (_, cellIdx) => {
                const active = (cellIdx + idx) % 3 !== 0;
                return (
                  <div
                    key={cellIdx}
                    style={{
                      height: '1.25rem',
                      borderRadius: 'var(--app-radius-control)',
                      backgroundColor: active ? 'var(--app-primary)' : 'var(--app-surface)',
                      border: '1px solid var(--app-border)',
                    }}
                  />
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const LeaderboardLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  if (records.length === 0) {
    return (
      <div data-layout="leaderboard">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  const sorted = [...records].sort(
    (a, b) => getNumericValue(entity, b) - getNumericValue(entity, a)
  );

  return (
    <div data-layout="leaderboard" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Ranked ${entity.pluralLabel.toLowerCase()}`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div style={cardStyle}>
        {sorted.map((rec, idx) => (
          <div
            key={String(rec.id ?? idx)}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '0.65rem 0',
              borderBottom: '1px solid var(--app-border)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <Badge tone={idx === 0 ? 'primary' : 'default'}>#{idx + 1}</Badge>
              <strong>{getPrimaryTextField(entity, rec)}</strong>
            </div>
            <span style={{ fontFamily: 'var(--app-font-mono)', fontWeight: 700 }}>
              {getNumericValue(entity, rec)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export const MapOrLocationListLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  if (records.length === 0) {
    return (
      <div data-layout="map_or_location_list">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  return (
    <div data-layout="map_or_location_list" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Locations & zones (${records.length})`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div style={{ display: 'grid', gap: '0.65rem' }}>
        {records.map((rec, idx) => (
          <div
            key={String(rec.id ?? idx)}
            style={{
              ...cardStyle,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <div>
              <strong style={{ fontFamily: 'var(--app-font-heading)' }}>
                {getPrimaryTextField(entity, rec)}
              </strong>
              <div style={{ fontSize: '0.8rem', color: 'var(--app-text-muted)' }}>
                {entity.fields
                  .slice(1)
                  .map((f) => `${f.label}: ${String(rec[f.name] ?? '—')}`)
                  .join(' • ')}
              </div>
            </div>
            <Badge tone="primary">Zone {idx + 1}</Badge>
          </div>
        ))}
      </div>
    </div>
  );
};

export const ReportDocumentLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  if (records.length === 0) {
    return (
      <div data-layout="report_document">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  const total = records.reduce((acc, r) => acc + getNumericValue(entity, r), 0);

  return (
    <div data-layout="report_document" style={{ maxWidth: '52rem', margin: '0 auto' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Structured ${entity.singularLabel} statement`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <article style={cardStyle}>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            borderBottom: '2px solid var(--app-border)',
            paddingBottom: '0.85rem',
            marginBottom: '1rem',
          }}
        >
          <div>
            <h2 style={{ margin: 0, fontFamily: 'var(--app-font-heading)' }}>
              {entity.pluralLabel} Summary Statement
            </h2>
            <span style={{ fontSize: '0.78rem', color: 'var(--app-text-muted)' }}>
              Verified Ledger Count: {records.length}
            </span>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: '0.75rem', color: 'var(--app-text-muted)' }}>Total Value</div>
            <div style={{ fontSize: '1.35rem', fontWeight: 700, fontFamily: 'var(--app-font-mono)' }}>
              {total.toLocaleString()}
            </div>
          </div>
        </div>
        <div style={{ display: 'grid', gap: '0.5rem' }}>
          {records.map((rec, idx) => (
            <div
              key={String(rec.id ?? idx)}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                padding: '0.5rem 0',
                borderBottom: '1px solid var(--app-border)',
              }}
            >
              <span>{getPrimaryTextField(entity, rec)}</span>
              <span style={{ fontFamily: 'var(--app-font-mono)', fontWeight: 600 }}>
                {getNumericValue(entity, rec).toLocaleString()}
              </span>
            </div>
          ))}
        </div>
      </article>
    </div>
  );
};

export const LogStreamLayout: React.FC<LayoutComponentProps> = (props) => {
  const { pageTitle, entity, records, primaryActions, emptyState, onRequestCreateModal } = props;
  const [filterText, setFilterText] = useState('');

  if (records.length === 0) {
    return (
      <div data-layout="log_stream">
        <PageHeader
          title={pageTitle}
          subtitle={entity.pluralLabel}
          primaryActions={primaryActions}
          onPrimaryClick={onRequestCreateModal}
        />
        <EmptyState
          headline={emptyState.headline}
          body={emptyState.body}
          ctaLabel={emptyState.ctaLabel}
          onAction={onRequestCreateModal}
          secondaryLabel={props.onLoadSampleSeed ? 'Load Sample Seed Data' : undefined}
          onSecondaryAction={props.onLoadSampleSeed}
        />
      </div>
    );
  }

  const matching = records.filter((r) =>
    JSON.stringify(r).toLowerCase().includes(filterText.toLowerCase())
  );

  return (
    <div data-layout="log_stream" style={{ display: 'grid', gap: 'var(--app-gap-grid)' }}>
      <PageHeader
        title={pageTitle}
        subtitle={`Live telemetry stream (${matching.length} events)`}
        primaryActions={primaryActions}
        onPrimaryClick={onRequestCreateModal}
      />
      <div style={cardStyle}>
        <div style={{ marginBottom: '0.75rem', maxWidth: '24rem' }}>
          <Input
            placeholder="Filter stream by severity, host, or message..."
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
          />
        </div>
        <div
          style={{
            display: 'grid',
            gap: '0.35rem',
            fontFamily: 'var(--app-font-mono)',
            fontSize: '0.78rem',
          }}
        >
          {matching.map((rec, idx) => {
            const raw = JSON.stringify(rec).toLowerCase();
            const tone =
              raw.includes('crit') || raw.includes('high') || raw.includes('err')
                ? 'danger'
                : raw.includes('warn')
                ? 'warning'
                : 'success';
            return (
              <div
                key={String(rec.id ?? idx)}
                style={{
                  backgroundColor: 'var(--app-surface)',
                  border: '1px solid var(--app-border)',
                  borderRadius: 'var(--app-radius-control)',
                  padding: '0.5rem 0.75rem',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '0.75rem',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                  <Badge tone={tone}>{tone.toUpperCase()}</Badge>
                  <span style={{ fontWeight: 600 }}>{getPrimaryTextField(entity, rec)}</span>
                </div>
                <span style={{ color: 'var(--app-text-muted)' }}>
                  {entity.fields
                    .slice(1)
                    .map((f) => `${f.name}=${String(rec[f.name] ?? '')}`)
                    .join(' ')}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export interface AdaptiveLayoutRendererProps extends LayoutComponentProps {
  layout: string;
}

export const AdaptiveLayoutRenderer: React.FC<AdaptiveLayoutRendererProps> = ({
  layout,
  ...rest
}) => {
  switch (layout) {
    case 'stat_tiles_with_charts':
      return <StatTilesWithChartsLayout {...rest} />;
    case 'data_table_with_filters':
      return <DataTableWithFiltersLayout {...rest} />;
    case 'card_grid':
      return <CardGridLayout {...rest} />;
    case 'kanban_board':
      return <KanbanBoardLayout {...rest} />;
    case 'calendar_month':
      return <CalendarMonthLayout {...rest} />;
    case 'calendar_week_agenda':
      return <CalendarWeekAgendaLayout {...rest} />;
    case 'timeline':
      return <TimelineLayout {...rest} />;
    case 'feed':
      return <FeedLayout {...rest} />;
    case 'master_detail':
      return <MasterDetailLayout {...rest} />;
    case 'form_wizard':
      return <FormWizardLayout {...rest} />;
    case 'single_form':
      return <SingleFormLayout {...rest} />;
    case 'checklist_today':
      return <ChecklistTodayLayout {...rest} />;
    case 'heatmap_streaks':
      return <HeatmapStreaksLayout {...rest} />;
    case 'leaderboard':
      return <LeaderboardLayout {...rest} />;
    case 'map_or_location_list':
      return <MapOrLocationListLayout {...rest} />;
    case 'report_document':
      return <ReportDocumentLayout {...rest} />;
    case 'log_stream':
      return <LogStreamLayout {...rest} />;
    default:
      return <CardGridLayout {...rest} />;
  }
};
