"""8-tuple look fingerprint, pairwise diversity guard, and Stage D no-leakage scanner."""

import re
from typing import Callable, Optional

from generators.blueprint.schemas import AppBlueprint, DomainAnalysis
from generators.design.contrast import primary_hue_bucket, validate_and_adjust_palette
from generators.design.schemas import (
    DesignDirection,
    LookFingerprint,
    StageDValidationReport,
)

FINGERPRINT_FIELD_NAMES: tuple[str, ...] = (
    "archetype",
    "nav_pattern",
    "home_layout",
    "primary_hue_bucket",
    "heading_font",
    "radius_class",
    "density",
    "color_mode",
)


def compute_fingerprint(
    domain: DomainAnalysis,
    blueprint: AppBlueprint,
    direction: DesignDirection,
) -> LookFingerprint:
    """Computes the 8-tuple look fingerprint for a generated application."""
    home_page = blueprint.get_home_page()
    return LookFingerprint(
        archetype=domain.archetype.value,
        nav_pattern=blueprint.navigation.pattern.value,
        home_layout=home_page.layout.value,
        primary_hue_bucket=primary_hue_bucket(direction.palette.primary),
        heading_font=direction.typography.heading_font,
        radius_class=direction.shape.radius_class.value,
        density=direction.density.value,
        color_mode=direction.color_mode.value,
    )


def fingerprint_distance(fp_a: LookFingerprint, fp_b: LookFingerprint) -> int:
    """Returns the number of differing attributes (0..8) between two look fingerprints."""
    tuple_a = fp_a.as_tuple()
    tuple_b = fp_b.as_tuple()
    return sum(1 for a, b in zip(tuple_a, tuple_b, strict=True) if a != b)


def check_diversity_guard(
    candidate: LookFingerprint,
    existing: list[tuple[str, LookFingerprint]],
    min_distance: int = 4,
) -> tuple[bool, int, list[str]]:
    """
    Compares candidate fingerprint against all previously generated app fingerprints.
    Requires pairwise distance >= min_distance (default 4 of 8 attributes).
    """
    if not existing:
        return True, 8, []

    diagnostics: list[str] = []
    min_observed = 8
    cand_tuple = candidate.as_tuple()

    for app_name, prev_fp in existing:
        dist = fingerprint_distance(candidate, prev_fp)
        if dist < min_observed:
            min_observed = dist
        if dist < min_distance:
            prev_tuple = prev_fp.as_tuple()
            matching_attrs = [
                f"{FINGERPRINT_FIELD_NAMES[i]}={cand_tuple[i]!r}"
                for i in range(8)
                if cand_tuple[i] == prev_tuple[i]
            ]
            diagnostics.append(
                f"Collision with '{app_name}': distance={dist}/8 (requires >={min_distance}). "
                f"Matching attributes ({len(matching_attrs)}): {', '.join(matching_attrs)}. "
                f"Conflicting fingerprint: {prev_fp.model_dump()}"
            )

    return len(diagnostics) == 0, min_observed, diagnostics


_GW_LOGO_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("GW logo monogram in markup", re.compile(r">\s*GW\s*<")),
    ("CX logo monogram in markup", re.compile(r">\s*CX\s*<")),
    ("Production Verified badge", re.compile(r"Production\s+Verified", re.IGNORECASE)),
    (
        "Bit-for-Bit Determinism badge",
        re.compile(r"Bit-for-Bit\s+Determinism", re.IGNORECASE),
    ),
    ("Hardcoded demo dataset (14250.00)", re.compile(r"14250\.00")),
    ("Hardcoded demo dataset (18400.50)", re.compile(r"18400\.50")),
    ("Hardcoded demo filename (monthly_sales.csv)", re.compile(r"monthly_sales\.csv")),
    ("Unpinned Tailwind CDN", re.compile(r"cdn\.tailwindcss\.com", re.IGNORECASE)),
    ("Unpinned Lucide CDN", re.compile(r"unpkg\.com/lucide", re.IGNORECASE)),
]


def scan_generated_source_for_leakage(
    files: dict[str, str],
    has_file_ingest_entity: bool,
    allow_opt_in_footer: bool = False,
) -> list[str]:
    """
    Scans generated source files for forbidden brand leakage, hardcoded demo data,
    unpinned CDNs, and CSV/upload UI when the blueprint has no file-ingest entity.
    """
    violations: list[str] = []

    for path, content in files.items():
        for label, pattern in _GW_LOGO_PATTERNS:
            if pattern.search(content):
                violations.append(f"{path}: forbidden {label}")

        # Check CodeX & Ghostwriter platform branding
        for brand_name in ("CodeX", "Ghostwriter"):
            if re.search(rf"\b{brand_name}\b", content, re.IGNORECASE):
                if not allow_opt_in_footer:
                    violations.append(f"{path}: forbidden '{brand_name}' branding leak")
                else:
                    # Even with opt-in footer, header/title cannot say Powered by CodeX/Ghostwriter
                    if re.search(rf"<title>[^<]*{brand_name}", content, re.IGNORECASE):
                        violations.append(f"{path}: forbidden '{brand_name}' in <title>")

        # Check CSV leakage when blueprint has no file_ingest entity
        if not has_file_ingest_entity:
            if re.search(r"\bcsv\b", content, re.IGNORECASE):
                violations.append(
                    f"{path}: contains 'CSV' reference in a non-file-ingest application"
                )
            if re.search(r'accept=["\']\.csv["\']', content, re.IGNORECASE):
                violations.append(
                    f"{path}: contains CSV file upload input in a non-file-ingest application"
                )

    return violations


def validate_stage_d(
    domain: DomainAnalysis,
    blueprint: AppBlueprint,
    direction: DesignDirection,
    existing_fingerprints: list[tuple[str, LookFingerprint]],
    generated_files: Optional[dict[str, str]] = None,
    allow_opt_in_footer: bool = False,
    min_distance: int = 4,
) -> tuple[DesignDirection, StageDValidationReport]:
    """
    Executes Stage D deterministic validation:
    1. WCAG AA contrast validation + deterministic lightness adjustment.
    2. 8-tuple look fingerprint calculation & diversity guard (distance >= 4).
    3. Optional generated source leakage scan.
    """
    adjusted_palette, adjustments, contrast_results = validate_and_adjust_palette(direction.palette)
    adjusted_direction = direction.model_copy(update={"palette": adjusted_palette})

    contrast_all_passed = all(pair.passed for pair in contrast_results)
    fp = compute_fingerprint(domain, blueprint, adjusted_direction)
    diversity_ok, min_dist, collisions = check_diversity_guard(
        fp, existing_fingerprints, min_distance=min_distance
    )

    leakage: list[str] = []
    if generated_files is not None:
        leakage = scan_generated_source_for_leakage(
            files=generated_files,
            has_file_ingest_entity=blueprint.has_file_ingest_entity(),
            allow_opt_in_footer=allow_opt_in_footer,
        )

    is_valid = contrast_all_passed and diversity_ok and (len(leakage) == 0)

    report = StageDValidationReport(
        valid=is_valid,
        fingerprint=fp,
        contrast_pairs=contrast_results,
        contrast_adjustments=adjustments,
        diversity_passed=diversity_ok,
        min_fingerprint_distance=min_dist,
        collision_diagnostics=collisions,
        leakage_violations=leakage,
    )
    return adjusted_direction, report


def resolve_diversity_with_retries(
    domain: DomainAnalysis,
    blueprint: AppBlueprint,
    initial_direction: DesignDirection,
    existing_fingerprints: list[tuple[str, LookFingerprint]],
    fallback_directions: list[DesignDirection],
    retry_fn: Optional[Callable[[list[str], int], DesignDirection]] = None,
    max_retries: int = 3,
    min_distance: int = 4,
) -> tuple[DesignDirection, StageDValidationReport, int]:
    """
    Validates initial_direction against existing_fingerprints.
    If a diversity collision occurs (< min_distance), calls retry_fn up to max_retries times
    (rejecting identical retries), then falls back to the next-best curated direction.
    Returns (final_direction, final_report, retries_used).
    """
    current_dir, report = validate_stage_d(
        domain=domain,
        blueprint=blueprint,
        direction=initial_direction,
        existing_fingerprints=existing_fingerprints,
        min_distance=min_distance,
    )
    if report.diversity_passed:
        return current_dir, report, 0

    seen_direction_Fingerprints: set[tuple[str, str, str, int, str, str, str, str]] = {
        report.fingerprint.as_tuple()
    }
    retries_used = 0

    if retry_fn is not None:
        for attempt in range(1, max_retries + 1):
            retries_used = attempt
            candidate_dir = retry_fn(report.collision_diagnostics, attempt)
            adj_dir, cand_report = validate_stage_d(
                domain=domain,
                blueprint=blueprint,
                direction=candidate_dir,
                existing_fingerprints=existing_fingerprints,
                min_distance=min_distance,
            )
            cand_tuple = cand_report.fingerprint.as_tuple()
            if cand_tuple in seen_direction_Fingerprints:
                cand_report.collision_diagnostics.append(
                    f"Attempt {attempt} produced an identical fingerprint to a prior attempt."
                )
                report = cand_report
                continue
            seen_direction_Fingerprints.add(cand_tuple)
            if cand_report.diversity_passed:
                return adj_dir, cand_report, retries_used
            current_dir, report = adj_dir, cand_report

    # Deterministic fallback to the curated direction maximizing min_fingerprint_distance
    best_fallback_dir = current_dir
    best_fallback_report = report

    for fb_dir in fallback_directions:
        adj_fb, fb_report = validate_stage_d(
            domain=domain,
            blueprint=blueprint,
            direction=fb_dir,
            existing_fingerprints=existing_fingerprints,
            min_distance=min_distance,
        )
        if fb_report.diversity_passed:
            return adj_fb, fb_report, retries_used
        if fb_report.min_fingerprint_distance > best_fallback_report.min_fingerprint_distance:
            best_fallback_dir = adj_fb
            best_fallback_report = fb_report

    return best_fallback_dir, best_fallback_report, retries_used
