"""Curated Design Direction Library (10+ directions) with bounded adjustments (Stage C)."""

from typing import Optional

from pydantic import BaseModel

from generators.blueprint.schemas import LayoutArchetype, NavPattern, ProductArchetype
from generators.design.contrast import (
    hex_to_hsl,
    hsl_to_hex,
    validate_and_adjust_palette,
)
from generators.design.schemas import (
    BorderStyle,
    BrandMarkSpec,
    ColorMode,
    DensityClass,
    DesignDirection,
    IconStyle,
    MotionLevel,
    PaletteTokens,
    RadiusClass,
    ShadowStyle,
    ShapeTokens,
    TypographyTokens,
)


class CuratedDirectionProfile(BaseModel):
    direction: DesignDirection
    name: str
    feel_summary: str
    layout_personality: str
    typical_archetypes: list[ProductArchetype]
    preferred_nav: NavPattern
    preferred_home_layout: LayoutArchetype


def _build_verified_direction(direction: DesignDirection) -> DesignDirection:
    adjusted_palette, _, _ = validate_and_adjust_palette(direction.palette)
    return direction.model_copy(update={"palette": adjusted_palette})


CURATED_DIRECTION_PROFILES: dict[str, CuratedDirectionProfile] = {
    "editorial_calm": CuratedDirectionProfile(
        name="Editorial Calm",
        feel_summary=(
            "Warm off-white canvas, literary serif headings, forest/olive accent, generous space"
        ),
        layout_personality=(
            "Quiet focus, spacious ritual cards with breathable margins and unhurried hierarchy"
        ),
        typical_archetypes=[
            ProductArchetype.HABIT_OR_GOAL_TRACKER,
            ProductArchetype.LEARNING_COURSE,
            ProductArchetype.HEALTH_LOG,
        ],
        preferred_nav=NavPattern.SIDEBAR,
        preferred_home_layout=LayoutArchetype.CHECKLIST_TODAY,
        direction=_build_verified_direction(
            DesignDirection(
                direction_id="editorial_calm",
                palette=PaletteTokens(
                    primary="#245436",
                    primary_foreground="#FFFFFF",
                    accent="#8F4B28",
                    neutral_ramp=[
                        "#FBF9F5",
                        "#F3EFE6",
                        "#E5DEC9",
                        "#C9BFA3",
                        "#9C9178",
                        "#6E6552",
                        "#4B4537",
                        "#2D2920",
                        "#1C241E",
                    ],
                    surface="#FBF9F5",
                    surface_elevated="#FFFFFF",
                    border="#6B6250",
                    text="#1C241E",
                    text_muted="#4B4537",
                    focus_ring="#245436",
                    success="#1B6E32",
                    warning="#8A4F00",
                    danger="#A81818",
                ),
                color_mode=ColorMode.LIGHT,
                typography=TypographyTokens(
                    heading_font="Fraunces",
                    body_font="Source Sans 3",
                    mono_font="JetBrains Mono",
                    scale_ratio=1.28,
                ),
                shape=ShapeTokens(
                    radius_class=RadiusClass.SOFT,
                    border_style=BorderStyle.HAIRLINE,
                    shadow_style=ShadowStyle.SOFT,
                ),
                density=DensityClass.SPACIOUS,
                motion=MotionLevel.SUBTLE,
                iconography=IconStyle.OUTLINE,
                brand_mark=BrandMarkSpec(
                    kind="geometric_glyph",
                    glyph_primitive="leaf_arch",
                    monogram_letters="EC",
                ),
                copy_voice=(
                    "Encouraging, reflective, unhurried short sentences that celebrate consistency."
                ),
                rationale=(
                    "Warm paper-like surfaces and editorial serif headings create a calm, "
                    "restorative atmosphere suited to daily habit rituals and deep learning."
                ),
            )
        ),
    ),
    "ledger_precision": CuratedDirectionProfile(
        name="Ledger Precision",
        feel_summary=(
            "Crisp slate-white, deep navy + teal accents, compact tables, tabular numerals"
        ),
        layout_personality=(
            "High-density financial grid with crisp hairline rules and aligned numeric columns"
        ),
        typical_archetypes=[
            ProductArchetype.FINANCE_LEDGER,
            ProductArchetype.ANALYTICS_DASHBOARD,
        ],
        preferred_nav=NavPattern.TOP_TABS,
        preferred_home_layout=LayoutArchetype.STAT_TILES_WITH_CHARTS,
        direction=_build_verified_direction(
            DesignDirection(
                direction_id="ledger_precision",
                palette=PaletteTokens(
                    primary="#0F3D5E",
                    primary_foreground="#FFFFFF",
                    accent="#0B6E66",
                    neutral_ramp=[
                        "#F8FAFC",
                        "#F1F5F9",
                        "#E2E8F0",
                        "#CBD5E1",
                        "#94A3B8",
                        "#64748B",
                        "#475569",
                        "#1E293B",
                        "#0F172A",
                    ],
                    surface="#F8FAFC",
                    surface_elevated="#FFFFFF",
                    border="#52637A",
                    text="#0F172A",
                    text_muted="#334155",
                    focus_ring="#0F3D5E",
                    success="#156D3B",
                    warning="#854D0E",
                    danger="#991B1B",
                ),
                color_mode=ColorMode.LIGHT,
                typography=TypographyTokens(
                    heading_font="IBM Plex Sans",
                    body_font="IBM Plex Sans",
                    mono_font="IBM Plex Mono",
                    scale_ratio=1.20,
                ),
                shape=ShapeTokens(
                    radius_class=RadiusClass.SHARP,
                    border_style=BorderStyle.CRISP,
                    shadow_style=ShadowStyle.FLAT,
                ),
                density=DensityClass.COMPACT,
                motion=MotionLevel.NONE,
                iconography=IconStyle.OUTLINE,
                brand_mark=BrandMarkSpec(
                    kind="geometric_glyph",
                    glyph_primitive="bars_ascending",
                    monogram_letters="LP",
                ),
                copy_voice="Exact, accounting-grade, noun-first labels with zero marketing fluff.",
                rationale=(
                    "Finance operators and billing analysts need scannable tabular numerals, "
                    "crisp borders, and authoritative navy/teal contrast for reconciliation."
                ),
            )
        ),
    ),
    "console_dark": CuratedDirectionProfile(
        name="Console Dark",
        feel_summary="Near-black carbon canvas, mono accents, cyan/amber signals, dense log views",
        layout_personality=(
            "Keyboard-driven terminal density with live severity badges and monospace streams"
        ),
        typical_archetypes=[
            ProductArchetype.OPS_MONITORING,
            ProductArchetype.SUPPORT_TICKETING,
        ],
        preferred_nav=NavPattern.COMMAND_PALETTE_PLUS_MINIMAL_TOP,
        preferred_home_layout=LayoutArchetype.LOG_STREAM,
        direction=_build_verified_direction(
            DesignDirection(
                direction_id="console_dark",
                palette=PaletteTokens(
                    primary="#22D3EE",
                    primary_foreground="#081018",
                    accent="#FBBF24",
                    neutral_ramp=[
                        "#0B0F17",
                        "#111827",
                        "#1F2937",
                        "#374151",
                        "#4B5563",
                        "#6B7280",
                        "#9CA3AF",
                        "#D1D5DB",
                        "#F9FAFB",
                    ],
                    surface="#0B0F17",
                    surface_elevated="#141C2B",
                    border="#64748B",
                    text="#F1F5F9",
                    text_muted="#94A3B8",
                    focus_ring="#22D3EE",
                    success="#34D399",
                    warning="#FBBF24",
                    danger="#F87171",
                ),
                color_mode=ColorMode.DARK,
                typography=TypographyTokens(
                    heading_font="Space Grotesk",
                    body_font="Inter",
                    mono_font="JetBrains Mono",
                    scale_ratio=1.18,
                ),
                shape=ShapeTokens(
                    radius_class=RadiusClass.SHARP,
                    border_style=BorderStyle.HAIRLINE,
                    shadow_style=ShadowStyle.NONE,
                ),
                density=DensityClass.COMPACT,
                motion=MotionLevel.NONE,
                iconography=IconStyle.OUTLINE,
                brand_mark=BrandMarkSpec(
                    kind="geometric_glyph",
                    glyph_primitive="shield_crest",
                    monogram_letters="CD",
                ),
                copy_voice=(
                    "Terse, technical, operator-grade telemetry terminology "
                    "(severity, source, ack)."
                ),
                rationale=(
                    "Security engineers and SREs working in low-light NOC environments rely on "
                    "dark surfaces, monospace log timestamps, and high-visibility cyan/amber cues."
                ),
            )
        ),
    ),
    "playful_momentum": CuratedDirectionProfile(
        name="Playful Momentum",
        feel_summary="Rounded pill shapes, saturated coral/sun accents, big touch targets",
        layout_personality=(
            "Tactile cards, celebratory streak counters, and mobile-friendly bottom navigation"
        ),
        typical_archetypes=[
            ProductArchetype.HABIT_OR_GOAL_TRACKER,
            ProductArchetype.COMMUNITY_FEED,
            ProductArchetype.LEARNING_COURSE,
        ],
        preferred_nav=NavPattern.BOTTOM_TABS,
        preferred_home_layout=LayoutArchetype.HEATMAP_STREAKS,
        direction=_build_verified_direction(
            DesignDirection(
                direction_id="playful_momentum",
                palette=PaletteTokens(
                    primary="#C2381E",
                    primary_foreground="#FFFFFF",
                    accent="#B45309",
                    neutral_ramp=[
                        "#FFFDF9",
                        "#FDF6EC",
                        "#F7E8D4",
                        "#EBD2B2",
                        "#C7AD8E",
                        "#8C755C",
                        "#5E4D3B",
                        "#3B2E22",
                        "#231815",
                    ],
                    surface="#FFFDF9",
                    surface_elevated="#FFFFFF",
                    border="#7A654F",
                    text="#231815",
                    text_muted="#524132",
                    focus_ring="#C2381E",
                    success="#157347",
                    warning="#945200",
                    danger="#B91C1C",
                ),
                color_mode=ColorMode.LIGHT,
                typography=TypographyTokens(
                    heading_font="Plus Jakarta Sans",
                    body_font="Plus Jakarta Sans",
                    mono_font="Fira Code",
                    scale_ratio=1.30,
                ),
                shape=ShapeTokens(
                    radius_class=RadiusClass.PILL,
                    border_style=BorderStyle.CRISP,
                    shadow_style=ShadowStyle.LAYERED,
                ),
                density=DensityClass.COMFORTABLE,
                motion=MotionLevel.LIVELY,
                iconography=IconStyle.SOLID,
                brand_mark=BrandMarkSpec(
                    kind="geometric_glyph",
                    glyph_primitive="spark_diamond",
                    monogram_letters="PM",
                ),
                copy_voice="Upbeat, energetic, action-first microcopy that rewards momentum.",
                rationale=(
                    "High-energy coral accents, generous pill touch targets, and lively "
                    "transitions make daily goal completion and community engagement rewarding."
                ),
            )
        ),
    ),
    "clinical_clean": CuratedDirectionProfile(
        name="Clinical Clean",
        feel_summary="Cool white, soft cerulean-teal, high legibility, low ornament",
        layout_personality=(
            "Structured appointment agendas and patient intake clarity with calm status badges"
        ),
        typical_archetypes=[
            ProductArchetype.HEALTH_LOG,
            ProductArchetype.BOOKING_SCHEDULER,
        ],
        preferred_nav=NavPattern.SIDEBAR,
        preferred_home_layout=LayoutArchetype.CALENDAR_WEEK_AGENDA,
        direction=_build_verified_direction(
            DesignDirection(
                direction_id="clinical_clean",
                palette=PaletteTokens(
                    primary="#025E8D",
                    primary_foreground="#FFFFFF",
                    accent="#0B7266",
                    neutral_ramp=[
                        "#F9FBFC",
                        "#F0F5F9",
                        "#E1EBF2",
                        "#C5D7E5",
                        "#94B2C9",
                        "#62829C",
                        "#405B73",
                        "#243B53",
                        "#102A43",
                    ],
                    surface="#F9FBFC",
                    surface_elevated="#FFFFFF",
                    border="#5A768E",
                    text="#102A43",
                    text_muted="#334E68",
                    focus_ring="#025E8D",
                    success="#146C43",
                    warning="#8A5000",
                    danger="#A61B1B",
                ),
                color_mode=ColorMode.LIGHT,
                typography=TypographyTokens(
                    heading_font="Public Sans",
                    body_font="Public Sans",
                    mono_font="IBM Plex Mono",
                    scale_ratio=1.22,
                ),
                shape=ShapeTokens(
                    radius_class=RadiusClass.SOFT,
                    border_style=BorderStyle.HAIRLINE,
                    shadow_style=ShadowStyle.FLAT,
                ),
                density=DensityClass.COMFORTABLE,
                motion=MotionLevel.SUBTLE,
                iconography=IconStyle.OUTLINE,
                brand_mark=BrandMarkSpec(
                    kind="geometric_glyph",
                    glyph_primitive="pulse_wave",
                    monogram_letters="CC",
                ),
                copy_voice="Calm, reassuring, unambiguous clinical and scheduling terminology.",
                rationale=(
                    "Medical receptionists, clinicians, and patients require high-legibility "
                    "Public Sans type and hygienic cerulean/teal hierarchy with zero clutter."
                ),
            )
        ),
    ),
    "studio_craft": CuratedDirectionProfile(
        name="Studio Craft",
        feel_summary="Muted earth tones, terracotta & olive accents, expressive serif headings",
        layout_personality=(
            "Tactile inventory and catalog cards with rich metadata and split master-detail"
        ),
        typical_archetypes=[
            ProductArchetype.CONTENT_CMS,
            ProductArchetype.INVENTORY_STOCK,
        ],
        preferred_nav=NavPattern.SPLIT_MASTER_DETAIL,
        preferred_home_layout=LayoutArchetype.MASTER_DETAIL,
        direction=_build_verified_direction(
            DesignDirection(
                direction_id="studio_craft",
                palette=PaletteTokens(
                    primary="#82361B",
                    primary_foreground="#FFFFFF",
                    accent="#3B5D11",
                    neutral_ramp=[
                        "#F7F4EF",
                        "#EFEAE1",
                        "#E0D7C8",
                        "#C7B9A5",
                        "#9E8E78",
                        "#736552",
                        "#524637",
                        "#362C21",
                        "#211A14",
                    ],
                    surface="#F7F4EF",
                    surface_elevated="#FFFFFF",
                    border="#706250",
                    text="#211A14",
                    text_muted="#4A3F31",
                    focus_ring="#82361B",
                    success="#28662B",
                    warning="#854D0E",
                    danger="#9E1C1C",
                ),
                color_mode=ColorMode.LIGHT,
                typography=TypographyTokens(
                    heading_font="Playfair Display",
                    body_font="DM Sans",
                    mono_font="JetBrains Mono",
                    scale_ratio=1.32,
                ),
                shape=ShapeTokens(
                    radius_class=RadiusClass.ROUND,
                    border_style=BorderStyle.HAIRLINE,
                    shadow_style=ShadowStyle.SOFT,
                ),
                density=DensityClass.SPACIOUS,
                motion=MotionLevel.SUBTLE,
                iconography=IconStyle.DUOTONE,
                brand_mark=BrandMarkSpec(
                    kind="wordmark",
                    glyph_primitive="cube_iso",
                    monogram_letters="SC",
                ),
                copy_voice=(
                    "Crafted, tactile, culinary/editorial precision focused on stock provenance."
                ),
                rationale=(
                    "Warm sand canvases and terracotta accents suit artisanal kitchens, studios, "
                    "and catalog curation where items are inspected in master-detail views."
                ),
            )
        ),
    ),
    "campus_energy": CuratedDirectionProfile(
        name="Campus Energy",
        feel_summary="Bold cobalt primary, electric amber badges, feed-first collaborative cards",
        layout_personality=(
            "Social builder feed and skill-tag cards optimized for rapid team discovery"
        ),
        typical_archetypes=[
            ProductArchetype.EVENT_HUB,
            ProductArchetype.COMMUNITY_FEED,
        ],
        preferred_nav=NavPattern.TOP_TABS,
        preferred_home_layout=LayoutArchetype.FEED,
        direction=_build_verified_direction(
            DesignDirection(
                direction_id="campus_energy",
                palette=PaletteTokens(
                    primary="#1D4ED8",
                    primary_foreground="#FFFFFF",
                    accent="#9A4406",
                    neutral_ramp=[
                        "#F8FAFF",
                        "#EEF2FF",
                        "#E0E7FF",
                        "#C7D2FE",
                        "#94A3B8",
                        "#64748B",
                        "#475569",
                        "#1E293B",
                        "#111827",
                    ],
                    surface="#F8FAFF",
                    surface_elevated="#FFFFFF",
                    border="#5B6B82",
                    text="#111827",
                    text_muted="#374151",
                    focus_ring="#1D4ED8",
                    success="#157347",
                    warning="#92400E",
                    danger="#B91C1C",
                ),
                color_mode=ColorMode.LIGHT,
                typography=TypographyTokens(
                    heading_font="Outfit",
                    body_font="DM Sans",
                    mono_font="Fira Code",
                    scale_ratio=1.26,
                ),
                shape=ShapeTokens(
                    radius_class=RadiusClass.ROUND,
                    border_style=BorderStyle.CRISP,
                    shadow_style=ShadowStyle.LAYERED,
                ),
                density=DensityClass.COMFORTABLE,
                motion=MotionLevel.LIVELY,
                iconography=IconStyle.SOLID,
                brand_mark=BrandMarkSpec(
                    kind="geometric_glyph",
                    glyph_primitive="compass_star",
                    monogram_letters="CE",
                ),
                copy_voice="Energetic, collaborative, peer-to-peer student builder language.",
                rationale=(
                    "Hackathon participants and student teams respond to bold cobalt primaries, "
                    "chunky skill badges, and a live project pitch feed."
                ),
            )
        ),
    ),
    "marketplace_warm": CuratedDirectionProfile(
        name="Marketplace Warm",
        feel_summary="Warm alabaster neutrals, burnt-amber CTAs, venue/slot availability cards",
        layout_personality="Card-forward venue directory and instant time-slot booking grid",
        typical_archetypes=[
            ProductArchetype.BOOKING_SCHEDULER,
            ProductArchetype.MARKETPLACE_DIRECTORY,
        ],
        preferred_nav=NavPattern.BOTTOM_TABS,
        preferred_home_layout=LayoutArchetype.CARD_GRID,
        direction=_build_verified_direction(
            DesignDirection(
                direction_id="marketplace_warm",
                palette=PaletteTokens(
                    primary="#9A3412",
                    primary_foreground="#FFFFFF",
                    accent="#065F46",
                    neutral_ramp=[
                        "#FAF8F5",
                        "#F3EFEA",
                        "#E6DFD5",
                        "#D0C5B6",
                        "#A69988",
                        "#786C5E",
                        "#544B40",
                        "#362F28",
                        "#1F1A17",
                    ],
                    surface="#FAF8F5",
                    surface_elevated="#FFFFFF",
                    border="#706457",
                    text="#1F1A17",
                    text_muted="#4A4037",
                    focus_ring="#9A3412",
                    success="#116944",
                    warning="#8A4B08",
                    danger="#A81818",
                ),
                color_mode=ColorMode.LIGHT,
                typography=TypographyTokens(
                    heading_font="Sora",
                    body_font="Plus Jakarta Sans",
                    mono_font="IBM Plex Mono",
                    scale_ratio=1.25,
                ),
                shape=ShapeTokens(
                    radius_class=RadiusClass.ROUND,
                    border_style=BorderStyle.HAIRLINE,
                    shadow_style=ShadowStyle.SOFT,
                ),
                density=DensityClass.COMFORTABLE,
                motion=MotionLevel.SUBTLE,
                iconography=IconStyle.DUOTONE,
                brand_mark=BrandMarkSpec(
                    kind="geometric_glyph",
                    glyph_primitive="court_lines",
                    monogram_letters="MW",
                ),
                copy_voice="Welcoming, availability-first, concierge booking microcopy.",
                rationale=(
                    "Sports court reservers and local directory browsers need clear availability "
                    "badges, warm inviting cards, and high-contrast burnt-amber reserve buttons."
                ),
            )
        ),
    ),
    "kanban_focus": CuratedDirectionProfile(
        name="Kanban Focus",
        feel_summary="Cool neutral grey canvas, indigo-slate chrome, color-coded workflow lanes",
        layout_personality="Multi-column kanban board and filtered tables with minimal chrome",
        typical_archetypes=[
            ProductArchetype.KANBAN_PROJECT,
            ProductArchetype.CRM_PIPELINE,
            ProductArchetype.INVENTORY_STOCK,
        ],
        preferred_nav=NavPattern.SIDEBAR,
        preferred_home_layout=LayoutArchetype.KANBAN_BOARD,
        direction=_build_verified_direction(
            DesignDirection(
                direction_id="kanban_focus",
                palette=PaletteTokens(
                    primary="#312E81",
                    primary_foreground="#FFFFFF",
                    accent="#0369A1",
                    neutral_ramp=[
                        "#F3F4F6",
                        "#E5E7EB",
                        "#D1D5DB",
                        "#9CA3AF",
                        "#6B7280",
                        "#4B5563",
                        "#374151",
                        "#1F2937",
                        "#111827",
                    ],
                    surface="#F3F4F6",
                    surface_elevated="#FFFFFF",
                    border="#5B6472",
                    text="#111827",
                    text_muted="#374151",
                    focus_ring="#312E81",
                    success="#157347",
                    warning="#854D0E",
                    danger="#B91C1C",
                ),
                color_mode=ColorMode.LIGHT,
                typography=TypographyTokens(
                    heading_font="DM Sans",
                    body_font="Inter",
                    mono_font="JetBrains Mono",
                    scale_ratio=1.20,
                ),
                shape=ShapeTokens(
                    radius_class=RadiusClass.SOFT,
                    border_style=BorderStyle.HAIRLINE,
                    shadow_style=ShadowStyle.FLAT,
                ),
                density=DensityClass.COMPACT,
                motion=MotionLevel.SUBTLE,
                iconography=IconStyle.OUTLINE,
                brand_mark=BrandMarkSpec(
                    kind="geometric_glyph",
                    glyph_primitive="hex_grid",
                    monogram_letters="KF",
                ),
                copy_voice=(
                    "Direct, status-first workflow microcopy (Backlog, In Progress, Shipped)."
                ),
                rationale=(
                    "Project managers and operations coordinators need a neutral grey canvas that "
                    "lets status lane colors and card priorities stand out without fatigue."
                ),
            )
        ),
    ),
    "civic_formal": CuratedDirectionProfile(
        name="Civic Formal",
        feel_summary="Restrained high-contrast white & deep crimson, conventional hierarchy",
        layout_personality=(
            "Structured document reports, multi-step wizards, and formal audit tables"
        ),
        typical_archetypes=[
            ProductArchetype.FORM_SURVEY,
            ProductArchetype.FINANCE_LEDGER,
            ProductArchetype.GENERIC_CRUD,
        ],
        preferred_nav=NavPattern.TOP_TABS,
        preferred_home_layout=LayoutArchetype.REPORT_DOCUMENT,
        direction=_build_verified_direction(
            DesignDirection(
                direction_id="civic_formal",
                palette=PaletteTokens(
                    primary="#7F1D1D",
                    primary_foreground="#FFFFFF",
                    accent="#1E3A8A",
                    neutral_ramp=[
                        "#FFFFFF",
                        "#F5F5F5",
                        "#E5E5E5",
                        "#D4D4D4",
                        "#A3A3A3",
                        "#737373",
                        "#525252",
                        "#262626",
                        "#0A0A0A",
                    ],
                    surface="#FFFFFF",
                    surface_elevated="#FAFAFA",
                    border="#525252",
                    text="#0A0A0A",
                    text_muted="#404040",
                    focus_ring="#7F1D1D",
                    success="#146C43",
                    warning="#854D0E",
                    danger="#991B1B",
                ),
                color_mode=ColorMode.BOTH,
                typography=TypographyTokens(
                    heading_font="Merriweather",
                    body_font="Public Sans",
                    mono_font="IBM Plex Mono",
                    scale_ratio=1.25,
                ),
                shape=ShapeTokens(
                    radius_class=RadiusClass.SHARP,
                    border_style=BorderStyle.CRISP,
                    shadow_style=ShadowStyle.NONE,
                ),
                density=DensityClass.SPACIOUS,
                motion=MotionLevel.NONE,
                iconography=IconStyle.OUTLINE,
                brand_mark=BrandMarkSpec(
                    kind="wordmark",
                    glyph_primitive="book_open",
                    monogram_letters="CF",
                ),
                copy_voice=(
                    "Authoritative, institutional, plain-language guidance with explicit rules."
                ),
                rationale=(
                    "Invoicing, formal filings, and enterprise compliance require authoritative "
                    "serif headers, maximum contrast, and zero decorative ambiguity."
                ),
            )
        ),
    ),
}


def get_curated_direction(direction_id: str) -> DesignDirection:
    if direction_id not in CURATED_DIRECTION_PROFILES:
        raise KeyError(
            f"Unknown direction_id '{direction_id}'. "
            f"Available: {sorted(CURATED_DIRECTION_PROFILES.keys())}"
        )
    return CURATED_DIRECTION_PROFILES[direction_id].direction.model_copy(deep=True)


def list_curated_directions() -> list[DesignDirection]:
    return [p.direction.model_copy(deep=True) for p in CURATED_DIRECTION_PROFILES.values()]


def apply_bounded_adjustments(
    direction: DesignDirection,
    hue_shift_deg: float = 0.0,
    radius_override: Optional[RadiusClass] = None,
    density_override: Optional[DensityClass] = None,
    color_mode_override: Optional[ColorMode] = None,
    monogram_override: Optional[str] = None,
    rationale_override: Optional[str] = None,
) -> DesignDirection:
    """
    Applies bounded adjustments to a curated DesignDirection (hue shift within [-60, +60] deg,
    radius class, density, color mode, monogram, rationale) and re-runs WCAG AA contrast adjustment.
    """
    clamped_shift = max(-60.0, min(60.0, hue_shift_deg))
    palette = direction.palette.model_copy(deep=True)

    if abs(clamped_shift) > 0.1:
        h, s, light = hex_to_hsl(palette.primary)
        shifted_primary = hsl_to_hex((h + clamped_shift) % 360.0, s, light)
        if shifted_primary not in ("#5A32A3", "#6D28D9"):
            palette.primary = shifted_primary
            palette.focus_ring = shifted_primary

    if color_mode_override is not None and color_mode_override != direction.color_mode:
        if color_mode_override == ColorMode.DARK:
            palette.surface = "#0B0F17"
            palette.surface_elevated = "#151D2A"
            palette.text = "#F1F5F9"
            palette.text_muted = "#94A3B8"
            palette.border = "#64748B"
        elif color_mode_override == ColorMode.LIGHT:
            palette.surface = "#F8FAFC"
            palette.surface_elevated = "#FFFFFF"
            palette.text = "#0F172A"
            palette.text_muted = "#334155"
            palette.border = "#64748B"

    adjusted_palette, _, _ = validate_and_adjust_palette(palette)

    shape = direction.shape.model_copy(
        update={"radius_class": radius_override or direction.shape.radius_class}
    )
    brand_mark = direction.brand_mark.model_copy(
        update={
            "monogram_letters": (
                monogram_override.strip().upper()[:3]
                if monogram_override
                and monogram_override.strip().upper() not in {"GW", "CX", "CODEX", "GHOSTWRITER"}
                else direction.brand_mark.monogram_letters
            )
        }
    )

    return direction.model_copy(
        update={
            "palette": adjusted_palette,
            "shape": shape,
            "density": density_override or direction.density,
            "color_mode": color_mode_override or direction.color_mode,
            "brand_mark": brand_mark,
            "rationale": rationale_override or direction.rationale,
        }
    )
