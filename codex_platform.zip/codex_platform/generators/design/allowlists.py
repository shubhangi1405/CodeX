"""Closed allowlists for Adaptive UI Generation (Stages B, C, and D)."""

ALLOWED_LAYOUTS: frozenset[str] = frozenset(
    {
        "stat_tiles_with_charts",
        "data_table_with_filters",
        "card_grid",
        "kanban_board",
        "calendar_month",
        "calendar_week_agenda",
        "timeline",
        "feed",
        "master_detail",
        "form_wizard",
        "single_form",
        "checklist_today",
        "heatmap_streaks",
        "leaderboard",
        "map_or_location_list",
        "report_document",
        "log_stream",
    }
)

ALLOWED_NAV_PATTERNS: frozenset[str] = frozenset(
    {
        "sidebar",
        "top_tabs",
        "bottom_tabs",
        "command_palette_plus_minimal_top",
        "split_master_detail",
    }
)

ALLOWED_HEADING_FONTS: frozenset[str] = frozenset(
    {
        "Fraunces",
        "IBM Plex Sans",
        "Space Grotesk",
        "Plus Jakarta Sans",
        "Public Sans",
        "Playfair Display",
        "Outfit",
        "Sora",
        "DM Sans",
        "Merriweather",
        "Inter",
    }
)

ALLOWED_BODY_FONTS: frozenset[str] = frozenset(
    {
        "Source Sans 3",
        "IBM Plex Sans",
        "Inter",
        "Plus Jakarta Sans",
        "Public Sans",
        "DM Sans",
    }
)

ALLOWED_MONO_FONTS: frozenset[str] = frozenset(
    {
        "JetBrains Mono",
        "IBM Plex Mono",
        "Fira Code",
    }
)

ALLOWED_ICONS: frozenset[str] = frozenset(
    {
        "activity",
        "alert-triangle",
        "award",
        "bar-chart-2",
        "bell",
        "book-open",
        "bookmark",
        "box",
        "briefcase",
        "calendar",
        "check-circle",
        "check-square",
        "clock",
        "code",
        "compass",
        "credit-card",
        "Database",
        "dollar-sign",
        "file-text",
        "filter",
        "Cpu",
        "flame",
        "folder",
        "globe",
        "grid",
        "heart",
        "home",
        "inbox",
        "kanban",
        "key",
        "layers",
        "layout",
        "list",
        "lock",
        "map-pin",
        "message-square",
        "package",
        "pie-chart",
        "plus-circle",
        " receipt",
        "receipt",
        "search",
        "send",
        "server",
        "settings",
        "shield",
        "shopping-bag",
        "sliders",
        "sparkles",
        "star",
        "Stethoscope",
        "stethoscope",
        "sun",
        "tag",
        "target",
        "terminal",
        "trending-up",
        "trophy",
        "truck",
        "upload",
        "user",
        "users",
        "utensils",
        "zap",
    }
)

ALLOWED_GLYPH_PRIMITIVES: frozenset[str] = frozenset(
    {
        "circle_ring",
        "hex_grid",
        "spark_diamond",
        "bars_ascending",
        "pulse_wave",
        "leaf_arch",
        "shield_crest",
        "court_lines",
        "book_open",
        "cube_iso",
        "check_badge",
        "compass_star",
    }
)

ALLOWED_DIRECTION_IDS: frozenset[str] = frozenset(
    {
        "editorial_calm",
        "ledger_precision",
        "console_dark",
        "playful_momentum",
        "clinical_clean",
        "studio_craft",
        "campus_energy",
        "marketplace_warm",
        "kanban_focus",
        "civic_formal",
    }
)

CODEX_BRAND_HEXES: frozenset[str] = frozenset(
    {
        "#5A32A3",
        "#6D28D9",
        "#6366F1",
        "#4F46E5",
        "#FAF9FD",
        "#E4DFF2",
    }
)

# Retained alias for backward compatibility
GHOSTWRITER_BRAND_HEXES: frozenset[str] = CODEX_BRAND_HEXES

FORBIDDEN_PLATFORM_MONOGRAMS: frozenset[str] = frozenset({"GW", "CX", "CODEX", "GHOSTWRITER"})
