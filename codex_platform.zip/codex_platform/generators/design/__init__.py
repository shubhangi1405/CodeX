"""Design tokens, allowlists, WCAG contrast adjuster, and diversity fingerprint guards."""
