"""Deterministic CSS token generator, Tailwind config writer, SVG brand mark, and token sheet."""

from generators.design.contrast import validate_and_adjust_palette
from generators.design.schemas import (
    DensityClass,
    DesignDirection,
    MotionLevel,
    RadiusClass,
    ShadowStyle,
)

_RADIUS_MAP: dict[RadiusClass, tuple[str, str]] = {
    RadiusClass.SHARP: ("2px", "2px"),
    RadiusClass.SOFT: ("8px", "6px"),
    RadiusClass.ROUND: ("14px", "10px"),
    RadiusClass.PILL: ("20px", "9999px"),
}

_SHADOW_MAP: dict[ShadowStyle, str] = {
    ShadowStyle.NONE: "none",
    ShadowStyle.FLAT: "0 1px 0 0 rgba(0, 0, 0, 0.06)",
    ShadowStyle.SOFT: "0 4px 12px -2px rgba(0, 0, 0, 0.07), 0 2px 4px -2px rgba(0, 0, 0, 0.04)",
    ShadowStyle.LAYERED: (
        "0 10px 24px -4px rgba(0, 0, 0, 0.10), 0 4px 8px -2px rgba(0, 0, 0, 0.06)"
    ),
}

_DENSITY_MAP: dict[DensityClass, tuple[str, str, str]] = {
    DensityClass.COMPACT: ("0.75rem", "0.5rem", "0.375rem 0.75rem"),
    DensityClass.COMFORTABLE: ("1.25rem", "0.875rem", "0.5rem 1rem"),
    DensityClass.SPACIOUS: ("1.75rem", "1.25rem", "0.625rem 1.25rem"),
}

_MOTION_MAP: dict[MotionLevel, str] = {
    MotionLevel.NONE: "0ms",
    MotionLevel.SUBTLE: "150ms",
    MotionLevel.LIVELY: "260ms",
}

_FONT_STACK_FALLBACKS: dict[str, str] = {
    "Fraunces": "'Fraunces', Georgia, 'Times New Roman', serif",
    "Playfair Display": "'Playfair Display', Georgia, Cambria, serif",
    "Merriweather": "'Merriweather', Georgia, serif",
    "IBM Plex Sans": "'IBM Plex Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    "Space Grotesk": "'Space Grotesk', 'Segoe UI', system-ui, sans-serif",
    "Plus Jakarta Sans": "'Plus Jakarta Sans', -apple-system, 'Segoe UI', sans-serif",
    "Public Sans": "'Public Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    "Outfit": "'Outfit', 'Segoe UI', system-ui, sans-serif",
    "Sora": "'Sora', 'Segoe UI', system-ui, sans-serif",
    "DM Sans": "'DM Sans', -apple-system, 'Segoe UI', sans-serif",
    "Source Sans 3": "'Source Sans 3', -apple-system, 'Segoe UI', sans-serif",
    "Inter": "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    "JetBrains Mono": "'JetBrains Mono', Consolas, 'Courier New', monospace",
    "IBM Plex Mono": "'IBM Plex Mono', Consolas, 'Courier New', monospace",
    "Fira Code": "'Fira Code', Consolas, 'Courier New', monospace",
}


def generate_design_tokens_css(direction: DesignDirection) -> str:
    """Generates design-tokens.css from a validated DesignDirection."""
    p = direction.palette
    card_radius, ctrl_radius = _RADIUS_MAP[direction.shape.radius_class]
    shadow_css = _SHADOW_MAP[direction.shape.shadow_style]
    pad_card, gap_grid, pad_btn = _DENSITY_MAP[direction.density]
    motion_ms = _MOTION_MAP[direction.motion]

    heading_stack = _FONT_STACK_FALLBACKS.get(
        direction.typography.heading_font, f"'{direction.typography.heading_font}', sans-serif"
    )
    body_stack = _FONT_STACK_FALLBACKS.get(
        direction.typography.body_font, f"'{direction.typography.body_font}', sans-serif"
    )
    mono_stack = _FONT_STACK_FALLBACKS.get(
        direction.typography.mono_font, f"'{direction.typography.mono_font}', monospace"
    )

    ramp_lines = "\n".join(
        f"  --app-neutral-{idx * 100 if idx > 0 else 50}: {hex_val};"
        for idx, hex_val in enumerate(p.neutral_ramp)
    )

    return f"""/* Auto-generated design tokens for direction: {direction.direction_id} */
:root {{
  --app-primary: {p.primary};
  --app-primary-fg: {p.primary_foreground};
  --app-accent: {p.accent};
{ramp_lines}
  --app-surface: {p.surface};
  --app-surface-elevated: {p.surface_elevated};
  --app-border: {p.border};
  --app-text: {p.text};
  --app-text-muted: {p.text_muted};
  --app-focus-ring: {p.focus_ring};
  --app-success: {p.success};
  --app-warning: {p.warning};
  --app-danger: {p.danger};

  --app-font-heading: {heading_stack};
  --app-font-body: {body_stack};
  --app-font-mono: {mono_stack};
  --app-scale-ratio: {direction.typography.scale_ratio};

  --app-radius-card: {card_radius};
  --app-radius-control: {ctrl_radius};
  --app-shadow-card: {shadow_css};

  --app-pad-card: {pad_card};
  --app-gap-grid: {gap_grid};
  --app-pad-control: {pad_btn};
  --app-motion-duration: {motion_ms};

  --color-primary: var(--app-primary);
  --color-primary-fg: var(--app-primary-fg);
  --color-accent: var(--app-accent);
  --color-surface: var(--app-surface);
  --color-surface-elevated: var(--app-surface-elevated);
  --color-border: var(--app-border);
  --color-text: var(--app-text);
  --color-text-muted: var(--app-text-muted);
  --color-focus: var(--app-focus-ring);
  --color-success: var(--app-success);
  --color-warning: var(--app-warning);
  --color-danger: var(--app-danger);
  --font-heading: var(--app-font-heading);
  --font-body: var(--app-font-body);
  --font-mono: var(--app-font-mono);
  --radius-base: var(--app-radius-card);
  --radius-control: var(--app-radius-control);
  --shadow-card: var(--app-shadow-card);
}}

@media (prefers-reduced-motion: reduce) {{
  :root {{
    --app-motion-duration: 0ms;
  }}
  *, *::before, *::after {{
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }}
}}

body {{
  background-color: var(--app-surface);
  color: var(--app-text);
  font-family: var(--app-font-body);
  margin: 0;
}}

h1, h2, h3, h4, .font-heading {{
  font-family: var(--app-font-heading);
}}

code, pre, .font-mono {{
  font-family: var(--app-font-mono);
}}

*:focus-visible {{
  outline: 2px solid var(--app-focus-ring);
  outline-offset: 2px;
}}
"""


def generate_tailwind_config(direction: DesignDirection) -> str:
    """Generates tailwind.config.js mapped purely to CSS custom properties."""
    return f"""/** @type {{import('tailwindcss').Config}} */
// Direction: {direction.direction_id}
export default {{
  content: [
    "./index.html",
    "./src/**/*.{{js,ts,jsx,tsx}}",
  ],
  theme: {{
    extend: {{
      colors: {{
        app: {{
          primary: "var(--app-primary)",
          "primary-fg": "var(--app-primary-fg)",
          accent: "var(--app-accent)",
          surface: "var(--app-surface)",
          elevated: "var(--app-surface-elevated)",
          border: "var(--app-border)",
          text: "var(--app-text)",
          muted: "var(--app-text-muted)",
          focus: "var(--app-focus-ring)",
          success: "var(--app-success)",
          warning: "var(--app-warning)",
          danger: "var(--app-danger)",
        }},
      }},
      fontFamily: {{
        heading: ["var(--app-font-heading)"],
        body: ["var(--app-font-body)"],
        mono: ["var(--app-font-mono)"],
      }},
      borderRadius: {{
        "app-card": "var(--app-radius-card)",
        "app-control": "var(--app-radius-control)",
      }},
      boxShadow: {{
        "app-card": "var(--app-shadow-card)",
      }},
      spacing: {{
        "app-card": "var(--app-pad-card)",
        "app-grid": "var(--app-gap-grid)",
      }},
    }},
  }},
  plugins: [],
}};
"""


_GLYPH_PATHS: dict[str, str] = {
    "leaf_arch": (
        '<path d="M6 18C6 10 12 6 18 6C18 12 14 18 6 18Z" '
        'stroke="currentColor" stroke-width="2" fill="none"/>'
        '<path d="M6 18L14 10" stroke="currentColor" stroke-width="1.8"/>'
    ),
    "bars_ascending": (
        '<rect x="5" y="13" width="3" height="6" rx="1" fill="currentColor"/>'
        '<rect x="10.5" y="9" width="3" height="10" rx="1" fill="currentColor"/>'
        '<rect x="16" y="5" width="3" height="14" rx="1" fill="currentColor"/>'
    ),
    "shield_crest": (
        '<path d="M12 3L19 6V11.5C19 16 15.8 19.6 12 21C8.2 19.6 5 16 5 11.5V6L12 3Z" '
        'stroke="currentColor" stroke-width="2" fill="none"/>'
        '<circle cx="12" cy="11.5" r="2.2" fill="currentColor"/>'
    ),
    "spark_diamond": (
        '<path d="M12 3L14.8 9.2L21 12L14.8 14.8L12 21L9.2 14.8L3 12L9.2 9.2L12 3Z" '
        'stroke="currentColor" stroke-width="2" fill="none"/>'
    ),
    "pulse_wave": (
        '<path d="M3 12H7L9.5 6L14.5 18L17 12H21" stroke="currentColor" '
        'stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>'
    ),
    "cube_iso": (
        '<path d="M12 3L20 7.5V16.5L12 21L4 16.5V7.5L12 3Z" '
        'stroke="currentColor" stroke-width="2" fill="none"/>'
        '<path d="M4 7.5L12 12L20 7.5M12 12V21" '
        'stroke="currentColor" stroke-width="1.8" fill="none"/>'
    ),
    "compass_star": (
        '<circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="2" fill="none"/>'
        '<path d="M15.5 8.5L13.5 13.5L8.5 15.5L10.5 10.5L15.5 8.5Z" '
        'stroke="currentColor" stroke-width="1.8" fill="none"/>'
    ),
    "court_lines": (
        '<rect x="4" y="5" width="16" height="14" rx="2" '
        'stroke="currentColor" stroke-width="2" fill="none"/>'
        '<line x1="12" y1="5" x2="12" y2="19" stroke="currentColor" stroke-width="1.8"/>'
        '<circle cx="12" cy="12" r="2.5" stroke="currentColor" stroke-width="1.8" fill="none"/>'
    ),
    "hex_grid": (
        '<polygon points="12,3 19,7 19,15 12,19 5,15 5,7" '
        'stroke="currentColor" stroke-width="2" fill="none"/>'
        '<circle cx="12" cy="11" r="2.5" fill="currentColor"/>'
    ),
    "book_open": (
        '<path d="M3 6C3 6 7 4.5 12 6.5C17 4.5 21 6 21 6V18.5C21 18.5 17 17 12 19'
        'C7 17 3 18.5 3 18.5V6Z" stroke="currentColor" stroke-width="2" fill="none"/>'
        '<line x1="12" y1="6.5" x2="12" y2="19" stroke="currentColor" stroke-width="1.8"/>'
    ),
    "circle_ring": (
        '<circle cx="12" cy="12" r="8" stroke="currentColor" stroke-width="2.2" fill="none"/>'
        '<circle cx="12" cy="12" r="3" fill="currentColor"/>'
    ),
    "check_badge": (
        '<circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="2" fill="none"/>'
        '<path d="M8.5 12.2L10.8 14.5L15.8 9.5" stroke="currentColor" '
        'stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>'
    ),
}


def render_brand_mark_svg(direction: DesignDirection, app_name: str = "") -> str:
    """Renders an allowed SVG brand mark primitive tied to the product."""
    _ = app_name
    inner = _GLYPH_PATHS.get(direction.brand_mark.glyph_primitive, _GLYPH_PATHS["circle_ring"])
    return (
        '<svg viewBox="0 0 24 24" width="20" height="20" '
        'aria-hidden="true" focusable="false">'
        f"{inner}</svg>"
    )


def render_direction_token_sheet_html(direction: DesignDirection) -> str:
    """Renders a self-contained HTML token specimen sheet that passes contrast checks."""
    _, _, contrast_pairs = validate_and_adjust_palette(direction.palette)
    css = generate_design_tokens_css(direction)
    svg = render_brand_mark_svg(direction)

    pair_rows = "".join(
        f"<tr>"
        f"<td>{c.pair_name}</td>"
        f"<td><code>{c.foreground_hex}</code> on <code>{c.background_hex}</code></td>"
        f"<td><strong>{c.contrast_ratio}:1</strong> (min {c.required_ratio}:1)</td>"
        f"<td>{'PASS' if c.passed else 'FAIL'}</td>"
        f"</tr>"
        for c in contrast_pairs
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Token Sheet — {direction.direction_id}</title>
  <style>
{css}
    .sheet {{ max-width: 960px; margin: 2rem auto; padding: var(--app-pad-card); }}
    .card {{
      background: var(--app-surface-elevated);
      border: 1px solid var(--app-border);
      border-radius: var(--app-radius-card);
      box-shadow: var(--app-shadow-card);
      padding: var(--app-pad-card);
      margin-bottom: var(--app-gap-grid);
    }}
    .btn-primary {{
      background: var(--app-primary);
      color: var(--app-primary-fg);
      border-radius: var(--app-radius-control);
      padding: var(--app-pad-control);
      border: none;
      font-weight: 600;
    }}
    table {{ width: 100%; border-collapse: collapse; font-size: 0.875rem; }}
    th, td {{ text-align: left; padding: 0.5rem; border-bottom: 1px solid var(--app-border); }}
  </style>
</head>
<body>
  <main class="sheet">
    <div class="card">
      <div style="display:flex;align-items:center;gap:0.75rem;">
        <span style="color:var(--app-primary)">{svg}</span>
        <strong>{direction.brand_mark.monogram_letters}</strong>
        <h1 style="margin:0">{direction.direction_id}</h1>
      </div>
      <p style="color:var(--app-text-muted)">{direction.rationale}</p>
      <p><strong>Copy Voice:</strong> {direction.copy_voice}</p>
      <button class="btn-primary">Primary Action Specimen</button>
    </div>
    <div class="card">
      <h2>WCAG 2.1 AA Contrast Verification</h2>
      <table>
        <thead>
          <tr><th>Pair</th><th>Colors</th><th>Ratio</th><th>Status</th></tr>
        </thead>
        <tbody>{pair_rows}</tbody>
      </table>
    </div>
  </main>
</body>
</html>
"""
