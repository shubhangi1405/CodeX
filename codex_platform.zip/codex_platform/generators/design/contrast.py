"""WCAG 2.1 contrast calculation, 30-degree hue bucketing, and deterministic lightness adjuster."""

import colorsys

from generators.design.schemas import (
    ContrastAdjustmentLog,
    ContrastPairResult,
    PaletteTokens,
)


def hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    clean = hex_color.strip().lstrip("#")
    r = int(clean[0:2], 16)
    g = int(clean[2:4], 16)
    b = int(clean[4:6], 16)
    return (r, g, b)


def rgb_to_hex(r: int, g: int, b: int) -> str:
    rc = max(0, min(255, int(round(r))))
    gc = max(0, min(255, int(round(g))))
    bc = max(0, min(255, int(round(b))))
    return f"#{rc:02X}{gc:02X}{bc:02X}"


def hex_to_hsl(hex_color: str) -> tuple[float, float, float]:
    """Returns (hue_degrees [0..360), saturation [0..1], lightness [0..1])."""
    r, g, b = hex_to_rgb(hex_color)
    h, lightness, s = colorsys.rgb_to_hls(r / 255.0, g / 255.0, b / 255.0)
    return ((h * 360.0) % 360.0, s, lightness)


def hsl_to_hex(hue_deg: float, saturation: float, lightness: float) -> str:
    h = (hue_deg % 360.0) / 360.0
    s = max(0.0, min(1.0, saturation))
    light_clamped = max(0.0, min(1.0, lightness))
    r, g, b = colorsys.hls_to_rgb(h, light_clamped, s)
    return rgb_to_hex(round(r * 255.0), round(g * 255.0), round(b * 255.0))


def primary_hue_bucket(hex_color: str) -> int:
    """Computes 30-degree hue bucket in {0, 30, ..., 330}, or -1 for near-achromatic colors."""
    hue_deg, sat, _ = hex_to_hsl(hex_color)
    if sat < 0.08:
        return -1
    bucket = int((hue_deg // 30.0) * 30) % 360
    return bucket


def _channel_linear(channel_byte: int) -> float:
    cs = channel_byte / 255.0
    if cs <= 0.04045:
        return cs / 12.92
    return float(((cs + 0.055) / 1.055) ** 2.4)


def relative_luminance(hex_color: str) -> float:
    """WCAG 2.1 relative luminance in [0.0, 1.0]."""
    r, g, b = hex_to_rgb(hex_color)
    r_lin = _channel_linear(r)
    g_lin = _channel_linear(g)
    b_lin = _channel_linear(b)
    return 0.2126 * r_lin + 0.7152 * g_lin + 0.0722 * b_lin


def contrast_ratio(hex_a: str, hex_b: str) -> float:
    """WCAG 2.1 contrast ratio between two hex colors in [1.0, 21.0]."""
    lum_a = relative_luminance(hex_a)
    lum_b = relative_luminance(hex_b)
    lighter = max(lum_a, lum_b)
    darker = min(lum_a, lum_b)
    return round((lighter + 0.05) / (darker + 0.05), 2)


def adjust_color_for_contrast(fg_hex: str, bg_hex: str, required_ratio: float) -> str:
    """
    Deterministically shifts HSL lightness of fg_hex until contrast_ratio(fg, bg) >= required_ratio.
    Preserves hue and saturation whenever possible.
    """
    if contrast_ratio(fg_hex, bg_hex) >= required_ratio:
        return fg_hex.upper()

    bg_lum = relative_luminance(bg_hex)
    hue_deg, sat, light = hex_to_hsl(fg_hex)

    # Try darkening first if background is light, or lightening first if background is dark
    prefer_darken = bg_lum > 0.179
    directions = [-1.0, 1.0] if prefer_darken else [1.0, -1.0]

    for sign in directions:
        curr_l = light
        for _ in range(105):
            curr_l = max(0.0, min(1.0, curr_l + sign * 0.01))
            candidate = hsl_to_hex(hue_deg, sat, curr_l)
            cr = contrast_ratio(candidate, bg_hex)
            if cr >= required_ratio:
                return candidate
            if curr_l in (0.0, 1.0):
                break

    # Final fallback to pure black or pure white
    black_cr = contrast_ratio("#000000", bg_hex)
    white_cr = contrast_ratio("#FFFFFF", bg_hex)
    return "#000000" if black_cr >= white_cr else "#FFFFFF"


def validate_and_adjust_palette(
    palette: PaletteTokens,
) -> tuple[PaletteTokens, list[ContrastAdjustmentLog], list[ContrastPairResult]]:
    """
    Checks all mandatory WCAG AA pairs (4.5:1 body text, 3.0:1 UI/borders/focus/status).
    If any token fails, deterministically shifts lightness until it passes and logs the adjustment.
    """
    data = palette.model_dump()
    adjustments: list[ContrastAdjustmentLog] = []

    # 1. Foreground tokens checked against surface
    surface_checks: list[tuple[str, str, float]] = [
        ("text", "surface", 4.5),
        ("text_muted", "surface", 4.5),
        ("border", "surface", 3.0),
        ("focus_ring", "surface", 3.0),
        ("success", "surface", 3.0),
        ("warning", "surface", 3.0),
        ("danger", "surface", 3.0),
    ]

    for fg_key, bg_key, req_ratio in surface_checks:
        orig_fg = str(data[fg_key])
        bg_val = str(data[bg_key])
        before_cr = contrast_ratio(orig_fg, bg_val)
        if before_cr < req_ratio:
            new_fg = adjust_color_for_contrast(orig_fg, bg_val, req_ratio)
            after_cr = contrast_ratio(new_fg, bg_val)
            data[fg_key] = new_fg
            adjustments.append(
                ContrastAdjustmentLog(
                    token_name=fg_key,
                    background_token=bg_key,
                    original_hex=orig_fg,
                    adjusted_hex=new_fg,
                    before_ratio=before_cr,
                    after_ratio=after_cr,
                    required_ratio=req_ratio,
                )
            )

    # 2. Ensure text also passes 4.5:1 against surface_elevated
    text_hex = str(data["text"])
    elevated_hex = str(data["surface_elevated"])
    elev_cr = contrast_ratio(text_hex, elevated_hex)
    if elev_cr < 4.5:
        new_text = adjust_color_for_contrast(text_hex, elevated_hex, 4.5)
        # Verify it still passes against surface
        if contrast_ratio(new_text, str(data["surface"])) >= 4.5:
            adjustments.append(
                ContrastAdjustmentLog(
                    token_name="text",
                    background_token="surface_elevated",
                    original_hex=text_hex,
                    adjusted_hex=new_text,
                    before_ratio=elev_cr,
                    after_ratio=contrast_ratio(new_text, elevated_hex),
                    required_ratio=4.5,
                )
            )
            data["text"] = new_text

    # 3. Primary button text (primary_foreground on primary >= 4.5:1)
    prim_hex = str(data["primary"])
    prim_fg_hex = str(data["primary_foreground"])
    prim_cr = contrast_ratio(prim_fg_hex, prim_hex)
    if prim_cr < 4.5:
        # First try adjusting primary_foreground (e.g. white or dark ink)
        adj_fg = adjust_color_for_contrast(prim_fg_hex, prim_hex, 4.5)
        adj_cr = contrast_ratio(adj_fg, prim_hex)
        if adj_cr >= 4.5:
            adjustments.append(
                ContrastAdjustmentLog(
                    token_name="primary_foreground",
                    background_token="primary",
                    original_hex=prim_fg_hex,
                    adjusted_hex=adj_fg,
                    before_ratio=prim_cr,
                    after_ratio=adj_cr,
                    required_ratio=4.5,
                )
            )
            data["primary_foreground"] = adj_fg
        else:
            # Shift primary lightness against adj_fg
            new_prim = adjust_color_for_contrast(prim_hex, adj_fg, 4.5)
            final_cr = contrast_ratio(adj_fg, new_prim)
            adjustments.append(
                ContrastAdjustmentLog(
                    token_name="primary",
                    background_token="primary_foreground",
                    original_hex=prim_hex,
                    adjusted_hex=new_prim,
                    before_ratio=prim_cr,
                    after_ratio=final_cr,
                    required_ratio=4.5,
                )
            )
            data["primary"] = new_prim
            data["primary_foreground"] = adj_fg

    adjusted_palette = PaletteTokens.model_validate(data)

    # Build final verification report
    all_pairs: list[tuple[str, str, str, float]] = [
        ("Body text on surface", "text", "surface", 4.5),
        ("Muted text on surface", "text_muted", "surface", 4.5),
        ("Body text on elevated surface", "text", "surface_elevated", 4.5),
        ("Primary button text on primary", "primary_foreground", "primary", 4.5),
        ("Border on surface", "border", "surface", 3.0),
        ("Focus ring on surface", "focus_ring", "surface", 3.0),
        ("Success status on surface", "success", "surface", 3.0),
        ("Warning status on surface", "warning", "surface", 3.0),
        ("Danger status on surface", "danger", "surface", 3.0),
    ]

    results: list[ContrastPairResult] = []
    final_dump = adjusted_palette.model_dump()
    for label, fg_k, bg_k, req in all_pairs:
        fg_v = str(final_dump[fg_k])
        bg_v = str(final_dump[bg_k])
        cr_val = contrast_ratio(fg_v, bg_v)
        results.append(
            ContrastPairResult(
                pair_name=label,
                foreground_token=fg_k,
                background_token=bg_k,
                foreground_hex=fg_v,
                background_hex=bg_v,
                contrast_ratio=cr_val,
                required_ratio=req,
                passed=cr_val >= req,
            )
        )

    return adjusted_palette, adjustments, results
