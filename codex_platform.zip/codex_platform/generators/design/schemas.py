"""Pydantic models for Stage C (DesignDirection) and Stage D (Validation & Fingerprint)."""

import re
from enum import Enum

from pydantic import BaseModel, Field, field_validator, model_validator

from generators.design.allowlists import (
    ALLOWED_BODY_FONTS,
    ALLOWED_DIRECTION_IDS,
    ALLOWED_GLYPH_PRIMITIVES,
    ALLOWED_HEADING_FONTS,
    ALLOWED_MONO_FONTS,
    CODEX_BRAND_HEXES,
    FORBIDDEN_PLATFORM_MONOGRAMS,
)

HEX_REGEX = re.compile(r"^#[0-9A-Fa-f]{6}$")


def _validate_hex(v: str) -> str:
    clean = v.strip().upper()
    if not HEX_REGEX.match(clean):
        raise ValueError(f"Invalid 6-digit hex color '{v}' (expected #RRGGBB)")
    return clean


class ColorMode(str, Enum):
    LIGHT = "light"
    DARK = "dark"
    BOTH = "both"


class RadiusClass(str, Enum):
    SHARP = "sharp"
    SOFT = "soft"
    ROUND = "round"
    PILL = "pill"


class BorderStyle(str, Enum):
    HAIRLINE = "hairline"
    CRISP = "crisp"
    ACCENT_LEFT = "accent_left"
    NONE = "none"


class ShadowStyle(str, Enum):
    NONE = "none"
    FLAT = "flat"
    SOFT = "soft"
    LAYERED = "layered"


class DensityClass(str, Enum):
    COMPACT = "compact"
    COMFORTABLE = "comfortable"
    SPACIOUS = "spacious"


class MotionLevel(str, Enum):
    NONE = "none"
    SUBTLE = "subtle"
    LIVELY = "lively"


class IconStyle(str, Enum):
    OUTLINE = "outline"
    SOLID = "solid"
    DUOTONE = "duotone"


class PaletteTokens(BaseModel):
    primary: str
    primary_foreground: str
    accent: str
    neutral_ramp: list[str] = Field(..., min_length=9, max_length=9)
    surface: str
    surface_elevated: str
    border: str
    text: str
    text_muted: str
    focus_ring: str
    success: str
    warning: str
    danger: str

    @field_validator(
        "primary",
        "primary_foreground",
        "accent",
        "surface",
        "surface_elevated",
        "border",
        "text",
        "text_muted",
        "focus_ring",
        "success",
        "warning",
        "danger",
    )
    @classmethod
    def check_hex_field(cls, v: str) -> str:
        return _validate_hex(v)

    @field_validator("neutral_ramp")
    @classmethod
    def check_neutral_ramp(cls, v: list[str]) -> list[str]:
        if len(v) != 9:
            raise ValueError("neutral_ramp must have exactly 9 steps (50..900)")
        return [_validate_hex(step) for step in v]

    @model_validator(mode="after")
    def reject_ghostwriter_brand_leak(self) -> "PaletteTokens":
        if self.primary in CODEX_BRAND_HEXES:
            raise ValueError(
                f"Primary color '{self.primary}' is reserved for "
                "CodeX / Ghostwriter's workspace brand"
            )
        return self


class TypographyTokens(BaseModel):
    heading_font: str
    body_font: str
    mono_font: str
    scale_ratio: float = Field(default=1.25, ge=1.12, le=1.40)

    @field_validator("heading_font")
    @classmethod
    def check_heading_font(cls, v: str) -> str:
        clean = v.strip()
        if clean not in ALLOWED_HEADING_FONTS:
            raise ValueError(f"Unknown heading_font '{clean}'")
        return clean

    @field_validator("body_font")
    @classmethod
    def check_body_font(cls, v: str) -> str:
        clean = v.strip()
        if clean not in ALLOWED_BODY_FONTS:
            raise ValueError(f"Unknown body_font '{clean}'")
        return clean

    @field_validator("mono_font")
    @classmethod
    def check_mono_font(cls, v: str) -> str:
        clean = v.strip()
        if clean not in ALLOWED_MONO_FONTS:
            raise ValueError(f"Unknown mono_font '{clean}'")
        return clean


class ShapeTokens(BaseModel):
    radius_class: RadiusClass
    border_style: BorderStyle
    shadow_style: ShadowStyle


class BrandMarkSpec(BaseModel):
    kind: str = Field(..., pattern="^(wordmark|geometric_glyph)$")
    glyph_primitive: str
    monogram_letters: str = Field(..., min_length=1, max_length=3)

    @field_validator("glyph_primitive")
    @classmethod
    def check_glyph_primitive(cls, v: str) -> str:
        clean = v.strip()
        if clean not in ALLOWED_GLYPH_PRIMITIVES:
            raise ValueError(f"Unknown glyph_primitive '{clean}'")
        return clean

    @field_validator("monogram_letters")
    @classmethod
    def check_monogram_not_gw(cls, v: str) -> str:
        clean = v.strip().upper()
        if clean in FORBIDDEN_PLATFORM_MONOGRAMS:
            raise ValueError(
                f"monogram_letters cannot be '{clean}' (reserved for CodeX / Ghostwriter)"
            )
        return clean


class DesignDirection(BaseModel):
    """Stage C: Complete design tokens, typography, shape, motion, brand mark, and rationale."""

    direction_id: str
    palette: PaletteTokens
    color_mode: ColorMode
    typography: TypographyTokens
    shape: ShapeTokens
    density: DensityClass
    motion: MotionLevel
    iconography: IconStyle
    brand_mark: BrandMarkSpec
    copy_voice: str = Field(..., min_length=10)
    rationale: str = Field(..., min_length=25)

    @field_validator("direction_id")
    @classmethod
    def check_direction_id(cls, v: str) -> str:
        clean = v.strip()
        if clean not in ALLOWED_DIRECTION_IDS:
            raise ValueError(f"Unknown direction_id '{clean}'")
        return clean


class ContrastPairResult(BaseModel):
    pair_name: str
    foreground_token: str
    background_token: str
    foreground_hex: str
    background_hex: str
    contrast_ratio: float
    required_ratio: float
    passed: bool


class ContrastAdjustmentLog(BaseModel):
    token_name: str
    background_token: str
    original_hex: str
    adjusted_hex: str
    before_ratio: float
    after_ratio: float
    required_ratio: float


class LookFingerprint(BaseModel):
    """8-tuple look fingerprint for diversity guard (Section 3.5)."""

    archetype: str
    nav_pattern: str
    home_layout: str
    primary_hue_bucket: int
    heading_font: str
    radius_class: str
    density: str
    color_mode: str

    def as_tuple(self) -> tuple[str, str, str, int, str, str, str, str]:
        return (
            self.archetype,
            self.nav_pattern,
            self.home_layout,
            self.primary_hue_bucket,
            self.heading_font,
            self.radius_class,
            self.density,
            self.color_mode,
        )


class StageDValidationReport(BaseModel):
    valid: bool
    fingerprint: LookFingerprint
    contrast_pairs: list[ContrastPairResult]
    contrast_adjustments: list[ContrastAdjustmentLog]
    diversity_passed: bool
    min_fingerprint_distance: int
    collision_diagnostics: list[str] = Field(default_factory=list)
    leakage_violations: list[str] = Field(default_factory=list)


class DesignProposalSet(BaseModel):
    """Set of 3 distinct DesignDirection proposals for the Build screen chooser."""

    proposals: list[DesignDirection] = Field(..., min_length=3, max_length=3)
