"""Stage E Application Generator: Composes apps from AppBlueprint + DesignDirection + ui_kit."""

import os
import zipfile
from pathlib import Path
from typing import Any, Optional

from engine.spec import WorkflowSpec
from generators.backend_composer import compose_backend_files
from generators.blueprint.archetypes import resolve_benchmark_bundle
from generators.blueprint.compiler import propose_three_directions
from generators.blueprint.schemas import AppBlueprint
from generators.design.contrast import validate_and_adjust_palette
from generators.design.fingerprint import validate_stage_d
from generators.design.schemas import DesignDirection, LookFingerprint
from generators.frontend_composer import compose_frontend_files
from generators.schemas import GeneratedAppManifest, GeneratedFile
from generators.standalone_bundler import compose_standalone_html


def _compose_readme_md(
    project_id: str,
    blueprint: AppBlueprint,
    direction: DesignDirection,
    routes: list[str],
    models: list[str],
) -> str:
    entity_lines = "\n".join(
        f"- **{ent.plural_label}** (`{ent.name}`): "
        + ", ".join(f"`{fld.name}` ({fld.field_type.value})" for fld in ent.fields)
        for ent in blueprint.entities
    )
    page_lines = "\n".join(
        f"- **{pg.title}** (`{pg.route}`) — Layout: `{pg.layout.value}`" for pg in blueprint.pages
    )
    route_lines = "\n".join(f"- `{r}`" for r in routes)
    model_lines = "\n".join(f"- `{m}`" for m in models)
    color_line = (
        f"- **Color Mode**: `{direction.color_mode.value}` | "
        f"**Primary**: `{direction.palette.primary}` | "
        f"**Surface**: `{direction.palette.surface}`"
    )
    type_line = (
        f"- **Typography**: Heading `{direction.typography.heading_font}` · "
        f"Body `{direction.typography.body_font}` · "
        f"Mono `{direction.typography.mono_font}`"
    )
    shape_line = (
        f"- **Shape & Density**: Radius `{direction.shape.radius_class.value}` · "
        f"Density `{direction.density.value}`"
    )

    return f"""# {blueprint.app_name}

> {blueprint.product_tagline}

## Product & Domain Summary
- **Product Kind**: {blueprint.domain.product_kind}
- **Archetype**: `{blueprint.domain.archetype.value}`
- **Primary Object**: `{blueprint.domain.primary_object}`
- **Target Audience**: {blueprint.domain.audience.who} ({blueprint.domain.audience.context_of_use})
- **Navigation Pattern**: `{blueprint.navigation.pattern.value}`
- **Home Page**: `{blueprint.home_page_id}` (`{blueprint.get_home_page().layout.value}`)

## Design Direction (`{direction.direction_id}`)
{color_line}
{type_line}
{shape_line}
- **Rationale**: {direction.rationale}

## Domain Entities
{entity_lines}

## Application Screens
{page_lines}

## API Endpoints
{route_lines}

## SQLAlchemy Models
{model_lines}

## Local Execution

### 1. Instant Standalone UI
Open `standalone_app.html` directly in any browser (zero external CDN dependencies).

### 2. Backend API (`FastAPI` + `SQLite`)
```bash
cd backend
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### 3. React + Vite Frontend
```bash
cd frontend
npm install
npm run dev
```
"""


def _sync_target_dir_preserving_databases(
    target_dir: Path,
    files: list[GeneratedFile],
    restyle_only: bool = False,
) -> None:
    """
    Writes generated files to target_dir while preserving any SQLite .db/.sqlite files,
    and when restyle_only=True, leaves existing backend files untouched.
    """
    target_dir.mkdir(parents=True, exist_ok=True)
    expected_rel_paths = {Path(f.path) for f in files}

    for root, _, filenames in os.walk(target_dir):
        for filename in filenames:
            abs_file = Path(root) / filename
            if abs_file.suffix.lower() in (".db", ".sqlite", ".sqlite3"):
                continue
            rel_file = abs_file.relative_to(target_dir)
            if rel_file not in expected_rel_paths:
                abs_file.unlink(missing_ok=True)

    for f in files:
        file_path = target_dir / f.path
        if restyle_only and f.category == "backend" and file_path.exists():
            continue
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(f.content, encoding="utf-8")


class AppGenerator:
    """
    Stage E Adaptive Application Generator.
    Composes backend, frontend (from generators/ui_kit/), and standalone_app.html
    from a validated AppBlueprint and DesignDirection.
    """

    @classmethod
    def generate_from_blueprint(
        cls,
        blueprint: AppBlueprint,
        direction: DesignDirection,
        output_base_dir: str = "apps/generated",
        project_id_override: Optional[str] = None,
        name_override: Optional[str] = None,
        version: int = 1,
        workflow: Optional[WorkflowSpec] = None,
        sample_seed_data: Optional[dict[str, list[dict[str, Any]]]] = None,
        direction_proposals: Optional[list[DesignDirection]] = None,
        existing_fingerprints: Optional[list[tuple[str, LookFingerprint]]] = None,
        custom_widgets: Optional[dict[str, str]] = None,
        allow_opt_in_footer: bool = False,
        previous_direction: Optional[DesignDirection] = None,
        design_history_count: int = 0,
        restyle_only: bool = False,
    ) -> GeneratedAppManifest:
        display_name = name_override or blueprint.app_name
        clean_name = "".join(c if c.isalnum() else "_" for c in display_name.lower()).strip("_")
        project_id = project_id_override or clean_name or "adaptive_app"
        target_dir = Path(output_base_dir) / project_id

        if sample_seed_data is None:
            bundle = resolve_benchmark_bundle(
                f"{blueprint.app_name} {blueprint.domain.product_kind} "
                f"{blueprint.domain.primary_object}"
            )
            sample_seed_data = bundle.sample_seed_data

        # Ensure palette passes WCAG AA contrast before composing CSS and HTML tokens
        adj_palette, initial_adjustments, _ = validate_and_adjust_palette(direction.palette)
        effective_direction = direction.model_copy(update={"palette": adj_palette})
        effective_bp = blueprint.model_copy(update={"app_name": display_name})

        backend_files, routes, models = compose_backend_files(
            project_id=project_id,
            blueprint=effective_bp,
            sample_seed_data=sample_seed_data,
            workflow=workflow,
        )

        frontend_files = compose_frontend_files(
            project_id=project_id,
            blueprint=effective_bp,
            direction=effective_direction,
            sample_seed_data=sample_seed_data,
            custom_widgets=custom_widgets,
            allow_opt_in_footer=allow_opt_in_footer,
        )

        standalone_html = compose_standalone_html(
            project_id=project_id,
            blueprint=effective_bp,
            direction=effective_direction,
            sample_seed_data=sample_seed_data,
            allow_opt_in_footer=allow_opt_in_footer,
        )

        readme_md = _compose_readme_md(
            project_id=project_id,
            blueprint=effective_bp,
            direction=effective_direction,
            routes=routes,
            models=models,
        )

        all_files: list[GeneratedFile] = [
            *backend_files,
            *frontend_files,
            GeneratedFile(
                path="standalone_app.html",
                content=standalone_html,
                category="frontend",
                description=f"Zero-CDN standalone HTML application for {effective_bp.app_name}",
            ),
            GeneratedFile(
                path="README.md",
                content=readme_md,
                category="docs",
                description=f"Architecture and setup guide for {effective_bp.app_name}",
            ),
        ]

        # Stage D deterministic validation on the complete generated source tree
        file_map = {f.path: f.content for f in all_files}
        validated_direction, validation_report = validate_stage_d(
            domain=effective_bp.domain,
            blueprint=effective_bp,
            direction=effective_direction,
            existing_fingerprints=existing_fingerprints or [],
            generated_files=file_map,
            allow_opt_in_footer=allow_opt_in_footer,
        )
        if initial_adjustments and not validation_report.contrast_adjustments:
            validation_report.contrast_adjustments = initial_adjustments

        if validation_report.leakage_violations:
            raise ValueError(
                "Stage D leakage guard rejected generated application:\n"
                + "\n".join(validation_report.leakage_violations)
            )
        if not all(p.passed for p in validation_report.contrast_pairs):
            raise ValueError("Stage D WCAG AA contrast check failed on generated application.")

        _sync_target_dir_preserving_databases(
            target_dir=target_dir,
            files=all_files,
            restyle_only=restyle_only,
        )

        zip_path = target_dir.parent / f"{project_id}.zip"
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for root, _, filenames in os.walk(target_dir):
                for filename in filenames:
                    abs_file = Path(root) / filename
                    if abs_file.suffix.lower() in (".db", ".sqlite", ".sqlite3"):
                        continue
                    rel_file = abs_file.relative_to(target_dir)
                    zf.write(abs_file, str(rel_file))

        proposals = direction_proposals or propose_three_directions(
            prompt=effective_bp.app_name,
            domain=effective_bp.domain,
            blueprint=effective_bp,
            primary_direction=validated_direction,
        )

        return GeneratedAppManifest(
            project_id=project_id,
            name=display_name,
            version=version,
            output_dir=str(target_dir),
            files=all_files,
            routes=routes,
            models=models,
            zip_path=str(zip_path),
            blueprint=effective_bp,
            design_direction=validated_direction,
            previous_design_direction=previous_direction,
            direction_proposals=proposals,
            design_history_count=design_history_count,
            validation_report=validation_report,
        )

    @classmethod
    def generate(
        cls,
        workflow: WorkflowSpec,
        output_base_dir: str = "apps/generated",
        blueprint: Optional[AppBlueprint] = None,
        direction: Optional[DesignDirection] = None,
        allow_opt_in_footer: bool = False,
        previous_direction: Optional[DesignDirection] = None,
        design_history_count: int = 0,
        restyle_only: bool = False,
    ) -> GeneratedAppManifest:
        """
        Generates a complete adaptive application from a WorkflowSpec (and optional
        explicit AppBlueprint + DesignDirection).
        """
        if blueprint is not None:
            search_hint = (
                f"{blueprint.app_name} {blueprint.domain.product_kind} "
                f"{blueprint.domain.primary_object} {workflow.name} {workflow.description}"
            )
        else:
            search_hint = f"{workflow.name} {workflow.description}"
        bundle = resolve_benchmark_bundle(search_hint)
        active_bp = blueprint or bundle.blueprint
        active_dir = direction or bundle.primary_direction

        return cls.generate_from_blueprint(
            blueprint=active_bp,
            direction=active_dir,
            output_base_dir=output_base_dir,
            name_override=workflow.name,
            version=workflow.version,
            workflow=workflow,
            sample_seed_data=bundle.sample_seed_data,
            direction_proposals=bundle.direction_proposals,
            allow_opt_in_footer=allow_opt_in_footer,
            previous_direction=previous_direction,
            design_history_count=design_history_count,
            restyle_only=restyle_only,
        )
