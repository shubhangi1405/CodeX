"""Stage E Backend Composer: Generates SQLAlchemy models, FastAPI CRUD routes, and seed scripts."""

import json
from typing import Any, Optional

from engine.spec import WorkflowSpec
from generators.blueprint.schemas import AppBlueprint, EntitySpec, FieldSpec, FieldType
from generators.schemas import GeneratedFile


def _to_pascal_case(snake_str: str) -> str:
    return "".join(part.capitalize() for part in snake_str.split("_") if part)


def _sqlalchemy_column_type(field: FieldSpec) -> str:
    ft = field.field_type
    if ft == FieldType.INTEGER:
        return "Integer"
    if ft in (FieldType.FLOAT, FieldType.CURRENCY):
        return "Float"
    if ft == FieldType.BOOLEAN:
        return "Boolean"
    if ft == FieldType.TEXT:
        return "Text"
    return "String"


def _pydantic_field_type(field: FieldSpec) -> str:
    ft = field.field_type
    if ft == FieldType.INTEGER:
        return "int"
    if ft in (FieldType.FLOAT, FieldType.CURRENCY):
        return "float"
    if ft == FieldType.BOOLEAN:
        return "bool"
    return "str"


def _default_python_literal(field: FieldSpec) -> str:
    if field.default_value is not None:
        return repr(field.default_value)
    ft = field.field_type
    if ft == FieldType.INTEGER:
        return "0"
    if ft in (FieldType.FLOAT, FieldType.CURRENCY):
        return "0.0"
    if ft == FieldType.BOOLEAN:
        return "False"
    if ft == FieldType.ENUM and field.enum_values:
        return repr(field.enum_values[0])
    return "''"


def _compose_requirements_txt() -> str:
    return (
        "fastapi>=0.115.0\n"
        "uvicorn>=0.32.0\n"
        "sqlalchemy>=2.0.36\n"
        "pydantic>=2.10.0\n"
        "python-multipart>=0.0.12\n"
    )


def _compose_database_py(project_id: str) -> str:
    return f'''"""SQLAlchemy database configuration for {project_id}."""

from typing import Generator
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

DATABASE_URL = "sqlite:///./{project_id}.db"

engine = create_engine(
    DATABASE_URL,
    connect_args={{"check_same_thread": False}},
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
'''


def _compose_models_py(blueprint: AppBlueprint) -> tuple[str, list[str]]:
    model_names: list[str] = []
    lines: list[str] = [
        f'"""Domain SQLAlchemy ORM models for {blueprint.app_name}."""',
        "",
        "from datetime import datetime, timezone",
        "from uuid import uuid4",
        "from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text",
        "from database import Base",
        "",
    ]

    for entity in blueprint.entities:
        class_name = f"{_to_pascal_case(entity.name)}Model"
        model_names.append(class_name)
        lines.append(f"class {class_name}(Base):")
        lines.append(f'    __tablename__ = "{entity.name}s"')
        lines.append("")
        lines.append("    id = Column(String, primary_key=True, default=lambda: str(uuid4()))")
        if blueprint.auth.required:
            lines.append("    owner_id = Column(String, nullable=True)")
        for fld in entity.fields:
            col_type = _sqlalchemy_column_type(fld)
            nullable = "False" if fld.required else "True"
            default_lit = _default_python_literal(fld)
            lines.append(
                f"    {fld.name} = Column({col_type}, nullable={nullable}, default={default_lit})"
            )
        lines.append(
            "    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))"
        )
        lines.append("")

    if blueprint.domain.needs_automation and blueprint.automations:
        model_names.append("AutomationExecutionModel")
        lines.append("class AutomationExecutionModel(Base):")
        lines.append('    __tablename__ = "automation_executions"')
        lines.append("")
        lines.append("    id = Column(String, primary_key=True, default=lambda: str(uuid4()))")
        lines.append("    automation_id = Column(String, nullable=False)")
        lines.append("    status = Column(String, nullable=False, default='completed')")
        lines.append("    summary_json = Column(Text, nullable=False, default='{}')")
        lines.append(
            "    executed_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))"
        )
        lines.append("")

    if blueprint.auth.required:
        lines.extend(
            [
                "class UserModel(Base):",
                '    __tablename__ = "users"',
                "",
                "    id = Column(String, primary_key=True, default=lambda: str(uuid4()))",
                "    email = Column(String, unique=True, nullable=False)",
                "    password_hash = Column(String, nullable=False)",
                "    display_name = Column(String, nullable=False, default='')",
                "    role = Column(String, nullable=False, default='member')",
                "    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))",
                "",
                "class SessionTokenModel(Base):",
                '    __tablename__ = "session_tokens"',
                "",
                "    id = Column(String, primary_key=True, default=lambda: str(uuid4()))",
                "    token = Column(String, unique=True, nullable=False)",
                "    user_id = Column(String, nullable=False)",
                "    revoked = Column(Boolean, default=False, nullable=False)",
                "    expires_at = Column(DateTime, nullable=False)",
                "    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))",
                "",
            ]
        )

    return "\n".join(lines), model_names


def _compose_auth_py(blueprint: AppBlueprint) -> str:
    return '''"""Authentication, password security, session management, and RBAC."""

import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional
from fastapi import Depends, HTTPException, Header, Query
from sqlalchemy.orm import Session
from database import get_db
from models import UserModel, SessionTokenModel


def hash_password(password: str) -> str:
    """Hashes a password using PBKDF2-HMAC-SHA256 with a cryptographically secure salt."""
    salt = secrets.token_hex(16)
    derived = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 100000)
    return f"{salt}:{derived.hex()}"


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifies a plain password against the stored salt:hash string."""
    try:
        salt, expected_hex = hashed_password.split(":", 1)
        derived = hashlib.pbkdf2_hmac("sha256", plain_password.encode("utf-8"), salt.encode("utf-8"), 100000)
        return hmac.compare_digest(derived.hex(), expected_hex)
    except Exception:
        return False


def create_session(db: Session, user_id: str, lifetime_hours: int = 24) -> str:
    """Creates a random 64-char session token with an expiration timestamp."""
    token_str = secrets.token_hex(32)
    expires_at = datetime.now(timezone.utc) + timedelta(hours=lifetime_hours)
    token_rec = SessionTokenModel(
        token=token_str,
        user_id=user_id,
        expires_at=expires_at,
        revoked=False,
    )
    db.add(token_rec)
    db.commit()
    return token_str


def get_user_from_token(db: Session, token: str) -> Optional[UserModel]:
    """Retrieves an active user if the session token is valid and unexpired."""
    rec = db.query(SessionTokenModel).filter(
        SessionTokenModel.token == token,
        SessionTokenModel.revoked == False,
    ).first()
    if not rec:
        return None
    now = datetime.now(timezone.utc)
    exp = rec.expires_at
    if exp.tzinfo is None:
        exp = exp.replace(tzinfo=timezone.utc)
    if exp < now:
        return None
    return db.query(UserModel).filter(UserModel.id == rec.user_id).first()


def revoke_session(db: Session, token: str) -> bool:
    """Revokes a session token immediately."""
    rec = db.query(SessionTokenModel).filter(SessionTokenModel.token == token).first()
    if rec:
        rec.revoked = True
        db.commit()
        return True
    return False


def get_current_user_optional(
    authorization: Optional[str] = Header(None),
    x_session_token: Optional[str] = Header(None),
    token: Optional[str] = Query(None),
    db: Session = Depends(get_db),
) -> Optional[UserModel]:
    """Extracts session token from Bearer auth, custom header, or query param without failing."""
    raw_token = None
    if authorization and authorization.lower().startswith("bearer "):
        raw_token = authorization[7:].strip()
    elif x_session_token:
        raw_token = x_session_token.strip()
    elif token:
        raw_token = token.strip()

    if not raw_token:
        return None
    return get_user_from_token(db, raw_token)


def get_current_user(
    current_user: Optional[UserModel] = Depends(get_current_user_optional),
) -> UserModel:
    """FastAPI dependency requiring an authenticated active user."""
    if not current_user:
        raise HTTPException(status_code=401, detail="Authentication required")
    return current_user
'''


def _compose_seed_py(
    blueprint: AppBlueprint,
    sample_seed_data: dict[str, list[dict[str, Any]]],
) -> str:
    seed_json = json.dumps(sample_seed_data, indent=2)
    entity_imports = [f"{_to_pascal_case(e.name)}Model" for e in blueprint.entities]
    if blueprint.auth.required:
        entity_imports.append("UserModel")
    imports_str = ", ".join(entity_imports)

    auth_import_stmt = "from auth import hash_password\n" if blueprint.auth.required else ""

    lines: list[str] = [
        f'"""Optional sample seed data loader for {blueprint.app_name}."""',
        "",
        "import json",
        "from sqlalchemy.orm import Session",
        "from database import Base, SessionLocal, engine",
        f"from models import {imports_str}",
        auth_import_stmt,
        f"SAMPLE_SEED_DATA = json.loads(r'''{seed_json}''')",
        "",
        "",
        "def seed_database(db: Session) -> dict[str, int]:",
        '    """Inserts domain sample records if tables are currently empty."""',
        "    inserted: dict[str, int] = {}",
    ]

    if blueprint.auth.required:
        lines.extend(
            [
                "    if db.query(UserModel).count() == 0:",
                "        admin_u = UserModel(",
                '            id="usr-admin",',
                '            email="admin@workspace.example",',
                '            password_hash=hash_password("Password123!"),',
                '            display_name="Admin Director",',
                '            role="admin",',
                "        )",
                "        member_u = UserModel(",
                '            id="usr-member",',
                '            email="member@workspace.example",',
                '            password_hash=hash_password("Password123!"),',
                '            display_name="Active Member",',
                '            role="member",',
                "        )",
                "        db.add_all([admin_u, member_u])",
                "        db.commit()",
                '        inserted["users"] = 2',
                "",
            ]
        )

    for entity in blueprint.entities:
        model_cls = f"{_to_pascal_case(entity.name)}Model"
        field_names = [f.name for f in entity.fields]
        lines.append(f'    records_{entity.name} = SAMPLE_SEED_DATA.get("{entity.name}", [])')
        lines.append(f"    existing_{entity.name} = db.query({model_cls}).count()")
        lines.append(f"    count_{entity.name} = 0")
        lines.append(f"    if existing_{entity.name} == 0:")
        lines.append(f"        for row in records_{entity.name}:")
        lines.append(f"            allowed = {repr(field_names)}")
        lines.append(
            "            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}"
        )
        if blueprint.auth.required:
            lines.append("            if 'owner_id' not in payload:")
            lines.append("                payload['owner_id'] = 'usr-member'")
        lines.append(f"            db.add({model_cls}(**payload))")
        lines.append(f"            count_{entity.name} += 1")
        lines.append(f'    inserted["{entity.name}"] = count_{entity.name}')

    lines.extend(
        [
            "    db.commit()",
            "    return inserted",
            "",
            "",
            'if __name__ == "__main__":',
            "    Base.metadata.create_all(bind=engine)",
            "    with SessionLocal() as session:",
            "        result = seed_database(session)",
            '        print("Seeded sample records:", result)',
            "",
        ]
    )
    return "\n".join(lines)


def _compose_engine_py(workflow: WorkflowSpec) -> str:
    wf_json = json.dumps(workflow.model_dump(), indent=2)
    return f'''"""Embedded deterministic automation engine for {workflow.name}."""

import json
from typing import Any

WORKFLOW_SPEC: dict[str, Any] = json.loads(r\'\'\'{wf_json}\'\'\')


def execute_automation_pipeline(records: list[dict[str, Any]]) -> dict[str, Any]:
    """Executes the validated workflow rules against domain records."""
    valid_count = 0
    quarantined_count = 0
    total_metric = 0.0

    for row in records:
        has_values = all(v is not None and str(v).strip() != "" for v in row.values())
        if has_values:
            valid_count += 1
            for val in row.values():
                if isinstance(val, (int, float)) and not isinstance(val, bool):
                    total_metric += float(val)
        else:
            quarantined_count += 1

    return {{
        "workflow_id": WORKFLOW_SPEC.get("id", "automation"),
        "workflow_name": WORKFLOW_SPEC.get("name", "Automation Pipeline"),
        "valid_records": valid_count,
        "quarantined_records": quarantined_count,
        "aggregated_metric": round(total_metric, 2),
    }}
'''


def _compose_entity_crud_block(
    entity: EntitySpec,
    auth_required: bool = False,
) -> tuple[list[str], list[str]]:
    model_cls = f"{_to_pascal_case(entity.name)}Model"
    create_schema = f"{_to_pascal_case(entity.name)}Create"
    update_schema = f"{_to_pascal_case(entity.name)}Update"
    routes = [
        f"GET /api/{entity.name}",
        f"POST /api/{entity.name}",
        f"PUT /api/{entity.name}/{{item_id}}",
        f"DELETE /api/{entity.name}/{{item_id}}",
    ]

    lines: list[str] = [
        f"class {create_schema}(BaseModel):",
    ]
    for fld in entity.fields:
        py_t = _pydantic_field_type(fld)
        default_lit = _default_python_literal(fld)
        lines.append(f"    {fld.name}: {py_t} = {default_lit}")

    lines.append("")
    lines.append(f"class {update_schema}(BaseModel):")
    for fld in entity.fields:
        py_t = _pydantic_field_type(fld)
        lines.append(f"    {fld.name}: Optional[{py_t}] = None")

    field_dict_entries = ", ".join(
        f'"{fld.name}": getattr(item, "{fld.name}")' for fld in entity.fields
    )

    owner_dict_line = (
        '    if hasattr(item, "owner_id") and item.owner_id: d["owner_id"] = item.owner_id\n'
        if auth_required
        else ""
    )

    lines.extend(
        [
            "",
            f"def _serialize_{entity.name}(item: {model_cls}) -> dict[str, Any]:",
            f'    d = {{"id": item.id, {field_dict_entries}}}',
            owner_dict_line,
            "    return d",
            "",
            f'@app.get("/api/{entity.name}")',
            f"def list_{entity.name}(",
            "    mine_only: bool = False,",
            "    current_user: Optional[Any] = Depends(get_current_user_optional)"
            if auth_required
            else "    current_user: Optional[Any] = None",
            ",    db: Session = Depends(get_db),",
            ") -> list[dict[str, Any]]:",
            f"    query = db.query({model_cls})",
        ]
    )

    if auth_required:
        lines.extend(
            [
                "    if mine_only:",
                "        if not current_user:",
                '            raise HTTPException(status_code=401, detail="Authentication required for personal records")',
                f"        query = query.filter({model_cls}.owner_id == current_user.id)",
            ]
        )

    lines.extend(
        [
            f"    rows = query.order_by({model_cls}.created_at.desc()).all()",
            f"    return [_serialize_{entity.name}(r) for r in rows]",
            "",
            f'@app.post("/api/{entity.name}", status_code=201)',
            f"def create_{entity.name}(",
            f"    payload: {create_schema},",
            "    current_user: Optional[Any] = Depends(get_current_user_optional)"
            if auth_required
            else "    current_user: Optional[Any] = None",
            ",    db: Session = Depends(get_db),",
            ") -> dict[str, Any]:",
            "    data = payload.model_dump()",
        ]
    )

    if auth_required:
        lines.extend(
            [
                "    if current_user:",
                '        data["owner_id"] = current_user.id',
            ]
        )

    lines.extend(
        [
            f"    record = {model_cls}(**data)",
            "    db.add(record)",
            "    db.commit()",
            "    db.refresh(record)",
            f"    return _serialize_{entity.name}(record)",
            "",
            f'@app.put("/api/{entity.name}/{{item_id}}")',
            f"def update_{entity.name}(",
            f"    item_id: str, payload: {update_schema},",
            "    current_user: Optional[Any] = Depends(get_current_user_optional)"
            if auth_required
            else "    current_user: Optional[Any] = None",
            ",    db: Session = Depends(get_db),",
            ") -> dict[str, Any]:",
            f"    record = db.query({model_cls}).filter({model_cls}.id == item_id).first()",
            "    if not record:",
            "        raise HTTPException(",
            f'            status_code=404, detail="{entity.singular_label} not found"',
            "        )",
        ]
    )

    if auth_required:
        lines.extend(
            [
                '    if hasattr(record, "owner_id") and record.owner_id and current_user:',
                '        if record.owner_id != current_user.id and getattr(current_user, "role", "") not in ("admin", "manager"):',
                '            raise HTTPException(status_code=403, detail="Forbidden: you do not own this record")',
            ]
        )

    lines.extend(
        [
            "    for k, v in payload.model_dump(exclude_unset=True).items():",
            "        if v is not None:",
            "            setattr(record, k, v)",
            "    db.commit()",
            "    db.refresh(record)",
            f"    return _serialize_{entity.name}(record)",
            "",
            f'@app.delete("/api/{entity.name}/{{item_id}}")',
            f"def delete_{entity.name}(",
            "    item_id: str,",
            "    current_user: Optional[Any] = Depends(get_current_user_optional)"
            if auth_required
            else "    current_user: Optional[Any] = None",
            ",    db: Session = Depends(get_db),",
            ") -> dict[str, str]:",
            f"    record = db.query({model_cls}).filter({model_cls}.id == item_id).first()",
            "    if not record:",
            "        raise HTTPException(",
            f'            status_code=404, detail="{entity.singular_label} not found"',
            "        )",
        ]
    )

    if auth_required:
        lines.extend(
            [
                '    if hasattr(record, "owner_id") and record.owner_id and current_user:',
                '        if record.owner_id != current_user.id and getattr(current_user, "role", "") not in ("admin", "manager"):',
                '            raise HTTPException(status_code=403, detail="Forbidden: you do not own this record")',
            ]
        )

    lines.extend(
        [
            "    db.delete(record)",
            "    db.commit()",
            '    return {"status": "deleted", "id": item_id}',
            "",
        ]
    )
    return lines, routes


def _compose_main_py(blueprint: AppBlueprint) -> tuple[str, list[str]]:
    entity_models = [f"{_to_pascal_case(e.name)}Model" for e in blueprint.entities]
    if blueprint.domain.needs_automation and blueprint.automations:
        entity_models.append("AutomationExecutionModel")
    if blueprint.auth.required:
        entity_models.extend(["UserModel", "SessionTokenModel"])
    models_import = ", ".join(entity_models)

    threat_json = json.dumps(blueprint.threat_model.model_dump(), indent=2)

    lines: list[str] = [
        f'"""FastAPI backend for {blueprint.app_name} — {blueprint.product_tagline}."""',
        "",
        "import json",
        "import time",
        "from datetime import datetime, timezone",
        "from typing import Any, Optional",
        "from fastapi import Depends, FastAPI, HTTPException, Header, Response",
        "from fastapi.middleware.cors import CORSMiddleware",
        "from pydantic import BaseModel",
        "from sqlalchemy.orm import Session",
        "from database import Base, engine, get_db",
        f"from models import {models_import}",
        "from seed import seed_database",
    ]

    if blueprint.auth.required:
        lines.extend(
            [
                "from auth import (",
                "    create_session,",
                "    get_current_user,",
                "    get_current_user_optional,",
                "    hash_password,",
                "    revoke_session,",
                "    verify_password,",
                ")",
            ]
        )
    else:
        lines.extend(
            [
                "def get_current_user_optional() -> Optional[Any]:",
                "    return None",
            ]
        )

    if blueprint.domain.needs_automation and blueprint.automations:
        lines.append("from engine import execute_automation_pipeline")

    lines.extend(
        [
            "",
            f"THREAT_MODEL_JSON = json.loads(r'''{threat_json}''')",
            "_CLIENT_REQUEST_TIMESTAMPS: dict[str, list[float]] = {}",
            "",
            "Base.metadata.create_all(bind=engine)",
            "",
            "app = FastAPI(",
            f"    title={repr(blueprint.app_name)},",
            f"    description={repr(blueprint.product_tagline)},",
            '    version="1.0.0",',
            ")",
            "",
            "app.add_middleware(",
            "    CORSMiddleware,",
            '    allow_origins=["*"],',
            "    allow_credentials=True,",
            '    allow_methods=["*"],',
            '    allow_headers=["*"],',
            ")",
            "",
            "@app.middleware('http')",
            "async def security_and_rate_limit_middleware(request, call_next):",
            "    client_ip = request.client.host if request.client else '127.0.0.1'",
            "    path = request.url.path",
            "    if path.startswith('/api/auth/') and request.method == 'POST':",
            "        now = time.time()",
            "        bucket = _CLIENT_REQUEST_TIMESTAMPS.setdefault(client_ip, [])",
            "        bucket[:] = [t for t in bucket if now - t < 60.0]",
            "        if len(bucket) >= 40:",
            "            return Response(",
            '                content=json.dumps({"detail": "Rate limit exceeded. Please wait before retrying."}),',
            "                status_code=429,",
            '                media_type="application/json",',
            "            )",
            "        bucket.append(now)",
            "",
            "    response = await call_next(request)",
            '    response.headers["X-Content-Type-Options"] = "nosniff"',
            '    response.headers["X-Frame-Options"] = "DENY"',
            '    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"',
            "    return response",
            "",
        ]
    )

    all_routes: list[str] = []
    for entity in blueprint.entities:
        crud_lines, entity_routes = _compose_entity_crud_block(
            entity, auth_required=blueprint.auth.required
        )
        lines.extend(crud_lines)
        all_routes.extend(entity_routes)

    # Auth routes
    if blueprint.auth.required:
        lines.extend(
            [
                "class RegisterRequest(BaseModel):",
                "    email: str",
                "    password: str",
                "    display_name: Optional[str] = ''",
                "    role: Optional[str] = 'member'",
                "",
                "class LoginRequest(BaseModel):",
                "    email: str",
                "    password: str",
                "",
                "class ResetPasswordRequest(BaseModel):",
                "    email: str",
                "    new_password: str",
                "",
                '@app.post("/api/auth/register", status_code=201)',
                "def api_auth_register(payload: RegisterRequest, db: Session = Depends(get_db)) -> dict[str, Any]:",
                '    if not payload.email or "@" not in payload.email:',
                '        raise HTTPException(status_code=422, detail="Valid email required")',
                "    if len(payload.password) < 8:",
                '        raise HTTPException(status_code=422, detail="Password must be at least 8 characters")',
                "    existing = db.query(UserModel).filter(UserModel.email == payload.email).first()",
                "    if existing:",
                '        raise HTTPException(status_code=409, detail="Email already registered")',
                "    u = UserModel(",
                "        email=payload.email,",
                "        password_hash=hash_password(payload.password),",
                '        display_name=payload.display_name or payload.email.split("@")[0],',
                "        role=payload.role or 'member',",
                "    )",
                "    db.add(u)",
                "    db.commit()",
                "    db.refresh(u)",
                "    token = create_session(db, u.id)",
                '    return {"token": token, "user": {"id": u.id, "email": u.email, "display_name": u.display_name, "role": u.role}}',
                "",
                '@app.post("/api/auth/login")',
                "def api_auth_login(payload: LoginRequest, db: Session = Depends(get_db)) -> dict[str, Any]:",
                "    u = db.query(UserModel).filter(UserModel.email == payload.email).first()",
                "    if not u or not verify_password(payload.password, u.password_hash):",
                '        raise HTTPException(status_code=401, detail="Invalid email or password")',
                "    token = create_session(db, u.id)",
                '    return {"token": token, "user": {"id": u.id, "email": u.email, "display_name": u.display_name, "role": u.role}}',
                "",
                '@app.post("/api/auth/logout")',
                "def api_auth_logout(",
                "    current_user: UserModel = Depends(get_current_user),",
                "    authorization: Optional[str] = Header(None),",
                "    db: Session = Depends(get_db),",
                ") -> dict[str, str]:",
                "    if authorization and authorization.lower().startswith('bearer '):",
                "        revoke_session(db, authorization[7:].strip())",
                '    return {"status": "logged_out"}',
                "",
                '@app.get("/api/auth/me")',
                "def api_auth_me(current_user: UserModel = Depends(get_current_user)) -> dict[str, Any]:",
                '    return {"id": current_user.id, "email": current_user.email, "display_name": current_user.display_name, "role": current_user.role}',
                "",
                '@app.post("/api/auth/reset-password")',
                "def api_auth_reset_password(payload: ResetPasswordRequest, db: Session = Depends(get_db)) -> dict[str, str]:",
                "    if len(payload.new_password) < 8:",
                '        raise HTTPException(status_code=422, detail="Password must be at least 8 characters")',
                "    u = db.query(UserModel).filter(UserModel.email == payload.email).first()",
                "    if not u:",
                '        raise HTTPException(status_code=404, detail="Account not found")',
                "    u.password_hash = hash_password(payload.new_password)",
                "    db.commit()",
                '    return {"status": "password_reset_success"}',
                "",
                '@app.get("/api/auth/status")',
                "def api_auth_status() -> dict[str, Any]:",
                "    return {",
                '        "auth_required": True,',
                '        "strategy": "token_session",',
                f'        "rationale": {repr(blueprint.auth.rationale)},',
                "    }",
                "",
            ]
        )
        all_routes.extend(
            [
                "POST /api/auth/register",
                "POST /api/auth/login",
                "POST /api/auth/logout",
                "GET /api/auth/me",
                "POST /api/auth/reset-password",
                "GET /api/auth/status",
            ]
        )
    else:
        lines.extend(
            [
                '@app.get("/api/auth/status")',
                "def api_auth_status() -> dict[str, Any]:",
                "    return {",
                '        "auth_required": False,',
                '        "strategy": "none",',
                f'        "rationale": {repr(blueprint.auth.rationale)},',
                "    }",
                "",
            ]
        )
        all_routes.append("GET /api/auth/status")

    # Security and Privacy routes
    lines.extend(
        [
            '@app.get("/api/privacy/export")',
            "def api_privacy_export(",
            "    current_user: Optional[Any] = Depends(get_current_user_optional)"
            if blueprint.auth.required
            else "    current_user: Optional[Any] = None",
            ",    db: Session = Depends(get_db),",
            ") -> dict[str, Any]:",
            "    payload: dict[str, Any] = {",
            f'        "application": {repr(blueprint.app_name)},',
            '        "exported_at": datetime.now(timezone.utc).isoformat(),',
            '        "user": {"id": current_user.id, "email": current_user.email} if current_user else None,',
            '        "records": {},',
            "    }",
        ]
    )

    for ent in blueprint.entities:
        model_name = f"{_to_pascal_case(ent.name)}Model"
        lines.extend(
            [
                f"    q_{ent.name} = db.query({model_name})",
                f"    if current_user and hasattr({model_name}, 'owner_id'):",
                f"        q_{ent.name} = q_{ent.name}.filter({model_name}.owner_id == current_user.id)",
                f'    payload["records"]["{ent.name}"] = [_serialize_{ent.name}(r) for r in q_{ent.name}.all()]',
            ]
        )

    lines.extend(
        [
            "    return payload",
            "",
            '@app.delete("/api/privacy/account")',
            "def api_privacy_account_deletion(",
            "    current_user: Any = Depends(get_current_user)"
            if blueprint.auth.required
            else "    current_user: Optional[Any] = None",
            ",    db: Session = Depends(get_db),",
            ") -> dict[str, Any]:",
        ]
    )

    if blueprint.auth.required:
        for ent in blueprint.entities:
            model_name = f"{_to_pascal_case(ent.name)}Model"
            lines.extend(
                [
                    f"    if hasattr({model_name}, 'owner_id'):",
                    f"        db.query({model_name}).filter({model_name}.owner_id == current_user.id).delete()",
                ]
            )
        lines.extend(
            [
                "    db.query(SessionTokenModel).filter(SessionTokenModel.user_id == current_user.id).delete()",
                "    db.query(UserModel).filter(UserModel.id == current_user.id).delete()",
                "    db.commit()",
                '    return {"status": "account_and_records_deleted", "user_id": current_user.id}',
                "",
            ]
        )
    else:
        lines.extend(
            [
                '    return {"status": "no_account_required_public_app"}',
                "",
            ]
        )

    lines.extend(
        [
            '@app.get("/api/security/threat-model")',
            "def api_security_threat_model() -> dict[str, Any]:",
            "    return THREAT_MODEL_JSON",
            "",
            '@app.get("/api/analytics/summary")',
            "def api_analytics_summary(db: Session = Depends(get_db)) -> dict[str, Any]:",
            "    counts: dict[str, int] = {}",
            "    total_count = 0",
        ]
    )

    for ent in blueprint.entities:
        model_name = f"{_to_pascal_case(ent.name)}Model"
        lines.extend(
            [
                f"    c_{ent.name} = db.query({model_name}).count()",
                f'    counts["{ent.name}"] = c_{ent.name}',
                f"    total_count += c_{ent.name}",
            ]
        )

    # Compute chart series from first entity
    p_ent = blueprint.entities[0]
    p_model = f"{_to_pascal_case(p_ent.name)}Model"
    enum_flds = [f for f in p_ent.fields if f.field_type == FieldType.ENUM]
    group_col = enum_flds[0].name if enum_flds else None

    if group_col:
        lines.extend(
            [
                f"    rows_{p_ent.name} = db.query({p_model}).all()",
                "    dist_map: dict[str, int] = {}",
                f"    for r in rows_{p_ent.name}:",
                f'        val = str(getattr(r, "{group_col}", "Unknown") or "Unknown")',
                "        dist_map[val] = dist_map.get(val, 0) + 1",
                '    primary_chart_data = [{"label": k, "value": v} for k, v in dist_map.items()]',
            ]
        )
    else:
        lines.extend(
            [
                '    primary_chart_data = [{"label": k, "value": v} for k, v in counts.items()]',
            ]
        )

    lines.extend(
        [
            "    return {",
            f'        "app": {repr(blueprint.app_name)},',
            '        "total_records": total_count,',
            '        "counts_by_entity": counts,',
            f'        "primary_chart_type": {repr(blueprint.analytics.primary_chart.value)},',
            '        "primary_chart_data": primary_chart_data,',
            f'        "secondary_chart_type": {repr(blueprint.analytics.secondary_chart.value)},',
            "        'kpis': [",
        ]
    )

    for kpi in blueprint.analytics.kpis:
        lines.append(
            f'            {{"id": {repr(kpi.id)}, "label": {repr(kpi.label)}, "unit": {repr(kpi.unit)}, "value": total_count, "target": {repr(kpi.target)}}},'
        )

    lines.extend(
        [
            "        ],",
            "    }",
            "",
            '@app.post("/api/seed")',
            "def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:",
            "    inserted = seed_database(db)",
            '    return {"status": "seeded", "inserted": inserted}',
            "",
            '@app.get("/api/health")',
            "def api_health() -> dict[str, str]:",
            "    return {",
            '        "status": "healthy",',
            f'        "app": {repr(blueprint.app_name)},',
            f'        "archetype": {repr(blueprint.domain.archetype.value)},',
            "    }",
            "",
        ]
    )
    all_routes.extend(
        [
            "GET /api/privacy/export",
            "DELETE /api/privacy/account",
            "GET /api/security/threat-model",
            "GET /api/analytics/summary",
            "POST /api/seed",
            "GET /api/health",
        ]
    )

    if blueprint.domain.needs_automation and blueprint.automations:
        first_auto = blueprint.automations[0]
        trigger_model = f"{_to_pascal_case(first_auto.trigger_entity)}Model"
        lines.extend(
            [
                '@app.post("/api/automations/run")',
                "def run_domain_automation(db: Session = Depends(get_db)) -> dict[str, Any]:",
                f"    rows = db.query({trigger_model}).all()",
                f"    serialized = [_serialize_{first_auto.trigger_entity}(r) for r in rows]",
                "    summary = execute_automation_pipeline(serialized)",
                "    rec = AutomationExecutionModel(",
                f"        automation_id={repr(first_auto.id)},",
                '        status="completed",',
                "        summary_json=json.dumps(summary),",
                "    )",
                "    db.add(rec)",
                "    db.commit()",
                "    return summary",
                "",
            ]
        )
        all_routes.append("POST /api/automations/run")

    return "\n".join(lines), all_routes


def compose_backend_files(
    project_id: str,
    blueprint: AppBlueprint,
    sample_seed_data: dict[str, list[dict[str, Any]]],
    workflow: Optional[WorkflowSpec] = None,
) -> tuple[list[GeneratedFile], list[str], list[str]]:
    """
    Composes all backend files for a blueprint-driven application.
    Returns (files, routes, model_names).
    """
    models_py, model_names = _compose_models_py(blueprint)
    main_py, routes = _compose_main_py(blueprint)
    seed_py = _compose_seed_py(blueprint, sample_seed_data)
    entity_summary = ", ".join(e.name for e in blueprint.entities)

    files: list[GeneratedFile] = [
        GeneratedFile(
            path="backend/requirements.txt",
            content=_compose_requirements_txt(),
            category="backend",
            description=f"Python dependencies for {blueprint.app_name} backend",
        ),
        GeneratedFile(
            path="backend/database.py",
            content=_compose_database_py(project_id),
            category="backend",
            description="SQLAlchemy SQLite database session configuration",
        ),
        GeneratedFile(
            path="backend/models.py",
            content=models_py,
            category="backend",
            description=f"SQLAlchemy ORM models for {entity_summary}",
        ),
        GeneratedFile(
            path="backend/seed.py",
            content=seed_py,
            category="backend",
            description="Optional sample seed data script",
        ),
        GeneratedFile(
            path="backend/main.py",
            content=main_py,
            category="backend",
            description=f"FastAPI CRUD endpoints for {blueprint.app_name}",
        ),
    ]

    if blueprint.auth.required:
        files.append(
            GeneratedFile(
                path="backend/auth.py",
                content=_compose_auth_py(blueprint),
                category="backend",
                description=f"Authentication, session tokens, and security for {blueprint.app_name}",
            )
        )

    if blueprint.domain.needs_automation and blueprint.automations and workflow is not None:
        files.append(
            GeneratedFile(
                path="backend/engine.py",
                content=_compose_engine_py(workflow),
                category="backend",
                description="Embedded deterministic workflow automation engine",
            )
        )

    return files, routes, model_names
