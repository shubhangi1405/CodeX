"""Stage E Frontend Composer: Composes React + Vite + ui_kit frontend from Blueprint & Direction."""

import json
import re
from pathlib import Path
from typing import Any, Optional

from generators.blueprint.schemas import AppBlueprint
from generators.design.schemas import DesignDirection
from generators.design.token_writer import (
    generate_design_tokens_css,
    generate_tailwind_config,
    render_brand_mark_svg,
)
from generators.schemas import GeneratedFile

UI_KIT_DIR = Path(__file__).resolve().parent / "ui_kit"

RAW_HEX_RE = re.compile(r"#[0-9A-Fa-f]{3,8}\b")


def validate_custom_tsx_component(filename: str, code: str) -> list[str]:
    """
    Validates a custom domain widget in src/custom/ against Section 3.6 rules:
    - Under 150 lines
    - Imports only from 'react' and '../ui_kit'
    - Zero raw hex colors (#RRGGBB)
    - Zero inline style={{ ... }}
    - Zero fetch() calls
    """
    errors: list[str] = []
    lines = code.splitlines()
    if len(lines) > 150:
        errors.append(f"{filename}: Exceeds 150 lines ({len(lines)} lines).")

    for idx, line in enumerate(lines, start=1):
        stripped = line.strip()
        if stripped.startswith("import ") and " from " in stripped:
            mod_part = stripped.split(" from ", 1)[1].strip().rstrip(";").strip("'\"")
            if mod_part not in ("react", "../ui_kit", "./ui_kit"):
                errors.append(
                    f"{filename}:{idx}: Disallowed import '{mod_part}' "
                    "(allowed: 'react', '../ui_kit')."
                )
        if RAW_HEX_RE.search(line):
            errors.append(
                f"{filename}:{idx}: Raw hex color literal is forbidden in custom widgets."
            )
        if "style={{" in line:
            errors.append(f"{filename}:{idx}: Inline style={{}} is forbidden in custom widgets.")
        if "fetch(" in line:
            errors.append(f"{filename}:{idx}: Direct fetch() call is forbidden in custom widgets.")

    return errors


def _compose_package_json(project_id: str) -> str:
    pkg = {
        "name": project_id.replace("_", "-"),
        "private": True,
        "version": "1.0.0",
        "type": "module",
        "scripts": {
            "dev": "vite --port 5174",
            "build": "tsc && vite build",
            "preview": "vite preview",
        },
        "dependencies": {
            "react": "^18.3.1",
            "react-dom": "^18.3.1",
        },
        "devDependencies": {
            "@types/react": "^18.3.12",
            "@types/react-dom": "^18.3.1",
            "@vitejs/plugin-react": "^4.3.3",
            "autoprefixer": "^10.4.20",
            "postcss": "^8.4.49",
            "tailwindcss": "^3.4.15",
            "typescript": "^5.6.3",
            "vite": "^5.4.11",
        },
    }
    return json.dumps(pkg, indent=2) + "\n"


def _compose_vite_config_ts() -> str:
    return """import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5174,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
    },
  },
});
"""


def _compose_index_html(blueprint: AppBlueprint, direction: DesignDirection) -> str:
    mode = direction.color_mode.value
    dens = direction.density.value
    return f"""<!DOCTYPE html>
<html lang="en" data-color-mode="{mode}" data-density="{dens}">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{blueprint.app_name} — {blueprint.product_tagline}</title>
  </head>
  <body class="bg-surface text-text font-body antialiased">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
"""


def _compose_index_css() -> str:
    return """@import './design-tokens.css';
@tailwind base;
@tailwind components;
@tailwind utilities;
"""


def _compose_main_tsx() -> str:
    return """import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
"""


def _compose_app_tsx(
    blueprint: AppBlueprint,
    direction: DesignDirection,
    sample_seed_data: dict[str, list[dict[str, Any]]],
    allow_opt_in_footer: bool = False,
) -> str:
    bp_json = json.dumps(blueprint.model_dump(), indent=2)
    dir_json = json.dumps(direction.model_dump(), indent=2)
    seed_json = json.dumps(sample_seed_data, indent=2)
    brand_svg = render_brand_mark_svg(direction, blueprint.app_name)
    footer_jsx = (
        '<footer className="px-6 py-3 text-xs text-text-muted border-t border-border text-center">'
        "Built with CodeX</footer>"
        if allow_opt_in_footer
        else ""
    )

    return f"""import React, {{ useEffect, useState }} from 'react';
import {{
  AdaptiveAppShell,
  AdaptiveLayoutRenderer,
  Button,
  FormField,
  Input,
  Modal,
  Select,
  Toast,
  EntityRecord,
  EntitySpecData,
  PageSpecData,
}} from './ui_kit';

const BLUEPRINT = {bp_json} as const;
const DESIGN_DIRECTION = {dir_json} as const;
const SAMPLE_SEED_DATA: Record<string, EntityRecord[]> = {seed_json};
const BRAND_SVG_MARKUP = {json.dumps(brand_svg)};
const NUMERIC_TYPES = new Set(['integer', 'float', 'currency']);

export default function App(): React.ReactElement {{
  const [activePageId, setActivePageId] = useState<string>(BLUEPRINT.home_page_id);
  const [recordsByEntity, setRecordsByEntity] = useState<Record<string, EntityRecord[]>>(() => {{
    const initial: Record<string, EntityRecord[]> = {{}};
    for (const ent of BLUEPRINT.entities) {{
      initial[ent.name] = [];
    }}
    return initial;
  }});
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formState, setFormState] = useState<Record<string, string | number | boolean>>({{}});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const pages = BLUEPRINT.pages as unknown as PageSpecData[];
  const entities = BLUEPRINT.entities as unknown as EntitySpecData[];
  const activePage = pages.find((p) => p.id === activePageId) || pages[0];
  const primaryEntityName = activePage.entities_used[0] || entities[0].name;
  const activeEntity = entities.find((e) => e.name === primaryEntityName) || entities[0];
  const activeRecords = recordsByEntity[activeEntity.name] || [];

  useEffect(() => {{
    for (const ent of entities) {{
      fetch(`/api/${{ent.name}}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data: EntityRecord[] | null) => {{
          if (Array.isArray(data) && data.length > 0) {{
            setRecordsByEntity((prev) => ({{ ...prev, [ent.name]: data }}));
          }}
        }})
        .catch(() => {{
          // Offline mode uses in-memory state
        }});
    }}
  }}, []);

  const openCreateModal = (): void => {{
    const defaults: Record<string, string | number | boolean> = {{}};
    for (const fld of activeEntity.fields) {{
      if (fld.field_type === 'boolean') {{
        defaults[fld.name] = Boolean(fld.default_value ?? false);
      }} else if (NUMERIC_TYPES.has(fld.field_type)) {{
        defaults[fld.name] = Number(fld.default_value ?? 0);
      }} else if (fld.field_type === 'enum' && fld.enum_values && fld.enum_values.length > 0) {{
        defaults[fld.name] = fld.enum_values[0];
      }} else {{
        defaults[fld.name] = String(fld.default_value ?? '');
      }}
    }}
    setFormState(defaults);
    setIsModalOpen(true);
  }};

  const handleCreateRecord = (): void => {{
    const newRecord: EntityRecord = {{
      id: `${{activeEntity.name}}-${{Date.now()}}`,
      ...formState,
    }};
    setRecordsByEntity((prev) => ({{
      ...prev,
      [activeEntity.name]: [newRecord, ...(prev[activeEntity.name] || [])],
    }}));
    fetch(`/api/${{activeEntity.name}}`, {{
      method: 'POST',
      headers: {{ 'Content-Type': 'application/json' }},
      body: JSON.stringify(formState),
    }}).catch(() => undefined);
    setIsModalOpen(false);
    setToastMsg(`Saved ${{activeEntity.singular_label}}`);
  }};

  const handleLoadSampleSeedData = (): void => {{
    setRecordsByEntity(SAMPLE_SEED_DATA);
    fetch('/api/seed', {{ method: 'POST' }}).catch(() => undefined);
    setToastMsg('Loaded domain sample records');
  }};

  const handleDeleteRecord = (recordId: string): void => {{
    setRecordsByEntity((prev) => ({{
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).filter((r) => String(r.id) !== recordId),
    }}));
    fetch(`/api/${{activeEntity.name}}/${{recordId}}`, {{
      method: 'DELETE',
    }}).catch(() => undefined);
    setToastMsg(`Removed ${{activeEntity.singular_label}}`);
  }};

  const [isLiveTouched, setIsLiveTouched] = useState<boolean>(false);

  const handleExportJsonData = (): void => {{
    const jsonStr = JSON.stringify(recordsByEntity, null, 2);
    const blob = new Blob([jsonStr], {{ type: 'application/json' }});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${{BLUEPRINT.app_name.toLowerCase().replace(/[^a-z0-9]/g, '_')}}_export.json`;
    a.click();
    URL.revokeObjectURL(url);
    setToastMsg('Workspace records exported');
  }};

  const handleToggleBoolean = (recordId: string, fieldName: string): void => {{
    setIsLiveTouched(true);
    setRecordsByEntity((prev) => ({{
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).map((r) =>
        String(r.id) === recordId ? {{ ...r, [fieldName]: !r[fieldName] }} : r
      ),
    }}));
  }};

  return (
    <div className="min-h-screen bg-surface text-text font-body">
      <AdaptiveAppShell
        pattern={{BLUEPRINT.navigation.pattern}}
        appName={{BLUEPRINT.app_name}}
        tagline={{BLUEPRINT.product_tagline}}
        brandMark={{
          <span
            className="inline-flex items-center"
            dangerouslySetInnerHTML={{{{ __html: BRAND_SVG_MARKUP }}}}
          />
        }}
        navItems={{BLUEPRINT.navigation.items.map((item) => ({{
          page_id: item.page_id,
          label: item.label,
          icon: item.icon,
        }}))}}
        activePageId={{activePage.id}}
        onSelectPage={{setActivePageId}}
        primaryAction={{
          <div className="flex items-center gap-2">
            {{isLiveTouched ? (
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-emerald-500/15 text-emerald-700 border border-emerald-500/30">
                Live Data
              </span>
            ) : activeRecords.length > 0 ? (
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-500/15 text-amber-700 border border-amber-500/30">
                Demo Seed Data
              </span>
            ) : null}}
            {{activeRecords.length === 0 && (
              <Button variant="secondary" onClick={{handleLoadSampleSeedData}}>
                Load Sample Data
              </Button>
            )}}
            {{activeRecords.length > 0 && (
              <Button variant="secondary" onClick={{handleExportJsonData}}>
                Export Data
              </Button>
            )}}
            <Button variant="primary" onClick={{openCreateModal}}>
              + {{activePage.primary_actions[0] || `New ${{activeEntity.singular_label}}`}}
            </Button>
          </div>
        }}
      >
        <div className="space-y-4">
          {{toastMsg && (
            <div className="flex justify-between items-center">
              <Toast message={{toastMsg}} tone="success" />
              <Button variant="ghost" onClick={{() => setToastMsg(null)}}>Dismiss</Button>
            </div>
          )}}
          <AdaptiveLayoutRenderer
            page={{activePage}}
            entity={{activeEntity}}
            records={{activeRecords}}
            onOpenCreate={{openCreateModal}}
            onDeleteRecord={{handleDeleteRecord}}
            onToggleBoolean={{handleToggleBoolean}}
          />
        </div>
      </AdaptiveAppShell>

      <Modal
        open={{isModalOpen}}
        title={{`Add ${{activeEntity.singular_label}}`}}
        onClose={{() => setIsModalOpen(false)}}
      >
        <div className="space-y-3">
          {{activeEntity.fields.map((fld) => (
            <FormField key={{fld.name}} label={{fld.label}} required={{fld.required}}>
              {{fld.field_type === 'enum' && fld.enum_values ? (
                <Select
                  value={{String(formState[fld.name] ?? fld.enum_values[0] ?? '')}}
                  options={{fld.enum_values.map((v) => ({{ value: v, label: v }}))}}
                  onChange={{(val) => setFormState((prev) => ({{ ...prev, [fld.name]: val }}))}}
                />
              ) : (
                <Input
                  type={{
                    NUMERIC_TYPES.has(fld.field_type)
                      ? 'number'
                      : fld.field_type === 'date'
                        ? 'date'
                        : 'text'
                  }}
                  value={{String(formState[fld.name] ?? '')}}
                  placeholder={{`Enter ${{fld.label}}`}}
                  onChange={{(val) =>
                    setFormState((prev) => ({{
                      ...prev,
                      [fld.name]: NUMERIC_TYPES.has(fld.field_type) ? Number(val) : val,
                    }}))
                  }}
                />
              )}}
            </FormField>
          ))}}
          <div className="flex justify-end gap-2 pt-3">
            <Button variant="secondary" onClick={{() => setIsModalOpen(false)}}>
              Cancel
            </Button>
            <Button variant="primary" onClick={{handleCreateRecord}}>
              Save {{activeEntity.singular_label}}
            </Button>
          </div>
        </div>
      </Modal>
      {footer_jsx}
    </div>
  );
}}
"""


def compose_frontend_files(
    project_id: str,
    blueprint: AppBlueprint,
    direction: DesignDirection,
    sample_seed_data: dict[str, list[dict[str, Any]]],
    custom_widgets: Optional[dict[str, str]] = None,
    allow_opt_in_footer: bool = False,
) -> list[GeneratedFile]:
    """
    Composes all frontend files for a blueprint-driven application, copying the
    shared themeable ui_kit and generating CSS design tokens + Tailwind config.
    """
    if custom_widgets:
        for fname, code in custom_widgets.items():
            errs = validate_custom_tsx_component(fname, code)
            if errs:
                raise ValueError("Invalid custom widget:\n" + "\n".join(errs))

    files: list[GeneratedFile] = [
        GeneratedFile(
            path="frontend/package.json",
            content=_compose_package_json(project_id),
            category="frontend",
            description=f"NPM package manifest for {blueprint.app_name}",
        ),
        GeneratedFile(
            path="frontend/vite.config.ts",
            content=_compose_vite_config_ts(),
            category="frontend",
            description="Vite development server and API proxy configuration",
        ),
        GeneratedFile(
            path="frontend/tailwind.config.js",
            content=generate_tailwind_config(direction),
            category="config",
            description="Tailwind configuration mapped to CSS custom property tokens",
        ),
        GeneratedFile(
            path="frontend/index.html",
            content=_compose_index_html(blueprint, direction),
            category="frontend",
            description=f"HTML entry point for {blueprint.app_name}",
        ),
        GeneratedFile(
            path="frontend/src/design-tokens.css",
            content=generate_design_tokens_css(direction),
            category="frontend",
            description=f"CSS custom properties for {direction.direction_id} direction",
        ),
        GeneratedFile(
            path="frontend/src/index.css",
            content=_compose_index_css(),
            category="frontend",
            description="Global stylesheet importing design-tokens.css",
        ),
        GeneratedFile(
            path="frontend/src/main.tsx",
            content=_compose_main_tsx(),
            category="frontend",
            description="React 18 root bootstrap",
        ),
        GeneratedFile(
            path="frontend/src/App.tsx",
            content=_compose_app_tsx(
                blueprint=blueprint,
                direction=direction,
                sample_seed_data=sample_seed_data,
                allow_opt_in_footer=allow_opt_in_footer,
            ),
            category="frontend",
            description=f"Adaptive React application for {blueprint.app_name}",
        ),
    ]

    # Bundle the shared themeable ui_kit into frontend/src/ui_kit/
    for kit_file in ("icons.tsx", "primitives.tsx", "shells.tsx", "layouts.tsx", "index.ts"):
        kit_path = UI_KIT_DIR / kit_file
        if kit_path.exists():
            files.append(
                GeneratedFile(
                    path=f"frontend/src/ui_kit/{kit_file}",
                    content=kit_path.read_text(encoding="utf-8"),
                    category="frontend",
                    description=f"Themeable UI kit module ({kit_file})",
                )
            )

    if custom_widgets:
        for fname, code in custom_widgets.items():
            clean_name = fname if fname.endswith(".tsx") else f"{fname}.tsx"
            files.append(
                GeneratedFile(
                    path=f"frontend/src/custom/{clean_name}",
                    content=code,
                    category="frontend",
                    description=f"Validated custom domain widget ({clean_name})",
                )
            )

    return files
