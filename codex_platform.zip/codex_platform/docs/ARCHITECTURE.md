# CodeX — Adaptive UI Generation & Deterministic Pipeline Architecture

## 1. Core Architectural Principle
> **The AI proposes; deterministic code validates.**

CodeX separates **domain and visual intelligence** (proposing structured schemas via Gemini) from **deterministic validation and code composition** (Pydantic allowlists, WCAG 2.1 AA contrast enforcement, 8-attribute diversity guards, zero-leakage scanners, and a themeable UI kit). Gemini never emits unconstrained full-app JSX or unvalidated CSS.

---

## 2. Six-Stage Adaptive Generation Pipeline (Stages A → F)

```mermaid
flowchart TD
    UserPrompt["User Product Idea + Approved Spec"] --> StageA["Stage A: DomainAnalysis\n(archetype, audience, primary_object, core_jobs, tone, data_shape, needs_automation)"]
    StageA --> StageB["Stage B: AppBlueprint\n(entities[], pages[], navigation shell, home_page_id, automations[])"]
    StageB --> StageC["Stage C: DesignDirection\n(curated direction_id + bounded palette, typography, shape, density, motion, brand_mark)"]
    StageC --> StageD["Stage D: Deterministic Validation\n(Pydantic allowlists, WCAG 2.1 AA lightness adjuster, 8-tuple fingerprint distance >= 4, zero-leakage scan)"]
    StageD --> StageE["Stage E: Composition\n(backend_composer + frontend_composer + generators/ui_kit/ + standalone_bundler)"]
    StageE --> StageF["Stage F: Verification\n(ruff, mypy, pytest, tsc, eslint, vitest, secret-scan, 8-app diversity matrix + browser screenshots)"]
```

### Stage A — `DomainAnalysis` (`generators/blueprint/schemas.py`)
Determines what the product is, who uses it, and whether a background automation pipeline actually belongs in the application:
- **`ProductArchetype`** (17 values): `analytics_dashboard`, `habit_or_goal_tracker`, `booking_scheduler`, `kanban_project`, `crm_pipeline`, `inventory_stock`, `finance_ledger`, `marketplace_directory`, `community_feed`, `learning_course`, `support_ticketing`, `event_hub`, `health_log`, `content_cms`, `form_survey`, `ops_monitoring`, `generic_crud` (fallback only).
- **`needs_automation`**: Boolean flag controlling whether the deterministic workflow engine (`backend/engine.py`) is included in the generated app. Non-pipeline apps (e.g., habit tracker, court booking, security log viewer) set `needs_automation = False` and contain zero CSV/pipeline code.

### Stage B — `AppBlueprint` (`generators/blueprint/schemas.py`)
Defines the domain data model, multi-page structure, and navigation shell:
- **`entities[]`**: Domain entities (`EntitySpec`) with typed fields (`FieldType`: `string`, `text`, `integer`, `float`, `boolean`, `date`, `datetime`, `enum`, `email`, `url`, `currency`, `json_tags`) and relationships.
- **`pages[]`**: Screens mapped to the **17 closed layout archetypes** (`LayoutArchetype`):
  `stat_tiles_with_charts`, `data_table_with_filters`, `card_grid`, `kanban_board`, `calendar_month`, `calendar_week_agenda`, `timeline`, `feed`, `master_detail`, `form_wizard`, `single_form`, `checklist_today`, `heatmap_streaks`, `leaderboard`, `map_or_location_list`, `report_document`, `log_stream`.
- **`navigation`**: Pattern from the **5 navigation shells** (`NavPattern`: `sidebar`, `top_tabs`, `bottom_tabs`, `command_palette_plus_minimal_top`, `split_master_detail`) and items with icons from the closed 44-icon allowlist.
- **`home_page_id`**: Landing screen reflecting the user's most frequent core job (validated to match `pages[]`).

### Stage C — `DesignDirection` & Curated Library (`generators/design/`)
- **`generators/design/directions.py`**: 10 curated design directions (`editorial_calm`, `ledger_precision`, `console_dark`, `playful_momentum`, `clinical_clean`, `studio_craft`, `campus_energy`, `marketplace_warm`, `kanban_focus`, `civic_formal`) with complete default tokens, layout personality, and copy voice.
- **Bounded Adjustments**: Allows hue shifts ($\pm 60^\circ$), radius class, density, and color mode overrides while rejecting CodeX's workspace brand purple (`#5A32A3`, `#6D28D9`) and forbidding `"CX"` / `"GW"` as a generated app monogram.
- **`generators/design/token_writer.py`**: Emits `design-tokens.css` (CSS custom properties `--app-*` and `--color-*`, plus `@media (prefers-reduced-motion: reduce)` rules), `tailwind.config.js`, and SVG brand marks from the 12 allowed geometric primitives.

### Stage D — Deterministic Validation (`generators/design/contrast.py` & `fingerprint.py`)
1. **Closed Allowlists (`generators/design/allowlists.py`)**: Rejects unknown layouts, icons, fonts, or glyph primitives.
2. **WCAG 2.1 AA Contrast Adjuster (`generators/design/contrast.py`)**: Computes relative luminance and contrast ratios across all 9 foreground/background token pairs ($4.5:1$ for body/muted/button text; $3.0:1$ for borders, focus rings, and semantic status colors). Automatically shifts HSL lightness until every pair passes and logs every adjustment.
3. **8-Tuple Diversity Guard (`generators/design/fingerprint.py`)**:
   $$\text{LookFingerprint} = (\text{archetype}, \text{nav\_pattern}, \text{home\_layout}, \text{primary\_hue\_bucket}_{30^\circ}, \text{heading\_font}, \text{radius\_class}, \text{density}, \text{color\_mode})$$
   Enforces a minimum Hamming distance of **$\ge 4$ of 8 attributes** against previously generated applications, with bounded retries and deterministic fallback to the most distant curated direction.
4. **Zero-Leakage Scanner**: Scans every generated file to guarantee zero `"CX"` / `"GW"` logos, zero `"CodeX"` / `"Ghostwriter"` strings (unless `allow_opt_in_footer=True`), zero `"Production Verified"` / `"Bit-for-Bit"` badges, zero hardcoded demo financial numbers (`14250.00`), and zero CSV/upload strings when the blueprint has no file-ingest entity.

### Stage E — Composition (`generators/ui_kit/` & Composers)
- **`generators/ui_kit/`**: Themeable React component library (`icons.tsx`, `primitives.tsx`, `shells.tsx`, `layouts.tsx`) implementing all 44 SVG icons, all 5 navigation shells, and all 17 layout archetypes using semantic CSS variables (`var(--app-*)`) with zero raw hex colors.
- **`generators/backend_composer.py`**: Generates `backend/models.py`, `backend/database.py`, `backend/main.py` (real FastAPI CRUD routes `GET/POST/PUT/DELETE /api/<entity>` for every blueprint entity), `backend/seed.py` (opt-in sample data), and `backend/engine.py` (only when `needs_automation=True`).
- **`generators/frontend_composer.py`**: Generates the Vite + React + TypeScript frontend bundling `src/ui_kit/`, `src/design-tokens.css`, `tailwind.config.js`, and `src/App.tsx`, plus `validate_custom_tsx_component` enforcing strict rules on any optional `src/custom/` widget.
- **`generators/standalone_bundler.py`**: Emits a zero-CDN, offline-ready `standalone_app.html` driven by the blueprint, design tokens, navigation shell, and 17 layout archetypes.

### Stage F — Build Studio Restyle & Verification (`apps/api/routes/generate.py` & `BuildScreen.tsx`)
- **Persisted Adaptive State (`apps/api/models.py`)**: Stores `domain_analysis_json`, `app_blueprint_json`, `design_direction_json`, `design_proposals_json`, `design_history_json`, and `look_fingerprint_json` in SQLite (`AdaptiveGenerationRecord`).
- **Look Controls Without Logic Rebuild**:
  - `POST /api/generate/restyle`: Applies natural-language restyle instructions (*"make it darker"*, *"more playful"*, *"denser tables"*, *"use green"*) or switches among the 3 proposed directions, re-validates WCAG AA contrast, and re-runs Stage E while leaving backend routes and SQLite `.db` records untouched.
  - `POST /api/generate/regenerate-look`: Selects the next distinct direction and re-composes the frontend.
  - `POST /api/generate/revert-look`: Pops from `design_history_json` to restore the prior look and displays a side-by-side Before/After Token Diff in `BuildScreen.tsx`.
