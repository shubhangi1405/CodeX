# Architectural Decision Records (ADRs)

## ADR-001: Constrained Typed Workflow Engine vs Free-form Generation
- **Status**: Accepted
- **Context**: LLMs generate unstable, hallucinated architectures when tasked with creating arbitrary software from scratch without strict guardrails.
- **Decision**: Restrict the core runtime to a typed, deterministic DAG engine (`engine/`) with a vetted node library. Model output is confined to proposing structured JSON specs validated by the engine before execution.
- **Consequences**: Software is inspectable, step-by-step debuggable, and replayable. Unvetted arbitrary code execution is eliminated.

## ADR-002: Sandboxed AST Expression Language vs eval()
- **Status**: Accepted
- **Context**: Nodes requiring custom rules or filter expressions could pose remote code execution (RCE) hazards if arbitrary Python or JS is evaluated.
- **Decision**: Implement a sandboxed expression evaluator using Python's standard `ast` module supporting arithmetic, boolean logic, string methods, and column references.
- **Consequences**: Zero RCE exposure; clear syntax errors for users.

## ADR-003: SQLite Default with In-Process Async Job Runner
- **Status**: Accepted
- **Context**: The system must run locally with a single command without external service dependencies (e.g. PostgreSQL, Redis, Celery).
- **Decision**: Default to SQLite with SQLAlchemy 2, paired with FastAPI's in-process background worker mechanism.
- **Consequences**: Zero-friction local development, instant portability.

## ADR-004: Independent Non-Circular Oracle for Automatic Tests
- **Status**: Accepted
- **Context**: Generating tests that use the same workflow engine to compute expected outputs creates circular, non-falsifiable test suites.
- **Decision**: Compute expected outputs using an independent reference implementation (`IndependentOracle` in plain Python/Pandas).
- **Consequences**: Tests reliably catch regressions and discrepancies between engine behavior and specifications.

## ADR-005: Deterministic SHA-256 Output Hashing for Replay Verification
- **Status**: Accepted
- **Context**: Users must be able to prove that past executions produce identical results for identical inputs.
- **Decision**: Hash normalized JSON outputs with sorted dictionary keys using SHA-256. Replay executions verify that `new_hash == past_hash`.
- **Consequences**: Mathematical guarantee of reproducibility.

## ADR-006: Standalone Generated Applications
- **Status**: Accepted
- **Context**: CodeX must not only display workflows within its own UI, but also build the complete standalone software for users to deploy.
- **Decision**: Implement `AppGenerator` in `generators/` to scaffold standalone applications with independent FastAPI backends, SQLite databases, React 18 UIs, and exportable ZIP archives.
- **Consequences**: Users receive complete, production-grade applications that operate independently of CodeX.

## ADR-007: Conversational Evolutionary DAG Mutations
- **Status**: Accepted
- **Context**: Users iteratively request changes in natural language ("filter amounts below $50", "require user_id"). Rewriting the entire DAG from scratch discards customizations and breaks working pipelines.
- **Decision**: Implement `WorkflowEvolver` to surgically insert or modify nodes and rewire edges topologically, bumping version numbers and generating diff records.
- **Consequences**: Safe incremental modifications without pipeline disruption.
