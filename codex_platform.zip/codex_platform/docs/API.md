# CodeX REST API Specification

The CodeX API is built with FastAPI and strictly validated with Pydantic v2 schemas.
Base URL prefix: `/api`

---

## 1. System & Health
- **`GET /api/health`**
  - Returns backend service status, version, and active timestamp.

---

## 2. Compiler & Natural Language Translation
- **`POST /api/compiler/interpret`**
  - **Body**: `{ "prompt": str, "provider": "mock" | "gemini" | "openai" }`
  - Returns `ProductUnderstanding` decomposing instructions into goals, inputs, outputs, rules, assumptions, and up to 3 clarification questions with strict provenance badges (`user_stated`, `assumption`, `ai_recommendation`).
- **`POST /api/compiler/clarify`**
  - **Body**: `{ "understanding": ProductUnderstanding, "answers": dict[str, str] }`
  - Incorporates user choices, promoting clarifications to validated assumptions.
- **`POST /api/compiler/compile`**
  - **Body**: `{ "prompt": str, "answers": dict[str, str], "provider": str, "max_repairs": 3 }`
  - Topologically drafts, validates, and auto-repairs candidate workflow DAG specs (max 3 bounded retry attempts).
- **`POST /api/compiler/evolve`**
  - **Body**: `{ "workflow": WorkflowSpec, "instruction": str, "provider": str }`
  - Applies surgical, targeted DAG modifications based on follow-up natural language instructions without breaking existing working nodes. Returns evolved spec, version bump, and structured diff.

---

## 3. Workflows & Execution
- **`POST /api/workflows/validate`**
  - **Body**: `WorkflowSpec`
  - Validates DAG acyclicity, node registration, port compatibility, and reachability.
- **`POST /api/workflows/run`**
  - **Body**: `{ "workflow": WorkflowSpec, "initial_inputs": dict[str, Any] }`
  - Deterministically executes topological graph, records duration, input/output counts, rejected rows, and output SHA-256 hash.
- **`POST /api/workflows/diff`**
  - **Body**: `{ "old_workflow": WorkflowSpec, "new_workflow": WorkflowSpec }`
  - Computes structural differences between versions (added/removed/modified nodes and edge rewirings).

---

## 4. Deterministic Runs & Replay (Layer 1 Core)
- **`GET /api/runs?workflow_id={id}`**
  - Lists immutable execution records.
- **`GET /api/runs/{run_id}`**
  - Retrieves detailed run record with input snapshot, output hash, and node results.
- **`POST /api/runs/{run_id}/replay`**
  - **Body**: `{ "new_inputs": Optional[dict[str, Any]] }`
  - Replays past run. On identical inputs, verifies 100% bit-for-bit identical SHA-256 output hash match.
- **`POST /api/runs/execute-node`**
  - **Body**: `{ "node_type": str, "node_id": str, "label": str, "config": dict, "inputs": dict }`
  - Rapid single-node isolated execution for UI step debugging.

---

## 5. Automated Test Generation & Oracle Verification
- **`POST /api/tests/generate`**
  - **Body**: `{ "workflow": WorkflowSpec }`
  - Synthesizes 8 test cases: Happy path, Empty file, Missing columns, Wrong types, Extreme/negative values, Single row (N=1), Empty optional fields, and Duplicate records. Uses independent Python/Pandas oracle.
- **`POST /api/tests/run`**
  - **Body**: `{ "workflow": WorkflowSpec, "test_suite": list[TestCase] }`
  - Runs all test cases against the engine and returns structured diagnostics (expected vs actual, failing node, remediation hints).

---

## 6. Feature Recommendations
- **`POST /api/recommendations/generate`**
  - **Body**: `{ "understanding": ProductUnderstanding }`
  - Generates 4-tiered recommendations (Essential, Recommended, Optional, Future) with business rationale and complexity sizing.
- **`POST /api/recommendations/apply`**
  - **Body**: `{ "workflow": WorkflowSpec, "decisions": list[FeatureDecision] }`
  - Applies accepted feature decisions to the workflow DAG.

---

## 7. Built Software Generation & Standalone Export
- **`POST /api/generate`**
  - **Body**: `{ "workflow": WorkflowSpec }`
  - Compiles workflow into a complete standalone project (FastAPI backend, React 18 frontend, SQLite models, embedded engine). Returns `GeneratedAppManifest`.
- **`GET /api/generate/export/{project_id}`**
  - Downloads standalone runnable ZIP archive containing full project codebase.
