# CodeX Adaptive UI Generation — 8-Benchmark Diversity & Accessibility Report

## 1. Executive Summary
- **Benchmark Applications Generated**: **8**
- **Pairwise Comparisons Evaluated**: **28** ($\binom{8}{2}$)
- **Minimum Pairwise Fingerprint Distance**: **5 / 8** (Required threshold: $\ge 4 / 8$)
- **Distinct Home Layouts**: **8**
- **Distinct Navigation Shells**: **5**
- **Distinct Heading Fonts**: **8**
- **WCAG 2.1 AA Contrast Compliance**: **100% (72 / 72 pairs passed across all 8 apps)**
- **Zero-Leakage Verification**: **0 violations** (zero `"CX"`/`"GW"` logos, zero `"CodeX"`/`"Ghostwriter"` strings, zero `"Production Verified"` badges, zero CSV leakage in non-CSV apps)

---

## 2. 8-Tuple Look Fingerprints Across the 8 Benchmark Apps

| Benchmark ID | Product Name | Archetype | Nav Shell | Home Layout | Primary (`Hue Bucket`) | Heading Font | Radius / Density / Mode |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `csv_ingestion_monthly_totals` | LedgerFlow Monthly Totals | `analytics_dashboard` | `top_tabs` | `stat_tiles_with_charts` | `#0F3D5E` (180°) | `IBM Plex Sans` | `sharp` / `compact` / `light` |
| `daily_habit_tracker` | SteadyCadence Rituals | `habit_or_goal_tracker` | `sidebar` | `checklist_today` | `#245436` (120°) | `Fraunces` | `soft` / `spacious` / `light` |
| `security_event_log_viewer` | BastionPulse SIEM | `ops_monitoring` | `command_palette_plus_minimal_top` | `log_stream` | `#14B8A6` (150°) | `Space Grotesk` | `sharp` / `compact` / `dark` |
| `sports_court_booking` | RallySlot Courts | `booking_scheduler` | `bottom_tabs` | `calendar_week_agenda` | `#B45309` (0°) | `Sora` | `round` / `comfortable` / `light` |
| `hackathon_team_finder` | ShipMate Hackers | `community_feed` | `top_tabs` | `feed` | `#1D4ED8` (210°) | `Outfit` | `pill` / `comfortable` / `both` |
| `restaurant_inventory` | MiseEnPlace Larder | `inventory_stock` | `split_master_detail` | `master_detail` | `#4D6B14` (60°) | `Playfair Display` | `round` / `spacious` / `light` |
| `clinic_appointment_scheduling` | VitalsPath Clinic | `health_log` | `sidebar` | `timeline` | `#86198F` (270°) | `Public Sans` | `soft` / `comfortable` / `light` |
| `freelance_invoice_tracker` | FolioNote Billing | `finance_ledger` | `split_master_detail` | `report_document` | `#7F1D1D` (0°) | `Merriweather` | `sharp` / `spacious` / `both` |

---

## 3. Pairwise 8-Attribute Fingerprint Distance Matrix (All 28 Pairs $\ge 4/8$)

| App \ App | `csv_ingestio` | `daily_habit_` | `security_eve` | `sports_court` | `hackathon_te` | `restaurant_i` | `clinic_appoi` | `freelance_in` |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `csv_ingestion_monthly_totals` | — | **7/8** | **6/8** | **7/8** | **7/8** | **7/8** | **7/8** | **7/8** |
| `daily_habit_tracker` | **7/8** | — | **8/8** | **7/8** | **8/8** | **6/8** | **5/8** | **7/8** |
| `security_event_log_viewer` | **6/8** | **8/8** | — | **8/8** | **8/8** | **8/8** | **8/8** | **7/8** |
| `sports_court_booking` | **7/8** | **7/8** | **8/8** | — | **7/8** | **6/8** | **6/8** | **7/8** |
| `hackathon_team_finder` | **7/8** | **8/8** | **8/8** | **7/8** | — | **8/8** | **7/8** | **7/8** |
| `restaurant_inventory` | **7/8** | **6/8** | **8/8** | **6/8** | **8/8** | — | **7/8** | **6/8** |
| `clinic_appointment_scheduling` | **7/8** | **5/8** | **8/8** | **6/8** | **7/8** | **7/8** | — | **8/8** |
| `freelance_invoice_tracker` | **7/8** | **7/8** | **7/8** | **7/8** | **7/8** | **6/8** | **8/8** | — |

---

## 4. WCAG 2.1 AA Contrast Verification Table

| Benchmark App & Direction | Body / Surface ($\ge 4.5$) | Muted / Surface ($\ge 4.5$) | Button FG / Primary ($\ge 4.5$) | Border / Surface ($\ge 3.0$) | Focus / Surface ($\ge 3.0$) | Status |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| `csv_ingestion_monthly_totals` (`ledger_precision`) | 17.06:1 | 9.9:1 | 11.35:1 | 5.86:1 | 10.85:1 | **PASS (9/9)** |
| `daily_habit_tracker` (`editorial_calm`) | 15.12:1 | 9.05:1 | 8.76:1 | 5.73:1 | 8.33:1 | **PASS (9/9)** |
| `security_event_log_viewer` (`console_dark`) | 17.51:1 | 7.48:1 | 7.69:1 | 4.03:1 | 7.71:1 | **PASS (9/9)** |
| `sports_court_booking` (`marketplace_warm`) | 16.26:1 | 9.53:1 | 5.02:1 | 5.43:1 | 4.74:1 | **PASS (9/9)** |
| `hackathon_team_finder` (`campus_energy`) | 16.99:1 | 9.87:1 | 6.7:1 | 5.2:1 | 6.42:1 | **PASS (9/9)** |
| `restaurant_inventory` (`studio_craft`) | 15.66:1 | 9.35:1 | 6.12:1 | 5.39:1 | 5.58:1 | **PASS (9/9)** |
| `clinic_appointment_scheduling` (`clinical_clean`) | 14.11:1 | 8.32:1 | 8.24:1 | 4.58:1 | 7.94:1 | **PASS (9/9)** |
| `freelance_invoice_tracker` (`civic_formal`) | 19.8:1 | 10.37:1 | 10.02:1 | 7.81:1 | 10.02:1 | **PASS (9/9)** |

---

## 5. Visual Verification & Browser Screenshots (Home Empty State + Populated Core Flow)

### LedgerFlow Monthly Totals (`csv_ingestion_monthly_totals`)
- **Benchmark Prompt**: *"CSV ingestion with monthly totals"*
- **Archetype**: `analytics_dashboard` | **Direction**: `ledger_precision` (`light`)
- **Navigation Shell**: `top_tabs` | **Home Layout**: `stat_tiles_with_charts`
- **Entities**: `transaction_batch`, `rejected_record`
- **Empty State Screenshot**: [`csv_ingestion_monthly_totals_home_empty.png`](./csv_ingestion_monthly_totals_home_empty.png)
- **Populated Core Flow Screenshot**: [`csv_ingestion_monthly_totals_core_flow.png`](./csv_ingestion_monthly_totals_core_flow.png)

### SteadyCadence Rituals (`daily_habit_tracker`)
- **Benchmark Prompt**: *"daily habit tracker"*
- **Archetype**: `habit_or_goal_tracker` | **Direction**: `editorial_calm` (`light`)
- **Navigation Shell**: `sidebar` | **Home Layout**: `checklist_today`
- **Entities**: `habit_ritual`, `reflection_note`
- **Empty State Screenshot**: [`daily_habit_tracker_home_empty.png`](./daily_habit_tracker_home_empty.png)
- **Populated Core Flow Screenshot**: [`daily_habit_tracker_core_flow.png`](./daily_habit_tracker_core_flow.png)

### BastionPulse SIEM (`security_event_log_viewer`)
- **Benchmark Prompt**: *"security event log viewer"*
- **Archetype**: `ops_monitoring` | **Direction**: `console_dark` (`dark`)
- **Navigation Shell**: `command_palette_plus_minimal_top` | **Home Layout**: `log_stream`
- **Entities**: `security_event`, `detection_rule`
- **Empty State Screenshot**: [`security_event_log_viewer_home_empty.png`](./security_event_log_viewer_home_empty.png)
- **Populated Core Flow Screenshot**: [`security_event_log_viewer_core_flow.png`](./security_event_log_viewer_core_flow.png)

### RallySlot Courts (`sports_court_booking`)
- **Benchmark Prompt**: *"sports court booking"*
- **Archetype**: `booking_scheduler` | **Direction**: `marketplace_warm` (`light`)
- **Navigation Shell**: `bottom_tabs` | **Home Layout**: `calendar_week_agenda`
- **Entities**: `court_reservation`, `court_venue`
- **Empty State Screenshot**: [`sports_court_booking_home_empty.png`](./sports_court_booking_home_empty.png)
- **Populated Core Flow Screenshot**: [`sports_court_booking_core_flow.png`](./sports_court_booking_core_flow.png)

### ShipMate Hackers (`hackathon_team_finder`)
- **Benchmark Prompt**: *"hackathon team finder for students"*
- **Archetype**: `community_feed` | **Direction**: `campus_energy` (`both`)
- **Navigation Shell**: `top_tabs` | **Home Layout**: `feed`
- **Entities**: `team_pitch`, `hacker_profile`
- **Empty State Screenshot**: [`hackathon_team_finder_home_empty.png`](./hackathon_team_finder_home_empty.png)
- **Populated Core Flow Screenshot**: [`hackathon_team_finder_core_flow.png`](./hackathon_team_finder_core_flow.png)

### MiseEnPlace Larder (`restaurant_inventory`)
- **Benchmark Prompt**: *"restaurant inventory"*
- **Archetype**: `inventory_stock` | **Direction**: `studio_craft` (`light`)
- **Navigation Shell**: `split_master_detail` | **Home Layout**: `master_detail`
- **Entities**: `pantry_ingredient`, `purveyor_order`
- **Empty State Screenshot**: [`restaurant_inventory_home_empty.png`](./restaurant_inventory_home_empty.png)
- **Populated Core Flow Screenshot**: [`restaurant_inventory_core_flow.png`](./restaurant_inventory_core_flow.png)

### VitalsPath Clinic (`clinic_appointment_scheduling`)
- **Benchmark Prompt**: *"clinic appointment scheduling"*
- **Archetype**: `health_log` | **Direction**: `clinical_clean` (`light`)
- **Navigation Shell**: `sidebar` | **Home Layout**: `timeline`
- **Entities**: `patient_visit`, `exam_room`
- **Empty State Screenshot**: [`clinic_appointment_scheduling_home_empty.png`](./clinic_appointment_scheduling_home_empty.png)
- **Populated Core Flow Screenshot**: [`clinic_appointment_scheduling_core_flow.png`](./clinic_appointment_scheduling_core_flow.png)

### FolioNote Billing (`freelance_invoice_tracker`)
- **Benchmark Prompt**: *"freelance invoice tracker"*
- **Archetype**: `finance_ledger` | **Direction**: `civic_formal` (`both`)
- **Navigation Shell**: `split_master_detail` | **Home Layout**: `report_document`
- **Entities**: `client_invoice`, `client_retainer`
- **Empty State Screenshot**: [`freelance_invoice_tracker_home_empty.png`](./freelance_invoice_tracker_home_empty.png)
- **Populated Core Flow Screenshot**: [`freelance_invoice_tracker_core_flow.png`](./freelance_invoice_tracker_core_flow.png)

