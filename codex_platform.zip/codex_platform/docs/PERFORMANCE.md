# CodeX Performance & Bundle Budget Ledger

## Milestone 0 Benchmarks

### Bundle Sizes (Production Build)
- **Target Budget**: Initial JS bundle under ~250 KB gzipped for the main route
- **Measured Numbers**:
  - `dist/index.html`: 0.46 kB (gzip: 0.30 kB)
  - `dist/assets/index.css`: 16.12 kB (gzip: 4.08 kB)
  - `dist/assets/index.js`: 236.09 kB (**gzip: 68.24 kB**)
- **Verdict**: **PASS** (68.24 KB gzipped is 72.7% below the 250 KB limit).

### Test Suite Execution Times
- Backend Pytest Suite: **0.86s** (3 tests passed)
- Frontend Vitest Suite: **75ms** (1 test passed)
- Total CI Check (`python scripts/runner.py check`): **~4.5s**
