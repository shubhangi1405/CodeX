from typing import Optional

from engine.compiler.providers import MockProvider, ModelProvider
from engine.compiler.schemas import ProductUnderstanding
from engine.recommender.schemas import (
    ComplexitySize,
    FeatureDecision,
    FeatureRecommendation,
    FeatureRecommendationList,
    RecommendationTier,
)
from engine.spec import WorkflowSpec


class FeatureRecommender:
    """
    Product intelligence engine that proposes high-value capabilities beyond
    the user's literal sentence. Every recommendation is strictly grounded in:
    1. A vetted node in the engine library, OR
    2. A configuration on an existing node, OR
    3. An application template capability (auth, db, schedule, export).
    """

    @classmethod
    def recommend_for_prompt(
        cls,
        understanding: ProductUnderstanding,
        workflow: WorkflowSpec | None = None,
        provider: Optional[ModelProvider] = None,
    ) -> list[FeatureRecommendation]:
        # 1. If a live AI provider is given, generate strictly project-tailored recommendations
        if provider is not None and not isinstance(provider, MockProvider):
            try:
                prompt_text = (
                    f"Project Goal: {understanding.goal}\n"
                    f"Summary: {understanding.summary}\n"
                    f"Target Users: {', '.join(understanding.target_users)}\n"
                    "Inputs:\n"
                    + "\n".join(f"- {i.title}: {i.description}" for i in understanding.inputs)
                    + "\nOutputs:\n"
                    + "\n".join(f"- {o.title}: {o.description}" for o in understanding.outputs)
                    + "\nBusiness Rules:\n"
                    + "\n".join(
                        f"- {r.title}: {r.description}" for r in understanding.business_rules
                    )
                )
                sys_prompt = (
                    "You are CodeX's Product Intelligence Recommender. "
                    "Propose exactly 5 high-value feature recommendations that are 100% specific "
                    "to the user's project described in the prompt (do NOT mention generic CSV "
                    "sales or unrelated domains). "
                    "You MUST include at least one recommendation in each of the 4 tiers: "
                    "'essential', 'recommended', 'optional', and 'future'. "
                    "Set decision='accepted' for essential and recommended tiers, 'pending' for "
                    "optional, and 'deferred' for future. "
                    "Set node_mapping on every item to one of: 'validate.required_fields', "
                    "'output.report', 'transform.filter', 'validate.type_check', "
                    "or 'trigger.webhook'."
                )
                ai_res = provider.generate_structured(
                    prompt=prompt_text,
                    system_prompt=sys_prompt,
                    schema_class=FeatureRecommendationList,
                )
                if ai_res.recommendations and len(ai_res.recommendations) >= 4:
                    # Ensure node_mapping is always populated
                    default_mappings = [
                        "validate.required_fields",
                        "output.report",
                        "transform.filter",
                        "validate.type_check",
                        "trigger.webhook",
                    ]
                    for idx, r in enumerate(ai_res.recommendations):
                        if not r.node_mapping:
                            r.node_mapping = default_mappings[idx % len(default_mappings)]
                        if not r.dependencies:
                            r.dependencies = [r.node_mapping]
                    return ai_res.recommendations
            except Exception:
                pass

        # 2. Domain-aware deterministic synthesis based on ProductUnderstanding
        text_lower = f"{understanding.goal} {understanding.summary}".lower()

        if any(
            kw in text_lower
            for kw in ("habit", "streak", "routine", "fitness", "workout", "task", "todo", "goal")
        ):
            return [
                FeatureRecommendation(
                    id="feat-rejected-audit",
                    title="Missed Check-In & Incomplete Entry Log",
                    description=(
                        "Automatically isolate incomplete daily habit entries or missing "
                        "timestamps into a dedicated review log without breaking streaks."
                    ),
                    rationale=(
                        "Users occasionally log partial habit check-ins or miss required fields; "
                        "graceful isolation keeps daily streak history accurate."
                    ),
                    tier=RecommendationTier.ESSENTIAL,
                    complexity=ComplexitySize.S,
                    mvp_candidate=True,
                    node_mapping="validate.required_fields",
                    dependencies=["validate.required_fields"],
                    risks=[],
                    decision=FeatureDecision.ACCEPTED,
                ),
                FeatureRecommendation(
                    id="feat-trend-viz",
                    title="Habit Streak & Completion Consistency Dashboard",
                    description=(
                        "Generate interactive visual progress charts showing completion rates, "
                        "active streaks, and monthly habit consistency trends."
                    ),
                    rationale=(
                        "Visualizing daily streaks and completion percentages motivates users "
                        "to maintain consistency and spot drop-off patterns."
                    ),
                    tier=RecommendationTier.RECOMMENDED,
                    complexity=ComplexitySize.M,
                    mvp_candidate=True,
                    node_mapping="output.report",
                    dependencies=["aggregate.monthly_totals", "output.report"],
                    risks=["Requires valid check-in date on all logged habit entries."],
                    decision=FeatureDecision.ACCEPTED,
                ),
                FeatureRecommendation(
                    id="feat-duplicate-detection",
                    title="Duplicate Daily Check-In Guard",
                    description=(
                        "Prevent accidental double-logging of the same habit on the same "
                        "calendar day so streak counts remain truthful."
                    ),
                    rationale=(
                        "Multiple taps or repeated syncs on the same day can artificially inflate "
                        "habit completion scores if not deduplicated."
                    ),
                    tier=RecommendationTier.RECOMMENDED,
                    complexity=ComplexitySize.M,
                    mvp_candidate=True,
                    node_mapping="transform.filter",
                    dependencies=["validate.required_fields"],
                    risks=[],
                    decision=FeatureDecision.ACCEPTED,
                ),
                FeatureRecommendation(
                    id="feat-score-normalization",
                    title="Habit Score & Duration Type Coercion",
                    description=(
                        "Normalize boolean completion flags (yes/no, 1/0, true/false) and numeric "
                        "durations or scores into standardized metrics."
                    ),
                    rationale=(
                        "Habit logs may mix binary check-ins with numeric targets (e.g. minutes "
                        "or glasses of water) that require clean numeric normalization."
                    ),
                    tier=RecommendationTier.OPTIONAL,
                    complexity=ComplexitySize.S,
                    mvp_candidate=False,
                    node_mapping="validate.type_check",
                    dependencies=["validate.type_check"],
                    risks=[],
                    decision=FeatureDecision.PENDING,
                ),
                FeatureRecommendation(
                    id="feat-webhook-trigger",
                    title="Automated Daily Reminder & Mobile Sync Webhook",
                    description=(
                        "Expose a webhook endpoint to sync habit completions from mobile shortcuts "
                        "or wearable devices and trigger reminder notifications."
                    ),
                    rationale=(
                        "Allows frictionless daily habit logging from external reminders or mobile "
                        "widgets without opening the full dashboard."
                    ),
                    tier=RecommendationTier.FUTURE,
                    complexity=ComplexitySize.L,
                    mvp_candidate=False,
                    node_mapping="trigger.webhook",
                    dependencies=["trigger.webhook"],
                    risks=["Requires webhook token configuration."],
                    decision=FeatureDecision.DEFERRED,
                ),
            ]

        # 3. Dynamic custom domain synthesis if not default CSV/sales
        is_default_csv = any(
            kw in text_lower for kw in ("csv", "monthly", "sales", "invoice", "revenue")
        )
        if not is_default_csv and understanding.goal:
            goal_short = understanding.goal[:55].rstrip(".")
            return [
                FeatureRecommendation(
                    id="feat-rejected-audit",
                    title=f"Invalid Record Validation & Audit Log ({goal_short})",
                    description=(
                        f"Validate incoming entries for '{understanding.goal}' and capture any "
                        "malformed or incomplete items into a structured quality log."
                    ),
                    rationale=(
                        "Ensures corrupt or incomplete user inputs never crash the core "
                        "application pipeline while keeping full visibility into rejected items."
                    ),
                    tier=RecommendationTier.ESSENTIAL,
                    complexity=ComplexitySize.S,
                    mvp_candidate=True,
                    node_mapping="validate.required_fields",
                    dependencies=["validate.required_fields"],
                    risks=[],
                    decision=FeatureDecision.ACCEPTED,
                ),
                FeatureRecommendation(
                    id="feat-trend-viz",
                    title="Interactive Progress & KPI Analytics Dashboard",
                    description=(
                        "Generate visual KPI cards and trend charts tailored to "
                        f"{understanding.goal}."
                    ),
                    rationale=(
                        "Gives target users immediate visual insight into trends, totals, "
                        "and performance metrics without manual calculation."
                    ),
                    tier=RecommendationTier.RECOMMENDED,
                    complexity=ComplexitySize.M,
                    mvp_candidate=True,
                    node_mapping="output.report",
                    dependencies=["aggregate.monthly_totals", "output.report"],
                    risks=[],
                    decision=FeatureDecision.ACCEPTED,
                ),
                FeatureRecommendation(
                    id="feat-duplicate-detection",
                    title="Rule-Based Filtering & Deduplication",
                    description=(
                        "Filter entries against domain business rules and prevent "
                        "duplicate submissions."
                    ),
                    rationale=(
                        "Keeps application analytics clean and prevents duplicate entries "
                        "from skewing computed summaries."
                    ),
                    tier=RecommendationTier.RECOMMENDED,
                    complexity=ComplexitySize.M,
                    mvp_candidate=True,
                    node_mapping="transform.filter",
                    dependencies=["validate.required_fields"],
                    risks=[],
                    decision=FeatureDecision.PENDING,
                ),
                FeatureRecommendation(
                    id="feat-currency-normalization",
                    title="Automatic Field Type Coercion & Formatting",
                    description=(
                        "Coerce dates, numbers, and status flags into strict schema types "
                        "before processing."
                    ),
                    rationale=(
                        "Prevents runtime type errors when users input varied date or "
                        "numeric formats."
                    ),
                    tier=RecommendationTier.OPTIONAL,
                    complexity=ComplexitySize.S,
                    mvp_candidate=False,
                    node_mapping="validate.type_check",
                    dependencies=["validate.type_check"],
                    risks=[],
                    decision=FeatureDecision.PENDING,
                ),
                FeatureRecommendation(
                    id="feat-webhook-trigger",
                    title="External API & Webhook Integration",
                    description=(
                        "Allow external services and mobile clients to push records and receive "
                        "automated status notifications."
                    ),
                    rationale=("Enables automated real-time workflows beyond manual data entry."),
                    tier=RecommendationTier.FUTURE,
                    complexity=ComplexitySize.L,
                    mvp_candidate=False,
                    node_mapping="trigger.webhook",
                    dependencies=["trigger.webhook"],
                    risks=["Requires API authentication setup."],
                    decision=FeatureDecision.DEFERRED,
                ),
            ]

        # 4. Canonical CSV / Financial Pipeline recommendations
        recs: list[FeatureRecommendation] = [
            FeatureRecommendation(
                id="feat-rejected-audit",
                title="Rejected Rows Audit Log & Export",
                description=(
                    "Capture invalid or unparseable records with exact line numbers "
                    "and structured failure reasons into an audit report."
                ),
                rationale=(
                    "CSVs in production frequently contain unexpected formatting errors. "
                    "Routing bad rows to an audit log prevents pipeline halts while maintaining "
                    "data integrity."
                ),
                tier=RecommendationTier.ESSENTIAL,
                complexity=ComplexitySize.S,
                mvp_candidate=True,
                node_mapping="validate.required_fields",
                dependencies=["validate.required_fields"],
                risks=[],
                decision=FeatureDecision.ACCEPTED,
            ),
            FeatureRecommendation(
                id="feat-trend-viz",
                title="Monthly Trend KPI Charting",
                description=(
                    "Generate responsive interactive bar and line charts alongside "
                    "tabular summaries in the final executive report."
                ),
                rationale=(
                    "Decision-makers need visual revenue trajectory indicators rather than "
                    "parsing multi-row numeric tables manually."
                ),
                tier=RecommendationTier.RECOMMENDED,
                complexity=ComplexitySize.M,
                mvp_candidate=True,
                node_mapping="output.report",
                dependencies=["aggregate.monthly_totals", "output.report"],
                risks=["Requires valid date columns on all grouped records."],
                decision=FeatureDecision.ACCEPTED,
            ),
            FeatureRecommendation(
                id="feat-duplicate-detection",
                title="Automatic Composite Duplicate Detection",
                description=(
                    "Flag or drop duplicated transactions based on date + identifier "
                    "composite keys."
                ),
                rationale=(
                    "Batch exports and upstream retries frequently introduce accidental duplicate "
                    "rows that distort financial aggregations."
                ),
                tier=RecommendationTier.RECOMMENDED,
                complexity=ComplexitySize.M,
                mvp_candidate=True,
                node_mapping="transform.filter",
                dependencies=["validate.required_fields"],
                risks=["Increases in-memory lookup cache for very large files."],
                decision=FeatureDecision.PENDING,
            ),
            FeatureRecommendation(
                id="feat-currency-normalization",
                title="Currency & Locale String Sanitization",
                description=(
                    "Automatically strip localized currency symbols ($/€/£) and formatting "
                    "commas before floating-point arithmetic."
                ),
                rationale=(
                    "Accounting exports often contain formatted currency strings that crash "
                    "standard numeric parsers if not sanitized."
                ),
                tier=RecommendationTier.OPTIONAL,
                complexity=ComplexitySize.S,
                mvp_candidate=False,
                node_mapping="validate.type_check",
                dependencies=["validate.type_check"],
                risks=[],
                decision=FeatureDecision.PENDING,
            ),
            FeatureRecommendation(
                id="feat-webhook-trigger",
                title="Automated Webhook Ingestion & Alerts",
                description=(
                    "Expose an authenticated REST endpoint to receive incoming CSV batches "
                    "and dispatch alert webhooks on validation failure."
                ),
                rationale=(
                    "Enables hands-free enterprise system integrations without manual "
                    "dashboard file uploads."
                ),
                tier=RecommendationTier.FUTURE,
                complexity=ComplexitySize.L,
                mvp_candidate=False,
                node_mapping="trigger.webhook",
                dependencies=["trigger.webhook"],
                risks=["Requires API key management and network access configuration."],
                decision=FeatureDecision.DEFERRED,
            ),
        ]

        return recs

    @classmethod
    def apply_decisions(
        cls,
        workflow: WorkflowSpec,
        recommendations: list[FeatureRecommendation],
    ) -> WorkflowSpec:
        """
        Applies accepted feature recommendations to modify or enrich
        the target workflow spec.
        """
        updated = workflow.model_copy(deep=True)

        for rec in recommendations:
            if rec.decision != FeatureDecision.ACCEPTED:
                continue

            if rec.id == "feat-trend-viz" or rec.node_mapping == "output.report":
                for node in updated.nodes:
                    if node.type == "output.report":
                        node.config["chart_type"] = "bar"
                        node.config["show_trend"] = True

            elif rec.id == "feat-rejected-audit" or rec.node_mapping == "validate.required_fields":
                for node in updated.nodes:
                    if node.type == "validate.required_fields":
                        node.config["rejection_strategy"] = "drop"
                        node.config["record_rejections"] = True

        return updated
