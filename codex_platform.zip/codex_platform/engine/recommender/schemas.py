from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class RecommendationTier(str, Enum):
    ESSENTIAL = "essential"
    RECOMMENDED = "recommended"
    OPTIONAL = "optional"
    FUTURE = "future"


class ComplexitySize(str, Enum):
    S = "S"
    M = "M"
    L = "L"


class FeatureDecision(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    DEFERRED = "deferred"


class FeatureRecommendation(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str
    title: str
    description: str
    rationale: str
    tier: RecommendationTier
    complexity: ComplexitySize
    mvp_candidate: bool = True
    node_mapping: Optional[str] = None
    dependencies: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    decision: FeatureDecision = FeatureDecision.PENDING


class FeatureRecommendationList(BaseModel):
    recommendations: list[FeatureRecommendation]
