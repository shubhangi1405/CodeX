import hashlib
import json
import time
import uuid
from datetime import datetime, timezone
from typing import Any

# Ensure nodes are registered
import engine.nodes  # noqa: F401
from engine.registry import NodeRegistry
from engine.spec import WorkflowSpec
from engine.types import NodeResult, NodeStatus, RunRecord


class WorkflowExecutionError(Exception):
    pass


class WorkflowExecutor:
    def __init__(self, node_timeout_seconds: float = 30.0, max_row_limit: int = 1000000):
        self.node_timeout_seconds = node_timeout_seconds
        self.max_row_limit = max_row_limit

    def execute(self, workflow: WorkflowSpec, initial_inputs: dict[str, Any]) -> RunRecord:
        """
        Executes a workflow deterministically in topological order.
        Identical input + identical workflow version produces identical output hash.
        Failures never crash the engine; downstream nodes are marked SKIPPED.
        """
        start_time = time.perf_counter()
        run_id = str(uuid.uuid4())
        started_at = datetime.now(timezone.utc).isoformat()

        # Validate DAG
        workflow.validate_dag()
        topological_order = workflow.get_topological_order()

        # Compute SHA-256 snapshot hash
        input_hash = self._compute_input_hash(workflow, initial_inputs)

        # Map edges: destination_node -> list of (destination_port, source_node, source_port)
        incoming_edges: dict[str, list[tuple[str, str, str]]] = {n.id: [] for n in workflow.nodes}
        for edge in workflow.edges:
            incoming_edges[edge.to_node].append((edge.to_port, edge.from_node, edge.from_port))

        node_specs = {n.id: n for n in workflow.nodes}
        node_results: dict[str, NodeResult] = {}
        all_node_outputs: dict[str, dict[str, Any]] = {}
        failed_or_skipped_nodes: set[str] = set()
        overall_errors: list[str] = []

        for node_id in topological_order:
            node_spec = node_specs[node_id]

            # Check if any upstream parent failed or was skipped
            parents = [from_node for _, from_node, _ in incoming_edges[node_id]]
            has_failed_parent = any(p in failed_or_skipped_nodes for p in parents)

            if has_failed_parent:
                node_result = NodeResult(
                    node_id=node_id,
                    status=NodeStatus.SKIPPED,
                    duration_ms=0.0,
                    errors=[f"Skipped because upstream node(s) failed or were skipped: {parents}"],
                )
                node_results[node_id] = node_result
                failed_or_skipped_nodes.add(node_id)
                continue

            # Gather inputs for this node
            node_inputs: dict[str, Any] = {}
            if not incoming_edges[node_id]:
                # Trigger / Entry node: pulls from initial_inputs
                node_inputs = dict(initial_inputs)
            else:
                for dest_port, from_node, from_port in incoming_edges[node_id]:
                    parent_outputs = all_node_outputs.get(from_node, {})
                    val = None
                    if from_port in parent_outputs:
                        val = parent_outputs[from_port]
                    elif "table" in parent_outputs:
                        val = parent_outputs["table"]
                    elif "valid_table" in parent_outputs:
                        val = parent_outputs["valid_table"]
                    if val is not None:
                        node_inputs[dest_port] = val
                        if "table" not in node_inputs and isinstance(val, list):
                            node_inputs["table"] = val

            # Instantiate and execute node
            node_start = time.perf_counter()
            try:
                node_instance = NodeRegistry.create(
                    node_type=node_spec.type,
                    node_id=node_id,
                    label=node_spec.label,
                    config=node_spec.config,
                )
                res = node_instance.execute(node_inputs, context={"run_id": run_id})
                node_results[node_id] = res

                if res.status == NodeStatus.SUCCESS:
                    all_node_outputs[node_id] = res.outputs
                else:
                    failed_or_skipped_nodes.add(node_id)
                    overall_errors.extend(res.errors)

            except Exception as e:
                node_duration = (time.perf_counter() - node_start) * 1000
                err_msg = f"Unhandled exception in node '{node_id}' ({node_spec.type}): {e}"
                node_results[node_id] = NodeResult(
                    node_id=node_id,
                    status=NodeStatus.FAILED,
                    duration_ms=round(node_duration, 2),
                    errors=[err_msg],
                )
                failed_or_skipped_nodes.add(node_id)
                overall_errors.append(err_msg)

        total_duration = (time.perf_counter() - start_time) * 1000
        completed_at = datetime.now(timezone.utc).isoformat()
        overall_status = NodeStatus.FAILED if overall_errors else NodeStatus.SUCCESS

        # Collect final outputs (from terminal nodes)
        terminal_nodes = [
            n.id for n in workflow.nodes if not any(e.from_node == n.id for e in workflow.edges)
        ]
        final_outputs: dict[str, Any] = {}
        for term_id in terminal_nodes:
            if term_id in all_node_outputs:
                final_outputs.update(all_node_outputs[term_id])

        output_hash = self._compute_output_hash(final_outputs)

        return RunRecord(
            run_id=run_id,
            workflow_id=workflow.id,
            workflow_version=workflow.version,
            status=overall_status,
            started_at=started_at,
            completed_at=completed_at,
            total_duration_ms=round(total_duration, 2),
            input_hash=input_hash,
            output_hash=output_hash,
            input_snapshot=dict(initial_inputs),
            node_results=node_results,
            final_outputs=final_outputs,
            errors=overall_errors,
        )

    def execute_single_node(
        self,
        node_type: str,
        node_id: str,
        label: str,
        config: dict[str, Any],
        inputs: dict[str, Any],
    ) -> NodeResult:
        """
        Executes a single node in isolation for rapid debugging or manual inspection.
        """
        node_instance = NodeRegistry.create(
            node_type=node_type,
            node_id=node_id,
            label=label,
            config=config,
        )
        return node_instance.execute(inputs, context={"single_node_execution": True})

    def _compute_input_hash(self, workflow: WorkflowSpec, inputs: dict[str, Any]) -> str:
        hasher = hashlib.sha256()
        hasher.update(str(workflow.id).encode("utf-8"))
        hasher.update(str(workflow.version).encode("utf-8"))
        for k in sorted(inputs.keys()):
            val = inputs[k]
            hasher.update(k.encode("utf-8"))
            if isinstance(val, (dict, list)):
                hasher.update(json.dumps(val, sort_keys=True).encode("utf-8"))
            else:
                hasher.update(str(val).encode("utf-8"))
        return hasher.hexdigest()

    def _compute_output_hash(self, outputs: dict[str, Any]) -> str:
        hasher = hashlib.sha256()
        for k in sorted(outputs.keys()):
            val = outputs[k]
            hasher.update(k.encode("utf-8"))
            if isinstance(val, (dict, list)):
                hasher.update(json.dumps(val, sort_keys=True, default=str).encode("utf-8"))
            else:
                hasher.update(str(val).encode("utf-8"))
        return hasher.hexdigest()
