import pytest

from engine.compiler.pipeline import draft_workflow
from engine.compiler.providers import MockProvider
from engine.compiler.schemas import ProductUnderstanding
from engine.testing.generator import TestCaseGenerator
from engine.testing.oracle import IndependentOracle
from engine.testing.runner import WorkflowTestRunner
from engine.testing.schemas import TestCase, TestCaseCategory


@pytest.fixture
def canonical_understanding() -> ProductUnderstanding:
    return ProductUnderstanding(
        goal="Validate CSV, calculate monthly totals, and generate report",
        summary="A pipeline that processes monthly sales CSVs.",
        target_users=["Finance Analyst"],
        inputs=[],
        outputs=[],
        business_rules=[],
        assumptions=[],
        clarifications=[],
    )


def test_independent_oracle_computes_correct_monthly_totals() -> None:
    csv_data = (
        "date,amount,category\n"
        "2026-01-15,100.00,Software\n"
        "2026-01-20,200.00,Hardware\n"
        "2026-02-10,350.50,Services\n"
        "2026-02-15,-50.00,Refund\n"  # filtered out by min_amount > 0
    )
    result = IndependentOracle.calculate_expected_monthly_totals(csv_data)

    assert result["valid_rows_count"] == 3
    assert result["rejected_count"] == 1
    assert result["total_revenue"] == 650.50
    assert len(result["monthly_totals"]) == 2
    assert result["monthly_totals"][0]["month"] == "2026-01"
    assert result["monthly_totals"][0]["total_amount"] == 300.0
    assert result["monthly_totals"][1]["month"] == "2026-02"
    assert result["monthly_totals"][1]["total_amount"] == 350.50


def test_generator_synthesizes_happy_path_and_edge_cases(
    canonical_understanding: ProductUnderstanding,
) -> None:
    workflow = draft_workflow(canonical_understanding, provider=MockProvider())
    tests = TestCaseGenerator.generate_suite(workflow)

    assert len(tests) >= 7
    categories = [t.category for t in tests]
    assert TestCaseCategory.HAPPY_PATH in categories
    assert TestCaseCategory.EDGE_CASE in categories

    test_ids = [t.id for t in tests]
    assert "test-happy-path" in test_ids
    assert "test-edge-empty-file" in test_ids
    assert "test-edge-missing-column" in test_ids
    assert "test-edge-wrong-types" in test_ids
    assert "test-edge-extreme-values" in test_ids
    assert "test-edge-single-row" in test_ids


def test_runner_executes_suite_and_verifies_results(
    canonical_understanding: ProductUnderstanding,
) -> None:
    workflow = draft_workflow(canonical_understanding, provider=MockProvider())
    tests = TestCaseGenerator.generate_suite(workflow)
    runner = WorkflowTestRunner()

    suite_result = runner.run_suite(workflow, tests)

    assert suite_result.total_tests == len(tests)
    assert suite_result.passed_tests > 0
    # Every test should pass according to its design (including expected edge case rejections)
    assert suite_result.all_passed is True


def test_runner_produces_structured_failure_explanation_on_mismatch(
    canonical_understanding: ProductUnderstanding,
) -> None:
    workflow = draft_workflow(canonical_understanding, provider=MockProvider())
    runner = WorkflowTestRunner()

    # Create a test case with an impossible expected revenue to trigger failure explanation
    failing_test = TestCase(
        id="test-impossible-revenue",
        name="Impossible Revenue Expectation",
        description="Expects revenue to be $999,999.00 on small dataset.",
        category=TestCaseCategory.HAPPY_PATH,
        input_data={
            "file": "date,amount,category\n2026-01-15,100.00,Software\n",
            "file_in": "date,amount,category\n2026-01-15,100.00,Software\n",
        },
        expected_output={"total_revenue": 999999.00},
        expect_failure=False,
    )

    result = runner.run_test(workflow, failing_test)

    assert result.passed is False
    assert result.failing_node == "aggregate.monthly_totals"
    assert result.explanation is not None
    assert "Revenue calculation mismatch" in result.explanation
    assert result.remediation is not None
