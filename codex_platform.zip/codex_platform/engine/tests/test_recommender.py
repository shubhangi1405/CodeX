from engine.compiler.pipeline import draft_workflow
from engine.compiler.providers import MockProvider
from engine.compiler.schemas import ProductUnderstanding
from engine.recommender.engine import FeatureRecommender
from engine.recommender.schemas import FeatureDecision, RecommendationTier


def test_recommender_produces_four_tiered_features() -> None:
    understanding = ProductUnderstanding(
        goal="Process monthly CSV",
        summary="A pipeline.",
        target_users=["Auditor"],
        inputs=[],
        outputs=[],
        business_rules=[],
        assumptions=[],
        clarifications=[],
    )
    workflow = draft_workflow(understanding, provider=MockProvider())
    recs = FeatureRecommender.recommend_for_prompt(understanding, workflow)

    assert len(recs) >= 4
    tiers = {r.tier for r in recs}
    assert RecommendationTier.ESSENTIAL in tiers
    assert RecommendationTier.RECOMMENDED in tiers
    assert RecommendationTier.OPTIONAL in tiers
    assert RecommendationTier.FUTURE in tiers

    # Check that rationales exist and are substantive
    for r in recs:
        assert len(r.rationale) > 10
        assert r.node_mapping is not None


def test_recommender_applies_accepted_decisions_to_workflow() -> None:
    understanding = ProductUnderstanding(
        goal="Process monthly CSV",
        summary="A pipeline.",
        target_users=["Auditor"],
        inputs=[],
        outputs=[],
        business_rules=[],
        assumptions=[],
        clarifications=[],
    )
    workflow = draft_workflow(understanding, provider=MockProvider())
    recs = FeatureRecommender.recommend_for_prompt(understanding, workflow)

    # Mark trend viz and audit log as accepted
    for r in recs:
        if r.id in ("feat-trend-viz", "feat-rejected-audit"):
            r.decision = FeatureDecision.ACCEPTED
        else:
            r.decision = FeatureDecision.REJECTED

    updated_wf = FeatureRecommender.apply_decisions(workflow, recs)

    report_node = next(n for n in updated_wf.nodes if n.type == "output.report")
    assert report_node.config.get("chart_type") == "bar"
    assert report_node.config.get("show_trend") is True

    req_node = next(n for n in updated_wf.nodes if n.type == "validate.required_fields")
    assert req_node.config.get("record_rejections") is True
