from pathlib import Path

from engine.registry import NodeRegistry
from engine.types import NodeStatus


def test_read_csv_node() -> None:
    csv_path = Path("samples/monthly_sales.csv")
    node = NodeRegistry.create(
        node_type="ingest.read_csv",
        node_id="n1",
        label="Read CSV",
        config={"delimiter": ",", "has_header": True},
    )
    result = node.execute({"file": str(csv_path)}, {})
    assert result.status == NodeStatus.SUCCESS
    assert result.row_count_out == 9
    assert "table" in result.outputs
    first_row = result.outputs["table"][0]
    assert first_row["category"] == "Software"
    assert first_row["amount"] == "1200.00"


def test_required_fields_node_drops_missing() -> None:
    node = NodeRegistry.create(
        node_type="validate.required_fields",
        node_id="n2",
        label="Required Fields",
        config={"required_columns": ["date", "amount"], "rejection_strategy": "drop"},
    )
    sample_table = [
        {"date": "2026-01-01", "amount": "100.0"},
        {"date": "2026-01-02", "amount": ""},  # Missing amount
        {"date": "", "amount": "200.0"},  # Missing date
        {"date": "2026-01-04", "amount": "400.0"},
    ]
    result = node.execute({"table": sample_table}, {})
    assert result.status == NodeStatus.SUCCESS
    assert result.row_count_out == 2
    assert result.rejected_count == 2
    assert len(result.rejected_rows) == 2
    assert "Missing required value" in result.rejected_rows[0].reason


def test_type_check_node_coerces_numbers() -> None:
    node = NodeRegistry.create(
        node_type="validate.type_check",
        node_id="n3",
        label="Type Check",
        config={"column_types": {"amount": "number", "date": "date"}, "coerce": True},
    )
    sample_table = [
        {"date": "2026-01-15", "amount": "$1,250.50"},
        {"date": "2026-01-16", "amount": "bad_number"},
    ]
    result = node.execute({"table": sample_table}, {})
    assert result.status == NodeStatus.SUCCESS
    assert result.row_count_out == 1
    assert result.rejected_count == 1
    assert result.outputs["table"][0]["amount"] == 1250.5


def test_filter_node() -> None:
    node = NodeRegistry.create(
        node_type="transform.filter",
        node_id="n4",
        label="Filter Positive",
        config={"expression": "amount > 0 and category == 'Software'"},
    )
    sample_table = [
        {"amount": 100.0, "category": "Software"},
        {"amount": -50.0, "category": "Software"},
        {"amount": 200.0, "category": "Hardware"},
    ]
    result = node.execute({"table": sample_table}, {})
    assert result.status == NodeStatus.SUCCESS
    assert result.row_count_out == 1
    assert result.rejected_count == 2


def test_monthly_totals_node() -> None:
    node = NodeRegistry.create(
        node_type="aggregate.monthly_totals",
        node_id="n5",
        label="Monthly Totals",
        config={"date_column": "date", "amount_column": "amount"},
    )
    sample_table = [
        {"date": "2026-01-10", "amount": 100.0},
        {"date": "2026-01-20", "amount": 250.0},
        {"date": "2026-02-05", "amount": 400.0},
    ]
    result = node.execute({"table": sample_table}, {})
    assert result.status == NodeStatus.SUCCESS
    assert result.row_count_out == 2
    totals = result.outputs["table"]
    assert totals[0]["month"] == "2026-01"
    assert totals[0]["total_amount"] == 350.0
    assert totals[0]["record_count"] == 2
    assert totals[1]["month"] == "2026-02"
    assert totals[1]["total_amount"] == 400.0


def test_assert_node_passes_and_fails() -> None:
    node_pass = NodeRegistry.create(
        node_type="quality.assert",
        node_id="n6",
        label="Assert",
        config={"rule": "row_count > 0"},
    )
    assert node_pass.execute({"table": [{"x": 1}]}, {}).status == NodeStatus.SUCCESS

    node_fail = NodeRegistry.create(
        node_type="quality.assert",
        node_id="n7",
        label="Assert Fail",
        config={"rule": "row_count > 0"},
    )
    res_fail = node_fail.execute({"table": []}, {})
    assert res_fail.status == NodeStatus.FAILED
    assert "Assertion failed" in res_fail.errors[0]


def test_export_csv_escapes_formula_injection() -> None:
    node = NodeRegistry.create(
        node_type="output.export_csv",
        node_id="n8",
        label="Export CSV",
        config={"filename": "out.csv", "protect_formula_injection": True},
    )
    sample_table = [
        {"name": "Alice", "formula": "=SUM(A1:A10)"},
        {"name": "Bob", "formula": "+12345"},
    ]
    result = node.execute({"table": sample_table}, {})
    assert result.status == NodeStatus.SUCCESS
    csv_text = result.outputs["file"]
    assert "'=SUM(A1:A10)" in csv_text
    assert "'+12345" in csv_text
