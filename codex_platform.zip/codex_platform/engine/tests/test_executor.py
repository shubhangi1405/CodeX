from pathlib import Path

from engine.executor import WorkflowExecutor
from engine.spec import EdgeSpec, NodeSpec, TriggerSpec, WorkflowSpec
from engine.types import NodeStatus


def create_csv_monthly_pipeline_spec() -> WorkflowSpec:
    return WorkflowSpec(
        id="wf-monthly-sales-v1",
        name="CSV Monthly Totals Pipeline",
        version=1,
        description="End-to-end deterministic monthly sales aggregator",
        trigger=TriggerSpec(id="t1", type="manual_upload"),
        nodes=[
            NodeSpec(
                id="node-read",
                type="ingest.read_csv",
                label="Read CSV",
                category="ingest",
                config={"delimiter": ",", "has_header": True},
            ),
            NodeSpec(
                id="node-req",
                type="validate.required_fields",
                label="Validate Required",
                category="validate",
                config={
                    "required_columns": ["date", "amount", "category"],
                    "rejection_strategy": "drop",
                },
            ),
            NodeSpec(
                id="node-type",
                type="validate.type_check",
                label="Type Check",
                category="validate",
                config={
                    "column_types": {"date": "date", "amount": "number"},
                    "coerce": True,
                },
            ),
            NodeSpec(
                id="node-filter",
                type="transform.filter",
                label="Filter Valid Amounts",
                category="transform",
                config={"expression": "amount > 0"},
            ),
            NodeSpec(
                id="node-monthly",
                type="aggregate.monthly_totals",
                label="Monthly Totals",
                category="aggregate",
                config={"date_column": "date", "amount_column": "amount"},
            ),
            NodeSpec(
                id="node-assert",
                type="quality.assert",
                label="Assert Summary Exists",
                category="quality",
                config={"rule": "row_count > 0"},
            ),
            NodeSpec(
                id="node-report",
                type="output.report",
                label="Monthly Report",
                category="output",
                config={"title": "Q1 2026 Sales Report", "chart_type": "bar"},
            ),
        ],
        edges=[
            EdgeSpec(
                id="e1",
                from_node="node-read",
                from_port="table",
                to_node="node-req",
                to_port="table",
            ),
            EdgeSpec(
                id="e2",
                from_node="node-req",
                from_port="table",
                to_node="node-type",
                to_port="table",
            ),
            EdgeSpec(
                id="e3",
                from_node="node-type",
                from_port="table",
                to_node="node-filter",
                to_port="table",
            ),
            EdgeSpec(
                id="e4",
                from_node="node-filter",
                from_port="table",
                to_node="node-monthly",
                to_port="table",
            ),
            EdgeSpec(
                id="e5",
                from_node="node-monthly",
                from_port="table",
                to_node="node-assert",
                to_port="table",
            ),
            EdgeSpec(
                id="e6",
                from_node="node-assert",
                from_port="table",
                to_node="node-report",
                to_port="table",
            ),
        ],
    )


def test_happy_path_csv_pipeline_runs_end_to_end() -> None:
    workflow = create_csv_monthly_pipeline_spec()
    executor = WorkflowExecutor()
    csv_file = Path("samples/monthly_sales.csv")

    run_record = executor.execute(workflow, {"file": str(csv_file)})

    assert run_record.status == NodeStatus.SUCCESS
    assert len(run_record.errors) == 0

    # Verify step-level node results
    assert "node-read" in run_record.node_results
    assert run_record.node_results["node-read"].row_count_out == 9

    assert "node-req" in run_record.node_results
    assert run_record.node_results["node-req"].status == NodeStatus.SUCCESS
    assert run_record.node_results["node-req"].rejected_count == 0

    assert "node-monthly" in run_record.node_results
    monthly_out = run_record.node_results["node-monthly"].outputs["table"]
    assert len(monthly_out) == 3  # Jan, Feb, Mar

    # Check totals:
    # Jan: 1200 + 350.5 + 890 = 2440.5
    # Feb: 450 + 2100 + 650.25 = 3200.25
    # Mar: 180 + 3200 + 950 = 4330.0
    months = {m["month"]: m["total_amount"] for m in monthly_out}
    assert months["2026-01"] == 2440.5
    assert months["2026-02"] == 3200.25
    assert months["2026-03"] == 4330.0

    # Final report output
    assert "report" in run_record.final_outputs
    assert run_record.final_outputs["report"]["title"] == "Q1 2026 Sales Report"


def test_corrupted_csv_pipeline_records_rejected_rows_without_crashing() -> None:
    workflow = create_csv_monthly_pipeline_spec()
    executor = WorkflowExecutor()
    corrupted_csv = Path("samples/corrupted_sales.csv")

    run_record = executor.execute(workflow, {"file": str(corrupted_csv)})

    assert run_record.status == NodeStatus.SUCCESS  # Successfully filtered & completed
    req_res = run_record.node_results["node-req"]
    assert req_res.rejected_count == 1  # Row 2 missing amount
    assert "Missing required value" in req_res.rejected_rows[0].reason

    type_res = run_record.node_results["node-type"]
    assert type_res.rejected_count == 1  # Row 3 invalid_number

    filter_res = run_record.node_results["node-filter"]
    assert filter_res.rejected_count == 1  # Row 5 negative amount (-150)


def test_empty_file_fails_gracefully_and_skips_downstream() -> None:
    workflow = create_csv_monthly_pipeline_spec()
    executor = WorkflowExecutor()
    empty_csv = Path("samples/empty.csv")

    run_record = executor.execute(workflow, {"file": str(empty_csv)})

    # Read node fails because 0 bytes
    assert run_record.status == NodeStatus.FAILED
    assert run_record.node_results["node-read"].status == NodeStatus.FAILED

    # Downstream nodes must be marked SKIPPED
    assert run_record.node_results["node-req"].status == NodeStatus.SKIPPED
    assert run_record.node_results["node-monthly"].status == NodeStatus.SKIPPED
    assert run_record.node_results["node-report"].status == NodeStatus.SKIPPED


def test_deterministic_replay_produces_identical_input_hash() -> None:
    workflow = create_csv_monthly_pipeline_spec()
    executor = WorkflowExecutor()
    csv_file = Path("samples/monthly_sales.csv")

    run_1 = executor.execute(workflow, {"file": str(csv_file)})
    run_2 = executor.execute(workflow, {"file": str(csv_file)})

    assert run_1.input_hash == run_2.input_hash
    assert run_1.final_outputs == run_2.final_outputs
