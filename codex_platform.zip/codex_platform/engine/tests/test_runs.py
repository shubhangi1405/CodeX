import tempfile

from engine.compiler.pipeline import draft_workflow
from engine.compiler.providers import MockProvider
from engine.compiler.schemas import ProductUnderstanding
from engine.executor import WorkflowExecutor
from engine.runs.storage import RunStorage
from engine.versioning.diff import WorkflowVersionManager


def test_storage_and_deterministic_replay_produces_identical_hash() -> None:
    understanding = ProductUnderstanding(
        goal="Process monthly CSV",
        summary="A pipeline.",
        target_users=["Auditor"],
        inputs=[],
        outputs=[],
        business_rules=[],
        assumptions=[],
        clarifications=[],
    )
    workflow = draft_workflow(understanding, provider=MockProvider())
    inputs = {
        "file": "date,amount,category\n2026-01-15,100.00,Software\n2026-02-10,200.00,Hardware\n",
        "file_in": "date,amount,category\n2026-01-15,100.00,Software\n2026-02-10,200.00,Hardware\n",
    }

    with tempfile.TemporaryDirectory() as tmpdir:
        storage = RunStorage(base_dir=tmpdir)
        executor = WorkflowExecutor()

        record = executor.execute(workflow, inputs)
        storage.save_run(record, workflow)

        # Retrieve run
        fetched = storage.get_run(record.run_id)
        assert fetched is not None
        fetched_rec, fetched_wf = fetched
        assert fetched_rec.run_id == record.run_id
        assert fetched_rec.input_hash == record.input_hash

        # Replay past run with identical inputs -> must be 100% bit-for-bit identical!
        replayed_rec, identical = storage.replay_run(record.run_id, new_inputs=None)
        assert identical is True
        assert replayed_rec.output_hash == record.output_hash
        assert replayed_rec.input_hash == record.input_hash

        # Replay with new inputs -> produces new run record under same workflow version
        new_inputs = {
            "file": "date,amount,category\n2026-03-01,500.00,Services\n",
            "file_in": "date,amount,category\n2026-03-01,500.00,Services\n",
        }
        new_rec, identical_new = storage.replay_run(record.run_id, new_inputs=new_inputs)
        assert identical_new is False
        assert new_rec.output_hash != record.output_hash
        assert new_rec.workflow_version == workflow.version


def test_workflow_diff_computes_added_removed_and_modified_nodes() -> None:
    understanding = ProductUnderstanding(
        goal="Process monthly CSV",
        summary="A pipeline.",
        target_users=["Auditor"],
        inputs=[],
        outputs=[],
        business_rules=[],
        assumptions=[],
        clarifications=[],
    )
    wf_v1 = draft_workflow(understanding, provider=MockProvider())
    wf_v2 = wf_v1.model_copy(deep=True)
    wf_v2.version = 2

    # Modify one node config
    wf_v2.nodes[0].config["delimiter"] = ";"

    # Add a node
    from engine.spec import NodeSpec
    from engine.types import DataType, Port

    wf_v2.nodes.append(
        NodeSpec(
            id="node-new",
            type="quality.assert",
            label="Assert Quality",
            category="quality",
            config={"rule": "row_count > 0"},
            input_ports=[Port(name="table", data_type=DataType.TABLE)],
            output_ports=[Port(name="table", data_type=DataType.TABLE)],
        )
    )

    diff = WorkflowVersionManager.compute_diff(wf_v1, wf_v2)
    assert diff.old_version == 1
    assert diff.new_version == 2
    assert len(diff.added_nodes) == 1
    assert diff.added_nodes[0].node_id == "node-new"
    assert len(diff.modified_nodes) == 1
    assert diff.modified_nodes[0].node_id == wf_v1.nodes[0].id
    assert diff.modified_nodes[0].old_config.get("delimiter") == ","
    assert diff.modified_nodes[0].new_config.get("delimiter") == ";"
