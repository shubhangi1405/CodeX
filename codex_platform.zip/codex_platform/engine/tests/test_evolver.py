from engine.compiler.evolver import WorkflowEvolver
from engine.spec import EdgeSpec, NodeSpec, TriggerSpec, WorkflowSpec
from engine.types import DataType, Port


def _create_sample_workflow() -> WorkflowSpec:
    return WorkflowSpec(
        id="wf-test-evolution",
        name="Test Evolution Pipeline",
        version=1,
        description="Test workflow for evolutionary modifications",
        trigger=TriggerSpec(id="t1", type="manual_upload", config={}),
        inputs=[Port(name="file", data_type=DataType.FILE)],
        nodes=[
            NodeSpec(
                id="node-read",
                type="ingest.read_csv",
                label="Read CSV",
                category="ingest",
                input_ports=[Port(name="file", data_type=DataType.FILE)],
                output_ports=[Port(name="table", data_type=DataType.TABLE)],
                config={"has_header": True},
            ),
            NodeSpec(
                id="node-req",
                type="validate.required_fields",
                label="Required Fields",
                category="validate",
                input_ports=[Port(name="table", data_type=DataType.TABLE)],
                output_ports=[Port(name="table", data_type=DataType.TABLE)],
                config={"required_columns": ["date", "amount"]},
            ),
            NodeSpec(
                id="node-agg",
                type="aggregate.monthly_totals",
                label="Monthly Totals",
                category="aggregate",
                input_ports=[Port(name="table", data_type=DataType.TABLE)],
                output_ports=[Port(name="table", data_type=DataType.TABLE)],
                config={"date_column": "date", "amount_column": "amount"},
            ),
        ],
        edges=[
            EdgeSpec(
                id="e1",
                from_node="node-read",
                from_port="table",
                to_node="node-req",
                to_port="table",
            ),
            EdgeSpec(
                id="e2",
                from_node="node-req",
                from_port="table",
                to_node="node-agg",
                to_port="table",
            ),
        ],
    )


def test_evolver_inserts_filter_node_when_threshold_specified() -> None:
    wf = _create_sample_workflow()
    evolved, diff, errors = WorkflowEvolver.evolve(wf, "filter out transactions below $50")

    assert len(errors) == 0
    assert evolved.version == 2
    # Verify a new filter node was inserted into the DAG
    filter_nodes = [n for n in evolved.nodes if n.type == "transform.filter"]
    assert len(filter_nodes) == 1
    assert "amount >= 50" in filter_nodes[0].config["expression"]

    # Verify diff recorded the addition
    assert len(diff.added_nodes) == 1
    assert diff.added_nodes[0].type == "transform.filter"


def test_evolver_updates_required_fields_when_column_requested() -> None:
    wf = _create_sample_workflow()
    evolved, diff, errors = WorkflowEvolver.evolve(wf, "also require user_id column")

    assert len(errors) == 0
    assert evolved.version == 2
    req_node = next(n for n in evolved.nodes if n.type == "validate.required_fields")
    assert "user_id" in req_node.config["required_columns"]
    assert len(diff.modified_nodes) == 1
