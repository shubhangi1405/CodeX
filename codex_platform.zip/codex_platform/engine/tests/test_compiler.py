from engine.compiler.pipeline import (
    clarify,
    compile_prompt_to_workflow,
    interpret,
)
from engine.compiler.providers import MockProvider
from engine.compiler.schemas import ItemAttribution
from engine.compiler.validator import WorkflowValidator
from engine.spec import EdgeSpec, NodeSpec, TriggerSpec, WorkflowSpec
from engine.types import DataType, Port


def test_interpret_produces_structured_understanding() -> None:
    provider = MockProvider()
    prompt = (
        "Whenever a new CSV arrives, validate the records, "
        "identify missing fields, calculate monthly totals and create a report."
    )
    understanding = interpret(prompt, provider)

    assert "CSV" in understanding.goal or "monthly" in understanding.goal
    assert len(understanding.inputs) >= 1
    assert len(understanding.outputs) >= 1
    assert len(understanding.business_rules) >= 1
    assert len(understanding.clarifications) <= 3

    # Verify attribution tagging
    attributions = {
        item.attribution
        for item in understanding.inputs
        + understanding.outputs
        + understanding.business_rules
        + understanding.assumptions
    }
    assert ItemAttribution.USER_STATED in attributions
    assert ItemAttribution.ASSUMPTION in attributions


def test_clarify_applies_user_answers() -> None:
    provider = MockProvider()
    prompt = "Process monthly sales CSV"
    understanding = interpret(prompt, provider)

    cq_id = understanding.clarifications[0].id
    answers = {cq_id: "Halt entire workflow on first error"}

    refined = clarify(understanding, answers)
    target_q = next(q for q in refined.clarifications if q.id == cq_id)
    assert target_q.selected_choice == "Halt entire workflow on first error"

    # Confirmed answer promoted to assumption
    clarified_items = [a for a in refined.assumptions if a.id == f"clarified-{cq_id}"]
    assert len(clarified_items) == 1
    assert "Halt entire workflow" in clarified_items[0].description


def test_validator_catches_invalid_dag_cycle() -> None:
    # Construct a cycle: n1 -> n2 -> n1
    spec = WorkflowSpec(
        id="wf-cycle",
        name="Cyclic Workflow",
        trigger=TriggerSpec(id="trig", type="manual_upload"),
        nodes=[
            NodeSpec(
                id="n1",
                type="validate.required_fields",
                label="Node 1",
                category="validate",
                config={"required_columns": ["col1"], "rejection_strategy": "drop"},
                input_ports=[Port(name="table_in", data_type=DataType.TABLE)],
                output_ports=[Port(name="valid_out", data_type=DataType.TABLE)],
            ),
            NodeSpec(
                id="n2",
                type="validate.type_check",
                label="Node 2",
                category="validate",
                config={"column_types": {"col1": "string"}},
                input_ports=[Port(name="table_in", data_type=DataType.TABLE)],
                output_ports=[Port(name="valid_out", data_type=DataType.TABLE)],
            ),
        ],
        edges=[
            EdgeSpec(
                id="e1", from_node="n1", from_port="valid_out", to_node="n2", to_port="table_in"
            ),
            EdgeSpec(
                id="e2", from_node="n2", from_port="valid_out", to_node="n1", to_port="table_in"
            ),
        ],
    )

    errors = WorkflowValidator.validate(spec)
    assert any("cycle" in e.lower() for e in errors)


def test_validator_catches_unknown_node_type() -> None:
    spec = WorkflowSpec(
        id="wf-unknown",
        name="Unknown Node Workflow",
        trigger=TriggerSpec(id="trig", type="manual_upload"),
        nodes=[
            NodeSpec(
                id="n1",
                type="unregistered.arbitrary_code_node",
                label="Arbitrary Code Node",
                category="transform",
                config={"script": "import os; os.system('echo bad')"},
            ),
        ],
        edges=[],
    )

    errors = WorkflowValidator.validate(spec)
    assert any("unknown type" in e.lower() for e in errors)


def test_validator_catches_port_type_mismatch() -> None:
    spec = WorkflowSpec(
        id="wf-mismatch",
        name="Type Mismatch",
        trigger=TriggerSpec(id="trig", type="manual_upload"),
        nodes=[
            NodeSpec(
                id="n1",
                type="quality.assert",
                label="Assert Node",
                category="quality",
                config={"rule": "row_count > 0"},
                input_ports=[Port(name="table_in", data_type=DataType.TABLE)],
                output_ports=[Port(name="passed_out", data_type=DataType.BOOLEAN)],
            ),
            NodeSpec(
                id="n2",
                type="ingest.read_csv",
                label="Read CSV",
                category="ingest",
                config={"delimiter": ","},
                input_ports=[Port(name="file_in", data_type=DataType.FILE)],
                output_ports=[Port(name="table_out", data_type=DataType.TABLE)],
            ),
        ],
        edges=[
            EdgeSpec(
                id="e-bad",
                from_node="n1",
                from_port="passed_out",  # boolean
                to_node="n2",
                to_port="file_in",  # file
            ),
        ],
    )

    errors = WorkflowValidator.validate(spec)
    assert any("type mismatch" in e.lower() for e in errors)


def test_validator_catches_disconnected_node() -> None:
    spec = WorkflowSpec(
        id="wf-disconnected",
        name="Disconnected Node",
        trigger=TriggerSpec(id="trig", type="manual_upload"),
        nodes=[
            NodeSpec(
                id="n1",
                type="ingest.read_csv",
                label="Read CSV",
                category="ingest",
                config={"delimiter": ","},
                input_ports=[Port(name="file_in", data_type=DataType.FILE)],
                output_ports=[Port(name="table_out", data_type=DataType.TABLE)],
            ),
            NodeSpec(
                id="n2",
                type="output.export_csv",
                label="Export CSV",
                category="output",
                config={"filename_template": "out.csv"},
                input_ports=[Port(name="table_in", data_type=DataType.TABLE)],
                output_ports=[Port(name="file_out", data_type=DataType.FILE)],
            ),
            NodeSpec(
                id="n-isolated",
                type="quality.assert",
                label="Lonely Assert",
                category="quality",
                config={"rule": "row_count > 0"},
                input_ports=[Port(name="table_in", data_type=DataType.TABLE)],
                output_ports=[Port(name="passed_out", data_type=DataType.BOOLEAN)],
            ),
        ],
        edges=[
            EdgeSpec(
                id="e1", from_node="n1", from_port="table_out", to_node="n2", to_port="table_in"
            ),
        ],
    )

    errors = WorkflowValidator.validate(spec)
    assert any("disconnected node 'n-isolated'" in e.lower() for e in errors)


def test_compile_prompt_happy_path() -> None:
    provider = MockProvider()
    prompt = (
        "Whenever a new CSV arrives, validate records, calculate monthly totals, and export report."
    )
    result = compile_prompt_to_workflow(prompt=prompt, provider=provider)

    assert result.success is True
    assert result.workflow is not None
    assert len(result.validation_errors) == 0
    assert len(result.repair_history) == 0
    assert len(result.workflow.nodes) >= 6


def test_compile_prompt_repair_loop_succeeds_on_retry() -> None:
    # Scripted workflow with an invalid node type on first attempt
    canonical = MockProvider()._generate_canonical_workflow().model_dump()
    broken_workflow = MockProvider()._generate_canonical_workflow().model_dump()
    broken_workflow["nodes"][1]["type"] = "unknown.invalid_node"

    # Provider will return broken workflow initially, then canonical on repair
    provider = MockProvider(
        scripted_workflows=[broken_workflow],
        repair_sequence=[canonical],
    )

    prompt = "Validate CSV and group by month"
    result = compile_prompt_to_workflow(prompt=prompt, provider=provider, max_repairs=3)

    assert result.success is True
    assert result.workflow is not None
    assert len(result.repair_history) == 1
    assert result.repair_history[0].success is True
    assert "Repaired successfully" in result.repair_history[0].repair_summary


def test_compile_prompt_bounded_retry_exhaustion_never_invents_pass() -> None:
    # Provider consistently returns broken workflow
    broken_workflow = MockProvider()._generate_canonical_workflow().model_dump()
    broken_workflow["nodes"][1]["type"] = "unknown.unfixable_node"

    provider = MockProvider(
        scripted_workflows=[broken_workflow],
        repair_sequence=[broken_workflow, broken_workflow, broken_workflow],
    )

    prompt = "Validate CSV"
    result = compile_prompt_to_workflow(prompt=prompt, provider=provider, max_repairs=3)

    assert result.success is False
    assert result.workflow is None
    assert len(result.repair_history) == 3
    assert len(result.validation_errors) > 0
    assert "Unable to repair workflow after 3 attempts" in result.diagnostics


def test_compile_distinct_domain_workflows_and_test_suites() -> None:
    from engine.testing.generator import TestCaseGenerator
    from engine.testing.runner import WorkflowTestRunner

    prompts = [
        "sports court booking",
        "security event log viewer",
        "hackathon team finder for students",
        "daily habit tracker",
        "clinic appointment scheduling",
        "restaurant inventory",
        "freelance invoice tracker",
        "Build a campus library book lending and overdue fine tracker",
    ]

    wf_names: set[str] = set()
    node_counts: set[int] = set()
    node_type_signatures: set[tuple[str, ...]] = set()
    required_col_signatures: set[tuple[str, ...]] = set()

    runner = WorkflowTestRunner()

    for p in prompts:
        provider = MockProvider()
        res = compile_prompt_to_workflow(prompt=p, provider=provider)
        assert res.success is True, f"Failed to compile '{p}': {res.validation_errors}"
        assert res.workflow is not None
        wf = res.workflow

        assert "CSV Ingestion, Validation & Monthly Totals" not in wf.name
        wf_names.add(wf.name)
        node_counts.add(len(wf.nodes))
        node_type_signatures.add(tuple(n.type for n in wf.nodes))

        req_node = next(n for n in wf.nodes if n.type == "validate.required_fields")
        req_cols = tuple(req_node.config.get("required_columns", []))
        assert req_cols != ("date", "amount"), f"Prompt '{p}' still used generic ('date', 'amount')"
        required_col_signatures.add(req_cols)

        # Generate and execute full 8-test verification suite for this domain workflow
        tests = TestCaseGenerator.generate_suite(wf)
        assert len(tests) == 8
        suite_res = runner.run_suite(wf, tests)
        assert suite_res.all_passed is True, (
            f"Test suite failed for '{p}' ({wf.name}): "
            + ", ".join(
                f"{r.test_case_id}: {r.explanation}" for r in suite_res.results if not r.passed
            )
        )

    # All 8 prompts must produce 8 distinct workflow names and 8 distinct column schemas
    assert len(wf_names) == len(prompts)
    assert len(required_col_signatures) == len(prompts)
    # Workflows must vary in node count (6, 7, and 8 nodes) and node type subsets
    assert len(node_counts) >= 3
    assert len(node_type_signatures) >= 3
