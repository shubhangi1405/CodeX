import pytest

from engine.expression import (
    ExpressionEvaluationError,
    ExpressionSecurityError,
    evaluate_expression,
)


def test_basic_comparisons() -> None:
    context = {"amount": 250.0, "category": "Hardware", "active": True}
    assert evaluate_expression("amount > 100", context) is True
    assert evaluate_expression("amount < 50", context) is False
    assert evaluate_expression("category == 'Hardware'", context) is True
    assert evaluate_expression("category != 'Software'", context) is True
    assert evaluate_expression("active == True", context) is True


def test_boolean_logic() -> None:
    context = {"amount": 250.0, "category": "Hardware", "status": "approved"}
    assert evaluate_expression("amount > 100 and category == 'Hardware'", context) is True
    assert evaluate_expression("amount < 50 or status == 'approved'", context) is True
    assert evaluate_expression("not (amount < 50)", context) is True


def test_arithmetic_and_string_methods() -> None:
    context = {"price": 100, "tax": 15, "code": "INV-2026-001"}
    assert evaluate_expression("price + tax == 115", context) is True
    assert evaluate_expression("price * 2 == 200", context) is True
    assert evaluate_expression("code.startswith('INV-')", context) is True
    assert evaluate_expression("code.endswith('-001')", context) is True


def test_whitelisted_functions() -> None:
    context = {"items": [10, 20, 30], "val": -42}
    assert evaluate_expression("len(items) == 3", context) is True
    assert evaluate_expression("sum(items) == 60", context) is True
    assert evaluate_expression("abs(val) == 42", context) is True


def test_security_blocks_malicious_syntax() -> None:
    context = {"x": 10}
    # Forbid __import__
    with pytest.raises(ExpressionSecurityError):
        evaluate_expression("__import__('os').system('ls')", context)

    # Forbid open()
    with pytest.raises(ExpressionSecurityError):
        evaluate_expression("open('/etc/passwd').read()", context)

    # Forbid lambda
    with pytest.raises(ExpressionSecurityError):
        evaluate_expression("(lambda y: y * 2)(10)", context)

    # Forbid arbitrary unwhitelisted function
    with pytest.raises(ExpressionSecurityError):
        evaluate_expression("eval('2 + 2')", context)

    # Forbid dunder attribute access
    with pytest.raises(ExpressionSecurityError):
        evaluate_expression("x.__class__.__bases__", context)


def test_syntax_error_handled_gracefully() -> None:
    with pytest.raises(ExpressionEvaluationError):
        evaluate_expression("amount > > 100", {"amount": 100})
