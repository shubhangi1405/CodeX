import ast
import operator
from typing import Any, Callable


class ExpressionSecurityError(Exception):
    pass


class ExpressionEvaluationError(Exception):
    pass


# Allowed safe binary operators
SAFE_BIN_OPS: dict[type[ast.operator], Callable[[Any, Any], Any]] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}

# Allowed safe unary operators
SAFE_UNARY_OPS: dict[type[ast.unaryop], Callable[[Any], Any]] = {
    ast.Not: operator.not_,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}

# Allowed safe comparison operators
SAFE_COMPARE_OPS: dict[type[ast.cmpop], Callable[[Any, Any], Any]] = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.In: lambda a, b: a in b,
    ast.NotIn: lambda a, b: a not in b,
}

# Whitelisted global functions
SAFE_GLOBALS: dict[str, Callable[..., Any]] = {
    "len": len,
    "sum": sum,
    "min": min,
    "max": max,
    "abs": abs,
    "round": round,
    "int": int,
    "float": float,
    "str": str,
    "bool": bool,
}

# Whitelisted string methods
SAFE_STRING_METHODS = {"startswith", "endswith", "lower", "upper", "strip", "replace", "contains"}


def evaluate_expression(expr_str: str, context: dict[str, Any]) -> Any:
    """
    Parses and evaluates an expression safely using Python's AST module.
    Prevents any arbitrary code execution or unvetted builtins.
    """
    if not expr_str or not expr_str.strip():
        return True

    try:
        parsed = ast.parse(expr_str.strip(), mode="eval")
    except SyntaxError as e:
        raise ExpressionEvaluationError(f"Syntax error in expression '{expr_str}': {e}") from e

    return _eval_node(parsed.body, context)


def _eval_node(node: ast.AST, context: dict[str, Any]) -> Any:
    if isinstance(node, ast.Constant):
        return node.value

    if isinstance(node, ast.Name):
        if node.id in context:
            return context[node.id]
        if node.id in SAFE_GLOBALS:
            return SAFE_GLOBALS[node.id]
        if node.id in ("True", "true"):
            return True
        if node.id in ("False", "false"):
            return False
        if node.id in ("None", "null"):
            return None
        # Return None or raise if missing
        return None

    if isinstance(node, ast.BoolOp):
        if isinstance(node.op, ast.And):
            for val in node.values:
                if not _eval_node(val, context):
                    return False
            return True
        if isinstance(node.op, ast.Or):
            for val in node.values:
                if _eval_node(val, context):
                    return True
            return False

    if isinstance(node, ast.BinOp):
        bin_op_type = type(node.op)
        if bin_op_type not in SAFE_BIN_OPS:
            raise ExpressionSecurityError(f"Forbidden binary operator: {bin_op_type.__name__}")
        left = _eval_node(node.left, context)
        right = _eval_node(node.right, context)
        return SAFE_BIN_OPS[bin_op_type](left, right)

    if isinstance(node, ast.UnaryOp):
        unary_op_type = type(node.op)
        if unary_op_type not in SAFE_UNARY_OPS:
            raise ExpressionSecurityError(f"Forbidden unary operator: {unary_op_type.__name__}")
        operand = _eval_node(node.operand, context)
        return SAFE_UNARY_OPS[unary_op_type](operand)

    if isinstance(node, ast.Compare):
        left = _eval_node(node.left, context)
        for op, comparator in zip(node.ops, node.comparators, strict=False):
            cmp_op_type = type(op)
            if cmp_op_type not in SAFE_COMPARE_OPS:
                raise ExpressionSecurityError(
                    f"Forbidden comparison operator: {cmp_op_type.__name__}"
                )
            right = _eval_node(comparator, context)
            if left is None or right is None:
                # Handle None comparisons safely
                if cmp_op_type is ast.Eq:
                    if left != right:
                        return False
                elif cmp_op_type is ast.NotEq:
                    if left == right:
                        return False
                else:
                    return False
            elif not SAFE_COMPARE_OPS[cmp_op_type](left, right):
                return False
            left = right
        return True

    if isinstance(node, ast.Call):
        func_node = node.func
        if isinstance(func_node, ast.Name):
            func_name = func_node.id
            if func_name not in SAFE_GLOBALS:
                raise ExpressionSecurityError(f"Forbidden function call: {func_name}")
            args = [_eval_node(arg, context) for arg in node.args]
            return SAFE_GLOBALS[func_name](*args)

        if isinstance(func_node, ast.Attribute):
            if func_node.attr.startswith("__"):
                raise ExpressionSecurityError(
                    f"Forbidden access to private/dunder method '{func_node.attr}'"
                )
            method_name = func_node.attr
            if method_name not in SAFE_STRING_METHODS:
                raise ExpressionSecurityError(f"Forbidden method call: {method_name}")
            target = _eval_node(func_node.value, context)
            args = [_eval_node(arg, context) for arg in node.args]
            if target is None:
                return False
            method = getattr(target, method_name, None)
            if method is None:
                return False
            return method(*args)

        raise ExpressionSecurityError(f"Forbidden function call format: {ast.dump(func_node)}")

    if isinstance(node, ast.Attribute):
        if node.attr.startswith("__"):
            raise ExpressionSecurityError(
                f"Forbidden access to private/dunder attribute '{node.attr}'"
            )
        target = _eval_node(node.value, context)
        if target is None:
            return None
        if isinstance(target, dict):
            return target.get(node.attr)
        return getattr(target, node.attr, None)

    if isinstance(node, ast.List):
        return [_eval_node(elt, context) for elt in node.elts]

    raise ExpressionSecurityError(f"Forbidden AST node type in expression: {type(node).__name__}")
