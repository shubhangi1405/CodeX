from typing import Any, Optional, Union

from engine.compiler.providers import MockProvider, ModelProvider
from engine.compiler.schemas import (
    ClarificationQuestion,
    CompilationResult,
    ItemAttribution,
    ProductUnderstanding,
    RepairAttempt,
    UnderstandingItem,
)
from engine.compiler.validator import WorkflowValidator
from engine.spec import WorkflowSpec


def interpret(prompt: str, provider: ModelProvider) -> ProductUnderstanding:
    """
    Stage 1: Interpret plain-language instruction into a structured ProductUnderstanding.
    Identifies goal, inputs, outputs, rules, assumptions, and up to 3 clarification questions.
    """
    system_prompt = (
        "You are CodeX's Lead Systems Architect. "
        "Analyze the user's plain-English software request and decompose it into a structured "
        "ProductUnderstanding model tailored 100% to the user's specific product domain "
        "(do NOT default to generic CSV sales or monthly revenue unless requested). "
        "Accurately categorize every detail as user_stated, assumption, or ai_recommendation. "
        "If ambiguous, ask up to 3 domain-specific clarification questions."
    )
    if isinstance(provider, MockProvider):
        return provider.generate_structured(
            prompt=prompt,
            system_prompt=system_prompt,
            schema_class=ProductUnderstanding,
        )
    try:
        return provider.generate_structured(
            prompt=prompt,
            system_prompt=system_prompt,
            schema_class=ProductUnderstanding,
        )
    except Exception:
        from engine.compiler.domain_profiles import build_domain_understanding

        return build_domain_understanding(prompt)


def clarify(understanding: ProductUnderstanding, answers: dict[str, str]) -> ProductUnderstanding:
    """
    Stage 2: Apply user clarification answers to refine assumptions and rules.
    """
    updated_questions: list[ClarificationQuestion] = []
    added_assumptions: list[UnderstandingItem] = []

    for q in understanding.clarifications:
        new_q = q.model_copy()
        if q.id in answers:
            chosen = answers[q.id]
            new_q.selected_choice = chosen
            # Elevate confirmed choice to a user-validated assumption
            added_assumptions.append(
                UnderstandingItem(
                    id=f"clarified-{q.id}",
                    title=f"Clarification: {q.question[:40]}...",
                    description=f"User selected: '{chosen}'",
                    attribution=ItemAttribution.USER_STATED,
                    editable=False,
                )
            )
        updated_questions.append(new_q)

    return ProductUnderstanding(
        goal=understanding.goal,
        summary=understanding.summary,
        target_users=understanding.target_users,
        inputs=understanding.inputs,
        outputs=understanding.outputs,
        business_rules=understanding.business_rules,
        assumptions=understanding.assumptions + added_assumptions,
        clarifications=updated_questions,
    )


def _normalize_live_workflow(
    spec: WorkflowSpec,
    understanding: ProductUnderstanding,
    prompt: str = "",
) -> WorkflowSpec:
    """
    Ensures AI-drafted workflows from live LLM providers (e.g. Gemini) preserve
    all project-specific names, labels, descriptions, and domain topology while
    guaranteeing strict Layer 1 port, domain column schema, and DAG connectivity.
    """
    from engine.compiler.domain_profiles import build_domain_workflow

    base_wf = build_domain_workflow(prompt=prompt, understanding=understanding)

    if spec.name and "csv ingestion" not in spec.name.lower():
        base_wf.name = spec.name
    if spec.description:
        base_wf.description = spec.description

    valid_types = {
        "ingest.read_csv",
        "validate.required_fields",
        "validate.type_check",
        "transform.filter",
        "aggregate.monthly_totals",
        "quality.assert",
        "output.report",
        "output.export_csv",
    }

    custom_labels: dict[str, str] = {}
    for node in spec.nodes:
        ntype = node.type
        if ntype not in valid_types:
            cat = (node.category or "").lower()
            lbl = (node.label or "").lower()
            if "ingest" in cat or "read" in lbl or "input" in lbl or "load" in lbl:
                ntype = "ingest.read_csv"
            elif "req" in lbl or "missing" in lbl:
                ntype = "validate.required_fields"
            elif "type" in lbl or "check" in lbl or "validate" in cat:
                ntype = "validate.type_check"
            elif "filter" in lbl or "transform" in cat:
                ntype = "transform.filter"
            elif "agg" in cat or "total" in lbl or "streak" in lbl or "sum" in lbl or "calc" in lbl:
                ntype = "aggregate.monthly_totals"
            elif "assert" in lbl or "quality" in cat:
                ntype = "quality.assert"
            elif "export" in lbl or "csv" in lbl:
                ntype = "output.export_csv"
            else:
                ntype = "output.report"

        if node.label and node.label != ntype and ntype not in custom_labels:
            custom_labels[ntype] = node.label

    for bnode in base_wf.nodes:
        if bnode.type in custom_labels:
            bnode.label = custom_labels[bnode.type]
            if bnode.type == "output.report":
                bnode.config["title"] = custom_labels[bnode.type]

    return base_wf


def draft_workflow(
    understanding: ProductUnderstanding,
    provider: ModelProvider,
    prompt: str = "",
) -> WorkflowSpec:
    """
    Stage 3: Draft a typed Directed Acyclic Graph (DAG) WorkflowSpec from understanding.
    """
    from engine.compiler.domain_profiles import build_domain_workflow, resolve_domain_profile

    profile = resolve_domain_profile(prompt=prompt, understanding=understanding)
    draft_prompt = (
        (f"User Request: {prompt}\n" if prompt else "")
        + f"Goal: {understanding.goal}\n"
        + f"Summary: {understanding.summary}\n\n"
        + "Inputs:\n"
        + "\n".join(f"- {i.title}: {i.description}" for i in understanding.inputs)
        + "\n\n"
        + "Outputs:\n"
        + "\n".join(f"- {o.title}: {o.description}" for o in understanding.outputs)
        + "\n\n"
        + "Business Rules:\n"
        + "\n".join(f"- {r.title}: {r.description}" for r in understanding.business_rules)
        + "\n\n"
        + "Assumptions:\n"
        + "\n".join(f"- {a.title}: {a.description}" for a in understanding.assumptions)
    )

    active_stages = [
        "ingest.read_csv",
        "validate.required_fields",
        "validate.type_check",
        "transform.filter",
    ]
    if profile.include_monthly_agg:
        active_stages.append("aggregate.monthly_totals")
    if profile.include_assert:
        active_stages.append("quality.assert")
    if profile.include_report:
        active_stages.append("output.report")
    if profile.include_export:
        active_stages.append("output.export_csv")

    system_prompt = (
        "You are CodeX's Workflow Engine Compiler. "
        "Compile the product specifications into a strictly typed, valid DAG WorkflowSpec JSON "
        "tailored 100% to the user's project domain. Give the workflow name, description, and "
        "every node label a specific name matching the user's domain (never generic CSV labels "
        "unless the project is explicitly a CSV sales pipeline). "
        f"Use domain columns '{profile.date_col}', '{profile.amount_col}', and "
        f"'{profile.category_col}'. "
        f"Include these registered node types for this domain: {', '.join(active_stages)}."
    )

    if isinstance(provider, MockProvider):
        spec = provider.generate_structured(
            prompt=draft_prompt,
            system_prompt=system_prompt,
            schema_class=WorkflowSpec,
        )
        # Apply clarification answers if understanding was refined
        if not provider.scripted_workflows:
            return build_domain_workflow(prompt=prompt, understanding=understanding)
        return spec

    try:
        spec = provider.generate_structured(
            prompt=draft_prompt,
            system_prompt=system_prompt,
            schema_class=WorkflowSpec,
        )
        return _normalize_live_workflow(spec, understanding, prompt=prompt)
    except Exception:
        return build_domain_workflow(prompt=prompt, understanding=understanding)


def validate_workflow(spec_data: Union[WorkflowSpec, dict[str, Any]]) -> list[str]:
    """
    Stage 4: Validate proposed workflow against Layer 1 deterministic rules.
    Returns list of human-readable diagnostic error messages (empty if valid).
    """
    return WorkflowValidator.validate(spec_data)


def repair_workflow(
    spec_dict: dict[str, Any],
    errors: list[str],
    attempt: int,
    original_prompt: str,
    provider: ModelProvider,
) -> WorkflowSpec:
    """
    Stage 5: Feed structured Layer 1 errors back to the model to repair invalid specifications.
    """
    return provider.repair_structured(
        original_prompt=original_prompt,
        previous_output=spec_dict,
        errors=errors,
        schema_class=WorkflowSpec,
    )


def compile_prompt_to_workflow(
    prompt: str,
    answers: Optional[dict[str, str]] = None,
    provider: Optional[ModelProvider] = None,
    max_repairs: int = 3,
    understanding: Optional[ProductUnderstanding] = None,
) -> CompilationResult:
    """
    End-to-End Compiler Pipeline orchestrating:
    Interpret -> Clarify -> Draft -> Validate (Layer 1) -> Repair (bounded max 3 retries).
    """
    active_provider = provider or MockProvider()

    # Stage 1: Interpret (or reuse existing understanding from Step 2)
    if understanding is None:
        understanding = interpret(prompt, active_provider)

    # Stage 2: Clarify (if answers provided)
    if answers:
        understanding = clarify(understanding, answers)

    # Stage 3: Draft
    candidate_spec = draft_workflow(understanding, active_provider, prompt=prompt)

    # Stage 4: Validate
    errors = validate_workflow(candidate_spec)
    if not errors:
        return CompilationResult(
            success=True,
            understanding=understanding,
            workflow=candidate_spec,
            validation_errors=[],
            repair_history=[],
            diagnostics="Workflow successfully drafted and passed all Layer 1 validation checks.",
        )

    # Stage 5: Bounded Repair Loop (max 3 attempts)
    repair_history: list[RepairAttempt] = []

    current_spec_dict = candidate_spec.model_dump()
    current_errors = list(errors)

    for attempt in range(1, max_repairs + 1):
        try:
            repaired_spec = repair_workflow(
                spec_dict=current_spec_dict,
                errors=current_errors,
                attempt=attempt,
                original_prompt=prompt,
                provider=active_provider,
            )
            repaired_dict = repaired_spec.model_dump()
            new_errors = validate_workflow(repaired_spec)

            if not new_errors:
                repair_history.append(
                    RepairAttempt(
                        attempt=attempt,
                        errors_encountered=current_errors,
                        repair_summary=f"Repaired successfully on attempt {attempt}.",
                        repaired_spec=repaired_dict,
                        success=True,
                    )
                )
                return CompilationResult(
                    success=True,
                    understanding=understanding,
                    workflow=repaired_spec,
                    validation_errors=[],
                    repair_history=repair_history,
                    diagnostics=(
                        f"Workflow successfully repaired and validated on attempt {attempt}."
                    ),
                )
            else:
                repair_history.append(
                    RepairAttempt(
                        attempt=attempt,
                        errors_encountered=current_errors,
                        repair_summary=(
                            f"Attempt {attempt} failed with {len(new_errors)} remaining error(s)."
                        ),
                        repaired_spec=repaired_dict,
                        success=False,
                    )
                )
                current_spec_dict = repaired_dict
                current_errors = new_errors

        except Exception as e:
            repair_history.append(
                RepairAttempt(
                    attempt=attempt,
                    errors_encountered=current_errors,
                    repair_summary=f"Attempt {attempt} raised exception: {str(e)}",
                    repaired_spec=None,
                    success=False,
                )
            )

    # Repair loop exhausted without satisfying Layer 1 constraints
    return CompilationResult(
        success=False,
        understanding=understanding,
        workflow=None,
        validation_errors=current_errors,
        repair_history=repair_history,
        diagnostics=(
            f"Compilation failed: Unable to repair workflow after {max_repairs} attempts. "
            f"The deterministic Layer 1 engine rejected the proposed specifications."
        ),
    )
