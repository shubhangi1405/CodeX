from typing import Any, Union

from pydantic import ValidationError

# Ensure all nodes are registered in the registry
import engine.nodes  # noqa: F401
from engine.registry import NodeRegistry
from engine.spec import WorkflowSpec


class WorkflowValidator:
    """
    Layer 1 Deterministic Validator.
    Enforces that any proposed workflow satisfies:
    1. WorkflowSpec JSON schema and field constraints.
    2. Directed Acyclic Graph (DAG) with zero cycles or self-loops.
    3. All node types exist in the NodeRegistry.
    4. All node configurations satisfy the registered node's Pydantic schema.
    5. All edges connect valid ports with matching, compatible data types.
    6. No isolated or unreachable nodes exist in the workflow.
    """

    @classmethod
    def validate(cls, spec_data: Union[WorkflowSpec, dict[str, Any]]) -> list[str]:
        errors: list[str] = []

        # 1. Schema Validation
        spec: WorkflowSpec
        if isinstance(spec_data, WorkflowSpec):
            spec = spec_data
        else:
            try:
                spec = WorkflowSpec.model_validate(spec_data)
            except ValidationError as e:
                for err in e.errors():
                    loc = " -> ".join(str(p) for p in err.get("loc", []))
                    errors.append(f"Schema violation at '{loc}': {err.get('msg')}")
                return errors

        # 2. DAG Topology & Cycle Check
        try:
            spec.validate_dag()
        except ValueError as e:
            errors.append(str(e))

        # Build node map
        node_map = {n.id: n for n in spec.nodes}

        # 3 & 4. Node Registry & Configuration Check
        for node in spec.nodes:
            try:
                node_cls = NodeRegistry.get(node.type)
            except KeyError:
                available = ", ".join(NodeRegistry.all_types())
                errors.append(
                    f"Node '{node.id}' uses unknown type '{node.type}'. "
                    f"Registered types: {available}."
                )
                continue

            # Validate configuration against node's Pydantic model
            try:
                node_cls.config_schema.model_validate(node.config)
            except ValidationError as e:
                for err in e.errors():
                    field_name = ".".join(str(p) for p in err.get("loc", []))
                    errors.append(
                        f"Node '{node.id}' ({node.type}) config error for '{field_name}': "
                        f"{err.get('msg')}."
                    )

        # 5. Port Matching & Compatibility Check
        for edge in spec.edges:
            src_node = node_map.get(edge.from_node)
            dst_node = node_map.get(edge.to_node)
            if not src_node or not dst_node:
                continue  # Handled by validate_dag

            # Match output port on source node
            src_ports = {p.name: p for p in src_node.output_ports}
            if not src_ports:
                # Fallback to registered class definition if node ports not explicitly in spec
                try:
                    src_cls = NodeRegistry.get(src_node.type)
                    src_ports = {p.name: p for p in src_cls.output_ports}
                except KeyError:
                    pass

            src_port = src_ports.get(edge.from_port)
            if not src_port:
                errors.append(
                    f"Edge '{edge.id}': source node '{src_node.id}' has no "
                    f"output port '{edge.from_port}'."
                )

            # Match input port on target node
            dst_ports = {p.name: p for p in dst_node.input_ports}
            if not dst_ports:
                try:
                    dst_cls = NodeRegistry.get(dst_node.type)
                    dst_ports = {p.name: p for p in dst_cls.input_ports}
                except KeyError:
                    pass

            dst_port = dst_ports.get(edge.to_port)
            if not dst_port:
                errors.append(
                    f"Edge '{edge.id}': target node '{dst_node.id}' has no "
                    f"input port '{edge.to_port}'."
                )

            # Check type compatibility
            if src_port and dst_port:
                if (
                    src_port.data_type != dst_port.data_type
                    and src_port.data_type != "any"
                    and dst_port.data_type != "any"
                ):
                    errors.append(
                        f"Edge '{edge.id}': type mismatch. Source "
                        f"'{edge.from_node}.{edge.from_port}' ({src_port.data_type}) -> "
                        f"target '{edge.to_node}.{edge.to_port}' ({dst_port.data_type})."
                    )

        # 6. Graph Connectivity & Reachability Check
        if len(spec.nodes) > 1:
            edge_connected_nodes = set()
            for edge in spec.edges:
                edge_connected_nodes.add(edge.from_node)
                edge_connected_nodes.add(edge.to_node)

            for node in spec.nodes:
                if node.id not in edge_connected_nodes:
                    errors.append(
                        f"Unreachable/disconnected node '{node.id}' ({node.label}) "
                        f"has no incoming or outgoing connections."
                    )

        return errors
