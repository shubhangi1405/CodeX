"""
Domain-adaptive workflow and understanding synthesis profiles for CodeX.
Ensures every user problem compiles into a domain-authentic ProductUnderstanding
and a distinct, valid WorkflowSpec DAG (varying node counts, node selections,
branching topologies, trigger configs, and domain column schemas).
"""

import re
from dataclasses import dataclass
from typing import Any, Optional

from engine.compiler.schemas import (
    ClarificationQuestion,
    ItemAttribution,
    ProductUnderstanding,
    UnderstandingItem,
)
from engine.spec import EdgeSpec, NodeSpec, TriggerSpec, WorkflowSpec
from engine.types import DataType, Port


@dataclass
class DomainWorkflowProfile:
    domain_key: str
    wf_id: str
    wf_name: str
    wf_description: str
    goal: str
    summary: str
    target_users: list[str]
    trigger_type: str
    trigger_config: dict[str, Any]
    date_col: str
    amount_col: str
    category_col: str
    sample_categories: tuple[str, str, str]
    sample_amounts: tuple[float, float, float, float, float, float, float]
    sample_filename: str
    include_monthly_agg: bool
    include_assert: bool
    include_report: bool
    include_export: bool
    branch_export_from_filter: bool
    lbl_read: str
    lbl_req: str
    lbl_types: str
    lbl_filter: str
    lbl_agg: str
    lbl_assert: str
    lbl_report: str
    lbl_export: str
    report_title: str
    chart_type: str
    export_filename: str
    input_title: str
    input_desc: str
    rule_validate_title: str
    rule_validate_desc: str
    rule_Secondary_title: str
    rule_Secondary_desc: str
    cq_error_question: str
    cq_metric_question: str
    cq_metric_options: list[str]

    @property
    def domain_id(self) -> str:
        return self.domain_key


def _extract_subject_words(text: str) -> tuple[str, str]:
    """Extracts a clean human-readable title and snake_case noun prefix from a user prompt."""
    cleaned = re.sub(
        r"^(please\s+)?(build|create|make|design|develop|generate|i\s+want|i\s+need|we\s+need)\s+(a|an|the|me\s+a)?\s*",
        "",
        text.strip(),
        flags=re.IGNORECASE,
    )
    first_clause = re.split(r"[.!?;,\n]", cleaned)[0].strip()
    words = [w for w in re.findall(r"[A-Za-z0-9]+", first_clause) if len(w) > 1]
    if not words:
        return ("Custom Application", "record")

    title_words = words[:5]
    subject_title = " ".join(w.capitalize() if w.islower() else w for w in title_words)

    stop_words = {
        "app",
        "application",
        "system",
        "platform",
        "tool",
        "portal",
        "dashboard",
        "tracker",
        "viewer",
        "finder",
        "manager",
        "for",
        "with",
        "and",
        "the",
        "daily",
        "simple",
        "smart",
        "modern",
    }
    domain_nouns = [w.lower() for w in words if w.lower() not in stop_words]
    primary_noun = domain_nouns[0] if domain_nouns else words[0].lower()
    primary_noun = re.sub(r"[^a-z0-9]", "", primary_noun)[:16] or "record"
    return (subject_title, primary_noun)


def resolve_domain_profile(
    prompt: str = "",
    understanding: Optional[ProductUnderstanding] = None,
) -> DomainWorkflowProfile:
    """
    Deterministically resolves a DomainWorkflowProfile from the user's prompt
    and/or ProductUnderstanding. Covers canonical benchmarks plus dynamic
    synthesis for arbitrary custom prompts.
    """
    combined = prompt
    if understanding:
        combined = f"{prompt} {understanding.goal} {understanding.summary}".strip()
    p_lower = combined.lower()

    # 1. Explicit canonical CSV / Monthly Sales pipeline (only when CSV or
    # monthly sales is requested)
    is_explicit_csv_sales = any(
        k in p_lower for k in ("monthly sales", "monthly totals", "validate csv", "new csv arrives")
    ) or (
        "csv" in p_lower
        and not any(
            k in p_lower
            for k in (
                "habit",
                "court",
                "security",
                "siem",
                "hackathon",
                "clinic",
                "patient",
                "restaurant",
                "pantry",
                "invoice",
            )
        )
    )
    if is_explicit_csv_sales or not combined.strip():
        return DomainWorkflowProfile(
            domain_key="csv_monthly_totals",
            wf_id="wf-canonical-csv",
            wf_name="CSV Ingestion, Validation & Monthly Totals",
            wf_description="Production workflow compiled from plain-English requirements.",
            goal=(
                "Automate ingestion, data validation, monthly totals calculation, "
                "and report generation from CSV files."
            ),
            summary=(
                "A deterministic data pipeline that watches or receives CSV uploads, "
                "inspects missing required fields, normalizes column data, groups sales "
                "totals by month, and exports interactive report charts."
            ),
            target_users=["Operations Analyst", "Finance Lead", "Data Operations Manager"],
            trigger_type="manual_upload",
            trigger_config={"accepted_extensions": [".csv"]},
            date_col="date",
            amount_col="amount",
            category_col="category",
            sample_categories=("Software", "Hardware", "Services"),
            sample_amounts=(1200.0, 350.5, 890.0, 2100.0, 450.0, 1500.0, 780.25),
            sample_filename="monthly_sales.csv",
            include_monthly_agg=True,
            include_assert=True,
            include_report=True,
            include_export=True,
            branch_export_from_filter=False,
            lbl_read="Read CSV File",
            lbl_req="Validate Required Fields",
            lbl_types="Coerce & Check Types",
            lbl_filter="Filter Positive Amounts",
            lbl_agg="Calculate Monthly Totals",
            lbl_assert="Assert Rows Exist",
            lbl_report="Generate Monthly Report",
            lbl_export="Export Totals CSV",
            report_title="Monthly Revenue Report",
            chart_type="bar",
            export_filename="monthly_totals.csv",
            input_title="CSV File Source",
            input_desc=(
                "Incoming comma-separated values file containing monthly transactional records."
            ),
            rule_validate_title="Record Validation",
            rule_validate_desc=(
                "Verify that required fields ('date', 'amount') exist and conform to schema."
            ),
            rule_Secondary_title="Monthly Totals Aggregation",
            rule_Secondary_desc="Group transactions by month (YYYY-MM) and sum amounts.",
            cq_error_question="How should corrupt or incomplete records be handled?",
            cq_metric_question="What column represents the monetary amount?",
            cq_metric_options=["amount", "total_price", "value"],
        )

    # 2. Daily Habit / Streak / Ritual / Fitness Tracker
    if any(
        k in p_lower
        for k in (
            "habit",
            "streak",
            "routine",
            "ritual",
            "fitness",
            "workout",
            "meditation",
            "wellness",
        )
    ):
        return DomainWorkflowProfile(
            domain_key="daily_habit_tracker",
            wf_id="wf-habit-streak-tracker",
            wf_name="Habit Tracker & Streak Consistency Engine",
            wf_description=(
                "Ingests daily habit check-ins, validates completion timestamps and streak points, "
                "filters active rituals, and generates a habit consistency dashboard."
            ),
            goal=(
                "Track daily habit completions, calculate active streaks, "
                "and visualize consistency trends."
            ),
            summary=(
                "A deterministic habit tracking engine that logs daily check-ins, "
                "validates completion timestamps and streak points, filters missed logs, "
                "and renders interactive habit streak and momentum reports."
            ),
            target_users=[
                "Habit Tracker User",
                "Personal Productivity Coach",
                "Wellness Enthusiast",
            ],
            trigger_type="daily_checkin_sync",
            trigger_config={"cadence": "daily", "source": "habit_checkin_form"},
            date_col="checkin_date",
            amount_col="streak_points",
            category_col="habit_name",
            sample_categories=("Morning Meditation", "30m Deep Reading", "Strength Workout"),
            sample_amounts=(100.0, 60.0, 90.0, 120.0, 75.0, 110.0, 85.0),
            sample_filename="habit_checkins.csv",
            include_monthly_agg=True,
            include_assert=True,
            include_report=True,
            include_export=False,
            branch_export_from_filter=False,
            lbl_read="Ingest Daily Habit Check-Ins",
            lbl_req="Validate Habit & Check-In Date",
            lbl_types="Normalize Streak Points & Dates",
            lbl_filter="Filter Completed Daily Rituals",
            lbl_agg="Compute Habit Streak & Consistency",
            lbl_assert="Assert Active Streak Continuity",
            lbl_report="Habit Streak & Momentum Dashboard",
            lbl_export="Export Verified Habit History",
            report_title="Habit Streak & Consistency Report",
            chart_type="line",
            export_filename="habit_streak_summary.csv",
            input_title="Daily Habit Check-In Entries",
            input_desc=(
                "Daily ritual check-ins containing habit_name, checkin_date, and streak_points."
            ),
            rule_validate_title="Habit Check-In Validation",
            rule_validate_desc=(
                "Ensure every logged habit entry has a valid checkin_date and "
                "positive streak_points."
            ),
            rule_Secondary_title="Streak & Consistency Rollup",
            rule_Secondary_desc=(
                "Calculate active streak momentum and completion consistency across rituals."
            ),
            cq_error_question="How should incomplete or missed habit check-in entries be handled?",
            cq_metric_question="How should daily habit progress be measured?",
            cq_metric_options=["streak_points", "duration_minutes", "binary_completion"],
        )

    # 3. Security Event Log Viewer / SIEM / SOC Telemetry
    if any(
        k in p_lower
        for k in (
            "security",
            "siem",
            "log viewer",
            "event log",
            "soc",
            "telemetry",
            "intrusion",
            "audit log",
        )
    ):
        return DomainWorkflowProfile(
            domain_key="security_event_log_viewer",
            wf_id="wf-security-siem-triage",
            wf_name="SIEM Security Event Triage & Anomaly Pipeline",
            wf_description=(
                "Ingests security telemetry streams, validates source "
                "timestamps and severity scores, "
                "isolates high-severity threat events, and dispatches SOC "
                "triage feeds and forensic IOC logs."
            ),
            goal=(
                "Ingest security event telemetry, filter high-severity anomalies, "
                "and surface real-time SOC incident triage feeds."
            ),
            summary=(
                "A high-density security event pipeline that parses telemetry logs, verifies "
                "UTC timestamps and severity scores, filters active threat indicators, and outputs "
                "both an interactive SOC incident stream and a forensic IOC export."
            ),
            target_users=["SOC Tier-2 Analyst", "Incident Responder", "Security Engineer"],
            trigger_type="siem_telemetry_stream",
            trigger_config={"protocol": "syslog_structured", "severity_floor": 1},
            date_col="event_timestamp",
            amount_col="severity_score",
            category_col="event_type",
            sample_categories=("SSH Brute Force", "IAM Privilege Escalation", "TLS Cert Anomaly"),
            sample_amounts=(85.0, 95.0, 40.0, 90.0, 65.0, 88.0, 72.0),
            sample_filename="siem_security_events.csv",
            include_monthly_agg=False,
            include_assert=True,
            include_report=True,
            include_export=True,
            branch_export_from_filter=True,
            lbl_read="Ingest SIEM Telemetry Stream",
            lbl_req="Validate Timestamp & Severity Fields",
            lbl_types="Verify UTC Timestamp & Severity Score",
            lbl_filter="Filter High-Severity Threat Events",
            lbl_agg="Aggregate Threat Severity Windows",
            lbl_assert="Assert Threat Stream Integrity",
            lbl_report="SOC Incident & Threat Triage Feed",
            lbl_export="Export Forensic IOC Audit Log",
            report_title="SOC Security Event Triage Stream",
            chart_type="area",
            export_filename="soc_ioc_forensics.csv",
            input_title="SIEM Security Telemetry Stream",
            input_desc=(
                "Structured security event logs with event_timestamp, "
                "severity_score, and event_type."
            ),
            rule_validate_title="Telemetry Schema Enforcement",
            rule_validate_desc=(
                "Reject malformed packets missing event_timestamp or numeric severity_score."
            ),
            rule_Secondary_title="High-Severity Anomaly Isolation",
            rule_Secondary_desc=(
                "Filter active threat events (severity_score > 0) and branch "
                "to forensic IOC archive."
            ),
            cq_error_question="How should malformed or truncated telemetry packets be handled?",
            cq_metric_question="Which numeric field represents threat priority?",
            cq_metric_options=["severity_score", "risk_index", "cvss_score"],
        )

    # 4. Sports Court / Venue / Facility Booking Scheduler
    if any(
        k in p_lower
        for k in (
            "court",
            "tennis",
            "pickleball",
            "padel",
            "sports",
            "venue",
            "room booking",
            "reservation",
        )
    ):
        return DomainWorkflowProfile(
            domain_key="sports_court_booking",
            wf_id="wf-court-booking-scheduler",
            wf_name="Sports Court Slot Reservation & Conflict Guard",
            wf_description=(
                "Validates court reservation requests, checks slot dates and court fees, "
                "prevents double-booked time slots, and updates the live court availability board."
            ),
            goal=(
                "Manage sports court reservations, enforce slot conflict rules, "
                "and publish live court availability schedules."
            ),
            summary=(
                "A reservation scheduling workflow that validates player booking requests, "
                "verifies court slot dates and reservation fees, filters available slots, "
                "asserts zero double-bookings, and renders the court schedule matrix."
            ),
            target_users=["Club Member", "Court Facility Coordinator", "Athletic Director"],
            trigger_type="reservation_request",
            trigger_config={"slot_duration_mins": 60, "conflict_guard": True},
            date_col="slot_date",
            amount_col="court_fee",
            category_col="court_name",
            sample_categories=(
                "Court 1 - Stadium Hard",
                "Court 2 - Indoor Clay",
                "Court 3 - Padel Glass",
            ),
            sample_amounts=(45.0, 60.0, 50.0, 45.0, 75.0, 60.0, 50.0),
            sample_filename="court_reservations.csv",
            include_monthly_agg=False,
            include_assert=True,
            include_report=True,
            include_export=False,
            branch_export_from_filter=False,
            lbl_read="Ingest Court Reservation Requests",
            lbl_req="Validate Court, Player & Slot Date",
            lbl_types="Verify Slot Date & Court Fee",
            lbl_filter="Filter Confirmed Available Slots",
            lbl_agg="Calculate Court Utilization Totals",
            lbl_assert="Assert Zero Slot Double-Booking",
            lbl_report="Court Availability & Schedule Board",
            lbl_export="Export Confirmed Court Schedule",
            report_title="Live Court Availability & Utilization Board",
            chart_type="bar",
            export_filename="confirmed_court_schedule.csv",
            input_title="Court Slot Reservation Requests",
            input_desc=(
                "Incoming booking requests with slot_date, court_name, player info, and court_fee."
            ),
            rule_validate_title="Reservation Slot Validation",
            rule_validate_desc=(
                "Ensure every booking specifies a valid slot_date and positive court_fee."
            ),
            rule_Secondary_title="Double-Booking Conflict Guard",
            rule_Secondary_desc=(
                "Filter out cancelled slots and assert zero overlapping reservations."
            ),
            cq_error_question=(
                "How should conflicting or incomplete reservation requests be handled?"
            ),
            cq_metric_question="Which numeric field should be tracked per court slot?",
            cq_metric_options=["court_fee", "slot_duration_mins", "player_count"],
        )

    # 5. Hackathon Team Finder / Student Squad Directory
    if any(
        k in p_lower
        for k in ("hackathon", "team finder", "squad", "teammate", "co-founder", "cofounder")
    ):
        return DomainWorkflowProfile(
            domain_key="hackathon_team_finder",
            wf_id="wf-hackathon-team-matcher",
            wf_name="Hackathon Squad Formation & Skill Matching Pipeline",
            wf_description=(
                "Ingests student builder profiles and squad pitches, validates project tracks "
                "and open role counts, filters teams actively recruiting, and "
                "builds the match directory."
            ),
            goal=(
                "Match hackathon participants with open student squads based on project track, "
                "role capacity, and complementary technical skills."
            ),
            summary=(
                "A community matching workflow that ingests squad listings, verifies creation "
                "dates and open role capacity, filters squads with available spots, and publishes "
                "an interactive hackathon team discovery board."
            ),
            target_users=["Student Hacker", "Squad Lead", "Hackathon Organizer"],
            trigger_type="squad_listing_post",
            trigger_config={"max_team_size": 4, "matching_mode": "skill_complement"},
            date_col="created_date",
            amount_col="open_spots",
            category_col="project_track",
            sample_categories=("AI Agents Track", "Climate & Hardware", "Zero-Knowledge Web3"),
            sample_amounts=(2.0, 3.0, 1.0, 2.0, 1.0, 3.0, 2.0),
            sample_filename="hackathon_squads.csv",
            include_monthly_agg=False,
            include_assert=True,
            include_report=True,
            include_export=False,
            branch_export_from_filter=True,
            lbl_read="Load Student Profiles & Squad Posts",
            lbl_req="Validate Squad Date & Open Spots",
            lbl_types="Verify Open Role Capacity & Dates",
            lbl_filter="Filter Squads Accepting New Members",
            lbl_agg="Aggregate Squad Capacity by Track",
            lbl_assert="Assert Eligible Match Candidates",
            lbl_report="Hackathon Squad & Skill Match Board",
            lbl_export="Export Matched Roster Directory",
            report_title="Hackathon Squad & Role Discovery Directory",
            chart_type="bar",
            export_filename="hackathon_team_directory.csv",
            input_title="Student Builder Profiles & Squad Listings",
            input_desc=(
                "Submitted team pitches containing created_date, project_track, and open_spots."
            ),
            rule_validate_title="Squad Listing Completeness",
            rule_validate_desc=(
                "Ensure every squad listing specifies created_date and numeric open_spots."
            ),
            rule_Secondary_title="Open Role Capacity Filter",
            rule_Secondary_desc=(
                "Surface only squads that currently have open_spots > 0 for recruiting."
            ),
            cq_error_question=(
                "How should full squads or incomplete participant profiles be handled?"
            ),
            cq_metric_question="Which numeric metric determines squad availability?",
            cq_metric_options=["open_spots", "compatibility_score", "team_size"],
        )

    # 6. Restaurant / Kitchen / Warehouse Inventory & Stock
    if any(
        k in p_lower
        for k in (
            "restaurant",
            "inventory",
            "pantry",
            "larder",
            "kitchen",
            "stock",
            "warehouse",
            "sku",
        )
    ):
        return DomainWorkflowProfile(
            domain_key="restaurant_inventory",
            wf_id="wf-inventory-par-monitor",
            wf_name="Kitchen Par-Level & Stock Depletion Pipeline",
            wf_description=(
                "Ingests station stock counts, validates SKU audit dates and quantities, "
                "aggregates par-level usage, and generates reorder reports and purchase orders."
            ),
            goal=(
                "Track ingredient and SKU stock quantities against par levels, "
                "flag low-stock stations, and generate supplier restock orders."
            ),
            summary=(
                "An inventory control pipeline that ingests station count sheets, verifies "
                "audit dates and unit quantities, rolls up monthly depletion by station, and "
                "outputs both a par-level dashboard and a supplier purchase order CSV."
            ),
            target_users=["Executive Chef", "Kitchen Inventory Lead", "Purchasing Manager"],
            trigger_type="station_count_sync",
            trigger_config={"par_alert_mode": "immediate", "unit_check": True},
            date_col="audit_date",
            amount_col="stock_qty",
            category_col="station_category",
            sample_categories=("Walk-In Cooler", "Dry Larder", "Pastry Station"),
            sample_amounts=(24.0, 15.0, 40.0, 18.0, 32.0, 12.0, 28.0),
            sample_filename="kitchen_stock_counts.csv",
            include_monthly_agg=True,
            include_assert=False,
            include_report=True,
            include_export=True,
            branch_export_from_filter=False,
            lbl_read="Ingest Pantry & Cold-Storage Counts",
            lbl_req="Validate Audit Date & Stock Quantity",
            lbl_types="Verify Unit Quantities & Audit Dates",
            lbl_filter="Filter Active In-Stock Ingredients",
            lbl_agg="Calculate Station Par & Depletion Totals",
            lbl_assert="Assert Positive Par-Level Stock",
            lbl_report="Kitchen Par-Level & Reorder Dashboard",
            lbl_export="Export Supplier Purchase Order CSV",
            report_title="Station Inventory & Par-Level Reorder Report",
            chart_type="bar",
            export_filename="supplier_purchase_order.csv",
            input_title="Station SKU & Pantry Count Sheets",
            input_desc=(
                "Inventory audit records containing audit_date, station_category, and stock_qty."
            ),
            rule_validate_title="SKU Count Verification",
            rule_validate_desc=(
                "Ensure every stock count includes a valid audit_date and non-negative stock_qty."
            ),
            rule_Secondary_title="Station Depletion & Reorder Rollup",
            rule_Secondary_desc=(
                "Aggregate stock_qty by period and station to prepare supplier restock orders."
            ),
            cq_error_question="How should uncounted SKUs or negative stock adjustments be handled?",
            cq_metric_question="Which numeric field tracks inventory level?",
            cq_metric_options=["stock_qty", "par_variance", "unit_cost"],
        )

    # 7. Clinic / Patient Appointment / Medical Triage Scheduling
    if any(
        k in p_lower
        for k in (
            "clinic",
            "patient",
            "appointment",
            "medical",
            "doctor",
            "triage",
            "hospital",
            "intake",
        )
    ):
        return DomainWorkflowProfile(
            domain_key="clinic_appointment_scheduling",
            wf_id="wf-clinic-patient-triage",
            wf_name="Clinical Patient Intake & Provider Schedule Pipeline",
            wf_description=(
                "Processes patient intake check-ins, validates appointment "
                "slots and visit durations, "
                "filters active triage queues, and updates the clinical provider schedule board."
            ),
            goal=(
                "Coordinate patient intake check-ins, validate clinician appointment slots, "
                "and monitor live triage room queues."
            ),
            summary=(
                "A clinical operations workflow that ingests patient appointment records, "
                "validates visit dates and allotted durations, filters active checked-in visits, "
                "asserts clinical queue SLA compliance, and renders the provider schedule board."
            ),
            target_users=["Front-Desk Care Coordinator", "Triage Nurse", "Attending Physician"],
            trigger_type="patient_intake_checkin",
            trigger_config={"triage_queue": True, "sla_wait_limit_mins": 20},
            date_col="visit_date",
            amount_col="duration_mins",
            category_col="clinical_dept",
            sample_categories=("Primary Care", "Cardiology Consult", "Pediatric Triage"),
            sample_amounts=(30.0, 45.0, 20.0, 60.0, 30.0, 45.0, 30.0),
            sample_filename="clinic_appointments.csv",
            include_monthly_agg=False,
            include_assert=True,
            include_report=True,
            include_export=False,
            branch_export_from_filter=False,
            lbl_read="Ingest Patient Intake & Check-Ins",
            lbl_req="Validate Visit Date & Slot Duration",
            lbl_types="Verify Appointment Date & Minutes",
            lbl_filter="Filter Active Triage & Checked-In Visits",
            lbl_agg="Aggregate Provider Utilization Hours",
            lbl_assert="Assert Clinical Queue SLA Compliance",
            lbl_report="Clinical Provider Schedule & Triage Board",
            lbl_export="Export Daily Clinical Roster",
            report_title="Clinical Provider Schedule & Triage Status",
            chart_type="bar",
            export_filename="clinical_schedule_roster.csv",
            input_title="Patient Intake & Appointment Records",
            input_desc=(
                "Clinical appointment entries with visit_date, clinical_dept, and duration_mins."
            ),
            rule_validate_title="Appointment Slot Validation",
            rule_validate_desc=(
                "Verify every patient visit has a valid visit_date and positive duration_mins."
            ),
            rule_Secondary_title="Active Triage Queue Filtering",
            rule_Secondary_desc="Filter confirmed visits and verify clinical queue SLA readiness.",
            cq_error_question=(
                "How should unconfirmed walk-ins or missing slot durations be handled?"
            ),
            cq_metric_question="Which numeric metric tracks appointment allocation?",
            cq_metric_options=["duration_mins", "triage_acuity", "copay_amount"],
        )

    # 8. Freelance Invoice / Expense / Billing / Order Ledger
    if any(
        k in p_lower
        for k in (
            "invoice",
            "freelance",
            "billing",
            "retainer",
            "receivable",
            "expense",
            "receipt",
            "order",
        )
    ):
        return DomainWorkflowProfile(
            domain_key="freelance_invoice_tracker",
            wf_id="wf-client-invoice-ledger",
            wf_name="Client Invoice & Receivables Aging Pipeline",
            wf_description=(
                "Ingests client invoices and retainer milestones, validates "
                "issue dates and invoice amounts, "
                "aggregates monthly receivables, and exports formal billing "
                "statements and tax ledgers."
            ),
            goal=(
                "Track client invoices and retainers, validate Net-15 billing terms, "
                "and generate receivables aging statements."
            ),
            summary=(
                "A financial ledger pipeline that processes client invoices, validates issue "
                "dates and monetary amounts, filters billable milestones, aggregates monthly "
                "receivables, and outputs client aging statements and tax exports."
            ),
            target_users=[
                "Independent Consultant",
                "Studio Principal",
                "Client Billing Specialist",
            ],
            trigger_type="invoice_ledger_dispatch",
            trigger_config={"payment_terms": "Net-15", "currency": "USD"},
            date_col="issue_date",
            amount_col="invoice_amount",
            category_col="billing_type",
            sample_categories=("Monthly Retainer", "Fixed Milestone", "Advisory Sprint"),
            sample_amounts=(4500.0, 2800.0, 6200.0, 3500.0, 5000.0, 4200.0, 3100.0),
            sample_filename="client_invoices.csv",
            include_monthly_agg=True,
            include_assert=True,
            include_report=True,
            include_export=True,
            branch_export_from_filter=False,
            lbl_read="Ingest Client Invoices & Retainers",
            lbl_req="Validate Issue Date & Invoice Amount",
            lbl_types="Normalize Currency & Net-15 Dates",
            lbl_filter="Filter Billable Issued Invoices",
            lbl_agg="Aggregate Monthly Receivables & Retainers",
            lbl_assert="Assert Positive Receivables Balance",
            lbl_report="Client Receivables & Aging Statement",
            lbl_export="Export Accountant Tax Ledger CSV",
            report_title="Client Receivables & Aging Statement",
            chart_type="bar",
            export_filename="client_receivables_ledger.csv",
            input_title="Client Invoice & Retainer Entries",
            input_desc="Billing records containing issue_date, billing_type, and invoice_amount.",
            rule_validate_title="Invoice Schema & Term Validation",
            rule_validate_desc=(
                "Ensure every invoice specifies a valid issue_date and positive invoice_amount."
            ),
            rule_Secondary_title="Monthly Receivables Aggregation",
            rule_Secondary_desc=(
                "Group billable invoices by month and billing_type for tax and aging statements."
            ),
            cq_error_question="How should draft invoices with missing amounts or dates be handled?",
            cq_metric_question="Which monetary field should be summed for receivables?",
            cq_metric_options=["invoice_amount", "retainer_cap", "net_balance"],
        )

    # 9. Shift / Attendance / Payroll
    if any(k in p_lower for k in ("attendance", "shift", "payroll", "timesheet", "roster")):
        return DomainWorkflowProfile(
            domain_key="shift_attendance",
            wf_id="wf-shift-attendance-payroll",
            wf_name="Shift Attendance & Payroll Hours Pipeline",
            wf_description=(
                "Validates employee shift punches, normalizes logged hours, "
                "filters completed shifts, and aggregates monthly payroll hours."
            ),
            goal="Automate shift punch validation, hours normalization, and payroll reporting.",
            summary=(
                "A workforce timekeeping pipeline that ingests shift logs, verifies shift_date "
                "and logged_hours, filters completed punches, and computes payroll summaries."
            ),
            target_users=["Payroll Officer", "Operations Manager", "Shift Supervisor"],
            trigger_type="timesheet_punch_sync",
            trigger_config={"overtime_threshold_hrs": 40},
            date_col="shift_date",
            amount_col="logged_hours",
            category_col="shift_role",
            sample_categories=("Morning Shift", "Evening Shift", "Weekend On-Call"),
            sample_amounts=(8.0, 7.5, 8.0, 9.0, 8.0, 6.5, 8.0),
            sample_filename="shift_timesheets.csv",
            include_monthly_agg=True,
            include_assert=True,
            include_report=True,
            include_export=False,
            branch_export_from_filter=False,
            lbl_read="Read Shift Punch Logs",
            lbl_req="Validate Shift Date & Logged Hours",
            lbl_types="Normalize Logged Hours & Dates",
            lbl_filter="Filter Completed Shift Punches",
            lbl_agg="Aggregate Monthly Payroll Hours",
            lbl_assert="Verify Payroll Batch Integrity",
            lbl_report="Generate Payroll Hours Dashboard",
            lbl_export="Export Verified Shift Summary",
            report_title="Monthly Shift & Payroll Hours Report",
            chart_type="bar",
            export_filename="payroll_shift_hours.csv",
            input_title="Employee Shift Punch Records",
            input_desc="Timesheet entries containing shift_date, shift_role, and logged_hours.",
            rule_validate_title="Timesheet Punch Validation",
            rule_validate_desc=(
                "Ensure every shift entry has a valid shift_date and positive logged_hours."
            ),
            rule_Secondary_title="Payroll Hours Aggregation",
            rule_Secondary_desc="Sum verified logged_hours by month and shift_role.",
            cq_error_question="How should unclosed shift punches be handled?",
            cq_metric_question="Which numeric field tracks shift duration?",
            cq_metric_options=["logged_hours", "billable_hours", "overtime_hours"],
        )

    # 10. Dynamic Custom Problem Synthesizer for ANY user prompt!
    subject_title, noun = _extract_subject_words(combined)
    slug = re.sub(r"[^a-z0-9]+", "-", subject_title.lower()).strip("-")[:28] or "custom-app"

    is_schedule_or_event = any(
        k in p_lower
        for k in (
            "schedule",
            "calendar",
            "booking",
            "event",
            "ticket",
            "kanban",
            "board",
            "task",
            "project",
            "bug",
            "issue",
        )
    )
    is_directory_or_feed = any(
        k in p_lower
        for k in (
            "directory",
            "finder",
            "match",
            "community",
            "feed",
            "forum",
            "social",
            "catalog",
            "library",
            "course",
        )
    )

    date_col = f"{noun}_date"
    if is_schedule_or_event:
        amount_col = f"{noun}_priority"
        category_col = f"{noun}_stage"
        include_monthly = False
        include_export = False
        branch_export = False
        chart_type = "bar"
    elif is_directory_or_feed:
        amount_col = f"{noun}_score"
        category_col = f"{noun}_group"
        include_monthly = False
        include_export = True
        branch_export = True
        chart_type = "bar"
    else:
        amount_col = f"{noun}_metric"
        category_col = f"{noun}_type"
        include_monthly = True
        include_export = False
        branch_export = False
        chart_type = "line"

    return DomainWorkflowProfile(
        domain_key=f"custom_{noun}",
        wf_id=f"wf-{slug}",
        wf_name=f"{subject_title} Automation & Verification Pipeline",
        wf_description=(
            f"Ingests {subject_title.lower()} records, validates {date_col} and {amount_col}, "
            f"enforces domain filter rules, and publishes the {subject_title} dashboard."
        ),
        goal=understanding.goal
        if understanding and understanding.goal
        else (
            f"Manage {subject_title.lower()} entries, enforce validation rules on {date_col} and "
            f"{amount_col}, and surface live {subject_title.lower()} insights."
        ),
        summary=understanding.summary
        if understanding and understanding.summary
        else (
            f"A deterministic workflow tailored to {subject_title} that ingests domain records, "
            f"validates {date_col} and {amount_col}, filters active items, and renders "
            f"an interactive {subject_title} overview."
        ),
        target_users=(
            understanding.target_users
            if understanding and understanding.target_users
            else [f"{subject_title} User", f"{subject_title} Coordinator", "Operations Lead"]
        ),
        trigger_type=f"{noun}_event_ingest",
        trigger_config={"domain": noun, "realtime_validation": True},
        date_col=date_col,
        amount_col=amount_col,
        category_col=category_col,
        sample_categories=(
            f"Primary {subject_title}",
            f"Active {subject_title}",
            f"Priority {subject_title}",
        ),
        sample_amounts=(80.0, 45.0, 95.0, 110.0, 60.0, 85.0, 70.0),
        sample_filename=f"{noun}_records.csv",
        include_monthly_agg=include_monthly,
        include_assert=True,
        include_report=True,
        include_export=include_export,
        branch_export_from_filter=branch_export,
        lbl_read=f"Ingest {subject_title} Records",
        lbl_req=f"Validate {date_col} & {amount_col}",
        lbl_types=f"Verify {subject_title} Schema Types",
        lbl_filter=f"Filter Active {subject_title} Items",
        lbl_agg=f"Aggregate {subject_title} Metrics",
        lbl_assert=f"Assert {subject_title} Integrity",
        lbl_report=f"{subject_title} Live Dashboard",
        lbl_export=f"Export Verified {subject_title} Data",
        report_title=f"{subject_title} Activity & KPI Report",
        chart_type=chart_type,
        export_filename=f"{noun}_verified_export.csv",
        input_title=f"{subject_title} Domain Records",
        input_desc=(
            f"Incoming {subject_title.lower()} entries containing "
            f"{date_col}, {category_col}, and {amount_col}."
        ),
        rule_validate_title=f"{subject_title} Schema Validation",
        rule_validate_desc=(
            f"Ensure every {subject_title.lower()} entry includes a valid "
            f"{date_col} and positive {amount_col}."
        ),
        rule_Secondary_title=f"{subject_title} Filtering & Verification",
        rule_Secondary_desc=(
            f"Filter active {subject_title.lower()} records where "
            f"{amount_col} > 0 and verify dataset integrity."
        ),
        cq_error_question=f"How should incomplete {subject_title.lower()} entries be handled?",
        cq_metric_question=f"Which numeric metric should be tracked for {subject_title}?",
        cq_metric_options=[amount_col, f"{noun}_count", f"{noun}_rating"],
    )


def build_domain_understanding(prompt: str) -> ProductUnderstanding:
    """Builds a domain-specific ProductUnderstanding from the resolved DomainWorkflowProfile."""
    profile = resolve_domain_profile(prompt=prompt)
    return ProductUnderstanding(
        goal=profile.goal,
        summary=profile.summary,
        target_users=profile.target_users,
        inputs=[
            UnderstandingItem(
                id="inp-primary",
                title=profile.input_title,
                description=profile.input_desc,
                attribution=ItemAttribution.USER_STATED,
            ),
            UnderstandingItem(
                id="inp-schema",
                title=f"Typed Schema ({profile.date_col}, {profile.amount_col})",
                description=(
                    f"Standard ISO date in '{profile.date_col}', numeric value in "
                    f"'{profile.amount_col}', and classification in '{profile.category_col}'."
                ),
                attribution=ItemAttribution.ASSUMPTION,
            ),
        ],
        outputs=[
            UnderstandingItem(
                id="out-report",
                title=profile.report_title,
                description=(
                    f"Interactive {profile.chart_type} visualization and structured summary for "
                    f"{profile.wf_name}."
                ),
                attribution=ItemAttribution.USER_STATED,
            ),
            UnderstandingItem(
                id="out-audit",
                title="Quarantined & Rejected Entry Log",
                description=(
                    f"Structured audit log capturing any record missing '{profile.date_col}' "
                    f"or '{profile.amount_col}'."
                ),
                attribution=ItemAttribution.AI_RECOMMENDATION,
            ),
        ]
        + (
            [
                UnderstandingItem(
                    id="out-csv",
                    title=profile.lbl_export,
                    description=f"Downloadable verified dataset ({profile.export_filename}).",
                    attribution=ItemAttribution.AI_RECOMMENDATION,
                )
            ]
            if profile.include_export
            else []
        ),
        business_rules=[
            UnderstandingItem(
                id="rule-validate",
                title=profile.rule_validate_title,
                description=profile.rule_validate_desc,
                attribution=ItemAttribution.USER_STATED,
            ),
            UnderstandingItem(
                id="rule-secondary",
                title=profile.rule_Secondary_title,
                description=profile.rule_Secondary_desc,
                attribution=ItemAttribution.USER_STATED,
            ),
        ],
        assumptions=[
            UnderstandingItem(
                id="asm-date-col",
                title="Timestamp / Date Field",
                description=f"The primary date/time field is '{profile.date_col}'.",
                attribution=ItemAttribution.ASSUMPTION,
            ),
            UnderstandingItem(
                id="asm-amount-col",
                title="Primary Numeric Metric Field",
                description=f"The primary numeric metric or score field is '{profile.amount_col}'.",
                attribution=ItemAttribution.ASSUMPTION,
            ),
        ],
        clarifications=[
            ClarificationQuestion(
                id="cq-error-strategy",
                question=profile.cq_error_question,
                context=(
                    f"If an entry is missing '{profile.date_col}' or "
                    f"'{profile.amount_col}', how should the workflow proceed?"
                ),
                options=[
                    "Drop invalid rows to rejected log and continue",
                    "Halt entire workflow on first error",
                ],
                default_choice="Drop invalid rows to rejected log and continue",
                selected_choice="Drop invalid rows to rejected log and continue",
            ),
            ClarificationQuestion(
                id="cq-metric-col",
                question=profile.cq_metric_question,
                context="Used for validation, filtering, and summary visualizations.",
                options=profile.cq_metric_options,
                default_choice=profile.cq_metric_options[0],
                selected_choice=profile.cq_metric_options[0],
            ),
        ],
    )


def build_domain_workflow(
    prompt: str = "",
    understanding: Optional[ProductUnderstanding] = None,
) -> WorkflowSpec:
    """
    Constructs a domain-specific WorkflowSpec with domain-authentic node labels,
    column names, node selection (6, 7, or 8 nodes), and DAG branching topology.
    """
    profile = resolve_domain_profile(prompt=prompt, understanding=understanding)

    # Check if user selected "Halt entire workflow" in clarifications
    rejection_strategy = "drop"
    if understanding:
        for cq in understanding.clarifications:
            if cq.selected_choice and "halt" in cq.selected_choice.lower():
                rejection_strategy = "halt"
        for asm in understanding.assumptions:
            if "halt entire workflow" in asm.description.lower():
                rejection_strategy = "halt"

    nodes: list[NodeSpec] = [
        NodeSpec(
            id="node-read",
            type="ingest.read_csv",
            label=profile.lbl_read,
            category="ingest",
            config={"delimiter": ",", "has_header": True, "encoding": "utf-8"},
            input_ports=[
                Port(name="file_in", data_type=DataType.FILE),
                Port(name="file", data_type=DataType.FILE),
            ],
            output_ports=[
                Port(name="table_out", data_type=DataType.TABLE),
                Port(name="table", data_type=DataType.TABLE),
            ],
        ),
        NodeSpec(
            id="node-req",
            type="validate.required_fields",
            label=profile.lbl_req,
            category="validate",
            config={
                "required_columns": [profile.date_col, profile.amount_col],
                "rejection_strategy": rejection_strategy,
            },
            input_ports=[
                Port(name="table_in", data_type=DataType.TABLE),
                Port(name="table", data_type=DataType.TABLE),
            ],
            output_ports=[
                Port(name="valid_out", data_type=DataType.TABLE),
                Port(name="rejected_out", data_type=DataType.TABLE),
                Port(name="table", data_type=DataType.TABLE),
            ],
        ),
        NodeSpec(
            id="node-types",
            type="validate.type_check",
            label=profile.lbl_types,
            category="validate",
            config={
                "column_types": {profile.amount_col: "number", profile.date_col: "date"},
                "coerce": True,
                "rejection_strategy": rejection_strategy,
            },
            input_ports=[
                Port(name="table_in", data_type=DataType.TABLE),
                Port(name="table", data_type=DataType.TABLE),
            ],
            output_ports=[
                Port(name="valid_out", data_type=DataType.TABLE),
                Port(name="rejected_out", data_type=DataType.TABLE),
                Port(name="table", data_type=DataType.TABLE),
            ],
        ),
        NodeSpec(
            id="node-filter",
            type="transform.filter",
            label=profile.lbl_filter,
            category="transform",
            config={"expression": f"{profile.amount_col} > 0"},
            input_ports=[
                Port(name="table_in", data_type=DataType.TABLE),
                Port(name="table", data_type=DataType.TABLE),
            ],
            output_ports=[
                Port(name="matched_out", data_type=DataType.TABLE),
                Port(name="unmatched_out", data_type=DataType.TABLE),
                Port(name="table", data_type=DataType.TABLE),
            ],
        ),
    ]

    edges: list[EdgeSpec] = [
        EdgeSpec(
            id="e1",
            from_node="node-read",
            from_port="table_out",
            to_node="node-req",
            to_port="table_in",
        ),
        EdgeSpec(
            id="e2",
            from_node="node-req",
            from_port="valid_out",
            to_node="node-types",
            to_port="table_in",
        ),
        EdgeSpec(
            id="e3",
            from_node="node-types",
            from_port="valid_out",
            to_node="node-filter",
            to_port="table_in",
        ),
    ]

    last_core_node = "node-filter"
    last_core_port = "matched_out"
    edge_idx = 4

    if profile.include_monthly_agg:
        nodes.append(
            NodeSpec(
                id="node-monthly",
                type="aggregate.monthly_totals",
                label=profile.lbl_agg,
                category="aggregate",
                config={
                    "date_column": profile.date_col,
                    "amount_column": profile.amount_col,
                    "group_by_columns": [profile.category_col],
                },
                input_ports=[
                    Port(name="table_in", data_type=DataType.TABLE),
                    Port(name="table", data_type=DataType.TABLE),
                ],
                output_ports=[
                    Port(name="table_out", data_type=DataType.TABLE),
                    Port(name="table", data_type=DataType.TABLE),
                ],
            )
        )
        edges.append(
            EdgeSpec(
                id=f"e{edge_idx}",
                from_node=last_core_node,
                from_port=last_core_port,
                to_node="node-monthly",
                to_port="table_in",
            )
        )
        edge_idx += 1
        last_core_node = "node-monthly"
        last_core_port = "table_out"

    if profile.include_assert:
        # For canonical CSV or fan-out workflows, check if assert is parallel or inline
        if profile.domain_key == "csv_monthly_totals" or (
            profile.branch_export_from_filter and not profile.include_monthly_agg
        ):
            nodes.append(
                NodeSpec(
                    id="node-assert",
                    type="quality.assert",
                    label=profile.lbl_assert,
                    category="quality",
                    config={"rule": "row_count > 0"},
                    input_ports=[
                        Port(name="table_in", data_type=DataType.TABLE),
                        Port(name="table", data_type=DataType.TABLE),
                    ],
                    output_ports=[
                        Port(name="passed_out", data_type=DataType.BOOLEAN),
                        Port(name="table", data_type=DataType.TABLE),
                    ],
                )
            )
            edges.append(
                EdgeSpec(
                    id=f"e{edge_idx}",
                    from_node=last_core_node,
                    from_port=last_core_port,
                    to_node="node-assert",
                    to_port="table_in",
                )
            )
            edge_idx += 1
        else:
            # Inline quality assertion gate feeding downstream report
            nodes.append(
                NodeSpec(
                    id="node-assert",
                    type="quality.assert",
                    label=profile.lbl_assert,
                    category="quality",
                    config={"rule": "row_count > 0"},
                    input_ports=[
                        Port(name="table_in", data_type=DataType.TABLE),
                        Port(name="table", data_type=DataType.TABLE),
                    ],
                    output_ports=[
                        Port(name="table_out", data_type=DataType.TABLE),
                        Port(name="table", data_type=DataType.TABLE),
                    ],
                )
            )
            edges.append(
                EdgeSpec(
                    id=f"e{edge_idx}",
                    from_node=last_core_node,
                    from_port=last_core_port,
                    to_node="node-assert",
                    to_port="table_in",
                )
            )
            edge_idx += 1
            last_core_node = "node-assert"
            last_core_port = "table_out"

    if profile.include_report:
        nodes.append(
            NodeSpec(
                id="node-report",
                type="output.report",
                label=profile.lbl_report,
                category="output",
                config={
                    "title": profile.report_title,
                    "chart_type": profile.chart_type,
                    "summary_columns": [profile.date_col, profile.amount_col, profile.category_col],
                },
                input_ports=[
                    Port(name="table_in", data_type=DataType.TABLE),
                    Port(name="table", data_type=DataType.TABLE),
                ],
                output_ports=[
                    Port(name="report_out", data_type=DataType.REPORT),
                    Port(name="report", data_type=DataType.REPORT),
                ],
            )
        )
        edges.append(
            EdgeSpec(
                id=f"e{edge_idx}",
                from_node=last_core_node,
                from_port=last_core_port,
                to_node="node-report",
                to_port="table_in",
            )
        )
        edge_idx += 1

    if profile.include_export:
        export_src_node = "node-filter" if profile.branch_export_from_filter else last_core_node
        export_src_port = "matched_out" if profile.branch_export_from_filter else last_core_port
        nodes.append(
            NodeSpec(
                id="node-export",
                type="output.export_csv",
                label=profile.lbl_export,
                category="output",
                config={
                    "filename": profile.export_filename,
                    "protect_formula_injection": True,
                },
                input_ports=[
                    Port(name="table_in", data_type=DataType.TABLE),
                    Port(name="table", data_type=DataType.TABLE),
                ],
                output_ports=[
                    Port(name="file_out", data_type=DataType.FILE),
                    Port(name="file", data_type=DataType.FILE),
                ],
            )
        )
        edges.append(
            EdgeSpec(
                id=f"e{edge_idx}",
                from_node=export_src_node,
                from_port=export_src_port,
                to_node="node-export",
                to_port="table_in",
            )
        )

    outputs: list[Port] = [Port(name="report", data_type=DataType.REPORT)]
    if profile.include_export:
        outputs.append(Port(name="csv_file", data_type=DataType.FILE))

    return WorkflowSpec(
        id=profile.wf_id,
        name=profile.wf_name,
        version=1,
        description=profile.wf_description,
        trigger=TriggerSpec(
            id=f"trig-{profile.domain_key[:16]}",
            type=profile.trigger_type,
            config=profile.trigger_config,
        ),
        inputs=[Port(name="file_in", data_type=DataType.FILE)],
        nodes=nodes,
        edges=edges,
        outputs=outputs,
    )
