from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field

from engine.spec import WorkflowSpec


class ItemAttribution(str, Enum):
    USER_STATED = "user_stated"
    ASSUMPTION = "assumption"
    AI_RECOMMENDATION = "ai_recommendation"


class UnderstandingItem(BaseModel):
    id: str
    title: str
    description: str = ""
    attribution: ItemAttribution = ItemAttribution.USER_STATED
    editable: bool = True


class ClarificationQuestion(BaseModel):
    id: str
    question: str
    context: str = ""
    options: list[str]
    default_choice: str
    selected_choice: Optional[str] = None


class ProductUnderstanding(BaseModel):
    goal: str
    summary: str
    target_users: list[str] = Field(default_factory=list)
    inputs: list[UnderstandingItem] = Field(default_factory=list)
    outputs: list[UnderstandingItem] = Field(default_factory=list)
    business_rules: list[UnderstandingItem] = Field(default_factory=list)
    assumptions: list[UnderstandingItem] = Field(default_factory=list)
    clarifications: list[ClarificationQuestion] = Field(default_factory=list)


class RepairAttempt(BaseModel):
    attempt: int
    errors_encountered: list[str]
    repair_summary: str
    repaired_spec: Optional[dict[str, Any]] = None
    success: bool


class CompilationResult(BaseModel):
    success: bool
    understanding: ProductUnderstanding
    workflow: Optional[WorkflowSpec] = None
    validation_errors: list[str] = Field(default_factory=list)
    repair_history: list[RepairAttempt] = Field(default_factory=list)
    diagnostics: str = ""
