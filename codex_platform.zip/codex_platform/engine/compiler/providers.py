import json
import logging
import os
import time
from abc import ABC, abstractmethod
from typing import Any, Optional, Type, TypeVar

import httpx
from dotenv import load_dotenv
from pydantic import BaseModel

from engine.compiler.schemas import ProductUnderstanding
from engine.spec import WorkflowSpec
from generators.blueprint.archetypes import resolve_benchmark_bundle
from generators.blueprint.schemas import AppBlueprint, DomainAnalysis
from generators.design.schemas import DesignDirection, DesignProposalSet

load_dotenv()

logger = logging.getLogger("ghostwriter.providers")

T = TypeVar("T", bound=BaseModel)


class ModelProvider(ABC):
    """
    Abstract interface for AI model providers proposing structured workflows.
    All outputs must be strictly validated against Pydantic schemas.
    """

    @abstractmethod
    def generate_structured(self, prompt: str, system_prompt: str, schema_class: Type[T]) -> T:
        pass

    @abstractmethod
    def repair_structured(
        self,
        original_prompt: str,
        previous_output: dict[str, Any],
        errors: list[str],
        schema_class: Type[T],
    ) -> T:
        pass


class MockProvider(ModelProvider):
    """
    Deterministic Mock Provider used for tests, offline mode, and zero-token development.
    Guarantees reproducible compilation and allows simulated repair sequences.
    """

    def __init__(
        self,
        scripted_workflows: Optional[list[dict[str, Any]]] = None,
        repair_sequence: Optional[list[dict[str, Any]]] = None,
    ) -> None:
        self.scripted_workflows = scripted_workflows or []
        self.repair_sequence = repair_sequence or []
        self.workflow_index = 0
        self.repair_index = 0
        self.last_prompt = ""
        self.telemetry_log: list[dict[str, Any]] = []

    def generate_structured(self, prompt: str, system_prompt: str, schema_class: Type[T]) -> T:
        self.last_prompt = prompt
        t0 = time.perf_counter()

        if schema_class == ProductUnderstanding:
            understanding = self._generate_canonical_understanding(prompt)
            res = schema_class.model_validate(understanding.model_dump())
            self._log_call("ProductUnderstanding", t0, prompt, "valid")
            return res

        if schema_class == DomainAnalysis:
            bundle = resolve_benchmark_bundle(prompt)
            res = schema_class.model_validate(bundle.domain_analysis.model_dump())
            self._log_call("StageA_DomainAnalysis", t0, prompt, "valid")
            return res

        if schema_class == AppBlueprint:
            bundle = resolve_benchmark_bundle(prompt)
            res = schema_class.model_validate(bundle.blueprint.model_dump())
            self._log_call("StageB_AppBlueprint", t0, prompt, "valid")
            return res

        if schema_class == DesignDirection:
            bundle = resolve_benchmark_bundle(prompt)
            res = schema_class.model_validate(bundle.primary_direction.model_dump())
            self._log_call("StageC_DesignDirection", t0, prompt, "valid")
            return res

        if schema_class == DesignProposalSet:
            bundle = resolve_benchmark_bundle(prompt)
            proposal_set = DesignProposalSet(proposals=bundle.direction_proposals[:3])
            res = schema_class.model_validate(proposal_set.model_dump())
            self._log_call("StageC_DesignProposalSet", t0, prompt, "valid")
            return res

        # Check if an explicit scripted workflow was configured for testing
        if (
            schema_class == WorkflowSpec
            and self.scripted_workflows
            and self.workflow_index < len(self.scripted_workflows)
        ):
            data = self.scripted_workflows[self.workflow_index]
            self.workflow_index += 1
            res = schema_class.model_validate(data)
            self._log_call("WorkflowSpec_Scripted", t0, prompt, "valid")
            return res

        if schema_class == WorkflowSpec:
            workflow = self._generate_canonical_workflow(prompt=prompt)
            res = schema_class.model_validate(workflow.model_dump())
            self._log_call("WorkflowSpec", t0, prompt, "valid")
            return res

        raise NotImplementedError(
            f"MockProvider does not implement schema '{schema_class.__name__}'."
        )

    def _log_call(self, stage: str, start_time: float, prompt: str, outcome: str) -> None:
        latency_ms = round((time.perf_counter() - start_time) * 1000.0, 2)
        entry = {
            "stage": stage,
            "provider": "mock",
            "model": "mock-deterministic-v1",
            "latency_ms": latency_ms,
            "input_tokens": max(1, len(prompt) // 4),
            "output_tokens": 256,
            "validation_outcome": outcome,
        }
        self.telemetry_log.append(entry)

    def repair_structured(
        self,
        original_prompt: str,
        previous_output: dict[str, Any],
        errors: list[str],
        schema_class: Type[T],
    ) -> T:
        if self.repair_sequence and self.repair_index < len(self.repair_sequence):
            repaired = self.repair_sequence[self.repair_index]
            self.repair_index += 1
            return schema_class.model_validate(repaired)

        if schema_class in (DomainAnalysis, AppBlueprint, DesignDirection, DesignProposalSet):
            return self.generate_structured(
                prompt=original_prompt,
                system_prompt="Repair adaptive schema to canonical valid specification.",
                schema_class=schema_class,
            )

        # Default repair logic: resolve known errors on previous output or fallback to valid spec
        data = dict(previous_output)
        # Fix missing required columns
        for node in data.get("nodes", []):
            if node.get("type") == "validate.required_fields":
                cfg = node.get("config", {})
                if not cfg.get("required_columns"):
                    cfg["required_columns"] = ["date", "amount"]
                    cfg["rejection_strategy"] = "drop"
            if node.get("type") == "unknown.invalid_node":
                node["type"] = "validate.required_fields"
                node["config"] = {
                    "required_columns": ["date", "amount"],
                    "rejection_strategy": "drop",
                }

        # Return repaired spec or canonical fallback
        try:
            return schema_class.model_validate(data)
        except Exception:
            return schema_class.model_validate(self._generate_canonical_workflow().model_dump())

    def _generate_canonical_understanding(self, prompt: str) -> ProductUnderstanding:
        from engine.compiler.domain_profiles import build_domain_understanding

        return build_domain_understanding(prompt)

    def _generate_canonical_workflow(self, prompt: str = "") -> WorkflowSpec:
        from engine.compiler.domain_profiles import build_domain_workflow

        p_text = prompt or getattr(self, "last_prompt", "")
        return build_domain_workflow(prompt=p_text)


def verify_gemini_model_available(model_name: str, api_key: str) -> bool:
    """
    Verifies that the configured Gemini model exists on the live Gemini API endpoint.
    Fails fast with a clear ValueError if the model is unavailable or key is invalid.
    """
    if not api_key:
        raise ValueError("Cannot verify Gemini model: GEMINI_API_KEY is empty.")
    clean_model = model_name.removeprefix("models/")
    url = f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}"
    with httpx.Client(timeout=15.0) as client:
        resp = client.get(url)
        resp.raise_for_status()
        models_payload = resp.json().get("models", [])
        available_names = {
            m.get("name", "").removeprefix("models/") for m in models_payload if m.get("name")
        }
        if clean_model not in available_names:
            sample = sorted(n for n in available_names if "gemini" in n)[:8]
            raise ValueError(
                f"Configured GEMINI_MODEL '{clean_model}' does not exist on the Gemini API "
                f"endpoint. Available flash/pro models: {sample}"
            )
    return True


class GeminiProvider(ModelProvider):
    """
    Google Gemini Provider using standard REST endpoint and structured JSON schemas.
    Reads GEMINI_API_KEY and GEMINI_MODEL from environment variables.
    """

    def __init__(self, model_name: str = "", api_key: str = "") -> None:
        self.model_name = (
            model_name or os.environ.get("GEMINI_MODEL", "gemini-3.5-flash-lite")
        ).removeprefix("models/")
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY", "")
        self.telemetry_log: list[dict[str, Any]] = []
        self._verified_models: set[str] = set()

    def ensure_model_verified(self) -> bool:
        if self.model_name in self._verified_models:
            return True
        if verify_gemini_model_available(self.model_name, self.api_key):
            self._verified_models.add(self.model_name)
            return True
        return False

    def generate_structured(self, prompt: str, system_prompt: str, schema_class: Type[T]) -> T:
        if not self.api_key:
            raise ValueError(
                "GEMINI_API_KEY is not set in environment. Switch to MockProvider or provide key."
            )

        schema = schema_class.model_json_schema()
        full_system_prompt = (
            f"{system_prompt}\n\n"
            "You MUST output ONLY a valid JSON object matching this JSON Schema "
            "(do not output explanation or markdown):\n"
            f"{json.dumps(schema, indent=2)}"
        )

        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "system_instruction": {"parts": [{"text": full_system_prompt}]},
            "generationConfig": {
                "response_mime_type": "application/json",
                "temperature": 0.2,
            },
        }

        models_to_try = [self.model_name]
        for fm in ("gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-flash-lite", "gemini-1.5-flash"):
            if fm not in models_to_try:
                models_to_try.append(fm)

        last_error: Optional[Exception] = None
        for model in models_to_try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={self.api_key}"
            t0 = time.perf_counter()
            try:
                with httpx.Client(timeout=45.0) as client:
                    resp = client.post(url, json=payload)
                    resp.raise_for_status()
                    res_json = resp.json()
                    usage = res_json.get("usageMetadata", {})
                    in_tokens = int(usage.get("promptTokenCount", 0))
                    out_tokens = int(usage.get("candidatesTokenCount", 0))
                    candidates = res_json.get("candidates", [])
                    if not candidates:
                        raise ValueError("No candidates returned by Gemini.")
                    raw_text = candidates[0]["content"]["parts"][0]["text"].strip()
                    if raw_text.startswith("```json"):
                        raw_text = raw_text[7:]
                    if raw_text.startswith("```"):
                        raw_text = raw_text[3:]
                    if raw_text.endswith("```"):
                        raw_text = raw_text[:-3]
                    raw_text = raw_text.strip()
                    validated = schema_class.model_validate_json(raw_text)
                    latency_ms = round((time.perf_counter() - t0) * 1000.0, 2)
                    telemetry_entry = {
                        "stage": schema_class.__name__,
                        "provider": "gemini",
                        "model": model,
                        "latency_ms": latency_ms,
                        "input_tokens": in_tokens,
                        "output_tokens": out_tokens,
                        "validation_outcome": "valid",
                    }
                    self.telemetry_log.append(telemetry_entry)
                    logger.info(
                        "Gemini stage=%s model=%s latency_ms=%.2f in=%d out=%d outcome=valid",
                        schema_class.__name__,
                        model,
                        latency_ms,
                        in_tokens,
                        out_tokens,
                    )
                    return validated
            except Exception as e:
                latency_ms = round((time.perf_counter() - t0) * 1000.0, 2)
                self.telemetry_log.append(
                    {
                        "stage": schema_class.__name__,
                        "provider": "gemini",
                        "model": model,
                        "latency_ms": latency_ms,
                        "input_tokens": 0,
                        "output_tokens": 0,
                        "validation_outcome": f"error:{type(e).__name__}",
                    }
                )
                last_error = e
                continue

        if last_error:
            raise last_error
        raise RuntimeError("Failed to generate structured output from Gemini provider.")

    def repair_structured(
        self,
        original_prompt: str,
        previous_output: dict[str, Any],
        errors: list[str],
        schema_class: Type[T],
    ) -> T:
        repair_prompt = (
            f"Original Request:\n{original_prompt}\n\n"
            f"Previous Proposed Spec (JSON):\n{json.dumps(previous_output, indent=2)}\n\n"
            f"Validation Errors Encountered by Engine:\n"
            + "\n".join(f"- {e}" for e in errors)
            + "\n\nPlease fix these errors and return corrected JSON conforming to the schema."
        )
        return self.generate_structured(
            prompt=repair_prompt,
            system_prompt=(
                "You are CodeX's Specification Repair Specialist. Return only the repaired JSON."
            ),
            schema_class=schema_class,
        )


class OpenAICompatibleProvider(ModelProvider):
    """
    OpenAI-Compatible Provider supporting Ollama, vLLM, and OpenAI API endpoints.
    Reads OPENAI_API_KEY and OPENAI_BASE_URL from environment variables.
    """

    def __init__(
        self,
        model_name: str = "gpt-4o-mini",
        api_key: str = "",
        base_url: str = "",
    ) -> None:
        self.model_name = model_name
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "dummy")
        self.base_url = base_url or os.environ.get("OPENAI_BASE_URL", "http://localhost:11434/v1")

    def generate_structured(self, prompt: str, system_prompt: str, schema_class: Type[T]) -> T:
        url = f"{self.base_url.rstrip('/')}/chat/completions"
        headers = {"Authorization": f"Bearer {self.api_key}"}

        payload = {
            "model": self.model_name,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            "response_format": {"type": "json_object"},
            "temperature": 0.2,
        }

        with httpx.Client(timeout=30.0) as client:
            resp = client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            content = resp.json()["choices"][0]["message"]["content"]
            return schema_class.model_validate_json(content)

    def repair_structured(
        self,
        original_prompt: str,
        previous_output: dict[str, Any],
        errors: list[str],
        schema_class: Type[T],
    ) -> T:
        repair_prompt = (
            f"Previous Spec:\n{json.dumps(previous_output, indent=2)}\n\n"
            f"Errors:\n" + "\n".join(f"- {e}" for e in errors)
        )
        return self.generate_structured(
            prompt=repair_prompt,
            system_prompt="Repair the invalid workflow JSON based on errors.",
            schema_class=schema_class,
        )
