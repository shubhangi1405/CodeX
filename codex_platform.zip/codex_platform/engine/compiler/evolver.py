import re
from typing import Any, Optional

from engine.compiler.providers import ModelProvider
from engine.compiler.validator import WorkflowValidator
from engine.spec import WorkflowSpec
from engine.types import DataType
from engine.versioning.diff import WorkflowDiff, WorkflowVersionManager


class WorkflowEvolver:
    """
    Milestone 8: Conversational Workflow Evolution.
    Applies surgical, targeted DAG modifications based on follow-up natural language instructions
    without blowing away or corrupting existing working pipelines.
    """

    @classmethod
    def evolve(
        cls,
        current_wf: WorkflowSpec,
        instruction: str,
        provider: Optional[ModelProvider] = None,
    ) -> tuple[WorkflowSpec, WorkflowDiff, list[str]]:
        """
        Evolves a workflow DAG according to user instruction.
        Returns:
            - Evolved WorkflowSpec with bumped version
            - Structured WorkflowDiff between old and new
            - List of validation errors (empty if valid)
        """
        instruction_lower = instruction.lower().strip()

        # Create copy of workflow spec
        new_wf_dict = current_wf.model_dump()
        new_wf_dict["version"] = current_wf.version + 1

        nodes: list[dict[str, Any]] = new_wf_dict.get("nodes", [])
        edges: list[dict[str, Any]] = new_wf_dict.get("edges", [])

        # Determine primary numeric metric column for this workflow (defaults to "amount")
        metric_col = "amount"
        for n in nodes:
            if n.get("type") == "validate.type_check":
                col_types = n.get("config", {}).get("column_types", {})
                if isinstance(col_types, dict):
                    for cname, ctype in col_types.items():
                        if ctype in ("number", "float", "int"):
                            metric_col = str(cname)
                            break
            elif n.get("type") == "aggregate.monthly_totals":
                if n.get("config", {}).get("amount_column"):
                    metric_col = str(n["config"]["amount_column"])
        if "amount" in instruction_lower:
            metric_col = "amount"

        applied = False

        # 1. Check for threshold / amount filtering instruction
        # e.g., "filter out orders below $50", "filter amount > 100", "only amount >= 50"
        match_amount = re.search(r"(\>|\<|\>\=|\<\=)\s*\$?(\d+(\.\d+)?)", instruction)
        match_below = re.search(r"below\s*\$?(\d+(\.\d+)?)", instruction_lower)
        match_above = re.search(r"(above|over|greater than)\s*\$?(\d+(\.\d+)?)", instruction_lower)

        if "filter" in instruction_lower or match_amount or match_below or match_above:
            # Determine target expression
            new_expr = f"{metric_col} > 0"
            if match_amount:
                op = match_amount.group(1)
                val = match_amount.group(2)
                new_expr = f"{metric_col} {op} {val}"
            elif match_below:
                val = match_below.group(1)
                new_expr = f"{metric_col} >= {val}"
            elif match_above:
                val = match_above.group(2)
                new_expr = f"{metric_col} > {val}"

            # Check if a transform.filter node already exists
            filter_node = next((n for n in nodes if n["type"] == "transform.filter"), None)
            if filter_node:
                filter_node["config"]["expression"] = new_expr
                filter_node["label"] = f"Filter Valid Records ({new_expr})"
                applied = True
            else:
                # Insert filter node after first validate node
                val_node = next((n for n in nodes if n["type"].startswith("validate.")), None)
                if val_node:
                    new_node_id = f"node-filter-{len(nodes) + 1}"
                    new_node = {
                        "id": new_node_id,
                        "type": "transform.filter",
                        "label": f"Filter ({new_expr})",
                        "category": "transform",
                        "config": {"expression": new_expr},
                        "input_ports": [{"name": "table", "data_type": DataType.TABLE}],
                        "output_ports": [{"name": "table", "data_type": DataType.TABLE}],
                    }

                    # Find outgoing edge from val_node
                    outgoing = [e for e in edges if e["from_node"] == val_node["id"]]
                    if outgoing:
                        target_edge = outgoing[0]
                        # Rewire: val_node -> new_node -> old_target
                        old_target = target_edge["to_node"]
                        edges.remove(target_edge)
                        edges.append(
                            {
                                "id": f"e-{val_node['id']}-{new_node_id}",
                                "from_node": val_node["id"],
                                "from_port": "table",
                                "to_node": new_node_id,
                                "to_port": "table",
                            }
                        )
                        edges.append(
                            {
                                "id": f"e-{new_node_id}-{old_target}",
                                "from_node": new_node_id,
                                "from_port": "table",
                                "to_node": old_target,
                                "to_port": "table",
                            }
                        )
                        nodes.append(new_node)
                        applied = True

        # 2. Check for deduplication / duplicate detection
        if ("deduplicate" in instruction_lower or "duplicate" in instruction_lower) and not applied:
            # Check if filter or required fields can do it, or add filter expression
            new_node_id = f"node-dedup-{len(nodes) + 1}"
            new_node = {
                "id": new_node_id,
                "type": "transform.filter",
                "label": "Deduplicate & Clean Records",
                "category": "transform",
                "config": {"expression": f"{metric_col} != null && {metric_col} > 0"},
                "input_ports": [{"name": "table", "data_type": DataType.TABLE}],
                "output_ports": [{"name": "table", "data_type": DataType.TABLE}],
            }
            # Insert before aggregate node if present
            agg_node = next((n for n in nodes if n["type"].startswith("aggregate.")), None)
            if agg_node:
                incoming = [e for e in edges if e["to_node"] == agg_node["id"]]
                if incoming:
                    in_edge = incoming[0]
                    prev_node_id = in_edge["from_node"]
                    edges.remove(in_edge)
                    edges.append(
                        {
                            "id": f"e-{prev_node_id}-{new_node_id}",
                            "from_node": prev_node_id,
                            "from_port": "table",
                            "to_node": new_node_id,
                            "to_port": "table",
                        }
                    )
                    edges.append(
                        {
                            "id": f"e-{new_node_id}-{agg_node['id']}",
                            "from_node": new_node_id,
                            "from_port": "table",
                            "to_node": agg_node["id"],
                            "to_port": "table",
                        }
                    )
                    nodes.append(new_node)
                    applied = True

        # 3. Check for required column / missing field updates
        if ("require" in instruction_lower or "column" in instruction_lower) and not applied:
            req_node = next((n for n in nodes if n["type"] == "validate.required_fields"), None)
            if req_node:
                # Add extracted word to required columns if applicable
                words = re.findall(r"\b[a-zA-Z_][a-zA-Z0-9_]*\b", instruction_lower)
                filtered_words = [
                    w
                    for w in words
                    if w
                    not in {
                        "require",
                        "required",
                        "field",
                        "fields",
                        "column",
                        "columns",
                        "add",
                        "must",
                        "have",
                        "the",
                        "and",
                        "validate",
                    }
                ]
                if filtered_words:
                    current_cols = set(req_node["config"].get("required_columns", []))
                    current_cols.update(filtered_words)
                    req_node["config"]["required_columns"] = sorted(list(current_cols))
                    cols_summary = ", ".join(sorted(current_cols))
                    req_node["label"] = f"Validate Required Fields ({cols_summary})"
                    applied = True

        # If not applied via surgical rules and provider is given, use provider
        if not applied and provider:
            system_prompt = (
                "You are CodeX's Workflow Evolver. "
                "Update the existing WorkflowSpec JSON to satisfy the user's evolution request. "
                "Maintain backwards compatibility, keep port types valid, and return valid JSON."
            )
            prompt = (
                f"Existing Workflow JSON:\n{current_wf.model_dump_json(indent=2)}\n\n"
                f"Evolution Instruction:\n{instruction}"
            )
            evolved_wf = provider.generate_structured(prompt, system_prompt, WorkflowSpec)
            evolved_wf.version = current_wf.version + 1
            validation_errors = WorkflowValidator.validate(evolved_wf.model_dump())
            diff = WorkflowVersionManager.compute_diff(current_wf, evolved_wf)
            return evolved_wf, diff, validation_errors

        # Fallback: if nothing matched, add an assertion node for the new rule
        if not applied:
            rule_text = instruction[:50].replace('"', "'")
            new_node_id = f"node-assert-{len(nodes) + 1}"
            new_node = {
                "id": new_node_id,
                "type": "quality.assert",
                "label": f"Assert: {rule_text}",
                "category": "quality",
                "config": {"rule": "row_count > 0"},
                "input_ports": [{"name": "table", "data_type": DataType.TABLE}],
                "output_ports": [{"name": "table", "data_type": DataType.TABLE}],
            }
            # Append before output
            out_node = next((n for n in nodes if n["type"].startswith("output.")), None)
            if out_node:
                incoming = [e for e in edges if e["to_node"] == out_node["id"]]
                if incoming:
                    in_edge = incoming[0]
                    prev_id = in_edge["from_node"]
                    edges.remove(in_edge)
                    edges.append(
                        {
                            "id": f"e-{prev_id}-{new_node_id}",
                            "from_node": prev_id,
                            "from_port": "table",
                            "to_node": new_node_id,
                            "to_port": "table",
                        }
                    )
                    edges.append(
                        {
                            "id": f"e-{new_node_id}-{out_node['id']}",
                            "from_node": new_node_id,
                            "from_port": "table",
                            "to_node": out_node["id"],
                            "to_port": "table",
                        }
                    )
                    nodes.append(new_node)

        # Build evolved WorkflowSpec
        evolved_spec = WorkflowSpec.model_validate(new_wf_dict)
        validation_errors = WorkflowValidator.validate(evolved_spec.model_dump())
        diff = WorkflowVersionManager.compute_diff(current_wf, evolved_spec)

        return evolved_spec, diff, validation_errors
