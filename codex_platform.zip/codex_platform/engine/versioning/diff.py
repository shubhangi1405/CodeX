from typing import Any

from pydantic import BaseModel, Field

from engine.spec import WorkflowSpec


class NodeDiff(BaseModel):
    node_id: str
    change_type: str  # "added" | "removed" | "modified"
    label: str
    type: str
    old_config: dict[str, Any] = Field(default_factory=dict)
    new_config: dict[str, Any] = Field(default_factory=dict)


class EdgeDiff(BaseModel):
    edge_id: str
    change_type: str  # "added" | "removed"
    from_node: str
    from_port: str
    to_node: str
    to_port: str


class WorkflowDiff(BaseModel):
    old_version: int
    new_version: int
    added_nodes: list[NodeDiff] = Field(default_factory=list)
    removed_nodes: list[NodeDiff] = Field(default_factory=list)
    modified_nodes: list[NodeDiff] = Field(default_factory=list)
    added_edges: list[EdgeDiff] = Field(default_factory=list)
    removed_edges: list[EdgeDiff] = Field(default_factory=list)
    summary: str


class WorkflowVersionManager:
    @staticmethod
    def compute_diff(old_wf: WorkflowSpec, new_wf: WorkflowSpec) -> WorkflowDiff:
        old_nodes = {n.id: n for n in old_wf.nodes}
        new_nodes = {n.id: n for n in new_wf.nodes}

        added_nodes: list[NodeDiff] = []
        removed_nodes: list[NodeDiff] = []
        modified_nodes: list[NodeDiff] = []

        # Find added and modified
        for nid, new_n in new_nodes.items():
            if nid not in old_nodes:
                added_nodes.append(
                    NodeDiff(
                        node_id=nid,
                        change_type="added",
                        label=new_n.label,
                        type=new_n.type,
                        new_config=new_n.config,
                    )
                )
            else:
                old_n = old_nodes[nid]
                if old_n.config != new_n.config or old_n.label != new_n.label:
                    modified_nodes.append(
                        NodeDiff(
                            node_id=nid,
                            change_type="modified",
                            label=new_n.label,
                            type=new_n.type,
                            old_config=old_n.config,
                            new_config=new_n.config,
                        )
                    )

        # Find removed
        for nid, old_n in old_nodes.items():
            if nid not in new_nodes:
                removed_nodes.append(
                    NodeDiff(
                        node_id=nid,
                        change_type="removed",
                        label=old_n.label,
                        type=old_n.type,
                        old_config=old_n.config,
                    )
                )

        # Edges diff
        old_edges = {
            f"{e.from_node}.{e.from_port}->{e.to_node}.{e.to_port}": e for e in old_wf.edges
        }
        new_edges = {
            f"{e.from_node}.{e.from_port}->{e.to_node}.{e.to_port}": e for e in new_wf.edges
        }

        added_edges: list[EdgeDiff] = []
        removed_edges: list[EdgeDiff] = []

        for key, e in new_edges.items():
            if key not in old_edges:
                added_edges.append(
                    EdgeDiff(
                        edge_id=key,
                        change_type="added",
                        from_node=e.from_node,
                        from_port=e.from_port,
                        to_node=e.to_node,
                        to_port=e.to_port,
                    )
                )

        for key, e in old_edges.items():
            if key not in new_edges:
                removed_edges.append(
                    EdgeDiff(
                        edge_id=key,
                        change_type="removed",
                        from_node=e.from_node,
                        from_port=e.from_port,
                        to_node=e.to_node,
                        to_port=e.to_port,
                    )
                )

        summary = (
            f"Diff v{old_wf.version} -> v{new_wf.version}: "
            f"+{len(added_nodes)} -{len(removed_nodes)} ~{len(modified_nodes)} nodes, "
            f"+{len(added_edges)} -{len(removed_edges)} edges."
        )

        return WorkflowDiff(
            old_version=old_wf.version,
            new_version=new_wf.version,
            added_nodes=added_nodes,
            removed_nodes=removed_nodes,
            modified_nodes=modified_nodes,
            added_edges=added_edges,
            removed_edges=removed_edges,
            summary=summary,
        )
