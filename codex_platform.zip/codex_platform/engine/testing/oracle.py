import io
from typing import Any

import pandas as pd


class IndependentOracle:
    """
    Independent reference implementation using standard pandas / Python.
    Strictly separated from the workflow engine nodes and executor
    to prevent circular verification.
    """

    @staticmethod
    def calculate_expected_monthly_totals(
        csv_text: str,
        required_cols: list[str] | None = None,
        date_col: str = "date",
        amount_col: str = "amount",
        min_amount: float = 0.0,
    ) -> dict[str, Any]:
        """
        Calculates reference monthly totals independently using pandas.
        """
        required_cols = required_cols or ["date", "amount"]
        if not csv_text.strip():
            return {
                "valid_rows_count": 0,
                "rejected_count": 0,
                "monthly_totals": [],
                "total_revenue": 0.0,
                "empty": True,
            }

        try:
            df = pd.read_csv(io.StringIO(csv_text))
        except Exception as e:
            return {
                "valid_rows_count": 0,
                "rejected_count": 0,
                "error": f"CSV parse error: {str(e)}",
                "monthly_totals": [],
                "total_revenue": 0.0,
                "empty": True,
            }

        initial_count = len(df)
        if initial_count == 0:
            return {
                "valid_rows_count": 0,
                "rejected_count": 0,
                "monthly_totals": [],
                "total_revenue": 0.0,
                "empty": True,
            }

        # Check required columns
        for col in required_cols:
            if col not in df.columns:
                return {
                    "valid_rows_count": 0,
                    "rejected_count": initial_count,
                    "missing_column": col,
                    "monthly_totals": [],
                    "total_revenue": 0.0,
                    "empty": False,
                }

        # Drop rows with nulls in required columns
        df_clean = df.dropna(subset=required_cols).copy()

        # Coerce amount to numeric
        df_clean[amount_col] = pd.to_numeric(
            df_clean[amount_col]
            .astype(str)
            .str.replace("$", "", regex=False)
            .str.replace(",", "", regex=False)
            .str.strip(),
            errors="coerce",
        )
        df_clean = df_clean.dropna(subset=[amount_col])

        # Filter by min_amount (amount > 0)
        df_clean = df_clean[df_clean[amount_col] > min_amount]

        # Parse date to YYYY-MM
        try:
            df_clean["_month"] = pd.to_datetime(df_clean[date_col], errors="coerce").dt.strftime(
                "%Y-%m"
            )
            df_clean = df_clean.dropna(subset=["_month"])
        except Exception:
            df_clean["_month"] = df_clean[date_col].astype(str).str[:7]

        valid_count = len(df_clean)
        rejected_count = initial_count - valid_count

        if valid_count == 0:
            return {
                "valid_rows_count": 0,
                "rejected_count": rejected_count,
                "monthly_totals": [],
                "total_revenue": 0.0,
                "empty": False,
            }

        grouped = (
            df_clean.groupby("_month", as_index=False)
            .agg(
                total_amount=(amount_col, "sum"),
                record_count=(amount_col, "count"),
            )
            .rename(columns={"_month": "month"})
        )

        monthly_totals = grouped.to_dict(orient="records")
        total_revenue = float(round(df_clean[amount_col].sum(), 2))

        return {
            "valid_rows_count": valid_count,
            "rejected_count": rejected_count,
            "monthly_totals": monthly_totals,
            "total_revenue": total_revenue,
            "empty": False,
        }
