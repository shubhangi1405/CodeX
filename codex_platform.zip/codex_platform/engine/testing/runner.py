import time
from typing import Any

from engine.executor import WorkflowExecutor
from engine.spec import WorkflowSpec
from engine.testing.schemas import TestCase, TestResult, TestSuiteResult
from engine.types import NodeStatus


class WorkflowTestRunner:
    """
    Executes test cases against a WorkflowSpec via the deterministic WorkflowExecutor,
    verifying actual outputs against the independent oracle.
    Produces structured failure explanations when an anomaly is detected.
    Never invents a pass.
    """

    def __init__(self, executor: WorkflowExecutor | None = None) -> None:
        self.executor = executor or WorkflowExecutor()

    def run_suite(self, workflow: WorkflowSpec, tests: list[TestCase]) -> TestSuiteResult:
        results: list[TestResult] = []

        for tc in tests:
            result = self.run_test(workflow, tc)
            results.append(result)

        passed_count = sum(1 for r in results if r.passed)
        failed_count = len(results) - passed_count

        return TestSuiteResult(
            workflow_id=workflow.id,
            total_tests=len(results),
            passed_tests=passed_count,
            failed_tests=failed_count,
            all_passed=failed_count == 0,
            results=results,
        )

    def run_test(self, workflow: WorkflowSpec, tc: TestCase) -> TestResult:
        start_time = time.perf_counter()

        try:
            record = self.executor.execute(workflow, tc.input_data)
        except Exception as e:
            duration_ms = (time.perf_counter() - start_time) * 1000
            # If unexpected unhandled exception occurred:
            if tc.expect_failure:
                return TestResult(
                    test_case_id=tc.id,
                    name=tc.name,
                    category=tc.category,
                    passed=True,
                    duration_ms=round(duration_ms, 2),
                    expected_output=tc.expected_output,
                    actual_output={"exception": str(e)},
                    failing_node=tc.expected_failure_node,
                    explanation=f"Expected failure condition met via exception: {str(e)}",
                )
            return TestResult(
                test_case_id=tc.id,
                name=tc.name,
                category=tc.category,
                passed=False,
                duration_ms=round(duration_ms, 2),
                expected_output=tc.expected_output,
                actual_output={"exception": str(e)},
                failing_node=tc.expected_failure_node or "engine.executor",
                explanation=f"Engine threw unexpected exception: {str(e)}",
                remediation=tc.remediation_hint
                or "Inspect input structure and node execution handlers.",
            )

        duration_ms = (time.perf_counter() - start_time) * 1000

        # Inspect final outputs
        actual_summary: dict[str, Any] = {}
        for nid, nr in record.node_results.items():
            if nr.status == NodeStatus.FAILED:
                actual_summary["failed_node"] = nid
                actual_summary["node_errors"] = nr.errors
            if "total_revenue" in nr.outputs_summary:
                actual_summary["total_revenue"] = nr.outputs_summary["total_revenue"]
            if nr.row_count_out > 0:
                actual_summary["last_row_count"] = nr.row_count_out

        # Case 1: Test expected a failure/rejection
        if tc.expect_failure:
            # Check if execution failed or skipped downstream due to errors
            has_failed_node = any(
                nr.status in (NodeStatus.FAILED, NodeStatus.SKIPPED)
                for nr in record.node_results.values()
            )
            has_rejections = any(nr.rejected_count > 0 for nr in record.node_results.values())

            if record.status == NodeStatus.FAILED or has_failed_node or has_rejections:
                return TestResult(
                    test_case_id=tc.id,
                    name=tc.name,
                    category=tc.category,
                    passed=True,
                    duration_ms=round(duration_ms, 2),
                    expected_output=tc.expected_output,
                    actual_output=actual_summary,
                    run_record=record,
                    explanation=(
                        "Engine correctly caught edge-case anomaly without unhandled crash."
                    ),
                )
            else:
                return TestResult(
                    test_case_id=tc.id,
                    name=tc.name,
                    category=tc.category,
                    passed=False,
                    duration_ms=round(duration_ms, 2),
                    expected_output=tc.expected_output,
                    actual_output=actual_summary,
                    failing_node=tc.expected_failure_node or "validator",
                    run_record=record,
                    explanation=(
                        f"Expected pipeline to reject edge case at '{tc.expected_failure_node}', "
                        "but pipeline completed successfully without rejecting bad data."
                    ),
                    remediation=tc.remediation_hint
                    or "Ensure validation rules strictly flag invalid records.",
                )

        # Case 2: Happy path or valid edge case
        if record.status == NodeStatus.FAILED:
            failing_node = next(
                (nid for nid, nr in record.node_results.items() if nr.status == NodeStatus.FAILED),
                "unknown",
            )
            return TestResult(
                test_case_id=tc.id,
                name=tc.name,
                category=tc.category,
                passed=False,
                duration_ms=round(duration_ms, 2),
                expected_output=tc.expected_output,
                actual_output=actual_summary,
                failing_node=failing_node,
                run_record=record,
                explanation=f"Node '{failing_node}' failed during execution: {record.errors}",
                remediation=tc.remediation_hint
                or f"Check inputs and configuration for node '{failing_node}'.",
            )

        # Compare outputs with oracle expected metrics
        expected_rev = tc.expected_output.get("total_revenue")
        actual_rev = None
        # Look for report or aggregate node outputs
        for nr in record.node_results.values():
            if "total_revenue" in nr.outputs_summary:
                try:
                    actual_rev = float(nr.outputs_summary["total_revenue"])
                    break
                except (ValueError, TypeError):
                    pass
            elif "table" in nr.outputs and isinstance(nr.outputs["table"], list):
                rows = nr.outputs["table"]
                if rows and isinstance(rows[0], dict) and "total_amount" in rows[0]:
                    actual_rev = round(sum(float(r.get("total_amount", 0.0)) for r in rows), 2)
                    break

        # For workflows without aggregate.monthly_totals, sum the configured numeric column
        # from the last downstream table output (e.g. quality.assert or transform.filter)
        if actual_rev is None and expected_rev is not None:
            from engine.testing.generator import TestCaseGenerator

            _, amount_col, _, _ = TestCaseGenerator._extract_workflow_columns(workflow)
            for nr in reversed(list(record.node_results.values())):
                if nr.status == NodeStatus.SUCCESS and "table" in nr.outputs:
                    rows = nr.outputs["table"]
                    if isinstance(rows, list):
                        if not rows:
                            actual_rev = 0.0
                            break
                        if isinstance(rows[0], dict) and (
                            amount_col in rows[0] or "amount" in rows[0]
                        ):
                            col_key = amount_col if amount_col in rows[0] else "amount"
                            try:
                                actual_rev = round(sum(float(r.get(col_key, 0.0)) for r in rows), 2)
                                actual_summary["total_revenue"] = actual_rev
                                break
                            except (ValueError, TypeError):
                                pass

        if expected_rev is not None:
            if actual_rev is None:
                return TestResult(
                    test_case_id=tc.id,
                    name=tc.name,
                    category=tc.category,
                    passed=False,
                    duration_ms=round(duration_ms, 2),
                    expected_output=tc.expected_output,
                    actual_output=actual_summary,
                    failing_node="aggregate.monthly_totals",
                    run_record=record,
                    explanation=(
                        f"Expected total_revenue of {expected_rev}, "
                        "but no revenue could be computed from workflow output."
                    ),
                    remediation=tc.remediation_hint
                    or "Ensure aggregate.monthly_totals is connected to table output.",
                )
            elif abs(actual_rev - float(expected_rev)) > 0.05:
                return TestResult(
                    test_case_id=tc.id,
                    name=tc.name,
                    category=tc.category,
                    passed=False,
                    duration_ms=round(duration_ms, 2),
                    expected_output=tc.expected_output,
                    actual_output=actual_summary,
                    failing_node="aggregate.monthly_totals",
                    run_record=record,
                    explanation=(
                        f"Revenue calculation mismatch: expected {expected_rev}, "
                        f"actual calculated was {actual_rev}."
                    ),
                    remediation=tc.remediation_hint
                    or "Verify aggregation and filter operations do not omit valid rows.",
                )

        return TestResult(
            test_case_id=tc.id,
            name=tc.name,
            category=tc.category,
            passed=True,
            duration_ms=round(duration_ms, 2),
            expected_output=tc.expected_output,
            actual_output=actual_summary,
            run_record=record,
            explanation="All expected criteria and row counts passed verification.",
        )
