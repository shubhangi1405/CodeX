from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field

from engine.types import RunRecord


class TestCaseCategory(str, Enum):
    HAPPY_PATH = "happy_path"
    EDGE_CASE = "edge_case"
    STRESS = "stress"


TestCaseCategory.__test__ = False  # type: ignore[attr-defined]


class EdgeCaseType(str, Enum):
    EMPTY_FILE = "empty_file"
    MISSING_REQUIRED_COLUMN = "missing_required_column"
    WRONG_TYPES = "wrong_types"
    DUPLICATE_ROWS = "duplicate_rows"
    EXTREME_VALUES = "extreme_values"
    SINGLE_ROW = "single_row"
    OPTIONAL_FIELDS_EMPTY = "optional_fields_empty"
    MALFORMED_ENCODING = "malformed_encoding"


class TestCase(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    __test__ = False

    id: str
    name: str
    description: str
    category: TestCaseCategory = TestCaseCategory.EDGE_CASE
    edge_case_type: Optional[EdgeCaseType] = None
    input_data: dict[str, Any] = Field(default_factory=dict)
    expected_output: dict[str, Any] = Field(default_factory=dict)
    expect_failure: bool = False
    expected_failure_node: Optional[str] = None
    remediation_hint: Optional[str] = None


class TestResult(BaseModel):
    __test__ = False

    test_case_id: str
    name: str
    category: TestCaseCategory
    passed: bool
    duration_ms: float
    expected_output: dict[str, Any] = Field(default_factory=dict)
    actual_output: dict[str, Any] = Field(default_factory=dict)
    failing_node: Optional[str] = None
    explanation: Optional[str] = None
    remediation: Optional[str] = None
    run_record: Optional[RunRecord] = None


class TestSuiteResult(BaseModel):
    __test__ = False

    workflow_id: str
    total_tests: int
    passed_tests: int
    failed_tests: int
    all_passed: bool
    results: list[TestResult]
