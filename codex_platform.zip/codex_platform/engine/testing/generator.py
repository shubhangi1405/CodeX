from typing import Optional

from engine.compiler.domain_profiles import resolve_domain_profile
from engine.spec import WorkflowSpec
from engine.testing.oracle import IndependentOracle
from engine.testing.schemas import EdgeCaseType, TestCase, TestCaseCategory


class TestCaseGenerator:
    """
    Automatically generates comprehensive verification test cases for a workflow:
    - Happy-path test with synthetic sample data.
    - Derived edge cases: empty file, missing required column, wrong types,
      duplicate rows, extreme values, single row, optional fields empty.
    - Expected outputs computed independently via IndependentOracle.
    """

    @classmethod
    def _extract_workflow_columns(cls, workflow: WorkflowSpec) -> tuple[str, str, str, list[str]]:
        """
        Extracts (date_col, amount_col, category_col, required_cols) from workflow node configs.
        Defaults to ('date', 'amount', 'category', ['date', 'amount']) for canonical CSV workflows.
        """
        date_col = "date"
        amount_col = "amount"
        category_col = "category"
        required_cols = ["date", "amount"]

        for n in workflow.nodes:
            if n.type == "validate.required_fields":
                cols = n.config.get("required_columns")
                if isinstance(cols, list) and cols:
                    required_cols = [str(c) for c in cols]
                    if len(required_cols) >= 2:
                        date_col = required_cols[0]
                        amount_col = required_cols[1]
            elif n.type == "validate.type_check":
                col_types = n.config.get("column_types")
                if isinstance(col_types, dict):
                    for col_name, col_type in col_types.items():
                        if col_type == "date":
                            date_col = str(col_name)
                        elif col_type in ("number", "float", "int"):
                            amount_col = str(col_name)
                        elif col_type == "string":
                            category_col = str(col_name)
            elif n.type == "aggregate.monthly_totals":
                if n.config.get("date_column"):
                    date_col = str(n.config["date_column"])
                if n.config.get("amount_column"):
                    amount_col = str(n.config["amount_column"])
            elif n.type == "output.report":
                summary_cols = n.config.get("summary_columns")
                if category_col == "category" and isinstance(summary_cols, list):
                    for sc in summary_cols:
                        sc_str = str(sc)
                        if sc_str not in (
                            date_col,
                            amount_col,
                            "month",
                            "total_amount",
                            "record_count",
                        ):
                            category_col = sc_str
                            break

        return date_col, amount_col, category_col, required_cols

    @classmethod
    def domain_categories(cls, workflow: WorkflowSpec) -> tuple[str, str, str]:
        text = f"{workflow.id} {workflow.name} {workflow.description}".lower()
        profile = resolve_domain_profile(text)
        if profile.domain_id != "csv_monthly_totals":
            return profile.sample_categories
        if any(k in text for k in ["task", "todo", "kanban", "sprint", "project"]):
            return ("Feature Development", "Code Review", "Documentation")
        if any(k in text for k in ["expense", "receipt", "reimburse"]):
            return ("Travel & Flights", "Client Meals", "Hotel & Lodging")
        if any(k in text for k in ["order", "ecommerce", "fulfillment", "invoice"]):
            return ("Express Order", "Standard Parcel", "Enterprise Order")
        if any(k in text for k in ["shift", "payroll", "timesheet", "attendance"]):
            return ("Morning Shift", "Evening Shift", "Weekend On-Call")
        if any(k in text for k in ["inventory", "stock", "warehouse", "sku"]):
            return ("SKU-101 Restock", "SKU-204 Audit", "SKU-309 Dispatch")
        return ("Software", "Hardware", "Services")

    @classmethod
    def build_domain_csv(cls, workflow: WorkflowSpec) -> str:
        date_col, amount_col, category_col, _ = cls._extract_workflow_columns(workflow)
        c1, c2, c3 = cls.domain_categories(workflow)
        text = f"{workflow.id} {workflow.name} {workflow.description}".lower()
        profile = resolve_domain_profile(text)
        header = f"{date_col},{amount_col},{category_col}"
        a1, a2, a3, a4, a5, a6, a7 = profile.sample_amounts
        return (
            f"{header}\n"
            f"2026-01-15,{a1:.2f},{c1}\n"
            f"2026-01-18,{a2:.2f},{c2}\n"
            f"2026-01-22,{a3:.2f},{c1 if profile.domain_id == 'csv_monthly_totals' else c3}\n"
            f"2026-02-05,{a4:.2f},{c3 if profile.domain_id == 'csv_monthly_totals' else c1}\n"
            f"2026-02-14,{a5:.2f},{c2}\n"
            f"2026-03-01,{a6:.2f},{c1}\n"
            f"2026-03-20,{a7:.2f},{c3}\n"
        )

    @classmethod
    def generate_suite(
        cls, workflow: WorkflowSpec, sample_csv: Optional[str] = None
    ) -> list[TestCase]:
        tests: list[TestCase] = []
        c1, c2, c3 = cls.domain_categories(workflow)
        date_col, amount_col, category_col, required_cols = cls._extract_workflow_columns(workflow)
        header = f"{date_col},{amount_col},{category_col}"

        # Find key node IDs
        req_node_id = None
        filter_node_id = None
        read_node_id = None

        for n in workflow.nodes:
            if n.type == "ingest.read_csv":
                read_node_id = n.id
            elif n.type == "validate.required_fields":
                req_node_id = n.id
            elif n.type == "transform.filter":
                filter_node_id = n.id

        # 1. Happy-path test
        happy_csv = (
            sample_csv if sample_csv and sample_csv.strip() else cls.build_domain_csv(workflow)
        )
        oracle_happy = IndependentOracle.calculate_expected_monthly_totals(
            happy_csv,
            required_cols=required_cols,
            date_col=date_col,
            amount_col=amount_col,
        )

        tests.append(
            TestCase(
                id="test-happy-path",
                name=f"Happy Path: Clean Multi-Month Records ({workflow.name[:32]})",
                description=(
                    f"Validates full pipeline flow for '{workflow.name}' from ingest to "
                    "report with valid multi-month records."
                ),
                category=TestCaseCategory.HAPPY_PATH,
                input_data={"file": happy_csv, "file_in": happy_csv},
                expected_output=oracle_happy,
                expect_failure=False,
            )
        )

        # 2. Edge Case: Empty File
        tests.append(
            TestCase(
                id="test-edge-empty-file",
                name="Edge Case: Empty File Ingestion",
                description=(
                    "Verifies the pipeline skips downstream processing gracefully "
                    "when the CSV is empty."
                ),
                category=TestCaseCategory.EDGE_CASE,
                edge_case_type=EdgeCaseType.EMPTY_FILE,
                input_data={"file": "", "file_in": ""},
                expected_output={"valid_rows_count": 0, "empty": True},
                expect_failure=True,
                expected_failure_node=read_node_id,
                remediation_hint=(
                    "Ensure read_csv handles empty strings by skipping downstream "
                    "nodes rather than crashing."
                ),
            )
        )

        # 3. Edge Case: Missing Required Column
        missing_csv = f"{date_col},{category_col}\n2026-01-15,{c1}\n2026-01-18,{c2}\n"
        tests.append(
            TestCase(
                id="test-edge-missing-column",
                name=f"Edge Case: Missing Required Column ({amount_col})",
                description=(
                    "Verifies validation flags schema mismatch when a mandatory column is absent."
                ),
                category=TestCaseCategory.EDGE_CASE,
                edge_case_type=EdgeCaseType.MISSING_REQUIRED_COLUMN,
                input_data={"file": missing_csv, "file_in": missing_csv},
                expected_output={"missing_column": amount_col, "valid_rows_count": 0},
                expect_failure=True,
                expected_failure_node=req_node_id,
                remediation_hint=(
                    f"Verify validate.required_fields rejects input missing '{amount_col}'."
                ),
            )
        )

        # 4. Edge Case: Wrong Types / Corrupted Numbers
        corrupted_csv = (
            f"{header}\n"
            f"2026-01-15,1200.00,{c1}\n"
            f"2026-01-18,NOT_A_NUMBER,{c2}\n"
            f"2026-02-14,450.00,{c2}\n"
        )
        oracle_corrupt = IndependentOracle.calculate_expected_monthly_totals(
            corrupted_csv,
            required_cols=required_cols,
            date_col=date_col,
            amount_col=amount_col,
        )
        tests.append(
            TestCase(
                id="test-edge-wrong-types",
                name="Edge Case: Corrupt Non-Numeric Data",
                description=(
                    "Ensures invalid types are dropped or coerced without "
                    "crashing numerical aggregation."
                ),
                category=TestCaseCategory.EDGE_CASE,
                edge_case_type=EdgeCaseType.WRONG_TYPES,
                input_data={"file": corrupted_csv, "file_in": corrupted_csv},
                expected_output=oracle_corrupt,
                expect_failure=False,
                remediation_hint=(
                    "Validate type_check coercion filters corrupted text before arithmetic sum."
                ),
            )
        )

        # 5. Edge Case: Extreme Values & Negative Numbers
        extreme_csv = (
            f"{header}\n"
            f"2026-01-15,1000.00,{c1}\n"
            "2026-01-20,-500.00,Invalid_Negative\n"
            f"2026-01-25,99999999.00,{c3}\n"
        )
        oracle_extreme = IndependentOracle.calculate_expected_monthly_totals(
            extreme_csv,
            required_cols=required_cols,
            date_col=date_col,
            amount_col=amount_col,
        )
        tests.append(
            TestCase(
                id="test-edge-extreme-values",
                name="Edge Case: Negative Numbers & Extreme Quantities",
                description=(
                    "Tests filter against negative values and large floating-point amounts."
                ),
                category=TestCaseCategory.EDGE_CASE,
                edge_case_type=EdgeCaseType.EXTREME_VALUES,
                input_data={"file": extreme_csv, "file_in": extreme_csv},
                expected_output=oracle_extreme,
                expect_failure=False,
                expected_failure_node=filter_node_id,
                remediation_hint=f"Check filter expression correctly excludes {amount_col} <= 0.",
            )
        )

        # 6. Edge Case: Single Row Boundary Condition
        single_csv = f"{header}\n2026-04-10,750.00,{c3}\n"
        oracle_single = IndependentOracle.calculate_expected_monthly_totals(
            single_csv,
            required_cols=required_cols,
            date_col=date_col,
            amount_col=amount_col,
        )
        tests.append(
            TestCase(
                id="test-edge-single-row",
                name="Edge Case: Single Row Boundary (N=1)",
                description=(
                    "Verifies aggregation and reporting do not fail when given a single record."
                ),
                category=TestCaseCategory.EDGE_CASE,
                edge_case_type=EdgeCaseType.SINGLE_ROW,
                input_data={"file": single_csv, "file_in": single_csv},
                expected_output=oracle_single,
                expect_failure=False,
            )
        )

        # 7. Edge Case: Optional Fields Blank
        blank_optional_csv = f"{header}\n2026-01-15,500.00,\n2026-01-18,600.00,\n"
        oracle_blank = IndependentOracle.calculate_expected_monthly_totals(
            blank_optional_csv,
            required_cols=required_cols,
            date_col=date_col,
            amount_col=amount_col,
        )
        tests.append(
            TestCase(
                id="test-edge-blank-optional-fields",
                name="Edge Case: Empty Optional Fields",
                description=(
                    "Verifies that empty values in optional columns do not cause false "
                    "validation rejections."
                ),
                category=TestCaseCategory.EDGE_CASE,
                edge_case_type=EdgeCaseType.OPTIONAL_FIELDS_EMPTY,
                input_data={"file": blank_optional_csv, "file_in": blank_optional_csv},
                expected_output=oracle_blank,
                expect_failure=False,
            )
        )

        # 8. Edge Case: Duplicate Records
        duplicate_csv = (
            f"{header}\n2026-02-01,100.00,{c1}\n2026-02-01,100.00,{c1}\n2026-02-01,100.00,{c1}\n"
        )
        oracle_dup = IndependentOracle.calculate_expected_monthly_totals(
            duplicate_csv,
            required_cols=required_cols,
            date_col=date_col,
            amount_col=amount_col,
        )
        tests.append(
            TestCase(
                id="test-edge-duplicate-rows",
                name="Edge Case: Duplicate Records Handling",
                description=(
                    "Verifies that identical rows aggregate deterministically "
                    "without unexpected keys."
                ),
                category=TestCaseCategory.EDGE_CASE,
                edge_case_type=EdgeCaseType.DUPLICATE_ROWS,
                input_data={"file": duplicate_csv, "file_in": duplicate_csv},
                expected_output=oracle_dup,
                expect_failure=False,
            )
        )

        return tests
