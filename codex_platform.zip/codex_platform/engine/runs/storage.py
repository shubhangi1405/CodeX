import json
from pathlib import Path
from typing import Any, Optional

from engine.executor import WorkflowExecutor
from engine.spec import WorkflowSpec
from engine.types import RunRecord


class RunStorage:
    """
    Persistent run storage and deterministic replay engine.
    Stores immutable run records and workflow versions.
    Replay test: rerunning with identical inputs must produce record-identical output hash.
    """

    def __init__(self, base_dir: Path | str = "data/runs") -> None:
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self._memory_cache: dict[str, tuple[RunRecord, WorkflowSpec]] = {}

    def save_run(self, record: RunRecord, workflow: WorkflowSpec) -> None:
        self._memory_cache[record.run_id] = (record, workflow)

        run_file = self.base_dir / f"{record.run_id}.json"
        data = {
            "record": record.model_dump(mode="json"),
            "workflow": workflow.model_dump(mode="json"),
        }
        run_file.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def get_run(self, run_id: str) -> Optional[tuple[RunRecord, WorkflowSpec]]:
        if run_id in self._memory_cache:
            return self._memory_cache[run_id]

        run_file = self.base_dir / f"{run_id}.json"
        if not run_file.exists():
            return None

        try:
            raw = json.loads(run_file.read_text(encoding="utf-8"))
            record = RunRecord.model_validate(raw["record"])
            workflow = WorkflowSpec.model_validate(raw["workflow"])
            self._memory_cache[run_id] = (record, workflow)
            return record, workflow
        except Exception:
            return None

    def list_runs(self, workflow_id: Optional[str] = None) -> list[RunRecord]:
        runs: list[RunRecord] = []

        # Read from disk
        for p in self.base_dir.glob("*.json"):
            try:
                raw = json.loads(p.read_text(encoding="utf-8"))
                rec = RunRecord.model_validate(raw["record"])
                if workflow_id is None or rec.workflow_id == workflow_id:
                    runs.append(rec)
            except Exception:
                continue

        # Sort by started_at desc
        runs.sort(key=lambda r: r.started_at, reverse=True)
        return runs

    def replay_run(
        self,
        run_id: str,
        new_inputs: Optional[dict[str, Any]] = None,
        executor: Optional[WorkflowExecutor] = None,
    ) -> tuple[RunRecord, bool]:
        """
        Replays a past run.
        If new_inputs is None:
          Re-runs against the identical input snapshot, verifying bit-for-bit identical output hash.
          Returns (replayed_record, is_bit_for_bit_identical).
        If new_inputs is provided:
          Runs the exact same workflow version on new inputs.
          Returns (new_record, False).
        """
        item = self.get_run(run_id)
        if not item:
            raise ValueError(f"Run ID '{run_id}' not found in storage.")

        past_record, workflow = item
        exec_instance = executor or WorkflowExecutor()

        if new_inputs is None:
            # Deterministic replay with identical input snapshot
            inputs = past_record.input_snapshot or {}
            replayed_record = exec_instance.execute(workflow, inputs)

            # Save the new replay run
            self.save_run(replayed_record, workflow)

            # Bit-for-bit / output hash check
            identical = (
                replayed_record.output_hash == past_record.output_hash
                and replayed_record.input_hash == past_record.input_hash
            )
            return replayed_record, identical
        else:
            # Re-run against new inputs on the same workflow version
            new_record = exec_instance.execute(workflow, new_inputs)
            self.save_run(new_record, workflow)
            return new_record, False
