from abc import ABC, abstractmethod
from typing import Any, Generic, Type, TypeVar

from pydantic import BaseModel

from engine.types import NodeResult, Port

TConfig = TypeVar("TConfig", bound=BaseModel)


class BaseNode(ABC, Generic[TConfig]):
    node_type: str
    category: str
    config_schema: Type[TConfig]
    input_ports: list[Port]
    output_ports: list[Port]
    failure_modes: list[str] = []

    def __init__(self, node_id: str, label: str, raw_config: dict[str, Any]):
        self.node_id = node_id
        self.label = label
        self.config: TConfig = self.config_schema.model_validate(raw_config)

    @abstractmethod
    def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> NodeResult:
        """
        Executes node logic deterministically.
        Must return a NodeResult with outputs, row counts, rejection logs,
        and execution diagnostics.
        """
        pass


class NodeRegistry:
    _registry: dict[str, Type[BaseNode[Any]]] = {}

    @classmethod
    def register(cls, node_cls: Type[BaseNode[Any]]) -> Type[BaseNode[Any]]:
        cls._registry[node_cls.node_type] = node_cls
        return node_cls

    @classmethod
    def get(cls, node_type: str) -> Type[BaseNode[Any]]:
        if node_type not in cls._registry:
            raise KeyError(
                f"Unknown node type '{node_type}'. Registered types: {list(cls._registry.keys())}"
            )
        return cls._registry[node_type]

    @classmethod
    def all_types(cls) -> list[str]:
        return list(cls._registry.keys())

    @classmethod
    def create(
        cls, node_type: str, node_id: str, label: str, config: dict[str, Any]
    ) -> BaseNode[Any]:
        node_cls = cls.get(node_type)
        return node_cls(node_id=node_id, label=label, raw_config=config)
