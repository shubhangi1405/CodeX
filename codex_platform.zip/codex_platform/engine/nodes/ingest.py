import csv
import io
import time
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from engine.registry import BaseNode, NodeRegistry
from engine.types import DataType, NodeResult, NodeStatus, Port


class ReadCSVConfig(BaseModel):
    delimiter: str = ","
    has_header: bool = True
    encoding: str = "utf-8"
    max_rows: int = 100000


@NodeRegistry.register
class ReadCSVNode(BaseNode[ReadCSVConfig]):
    node_type = "ingest.read_csv"
    category = "ingest"
    config_schema = ReadCSVConfig
    input_ports = [Port(name="file", data_type=DataType.FILE)]
    output_ports = [Port(name="table", data_type=DataType.TABLE)]
    failure_modes = [
        "File not found or unreadable",
        "File is completely empty",
        "Invalid CSV delimiter or format",
    ]

    def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> NodeResult:
        start_time = time.perf_counter()
        file_input = inputs.get("file") if inputs.get("file") is not None else inputs.get("file_in")

        if file_input is None:
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=0.0,
                errors=["Input port 'file' is required but received None."],
            )

        # File can be provided as a file path, string content, or bytes
        raw_text = ""
        if isinstance(file_input, (str, Path)) and Path(str(file_input)).exists():
            try:
                raw_text = Path(str(file_input)).read_text(encoding=self.config.encoding)
            except Exception as e:
                return NodeResult(
                    node_id=self.node_id,
                    status=NodeStatus.FAILED,
                    duration_ms=(time.perf_counter() - start_time) * 1000,
                    errors=[f"Failed to read file '{file_input}': {e}"],
                )
        elif isinstance(file_input, bytes):
            raw_text = file_input.decode(self.config.encoding, errors="replace")
        elif isinstance(file_input, str):
            raw_text = file_input
        else:
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=(time.perf_counter() - start_time) * 1000,
                errors=[f"Unsupported file input type: {type(file_input).__name__}"],
            )

        if not raw_text.strip():
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=(time.perf_counter() - start_time) * 1000,
                errors=["Input CSV is empty (0 bytes)."],
            )

        # Parse CSV
        reader = csv.reader(io.StringIO(raw_text), delimiter=self.config.delimiter)
        rows: list[dict[str, Any]] = []
        headers: list[str] = []

        try:
            for row_idx, raw_row in enumerate(reader):
                if not raw_row or all(cell.strip() == "" for cell in raw_row):
                    continue  # Skip empty lines

                if row_idx == 0 and self.config.has_header:
                    headers = [h.strip() for h in raw_row]
                    continue

                if not headers:
                    headers = [f"col_{i}" for i in range(len(raw_row))]

                row_dict = {
                    headers[i]: raw_row[i].strip() if i < len(raw_row) else ""
                    for i in range(len(headers))
                }
                rows.append(row_dict)

                if len(rows) >= self.config.max_rows:
                    break

        except Exception as e:
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=(time.perf_counter() - start_time) * 1000,
                errors=[f"CSV parsing error: {e}"],
            )

        duration = (time.perf_counter() - start_time) * 1000
        return NodeResult(
            node_id=self.node_id,
            status=NodeStatus.SUCCESS,
            duration_ms=round(duration, 2),
            row_count_in=len(rows),
            row_count_out=len(rows),
            rejected_count=0,
            outputs={"table": rows, "table_out": rows},
            inputs_summary={"file": str(file_input)[:100]},
            outputs_summary={"rows": len(rows), "columns": headers},
        )
