import time
from collections import defaultdict
from typing import Any

from pydantic import BaseModel, Field

from engine.registry import BaseNode, NodeRegistry
from engine.types import DataType, NodeResult, NodeStatus, Port


class MonthlyTotalsConfig(BaseModel):
    date_column: str = "date"
    amount_column: str = "amount"
    group_by_columns: list[str] = Field(default_factory=list)


@NodeRegistry.register
class MonthlyTotalsNode(BaseNode[MonthlyTotalsConfig]):
    node_type = "aggregate.monthly_totals"
    category = "aggregate"
    config_schema = MonthlyTotalsConfig
    input_ports = [Port(name="table", data_type=DataType.TABLE)]
    output_ports = [Port(name="table", data_type=DataType.TABLE)]
    failure_modes = [
        "Specified date_column or amount_column not present in table",
        "Invalid non-numeric values in amount column",
    ]

    def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> NodeResult:
        start_time = time.perf_counter()
        raw_table = inputs.get("table") or inputs.get("table_in")
        table: list[dict[str, Any]] = raw_table if raw_table is not None else []

        if not isinstance(table, list):
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=0.0,
                errors=["Input 'table' must be a list of row dicts."],
            )

        if not table:
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.SUCCESS,
                duration_ms=(time.perf_counter() - start_time) * 1000,
                row_count_in=0,
                row_count_out=0,
                outputs={"table": []},
                outputs_summary={"months": 0},
            )

        # Check column existence
        first_row = table[0]
        if self.config.date_column not in first_row:
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=(time.perf_counter() - start_time) * 1000,
                errors=[f"Date column '{self.config.date_column}' not found in table."],
            )
        if self.config.amount_column not in first_row:
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=(time.perf_counter() - start_time) * 1000,
                errors=[f"Amount column '{self.config.amount_column}' not found in table."],
            )

        # Group by YYYY-MM
        monthly_groups: dict[str, list[float]] = defaultdict(list)

        for row in table:
            date_val = str(row.get(self.config.date_column, "")).strip()
            # Extract YYYY-MM
            month_key = date_val[:7] if len(date_val) >= 7 else "Unknown"

            amount_raw = row.get(self.config.amount_column, 0.0)
            try:
                amount_num = float(amount_raw)
            except (ValueError, TypeError):
                amount_num = 0.0

            monthly_groups[month_key].append(amount_num)

        summary_rows: list[dict[str, Any]] = []
        for month in sorted(monthly_groups.keys()):
            amounts = monthly_groups[month]
            total = sum(amounts)
            count = len(amounts)
            avg = total / count if count > 0 else 0.0

            summary_rows.append(
                {
                    "month": month,
                    "total_amount": round(total, 2),
                    "record_count": count,
                    "average_amount": round(avg, 2),
                }
            )

        duration = (time.perf_counter() - start_time) * 1000
        total_rev = round(sum(r["total_amount"] for r in summary_rows), 2)
        return NodeResult(
            node_id=self.node_id,
            status=NodeStatus.SUCCESS,
            duration_ms=round(duration, 2),
            row_count_in=len(table),
            row_count_out=len(summary_rows),
            outputs={"table": summary_rows, "table_out": summary_rows},
            inputs_summary={"input_rows": len(table)},
            outputs_summary={
                "monthly_aggregates": len(summary_rows),
                "total_revenue": total_rev,
            },
        )
