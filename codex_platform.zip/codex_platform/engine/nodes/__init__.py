# Auto-register all node classes
from engine.nodes.aggregate import MonthlyTotalsNode
from engine.nodes.ingest import ReadCSVNode
from engine.nodes.output import ExportCSVNode, ReportNode
from engine.nodes.quality import AssertNode
from engine.nodes.transform import FilterNode
from engine.nodes.validate import RequiredFieldsNode, TypeCheckNode

__all__ = [
    "ReadCSVNode",
    "RequiredFieldsNode",
    "TypeCheckNode",
    "FilterNode",
    "MonthlyTotalsNode",
    "AssertNode",
    "ReportNode",
    "ExportCSVNode",
]
