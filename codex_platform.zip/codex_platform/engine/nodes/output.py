import csv
import io
import time
from typing import Any

from pydantic import BaseModel, Field

from engine.registry import BaseNode, NodeRegistry
from engine.types import DataType, NodeResult, NodeStatus, Port


class ReportConfig(BaseModel):
    title: str = "Executive Data Report"
    chart_type: str = "bar"
    summary_columns: list[str] = Field(default_factory=list)


@NodeRegistry.register
class ReportNode(BaseNode[ReportConfig]):
    node_type = "output.report"
    category = "output"
    config_schema = ReportConfig
    input_ports = [Port(name="table", data_type=DataType.TABLE)]
    output_ports = [Port(name="report", data_type=DataType.REPORT)]
    failure_modes = ["Input table is malformed"]

    def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> NodeResult:
        start_time = time.perf_counter()
        raw_table = inputs.get("table") or inputs.get("table_in")
        table: list[dict[str, Any]] = raw_table if raw_table is not None else []

        if not isinstance(table, list):
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=0.0,
                errors=["Input 'table' must be a list of row dicts."],
            )

        report_payload = {
            "title": self.config.title,
            "chart_type": self.config.chart_type,
            "total_records": len(table),
            "data": table,
        }

        duration = (time.perf_counter() - start_time) * 1000
        return NodeResult(
            node_id=self.node_id,
            status=NodeStatus.SUCCESS,
            duration_ms=round(duration, 2),
            row_count_in=len(table),
            row_count_out=1,
            outputs={"report": report_payload, "report_out": report_payload},
            inputs_summary={"table_rows": len(table)},
            outputs_summary={"report_title": self.config.title, "records": len(table)},
        )


class ExportCSVConfig(BaseModel):
    filename: str = "export.csv"
    protect_formula_injection: bool = True


@NodeRegistry.register
class ExportCSVNode(BaseNode[ExportCSVConfig]):
    node_type = "output.export_csv"
    category = "output"
    config_schema = ExportCSVConfig
    input_ports = [Port(name="table", data_type=DataType.TABLE)]
    output_ports = [Port(name="file", data_type=DataType.FILE)]
    failure_modes = ["Empty dataset or invalid columns"]

    def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> NodeResult:
        start_time = time.perf_counter()
        raw_table = inputs.get("table") or inputs.get("table_in")
        table: list[dict[str, Any]] = raw_table if raw_table is not None else []

        if not isinstance(table, list):
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=0.0,
                errors=["Input 'table' must be a list of row dicts."],
            )

        output_io = io.StringIO()
        if table:
            headers = list(table[0].keys())
            writer = csv.writer(output_io)
            writer.writerow(headers)

            for row in table:
                cleaned_row = []
                for h in headers:
                    val = str(row.get(h, ""))
                    # Formula injection protection: prepend single quote
                    if (
                        self.config.protect_formula_injection
                        and val
                        and val[0] in ("=", "+", "-", "@", "\t", "\r")
                    ):
                        val = f"'{val}"
                    cleaned_row.append(val)
                writer.writerow(cleaned_row)

        csv_content = output_io.getvalue()
        duration = (time.perf_counter() - start_time) * 1000

        return NodeResult(
            node_id=self.node_id,
            status=NodeStatus.SUCCESS,
            duration_ms=round(duration, 2),
            row_count_in=len(table),
            row_count_out=len(table),
            outputs={
                "file": csv_content,
                "file_out": csv_content,
                "filename": self.config.filename,
            },
            inputs_summary={"rows_to_export": len(table)},
            outputs_summary={
                "filename": self.config.filename,
                "bytes": len(csv_content.encode("utf-8")),
            },
        )
