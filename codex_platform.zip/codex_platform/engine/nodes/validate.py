import time
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel

from engine.registry import BaseNode, NodeRegistry
from engine.types import DataType, NodeResult, NodeStatus, Port, RejectedRow


class RequiredFieldsConfig(BaseModel):
    required_columns: list[str]
    rejection_strategy: Literal["drop", "halt"] = "drop"


@NodeRegistry.register
class RequiredFieldsNode(BaseNode[RequiredFieldsConfig]):
    node_type = "validate.required_fields"
    category = "validate"
    config_schema = RequiredFieldsConfig
    input_ports = [Port(name="table", data_type=DataType.TABLE)]
    output_ports = [
        Port(name="valid_table", data_type=DataType.TABLE),
        Port(name="rejected_table", data_type=DataType.TABLE),
    ]
    failure_modes = [
        "Required column does not exist in dataset headers",
        "Required field is null, empty, or whitespace in row",
        "Pipeline halted due to missing field policy",
    ]

    def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> NodeResult:
        start_time = time.perf_counter()
        raw_table = inputs.get("table") or inputs.get("table_in")
        table: list[dict[str, Any]] = raw_table if raw_table is not None else []

        if not isinstance(table, list):
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=0.0,
                errors=[f"Input 'table' must be a list of row dicts, got {type(table).__name__}"],
            )

        # Check if required columns exist in header schema
        if table:
            sample_keys = set(table[0].keys())
            missing_headers = [
                col for col in self.config.required_columns if col not in sample_keys
            ]
            if missing_headers:
                return NodeResult(
                    node_id=self.node_id,
                    status=NodeStatus.FAILED,
                    duration_ms=(time.perf_counter() - start_time) * 1000,
                    errors=[f"Required columns missing from dataset headers: {missing_headers}"],
                )

        valid_rows: list[dict[str, Any]] = []
        rejected_rows: list[RejectedRow] = []

        for idx, row in enumerate(table, start=1):
            missing_in_row = [
                col
                for col in self.config.required_columns
                if row.get(col) is None or str(row.get(col)).strip() == ""
            ]

            if missing_in_row:
                reason = f"Missing required value in column(s): {', '.join(missing_in_row)}"
                rejected_rows.append(RejectedRow(row_index=idx, data=row, reason=reason))
                if self.config.rejection_strategy == "halt":
                    return NodeResult(
                        node_id=self.node_id,
                        status=NodeStatus.FAILED,
                        duration_ms=(time.perf_counter() - start_time) * 1000,
                        row_count_in=len(table),
                        rejected_count=len(rejected_rows),
                        rejected_rows=rejected_rows,
                        errors=[f"Halted at row {idx}: {reason}"],
                    )
            else:
                valid_rows.append(row)

        duration = (time.perf_counter() - start_time) * 1000
        return NodeResult(
            node_id=self.node_id,
            status=NodeStatus.SUCCESS,
            duration_ms=round(duration, 2),
            row_count_in=len(table),
            row_count_out=len(valid_rows),
            rejected_count=len(rejected_rows),
            outputs={
                "valid_table": valid_rows,
                "valid_out": valid_rows,
                "table": valid_rows,  # Default alias
                "rejected_table": [r.data for r in rejected_rows],
                "rejected_out": [r.data for r in rejected_rows],
            },
            rejected_rows=rejected_rows,
            inputs_summary={"total_rows": len(table)},
            outputs_summary={"valid_rows": len(valid_rows), "rejected_rows": len(rejected_rows)},
        )


class TypeCheckConfig(BaseModel):
    column_types: dict[str, str]  # e.g. {"amount": "number", "date": "date"}
    coerce: bool = True
    rejection_strategy: Literal["drop", "halt"] = "drop"


@NodeRegistry.register
class TypeCheckNode(BaseNode[TypeCheckConfig]):
    node_type = "validate.type_check"
    category = "validate"
    config_schema = TypeCheckConfig
    input_ports = [Port(name="table", data_type=DataType.TABLE)]
    output_ports = [
        Port(name="table", data_type=DataType.TABLE),
        Port(name="rejected_table", data_type=DataType.TABLE),
    ]
    failure_modes = [
        "Unparseable numeric value (e.g. non-numeric string)",
        "Unparseable date value (unrecognized format)",
    ]

    def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> NodeResult:
        start_time = time.perf_counter()
        raw_table = inputs.get("table") or inputs.get("table_in")
        table: list[dict[str, Any]] = raw_table if raw_table is not None else []

        if not isinstance(table, list):
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=0.0,
                errors=["Input 'table' must be a list of row dicts."],
            )

        valid_rows: list[dict[str, Any]] = []
        rejected_rows: list[RejectedRow] = []

        for idx, row in enumerate(table, start=1):
            row_copy = dict(row)
            row_error: str | None = None

            for col, expected_type in self.config.column_types.items():
                if col not in row_copy or row_copy[col] is None or row_copy[col] == "":
                    continue  # Null check is handled by RequiredFieldsNode

                val = row_copy[col]

                if expected_type in ("number", "float", "int"):
                    if isinstance(val, (int, float)):
                        continue
                    if self.config.coerce:
                        cleaned = (
                            str(val).replace("$", "").replace("€", "").replace(",", "").strip()
                        )
                        try:
                            row_copy[col] = float(cleaned) if "." in cleaned else int(cleaned)
                        except ValueError:
                            row_error = f"Column '{col}' has invalid number: '{val}'"
                            break
                    else:
                        row_error = f"Column '{col}' is not numeric (type: {type(val).__name__})"
                        break

                elif expected_type == "date":
                    if isinstance(val, (datetime,)):
                        continue
                    if self.config.coerce:
                        date_str = str(val).strip()
                        parsed_date = None
                        date_formats = (
                            "%Y-%m-%d",
                            "%Y/%m/%d",
                            "%d-%m-%Y",
                            "%d/%m/%Y",
                            "%Y-%m-%dT%H:%M:%S",
                        )
                        for fmt in date_formats:
                            try:
                                parsed_date = datetime.strptime(date_str[:19], fmt)
                                break
                            except ValueError:
                                pass
                        if parsed_date:
                            row_copy[col] = parsed_date.strftime("%Y-%m-%d")
                        else:
                            row_error = f"Column '{col}' has unparseable date: '{val}'"
                            break

                elif expected_type == "boolean":
                    if isinstance(val, bool):
                        continue
                    if self.config.coerce:
                        s = str(val).strip().lower()
                        if s in ("true", "1", "yes", "t"):
                            row_copy[col] = True
                        elif s in ("false", "0", "no", "f"):
                            row_copy[col] = False
                        else:
                            row_error = f"Column '{col}' cannot coerce to boolean: '{val}'"
                            break

            if row_error:
                rejected_rows.append(RejectedRow(row_index=idx, data=row, reason=row_error))
                if self.config.rejection_strategy == "halt":
                    return NodeResult(
                        node_id=self.node_id,
                        status=NodeStatus.FAILED,
                        duration_ms=(time.perf_counter() - start_time) * 1000,
                        row_count_in=len(table),
                        rejected_count=len(rejected_rows),
                        rejected_rows=rejected_rows,
                        errors=[f"Halted at row {idx}: {row_error}"],
                    )
            else:
                valid_rows.append(row_copy)

        duration = (time.perf_counter() - start_time) * 1000
        return NodeResult(
            node_id=self.node_id,
            status=NodeStatus.SUCCESS,
            duration_ms=round(duration, 2),
            row_count_in=len(table),
            row_count_out=len(valid_rows),
            rejected_count=len(rejected_rows),
            outputs={
                "table": valid_rows,
                "valid_out": valid_rows,
                "rejected_table": [r.data for r in rejected_rows],
                "rejected_out": [r.data for r in rejected_rows],
            },
            rejected_rows=rejected_rows,
            inputs_summary={"total_rows": len(table)},
            outputs_summary={"valid_rows": len(valid_rows), "rejected_rows": len(rejected_rows)},
        )
