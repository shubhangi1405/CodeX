import time
from typing import Any

from pydantic import BaseModel, Field

from engine.expression import evaluate_expression
from engine.registry import BaseNode, NodeRegistry
from engine.types import DataType, NodeResult, NodeStatus, Port, RejectedRow


class FilterConfig(BaseModel):
    expression: str = Field(
        ..., description="Sandboxed expression evaluated per row, e.g. amount > 0"
    )


@NodeRegistry.register
class FilterNode(BaseNode[FilterConfig]):
    node_type = "transform.filter"
    category = "transform"
    config_schema = FilterConfig
    input_ports = [Port(name="table", data_type=DataType.TABLE)]
    output_ports = [
        Port(name="table", data_type=DataType.TABLE),
        Port(name="rejected_table", data_type=DataType.TABLE),
    ]
    failure_modes = [
        "Expression evaluation error on row fields",
        "Expression syntax error",
    ]

    def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> NodeResult:
        start_time = time.perf_counter()
        raw_table = inputs.get("table") or inputs.get("table_in")
        table: list[dict[str, Any]] = raw_table if raw_table is not None else []

        if not isinstance(table, list):
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=0.0,
                errors=["Input 'table' must be a list of row dicts."],
            )

        matched_rows: list[dict[str, Any]] = []
        filtered_out: list[RejectedRow] = []

        for idx, row in enumerate(table, start=1):
            try:
                passed = bool(evaluate_expression(self.config.expression, row))
                if passed:
                    matched_rows.append(row)
                else:
                    reason = f"Filtered out by rule: {self.config.expression}"
                    filtered_out.append(RejectedRow(row_index=idx, data=row, reason=reason))
            except Exception as e:
                return NodeResult(
                    node_id=self.node_id,
                    status=NodeStatus.FAILED,
                    duration_ms=(time.perf_counter() - start_time) * 1000,
                    errors=[
                        f"Error evaluating filter '{self.config.expression}' on row {idx}: {e}"
                    ],
                )

        duration = (time.perf_counter() - start_time) * 1000
        return NodeResult(
            node_id=self.node_id,
            status=NodeStatus.SUCCESS,
            duration_ms=round(duration, 2),
            row_count_in=len(table),
            row_count_out=len(matched_rows),
            rejected_count=len(filtered_out),
            outputs={
                "table": matched_rows,
                "matched_out": matched_rows,
                "unmatched_out": [r.data for r in filtered_out],
                "rejected_table": [r.data for r in filtered_out],
            },
            rejected_rows=filtered_out,
            inputs_summary={"total_rows": len(table)},
            outputs_summary={"matched_rows": len(matched_rows), "filtered_rows": len(filtered_out)},
        )
