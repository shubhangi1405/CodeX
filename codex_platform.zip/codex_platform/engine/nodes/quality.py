import time
from typing import Any

from pydantic import BaseModel, Field

from engine.expression import evaluate_expression
from engine.registry import BaseNode, NodeRegistry
from engine.types import DataType, NodeResult, NodeStatus, Port


class AssertConfig(BaseModel):
    rule: str = Field(..., description="Assertion condition, e.g. row_count > 0")
    message: str | None = None


@NodeRegistry.register
class AssertNode(BaseNode[AssertConfig]):
    node_type = "quality.assert"
    category = "quality"
    config_schema = AssertConfig
    input_ports = [Port(name="table", data_type=DataType.TABLE)]
    output_ports = [Port(name="table", data_type=DataType.TABLE)]
    failure_modes = [
        "Assertion condition evaluated to False",
        "Expression evaluation error on assertions",
    ]

    def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> NodeResult:
        start_time = time.perf_counter()
        raw_table = inputs.get("table") or inputs.get("table_in")
        table: list[dict[str, Any]] = raw_table if raw_table is not None else []

        # Build context for assertion
        row_count = len(table) if isinstance(table, list) else 0
        eval_ctx: dict[str, Any] = {
            "row_count": row_count,
            "table": table,
            "is_empty": row_count == 0,
        }

        # Calculate helper sums for numeric columns if table is present
        if isinstance(table, list) and table:
            for col in table[0].keys():
                try:
                    vals = [float(r[col]) for r in table if r.get(col) is not None]
                    eval_ctx[f"sum_{col}"] = sum(vals)
                    eval_ctx[f"avg_{col}"] = sum(vals) / len(vals) if vals else 0.0
                except (ValueError, TypeError):
                    pass

        try:
            passed = bool(evaluate_expression(self.config.rule, eval_ctx))
        except Exception as e:
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=(time.perf_counter() - start_time) * 1000,
                errors=[f"Error evaluating assertion rule '{self.config.rule}': {e}"],
            )

        duration = (time.perf_counter() - start_time) * 1000
        if not passed:
            err_msg = self.config.message or (
                f"Assertion failed: rule '{self.config.rule}' evaluated to False "
                f"(row_count={row_count})."
            )
            return NodeResult(
                node_id=self.node_id,
                status=NodeStatus.FAILED,
                duration_ms=round(duration, 2),
                row_count_in=row_count,
                row_count_out=0,
                errors=[err_msg],
                outputs_summary={"assertion": "failed", "rule": self.config.rule},
            )

        return NodeResult(
            node_id=self.node_id,
            status=NodeStatus.SUCCESS,
            duration_ms=round(duration, 2),
            row_count_in=row_count,
            row_count_out=row_count,
            outputs={"table": table, "table_out": table, "passed_out": True},
            inputs_summary={"row_count": row_count},
            outputs_summary={"assertion": "passed", "rule": self.config.rule},
        )
