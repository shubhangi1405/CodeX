from enum import Enum
from typing import Any, Optional

from pydantic import AliasChoices, BaseModel, ConfigDict, Field


class DataType(str, Enum):
    STRING = "string"
    NUMBER = "number"
    BOOLEAN = "boolean"
    DATE = "date"
    TABLE = "table"
    RECORD = "record"
    LIST = "list"
    FILE = "file"
    REPORT = "report"


class ColumnSchema(BaseModel):
    name: str
    data_type: DataType
    required: bool = True
    description: Optional[str] = None


class Port(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    name: str
    data_type: DataType = Field(
        validation_alias=AliasChoices("data_type", "dataType"),
        default=DataType.TABLE,
    )
    table_schema: Optional[list[ColumnSchema]] = None


class NodeStatus(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


class RejectedRow(BaseModel):
    row_index: int
    data: dict[str, Any]
    reason: str


class NodeResult(BaseModel):
    node_id: str
    status: NodeStatus
    duration_ms: float
    row_count_in: int = 0
    row_count_out: int = 0
    rejected_count: int = 0
    outputs: dict[str, Any] = Field(default_factory=dict)
    rejected_rows: list[RejectedRow] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
    inputs_summary: dict[str, Any] = Field(default_factory=dict)
    outputs_summary: dict[str, Any] = Field(default_factory=dict)


class RunRecord(BaseModel):
    run_id: str
    workflow_id: str
    workflow_version: int
    status: NodeStatus
    started_at: str
    completed_at: Optional[str] = None
    total_duration_ms: float = 0.0
    input_hash: str
    output_hash: Optional[str] = None
    input_snapshot: Optional[dict[str, Any]] = None
    node_results: dict[str, NodeResult] = Field(default_factory=dict)
    final_outputs: dict[str, Any] = Field(default_factory=dict)
    errors: list[str] = Field(default_factory=list)
