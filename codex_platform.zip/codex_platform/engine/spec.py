from collections import defaultdict, deque
from typing import Any, Optional

from pydantic import BaseModel, Field

from engine.types import Port


class TriggerSpec(BaseModel):
    id: str
    type: str
    config: dict[str, Any] = Field(default_factory=dict)


class NodeSpec(BaseModel):
    id: str
    type: str
    label: str
    category: str
    config: dict[str, Any] = Field(default_factory=dict)
    input_ports: list[Port] = Field(default_factory=list)
    output_ports: list[Port] = Field(default_factory=list)


class EdgeSpec(BaseModel):
    id: str
    from_node: str
    from_port: str
    to_node: str
    to_port: str


class TestCaseSpec(BaseModel):
    id: str
    name: str
    category: str  # happy_path | edge_case | boundary
    input_snapshot: dict[str, Any]
    expected_output: dict[str, Any] = Field(default_factory=dict)
    expect_failure: bool = False
    expected_failure_node: Optional[str] = None


class WorkflowSpec(BaseModel):
    id: str
    name: str
    version: int = 1
    description: str = ""
    trigger: TriggerSpec
    inputs: list[Port] = Field(default_factory=list)
    nodes: list[NodeSpec]
    edges: list[EdgeSpec]
    outputs: list[Port] = Field(default_factory=list)
    tests: list[TestCaseSpec] = Field(default_factory=list)

    def validate_dag(self) -> None:
        """
        Validates:
        1. Node existence for all edge endpoints.
        2. Graph is a Directed Acyclic Graph (DAG) with zero cycles.
        Raises ValueError with clear diagnostics if validation fails.
        """
        node_ids = {n.id for n in self.nodes}
        for edge in self.edges:
            if edge.from_node not in node_ids:
                raise ValueError(
                    f"Edge '{edge.id}' references unknown source node '{edge.from_node}'."
                )
            if edge.to_node not in node_ids:
                raise ValueError(
                    f"Edge '{edge.id}' references unknown target node '{edge.to_node}'."
                )
            if edge.from_node == edge.to_node:
                raise ValueError(
                    f"Self-loop detected on node '{edge.from_node}' in edge '{edge.id}'."
                )

        # Cycle detection via Kahn's algorithm
        self.get_topological_order()

    def get_topological_order(self) -> list[str]:
        """
        Computes topological ordering using Kahn's algorithm.
        Raises ValueError if a cycle is present.
        """
        in_degree: dict[str, int] = {n.id: 0 for n in self.nodes}
        adj_list: dict[str, list[str]] = defaultdict(list)

        for edge in self.edges:
            adj_list[edge.from_node].append(edge.to_node)
            in_degree[edge.to_node] += 1

        queue: deque[str] = deque([node_id for node_id, deg in in_degree.items() if deg == 0])
        ordered: list[str] = []

        while queue:
            curr = queue.popleft()
            ordered.append(curr)
            for neighbor in adj_list[curr]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        if len(ordered) != len(self.nodes):
            cyclic_nodes = [node_id for node_id, deg in in_degree.items() if deg > 0]
            raise ValueError(f"Workflow contains a directed cycle involving nodes: {cyclic_nodes}.")

        return ordered
