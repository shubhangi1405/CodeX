# CodeX ⚡

> *"Describe it. Verify it. Build it. Replay it."*

**CodeX** turns plain English into working, inspectable, and replayable software. It compiles natural-language instructions into a strictly typed directed acyclic graph (DAG) and an adaptive domain blueprint, executes workflows deterministically on sample data, benchmarks against an independent reference oracle, and scaffolds a complete domain-tailored production application (React frontend + FastAPI backend + SQLite storage).

---

## 🏛️ Architecture: The Two-Layer Guarantee

CodeX is built on a strict **Two-Layer Architecture** where generative AI is never allowed to bypass deterministic execution:

- **Layer 1: Deterministic Core (Source of Truth)**
  - Pure Python workflow engine (`engine/`) with zero web framework dependencies.
  - Closed type system: `string`, `number`, `boolean`, `date`, `table`, `record`, `list<T>`, `file`, `report`.
  - Kahn's algorithm DAG cycle detection, unreachable node checks, and port type validation.
  - Sandboxed AST expression evaluator (zero `eval()` or `exec()`).
  - Immutable run storage with SHA-256 snapshot hashes ensuring **100% bit-for-bit identical deterministic replay**.
  - Independent reference test oracle (pandas/pure-Python) for circularity-free verification.
  - Deterministic Stage D adaptive UI validation (WCAG 2.1 AA contrast adjuster, 8-tuple fingerprint diversity guard, and zero brand/CSV leakage scanner).

- **Layer 2: AI Assistance (Proposer & Assistant)**
  - Interprets plain-English instructions and extracts structured requirements.
  - Generates 4-tiered feature recommendations (Essential, High-Value, Optional, Future).
  - Drafts workflow specifications, `DomainAnalysis`, `AppBlueprint`, and `DesignDirection` via a bounded 3-attempt repair loop.
  - Enables conversational workflow evolution and natural-language visual restyling.
  - Scaffolds complete standalone applications with React + FastAPI + SQLite and exports them as ZIP bundles.

---

## 🚀 Quick Start (One-Command Launch)

### Prerequisites
- **Python**: 3.11+ (Python 3.11, 3.12, or 3.13)
- **Node.js**: 18+ and `npm`

### 1. Clone & Setup
```bash
git clone <repo-url> ghostwriter
cd ghostwriter

# Create Python virtual environment and activate
python -m venv .venv

# On Windows (PowerShell):
.\.venv\Scripts\Activate.ps1
# On macOS/Linux:
source .venv/bin/activate

# Install backend dependencies
pip install -r apps/api/requirements.txt
pip install -e .

# Install frontend dependencies
cd apps/web
npm install
cd ../..
```

### 2. Run Both Frontend and Backend
Use the unified cross-platform runner:
```bash
python scripts/runner.py dev
```
*(Or `make dev` if GNU Make is installed)*

- 🌐 **Web Interface**: [http://localhost:5173](http://localhost:5173)
- 🔌 **API Documentation (Swagger)**: [http://localhost:8000/docs](http://localhost:8000/docs)
- 🏥 **Health Check**: [http://localhost:8000/api/health](http://localhost:8000/api/health)

---

## 🧪 Running Tests & Quality Gates

CodeX maintains a 100% passing quality gate across all linters, typecheckers, and test suites.

Run all gates in a single command:
```bash
python scripts/runner.py check
```

Or run individual gates:
```bash
# Secret Hygiene Scan
python scripts/runner.py secret-scan

# Python & Frontend Linters (Ruff + ESLint)
python scripts/runner.py lint

# Strict Type Checks (Mypy + TypeScript tsc)
python scripts/runner.py typecheck

# Full Test Suites (Pytest 71 tests + Vitest 4 suites)
python scripts/runner.py test
```

---

## 🧭 How CodeX Works (7-Stage Journey)

1. **Prompt & Input**: Type any software or workflow instruction in plain English.
2. **Product Understanding**: CodeX extracts goals, inputs, outputs, rules, and assumptions with provenance tags (`User-Stated`, `Assumption`, `AI Recommendation`), and asks clarification questions if needed.
3. **Feature Recommendations**: Recommends features across 4 tiers (Essential, High-Value, Optional, Future) with S/M/L sizing. Accept, reject, or defer with live spec updates.
4. **Workflow DAG Canvas**: Interactive React Flow diagram layout with Dagre. Inspect nodes, ports, and data schemas with custom typed edge pills.
5. **Independent Testing Suite**: Automatically synthesizes 8 test scenarios (Happy Path, Empty File, Missing Columns, Corrupt Types, Extreme Values, etc.) verified against an independent Python oracle.
6. **Execution, Inspection & Replay**: Execute on sample data, inspect inputs/outputs/rejected rows on any node, and trigger deterministic replay verifying bit-for-bit identical hashes.
7. **Built Application, Adaptive UI & ZIP Export**: Compiles a domain-specific `AppBlueprint` and `DesignDirection` across 17 layout archetypes, 5 navigation shells, and 10 curated design directions, with interactive Restyle / Regenerate Look / Revert Look controls and 1-click ZIP export.

---

## 📁 Repository Structure

```
ghostwriter/
├── apps/
│   ├── api/                 # FastAPI REST API & routes
│   │   ├── routes/          # compiler, workflows, runs, tests, recommendations, generate
│   │   ├── database.py      # SQLite connection & session engine
│   │   └── main.py          # Application entrypoint & CORS setup
│   └── web/                 # React 18 + Vite + Tailwind frontend
│       ├── src/
│       │   ├── components/  # React Flow DAG canvas, drawers, and screen views
│       │   ├── stores/      # Zustand client state management
│       │   └── api/         # API client & configuration
│       └── vite.config.ts   # Vite configuration with vendor chunking
├── engine/                  # Deterministic Layer 1 workflow engine (pure Python)
│   ├── compiler/            # Natural language compiler, repair loop, providers
│   ├── nodes/               # Vetted node library (ingest, validate, transform, aggregate, output, quality)
│   ├── recommender/         # 4-tier recommendation engine
│   ├── runs/                # Immutable storage & deterministic replay
│   ├── testing/             # Independent oracle, test generator, test runner
│   ├── versioning/          # Workflow diff & version manager
│   ├── executor.py          # Topological DAG executor
│   ├── expression.py        # Sandboxed AST expression evaluator
│   ├── registry.py          # Node registry
│   ├── spec.py              # Pydantic v2 workflow specifications
│   └── types.py             # Closed type system & node models
├── generators/              # Complete built software scaffolding
│   ├── app_generator.py     # Generates standalone runnable apps
│   └── templates/           # FastAPI, React, SQLite templates
├── samples/                 # Canonical sample datasets (monthly_sales.csv)
├── docs/                    # ARCHITECTURE.md, API.md, DECISIONS.md, ERRORS.md
├── scripts/                 # runner.py cross-platform task runner
└── pyproject.toml           # Tool configs (ruff, mypy, pytest)
```

---

## 🔒 Security Posture

- **Sandboxed Expression Language**: Custom AST evaluator blocks `__class__`, `__subclasses__`, dunder attributes, attribute lookups on private members, and dangerous built-ins.
- **CSV Formula Injection Prevention**: Export CSV nodes automatically prepend single quotes (`'`) to any cell beginning with `=`, `+`, `-`, `@`, or `\t`.
- **Zero Arbitrary Execution**: Node library is closed and strictly registered. No model-generated arbitrary code execution is permitted inside the engine core.
- **Environment Isolation**: API keys are read strictly from environment variables on the backend and are never exposed to the client.

---

## 📖 Documentation
- [Architecture & Guarantees](docs/ARCHITECTURE.md)
- [REST API Specification](docs/API.md)
- [Design Decisions & Tradeoffs](docs/DECISIONS.md)
- [Error Taxonomy & Failure Modes](docs/ERRORS.md)
- [Performance & Benchmarks](docs/PERFORMANCE.md)
