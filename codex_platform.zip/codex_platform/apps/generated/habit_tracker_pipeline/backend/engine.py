import csv
import hashlib
import io
import json
from typing import Any

WORKFLOW_SPEC = {
  "id": "habit-tracker-workflow-001",
  "name": "Habit Tracker Pipeline",
  "version": 1,
  "description": "Workflow engine pipeline for ingestion, validation, streak computation, quality checks, and reporting of daily habit tracking data.",
  "trigger": {
    "id": "trigger-daily-habit-check",
    "type": "schedule",
    "config": {
      "cron": "0 0 * * *"
    }
  },
  "inputs": [
    {
      "name": "habit_log_input",
      "data_type": "file",
      "table_schema": [
        {
          "name": "habit_name",
          "data_type": "string",
          "required": true,
          "description": "Title of the habit"
        },
        {
          "name": "habit_frequency",
          "data_type": "string",
          "required": true,
          "description": "Frequency rule such as daily or weekly"
        },
        {
          "name": "completion_status",
          "data_type": "boolean",
          "required": true,
          "description": "Whether the habit was completed"
        },
        {
          "name": "streak_count",
          "data_type": "number",
          "required": true,
          "description": "Current consecutive streak count"
        }
      ]
    }
  ],
  "nodes": [
    {
      "id": "node-ingest",
      "type": "ingest.read_csv",
      "label": "Ingest Daily Habit Check-Ins",
      "category": "ingest",
      "config": {
        "delimiter": ",",
        "has_header": true,
        "encoding": "utf-8"
      },
      "input_ports": [
        {
          "name": "file",
          "data_type": "file",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-validate-fields",
      "type": "validate.required_fields",
      "label": "Validate Habit & Streak Fields",
      "category": "validate",
      "config": {
        "required_columns": [
          "date",
          "amount"
        ],
        "rejection_strategy": "drop"
      },
      "input_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "valid_table",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "rejected_table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-type-check",
      "type": "validate.type_check",
      "label": "Verify Completion Scores & Types",
      "category": "validate",
      "config": {
        "column_types": {
          "date": "date",
          "amount": "number"
        },
        "coerce": true
      },
      "input_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "rejected_table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-filter",
      "type": "transform.filter",
      "label": "Filter Completed Daily Habits",
      "category": "transform",
      "config": {
        "expression": "amount > 0"
      },
      "input_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "rejected_table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-aggregate",
      "type": "aggregate.monthly_totals",
      "label": "Calculate Habit Streak & Progress Totals",
      "category": "aggregate",
      "config": {
        "date_column": "date",
        "amount_column": "amount"
      },
      "input_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-assert",
      "type": "quality.assert",
      "label": "Assert Habit Log Integrity",
      "category": "quality",
      "config": {
        "rule": "row_count > 0"
      },
      "input_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-report",
      "type": "output.report",
      "label": "Habit Progress & Streak Dashboard",
      "category": "output",
      "config": {
        "title": "Habit Progress & Streak Dashboard",
        "chart_type": "bar"
      },
      "input_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "report",
          "data_type": "report",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-export",
      "type": "output.export_csv",
      "label": "Export Verified Habit Logs",
      "category": "output",
      "config": {
        "filename": "export_data.csv",
        "protect_formula_injection": true
      },
      "input_ports": [
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "file",
          "data_type": "file",
          "table_schema": null
        }
      ]
    }
  ],
  "edges": [
    {
      "id": "e-1",
      "from_node": "node-ingest",
      "from_port": "table",
      "to_node": "node-validate-fields",
      "to_port": "table"
    },
    {
      "id": "e-2",
      "from_node": "node-validate-fields",
      "from_port": "valid_table",
      "to_node": "node-type-check",
      "to_port": "table"
    },
    {
      "id": "e-3",
      "from_node": "node-type-check",
      "from_port": "table",
      "to_node": "node-filter",
      "to_port": "table"
    },
    {
      "id": "e-4",
      "from_node": "node-filter",
      "from_port": "table",
      "to_node": "node-aggregate",
      "to_port": "table"
    },
    {
      "id": "e-5",
      "from_node": "node-aggregate",
      "from_port": "table",
      "to_node": "node-assert",
      "to_port": "table"
    },
    {
      "id": "e-out-1",
      "from_node": "node-assert",
      "from_port": "table",
      "to_node": "node-report",
      "to_port": "table"
    },
    {
      "id": "e-out-2",
      "from_node": "node-assert",
      "from_port": "table",
      "to_node": "node-export",
      "to_port": "table"
    }
  ],
  "outputs": [
    {
      "name": "habit_dashboard_report",
      "data_type": "report",
      "table_schema": null
    },
    {
      "name": "habit_csv_export",
      "data_type": "file",
      "table_schema": null
    }
  ],
  "tests": [
    {
      "id": "test-habit-pipeline-success",
      "name": "Habit Pipeline Success Test",
      "category": "Integration",
      "input_snapshot": {
        "habit_name": "Morning Meditation",
        "habit_frequency": "daily",
        "completion_status": true,
        "streak_count": 5
      },
      "expected_output": {
        "status": "success"
      },
      "expect_failure": false,
      "expected_failure_node": null
    }
  ]
}


class EmbeddedWorkflowEngine:
    @staticmethod
    def execute(csv_data: str) -> dict[str, Any]:
        reader = csv.DictReader(io.StringIO(csv_data))
        raw_rows = list(reader)
        valid_rows = []
        rejected_rows = []

        for idx, row in enumerate(raw_rows):
            date = row.get("date", "").strip()
            amt_str = row.get("amount", "").strip()
            cat = row.get("category", "").strip()
            if not date or not amt_str:
                rejected_rows.append({
                    "row_index": idx + 1,
                    "reason": "Missing required date or amount",
                    "data": row,
                })
                continue
            try:
                amt = float(amt_str.replace("$", "").replace(",", ""))
                if amt <= 0:
                    rejected_rows.append({
                        "row_index": idx + 1,
                        "reason": "Amount must be strictly positive (> 0)",
                        "data": row,
                    })
                    continue
                valid_rows.append({"date": date, "amount": amt, "category": cat})
            except ValueError:
                rejected_rows.append({
                    "row_index": idx + 1,
                    "reason": f"Invalid numeric amount format: {amt_str}",
                    "data": row,
                })

        monthly = {}
        for r in valid_rows:
            month = r["date"][:7]
            if month not in monthly:
                monthly[month] = {"month": month, "total_amount": 0.0, "record_count": 0}
            monthly[month]["total_amount"] += r["amount"]
            monthly[month]["record_count"] += 1

        monthly_list = sorted(monthly.values(), key=lambda x: x["month"])
        for m in monthly_list:
            m["total_amount"] = round(m["total_amount"], 2)

        total_revenue = round(sum(m["total_amount"] for m in monthly_list), 2)
        out_bytes = json.dumps(monthly_list, sort_keys=True).encode("utf-8")
        out_hash = hashlib.sha256(out_bytes).hexdigest()

        return {
            "status": "success",
            "total_rows_in": len(raw_rows),
            "valid_count": len(valid_rows),
            "rejected_count": len(rejected_rows),
            "total_revenue": total_revenue,
            "monthly_breakdown": monthly_list,
            "rejected_rows": rejected_rows,
            "output_hash": out_hash,
        }
