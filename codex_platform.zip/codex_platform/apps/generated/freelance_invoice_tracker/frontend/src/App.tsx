import React, { useEffect, useState } from 'react';
import {
  AdaptiveAppShell,
  AdaptiveLayoutRenderer,
  Button,
  FormField,
  Input,
  Modal,
  Select,
  Toast,
  EntityRecord,
  EntitySpecData,
  PageSpecData,
} from './ui_kit';

const BLUEPRINT = {
  "app_name": "FolioNote Billing",
  "product_tagline": "Formal client invoice statements, retainer milestones, and aging receivables",
  "domain": {
    "product_kind": "Independent Consultant & Freelance Client Invoice Ledger",
    "archetype": "finance_ledger",
    "audience": {
      "who": "Independent designers, software consultants, and boutique studio principals",
      "context_of_use": "Desktop billing review and client statement dispatch",
      "device_likely_used": "desktop",
      "tech_comfort": "high"
    },
    "core_jobs": [
      "Draft and inspect itemized client invoice documents ready for dispatch",
      "Track overdue retainers, paid milestones, and tax withholding in the ledger",
      "Log billable project retainers and client payment terms"
    ],
    "primary_object": "client_invoice",
    "tone": "authoritative",
    "data_shape": "document",
    "needs_automation": false,
    "rationale": "Freelancers issuing formal client statements need a document-first invoice composer and crisp aging ledger rather than a generic chart dashboard."
  },
  "entities": [
    {
      "name": "client_invoice",
      "singular_label": "Client Invoice",
      "plural_label": "Client Invoices",
      "fields": [
        {
          "name": "invoice_number",
          "label": "Invoice Number",
          "field_type": "string",
          "required": true,
          "unique": true,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "client_organization",
          "label": "Client Organization",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "engagement_scope",
          "label": "Milestone / Deliverable Scope",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "due_date",
          "label": "Payment Due Date",
          "field_type": "date",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "invoice_amount",
          "label": "Invoice Total",
          "field_type": "currency",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "payment_state",
          "label": "Settlement Status",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Paid in Full",
            "Sent - Net 15",
            "Overdue Follow-Up",
            "Draft"
          ],
          "default_value": null
        }
      ],
      "relationships": []
    },
    {
      "name": "client_retainer",
      "singular_label": "Client Retainer",
      "plural_label": "Client Retainers",
      "fields": [
        {
          "name": "client_name",
          "label": "Client Account",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "billing_cadence",
          "label": "Billing Cadence",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Monthly Retainer",
            "Fixed Milestone",
            "Hourly Advisory"
          ],
          "default_value": null
        },
        {
          "name": "monthly_cap",
          "label": "Contract Value",
          "field_type": "currency",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        }
      ],
      "relationships": []
    }
  ],
  "pages": [
    {
      "id": "invoice-statements",
      "title": "Client Invoice Statements",
      "route": "/invoice-statements",
      "layout": "report_document",
      "entities_used": [
        "client_invoice"
      ],
      "primary_actions": [
        "Issue New Invoice",
        "Mark Paid in Full"
      ],
      "empty_state": {
        "headline": "No Client Invoices Issued Yet",
        "body": "Draft your first formal milestone or retainer invoice with Net-15 payment terms and itemized scope.",
        "cta_label": "Draft First Client Invoice",
        "cta_action_id": "create_client_invoice"
      }
    },
    {
      "id": "receivables-ledger",
      "title": "Receivables Aging Ledger",
      "route": "/receivables-ledger",
      "layout": "data_table_with_filters",
      "entities_used": [
        "client_invoice"
      ],
      "primary_actions": [
        "Filter Overdue",
        "Issue New Invoice"
      ],
      "empty_state": {
        "headline": "Receivables Ledger Is Clear",
        "body": "Issued invoices and settlement dates will be tracked in this table.",
        "cta_label": "Add Invoice Entry",
        "cta_action_id": "create_client_invoice"
      }
    },
    {
      "id": "active-retainers",
      "title": "Client Retainer Agreements",
      "route": "/active-retainers",
      "layout": "single_form",
      "entities_used": [
        "client_retainer"
      ],
      "primary_actions": [
        "Register Retainer Agreement"
      ],
      "empty_state": {
        "headline": "No Active Retainer Contracts",
        "body": "Record a recurring client retainer or fixed-fee advisory agreement.",
        "cta_label": "Add Client Retainer",
        "cta_action_id": "create_client_retainer"
      }
    }
  ],
  "navigation": {
    "pattern": "split_master_detail",
    "items": [
      {
        "page_id": "invoice-statements",
        "label": "Invoice Statements",
        "icon": "file-text"
      },
      {
        "page_id": "receivables-ledger",
        "label": "Aging Ledger",
        "icon": "dollar-sign"
      },
      {
        "page_id": "active-retainers",
        "label": "Retainers",
        "icon": "briefcase"
      }
    ]
  },
  "home_page_id": "invoice-statements",
  "automations": []
} as const;
const DESIGN_DIRECTION = {
  "direction_id": "civic_formal",
  "palette": {
    "primary": "#7F1D1D",
    "primary_foreground": "#FFFFFF",
    "accent": "#1E3A8A",
    "neutral_ramp": [
      "#FFFFFF",
      "#F5F5F5",
      "#E5E5E5",
      "#D4D4D4",
      "#A3A3A3",
      "#737373",
      "#525252",
      "#262626",
      "#0A0A0A"
    ],
    "surface": "#FFFFFF",
    "surface_elevated": "#FAFAFA",
    "border": "#525252",
    "text": "#0A0A0A",
    "text_muted": "#404040",
    "focus_ring": "#7F1D1D",
    "success": "#146C43",
    "warning": "#854D0E",
    "danger": "#991B1B"
  },
  "color_mode": "both",
  "typography": {
    "heading_font": "Merriweather",
    "body_font": "Public Sans",
    "mono_font": "IBM Plex Mono",
    "scale_ratio": 1.25
  },
  "shape": {
    "radius_class": "sharp",
    "border_style": "crisp",
    "shadow_style": "none"
  },
  "density": "spacious",
  "motion": "none",
  "iconography": "outline",
  "brand_mark": {
    "kind": "wordmark",
    "glyph_primitive": "book_open",
    "monogram_letters": "FN"
  },
  "copy_voice": "Authoritative, institutional, plain-language guidance with explicit rules.",
  "rationale": "Authoritative Merriweather serif headings, sharp document borders, and deep crimson seals make freelance invoices look like institutional legal statements."
} as const;
const SAMPLE_SEED_DATA: Record<string, EntityRecord[]> = {
  "client_invoice": [
    {
      "id": "inv-2041",
      "invoice_number": "INV-2026-041",
      "client_organization": "Kestrel Robotics Corp.",
      "engagement_scope": "Phase 2 Design System & Telemetry UI Architecture",
      "due_date": "2026-10-28",
      "invoice_amount": 12500.0,
      "payment_state": "Sent - Net 15"
    },
    {
      "id": "inv-2039",
      "invoice_number": "INV-2026-039",
      "client_organization": "Northstar BioLabs",
      "engagement_scope": "September Advisory Retainer & Assay Portal Audit",
      "due_date": "2026-10-05",
      "invoice_amount": 6800.0,
      "payment_state": "Paid in Full"
    },
    {
      "id": "inv-2036",
      "invoice_number": "INV-2026-036",
      "client_organization": "Vellum Publishing House",
      "engagement_scope": "Editorial Search & Typography Migration Milestone",
      "due_date": "2026-09-30",
      "invoice_amount": 4200.0,
      "payment_state": "Overdue Follow-Up"
    }
  ],
  "client_retainer": [
    {
      "id": "ret-1",
      "client_name": "Kestrel Robotics Corp.",
      "billing_cadence": "Monthly Retainer",
      "monthly_cap": 10000.0
    }
  ]
};
const BRAND_SVG_MARKUP = "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M3 6C3 6 7 4.5 12 6.5C17 4.5 21 6 21 6V18.5C21 18.5 17 17 12 19C7 17 3 18.5 3 18.5V6Z\" stroke=\"currentColor\" stroke-width=\"2\" fill=\"none\"/><line x1=\"12\" y1=\"6.5\" x2=\"12\" y2=\"19\" stroke=\"currentColor\" stroke-width=\"1.8\"/></svg>";
const NUMERIC_TYPES = new Set(['integer', 'float', 'currency']);

export default function App(): React.ReactElement {
  const [activePageId, setActivePageId] = useState<string>(BLUEPRINT.home_page_id);
  const [recordsByEntity, setRecordsByEntity] = useState<Record<string, EntityRecord[]>>(() => {
    const initial: Record<string, EntityRecord[]> = {};
    for (const ent of BLUEPRINT.entities) {
      initial[ent.name] = [];
    }
    return initial;
  });
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formState, setFormState] = useState<Record<string, string | number | boolean>>({});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const pages = BLUEPRINT.pages as unknown as PageSpecData[];
  const entities = BLUEPRINT.entities as unknown as EntitySpecData[];
  const activePage = pages.find((p) => p.id === activePageId) || pages[0];
  const primaryEntityName = activePage.entities_used[0] || entities[0].name;
  const activeEntity = entities.find((e) => e.name === primaryEntityName) || entities[0];
  const activeRecords = recordsByEntity[activeEntity.name] || [];

  useEffect(() => {
    for (const ent of entities) {
      fetch(`/api/${ent.name}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data: EntityRecord[] | null) => {
          if (Array.isArray(data) && data.length > 0) {
            setRecordsByEntity((prev) => ({ ...prev, [ent.name]: data }));
          }
        })
        .catch(() => {
          // Offline mode uses in-memory state
        });
    }
  }, []);

  const openCreateModal = (): void => {
    const defaults: Record<string, string | number | boolean> = {};
    for (const fld of activeEntity.fields) {
      if (fld.field_type === 'boolean') {
        defaults[fld.name] = Boolean(fld.default_value ?? false);
      } else if (NUMERIC_TYPES.has(fld.field_type)) {
        defaults[fld.name] = Number(fld.default_value ?? 0);
      } else if (fld.field_type === 'enum' && fld.enum_values && fld.enum_values.length > 0) {
        defaults[fld.name] = fld.enum_values[0];
      } else {
        defaults[fld.name] = String(fld.default_value ?? '');
      }
    }
    setFormState(defaults);
    setIsModalOpen(true);
  };

  const handleCreateRecord = (): void => {
    const newRecord: EntityRecord = {
      id: `${activeEntity.name}-${Date.now()}`,
      ...formState,
    };
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: [newRecord, ...(prev[activeEntity.name] || [])],
    }));
    fetch(`/api/${activeEntity.name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formState),
    }).catch(() => undefined);
    setIsModalOpen(false);
    setToastMsg(`Saved ${activeEntity.singular_label}`);
  };

  const handleLoadSampleSeedData = (): void => {
    setRecordsByEntity(SAMPLE_SEED_DATA);
    fetch('/api/seed', { method: 'POST' }).catch(() => undefined);
    setToastMsg('Loaded domain sample records');
  };

  const handleDeleteRecord = (recordId: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).filter((r) => String(r.id) !== recordId),
    }));
    fetch(`/api/${activeEntity.name}/${recordId}`, {
      method: 'DELETE',
    }).catch(() => undefined);
    setToastMsg(`Removed ${activeEntity.singular_label}`);
  };

  const handleToggleBoolean = (recordId: string, fieldName: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).map((r) =>
        String(r.id) === recordId ? { ...r, [fieldName]: !r[fieldName] } : r
      ),
    }));
  };

  return (
    <div className="min-h-screen bg-surface text-text font-body">
      <AdaptiveAppShell
        pattern={BLUEPRINT.navigation.pattern}
        appName={BLUEPRINT.app_name}
        tagline={BLUEPRINT.product_tagline}
        brandMark={
          <span
            className="inline-flex items-center"
            dangerouslySetInnerHTML={{ __html: BRAND_SVG_MARKUP }}
          />
        }
        navItems={BLUEPRINT.navigation.items.map((item) => ({
          page_id: item.page_id,
          label: item.label,
          icon: item.icon,
        }))}
        activePageId={activePage.id}
        onSelectPage={setActivePageId}
        primaryAction={
          <div className="flex items-center gap-2">
            {activeRecords.length === 0 && (
              <Button variant="secondary" onClick={handleLoadSampleSeedData}>
                Load Sample Data
              </Button>
            )}
            <Button variant="primary" onClick={openCreateModal}>
              + {activePage.primary_actions[0] || `New ${activeEntity.singular_label}`}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {toastMsg && (
            <div className="flex justify-between items-center">
              <Toast message={toastMsg} tone="success" />
              <Button variant="ghost" onClick={() => setToastMsg(null)}>Dismiss</Button>
            </div>
          )}
          <AdaptiveLayoutRenderer
            page={activePage}
            entity={activeEntity}
            records={activeRecords}
            onOpenCreate={openCreateModal}
            onDeleteRecord={handleDeleteRecord}
            onToggleBoolean={handleToggleBoolean}
          />
        </div>
      </AdaptiveAppShell>

      <Modal
        open={isModalOpen}
        title={`Add ${activeEntity.singular_label}`}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-3">
          {activeEntity.fields.map((fld) => (
            <FormField key={fld.name} label={fld.label} required={fld.required}>
              {fld.field_type === 'enum' && fld.enum_values ? (
                <Select
                  value={String(formState[fld.name] ?? fld.enum_values[0] ?? '')}
                  options={fld.enum_values.map((v) => ({ value: v, label: v }))}
                  onChange={(val) => setFormState((prev) => ({ ...prev, [fld.name]: val }))}
                />
              ) : (
                <Input
                  type={
                    NUMERIC_TYPES.has(fld.field_type)
                      ? 'number'
                      : fld.field_type === 'date'
                        ? 'date'
                        : 'text'
                  }
                  value={String(formState[fld.name] ?? '')}
                  placeholder={`Enter ${fld.label}`}
                  onChange={(val) =>
                    setFormState((prev) => ({
                      ...prev,
                      [fld.name]: NUMERIC_TYPES.has(fld.field_type) ? Number(val) : val,
                    }))
                  }
                />
              )}
            </FormField>
          ))}
          <div className="flex justify-end gap-2 pt-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCreateRecord}>
              Save {activeEntity.singular_label}
            </Button>
          </div>
        </div>
      </Modal>
      
    </div>
  );
}
