"""FastAPI backend for FolioNote Billing — Formal client invoice statements, retainer milestones, and aging receivables."""

import json
from typing import Any, Optional
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import ClientInvoiceModel, ClientRetainerModel
from seed import seed_database

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='FolioNote Billing',
    description='Formal client invoice statements, retainer milestones, and aging receivables',
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ClientInvoiceCreate(BaseModel):
    invoice_number: str = ''
    client_organization: str = ''
    engagement_scope: str = ''
    due_date: str = ''
    invoice_amount: float = 0.0
    payment_state: str = 'Paid in Full'

class ClientInvoiceUpdate(BaseModel):
    invoice_number: Optional[str] = None
    client_organization: Optional[str] = None
    engagement_scope: Optional[str] = None
    due_date: Optional[str] = None
    invoice_amount: Optional[float] = None
    payment_state: Optional[str] = None

def _serialize_client_invoice(item: ClientInvoiceModel) -> dict[str, Any]:
    return {"id": item.id, "invoice_number": getattr(item, "invoice_number"), "client_organization": getattr(item, "client_organization"), "engagement_scope": getattr(item, "engagement_scope"), "due_date": getattr(item, "due_date"), "invoice_amount": getattr(item, "invoice_amount"), "payment_state": getattr(item, "payment_state")}

@app.get("/api/client_invoice")
def list_client_invoice(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(ClientInvoiceModel).order_by(ClientInvoiceModel.created_at.desc()).all()
    return [_serialize_client_invoice(r) for r in rows]

@app.post("/api/client_invoice", status_code=201)
def create_client_invoice(
    payload: ClientInvoiceCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = ClientInvoiceModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_client_invoice(record)

@app.put("/api/client_invoice/{item_id}")
def update_client_invoice(
    item_id: str, payload: ClientInvoiceUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(ClientInvoiceModel).filter(ClientInvoiceModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Client Invoice not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_client_invoice(record)

@app.delete("/api/client_invoice/{item_id}")
def delete_client_invoice(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(ClientInvoiceModel).filter(ClientInvoiceModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Client Invoice not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class ClientRetainerCreate(BaseModel):
    client_name: str = ''
    billing_cadence: str = 'Monthly Retainer'
    monthly_cap: float = 0.0

class ClientRetainerUpdate(BaseModel):
    client_name: Optional[str] = None
    billing_cadence: Optional[str] = None
    monthly_cap: Optional[float] = None

def _serialize_client_retainer(item: ClientRetainerModel) -> dict[str, Any]:
    return {"id": item.id, "client_name": getattr(item, "client_name"), "billing_cadence": getattr(item, "billing_cadence"), "monthly_cap": getattr(item, "monthly_cap")}

@app.get("/api/client_retainer")
def list_client_retainer(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(ClientRetainerModel).order_by(ClientRetainerModel.created_at.desc()).all()
    return [_serialize_client_retainer(r) for r in rows]

@app.post("/api/client_retainer", status_code=201)
def create_client_retainer(
    payload: ClientRetainerCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = ClientRetainerModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_client_retainer(record)

@app.put("/api/client_retainer/{item_id}")
def update_client_retainer(
    item_id: str, payload: ClientRetainerUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(ClientRetainerModel).filter(ClientRetainerModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Client Retainer not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_client_retainer(record)

@app.delete("/api/client_retainer/{item_id}")
def delete_client_retainer(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(ClientRetainerModel).filter(ClientRetainerModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Client Retainer not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

@app.post("/api/seed")
def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:
    inserted = seed_database(db)
    return {"status": "seeded", "inserted": inserted}

@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {
        "status": "healthy",
        "app": 'FolioNote Billing',
        "archetype": 'finance_ledger',
    }
