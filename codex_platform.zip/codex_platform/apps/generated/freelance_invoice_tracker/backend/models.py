"""Domain SQLAlchemy ORM models for FolioNote Billing."""

from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from database import Base

class ClientInvoiceModel(Base):
    __tablename__ = "client_invoices"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    invoice_number = Column(String, nullable=False, default='')
    client_organization = Column(String, nullable=False, default='')
    engagement_scope = Column(String, nullable=False, default='')
    due_date = Column(String, nullable=False, default='')
    invoice_amount = Column(Float, nullable=False, default=0.0)
    payment_state = Column(String, nullable=False, default='Paid in Full')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class ClientRetainerModel(Base):
    __tablename__ = "client_retainers"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    client_name = Column(String, nullable=False, default='')
    billing_cadence = Column(String, nullable=False, default='Monthly Retainer')
    monthly_cap = Column(Float, nullable=False, default=0.0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
