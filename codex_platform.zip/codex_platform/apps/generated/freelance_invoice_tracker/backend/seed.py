"""Optional sample seed data loader for FolioNote Billing."""

import json
from sqlalchemy.orm import Session
from database import Base, SessionLocal, engine
from models import ClientInvoiceModel, ClientRetainerModel

SAMPLE_SEED_DATA = json.loads(r'''{
  "client_invoice": [
    {
      "id": "inv-2041",
      "invoice_number": "INV-2026-041",
      "client_organization": "Kestrel Robotics Corp.",
      "engagement_scope": "Phase 2 Design System & Telemetry UI Architecture",
      "due_date": "2026-10-28",
      "invoice_amount": 12500.0,
      "payment_state": "Sent - Net 15"
    },
    {
      "id": "inv-2039",
      "invoice_number": "INV-2026-039",
      "client_organization": "Northstar BioLabs",
      "engagement_scope": "September Advisory Retainer & Assay Portal Audit",
      "due_date": "2026-10-05",
      "invoice_amount": 6800.0,
      "payment_state": "Paid in Full"
    },
    {
      "id": "inv-2036",
      "invoice_number": "INV-2026-036",
      "client_organization": "Vellum Publishing House",
      "engagement_scope": "Editorial Search & Typography Migration Milestone",
      "due_date": "2026-09-30",
      "invoice_amount": 4200.0,
      "payment_state": "Overdue Follow-Up"
    }
  ],
  "client_retainer": [
    {
      "id": "ret-1",
      "client_name": "Kestrel Robotics Corp.",
      "billing_cadence": "Monthly Retainer",
      "monthly_cap": 10000.0
    }
  ]
}''')


def seed_database(db: Session) -> dict[str, int]:
    """Inserts domain sample records if tables are currently empty."""
    inserted: dict[str, int] = {}
    records_client_invoice = SAMPLE_SEED_DATA.get("client_invoice", [])
    existing_client_invoice = db.query(ClientInvoiceModel).count()
    count_client_invoice = 0
    if existing_client_invoice == 0:
        for row in records_client_invoice:
            allowed = ['invoice_number', 'client_organization', 'engagement_scope', 'due_date', 'invoice_amount', 'payment_state']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(ClientInvoiceModel(**payload))
            count_client_invoice += 1
    inserted["client_invoice"] = count_client_invoice
    records_client_retainer = SAMPLE_SEED_DATA.get("client_retainer", [])
    existing_client_retainer = db.query(ClientRetainerModel).count()
    count_client_retainer = 0
    if existing_client_retainer == 0:
        for row in records_client_retainer:
            allowed = ['client_name', 'billing_cadence', 'monthly_cap']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(ClientRetainerModel(**payload))
            count_client_retainer += 1
    inserted["client_retainer"] = count_client_retainer
    db.commit()
    return inserted


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as session:
        result = seed_database(session)
        print("Seeded sample records:", result)
