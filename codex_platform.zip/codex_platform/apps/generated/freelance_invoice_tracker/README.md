# FolioNote Billing

> Formal client invoice statements, retainer milestones, and aging receivables

## Product & Domain Summary
- **Product Kind**: Independent Consultant & Freelance Client Invoice Ledger
- **Archetype**: `finance_ledger`
- **Primary Object**: `client_invoice`
- **Target Audience**: Independent designers, software consultants, and boutique studio principals (Desktop billing review and client statement dispatch)
- **Navigation Pattern**: `split_master_detail`
- **Home Page**: `invoice-statements` (`report_document`)

## Design Direction (`civic_formal`)
- **Color Mode**: `both` | **Primary**: `#7F1D1D` | **Surface**: `#FFFFFF`
- **Typography**: Heading `Merriweather` · Body `Public Sans` · Mono `IBM Plex Mono`
- **Shape & Density**: Radius `sharp` · Density `spacious`
- **Rationale**: Authoritative Merriweather serif headings, sharp document borders, and deep crimson seals make freelance invoices look like institutional legal statements.

## Domain Entities
- **Client Invoices** (`client_invoice`): `invoice_number` (string), `client_organization` (string), `engagement_scope` (string), `due_date` (date), `invoice_amount` (currency), `payment_state` (enum)
- **Client Retainers** (`client_retainer`): `client_name` (string), `billing_cadence` (enum), `monthly_cap` (currency)

## Application Screens
- **Client Invoice Statements** (`/invoice-statements`) — Layout: `report_document`
- **Receivables Aging Ledger** (`/receivables-ledger`) — Layout: `data_table_with_filters`
- **Client Retainer Agreements** (`/active-retainers`) — Layout: `single_form`

## API Endpoints
- `GET /api/client_invoice`
- `POST /api/client_invoice`
- `PUT /api/client_invoice/{item_id}`
- `DELETE /api/client_invoice/{item_id}`
- `GET /api/client_retainer`
- `POST /api/client_retainer`
- `PUT /api/client_retainer/{item_id}`
- `DELETE /api/client_retainer/{item_id}`
- `POST /api/seed`
- `GET /api/health`

## SQLAlchemy Models
- `ClientInvoiceModel`
- `ClientRetainerModel`

## Local Execution

### 1. Instant Standalone UI
Open `standalone_app.html` directly in any browser (zero external CDN dependencies).

### 2. Backend API (`FastAPI` + `SQLite`)
```bash
cd backend
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### 3. React + Vite Frontend
```bash
cd frontend
npm install
npm run dev
```
