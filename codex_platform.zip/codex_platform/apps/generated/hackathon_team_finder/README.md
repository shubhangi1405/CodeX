# ShipMate Hackers

> Find your 48-hour hackathon squad, pitch bold prototypes, and claim bounties

## Product & Domain Summary
- **Product Kind**: University Hackathon Team Discovery & Project Pitch Feed
- **Archetype**: `community_feed`
- **Primary Object**: `team_pitch`
- **Target Audience**: Student hackers, designers, and ML builders forming 48-hour sprint teams (High-energy campus hacking hall on laptops and phones)
- **Navigation Pattern**: `top_tabs`
- **Home Page**: `live-pitch-feed` (`feed`)

## Design Direction (`campus_energy`)
- **Color Mode**: `both` | **Primary**: `#1D4ED8` | **Surface**: `#F8FAFF`
- **Typography**: Heading `Outfit` · Body `DM Sans` · Mono `Fira Code`
- **Shape & Density**: Radius `pill` · Density `comfortable`
- **Rationale**: Electric cobalt primaries, Outfit display type, and pill badges capture the collaborative urgency of a university hackathon pitch floor.

## Domain Entities
- **Team Pitches** (`team_pitch`): `project_title` (string), `prize_track` (enum), `needed_role` (enum), `open_spots` (integer), `discord_handle` (string)
- **Hacker Profiles** (`hacker_profile`): `hacker_name` (string), `university` (string), `primary_stack` (string), `bounty_points` (integer)

## Application Screens
- **Live Squad Pitch Feed** (`/live-pitch-feed`) — Layout: `feed`
- **Free-Agent Builders** (`/hacker-directory`) — Layout: `card_grid`
- **Track Leaderboard** (`/bounty-leaderboard`) — Layout: `leaderboard`

## API Endpoints
- `GET /api/team_pitch`
- `POST /api/team_pitch`
- `PUT /api/team_pitch/{item_id}`
- `DELETE /api/team_pitch/{item_id}`
- `GET /api/hacker_profile`
- `POST /api/hacker_profile`
- `PUT /api/hacker_profile/{item_id}`
- `DELETE /api/hacker_profile/{item_id}`
- `POST /api/seed`
- `GET /api/health`

## SQLAlchemy Models
- `TeamPitchModel`
- `HackerProfileModel`

## Local Execution

### 1. Instant Standalone UI
Open `standalone_app.html` directly in any browser (zero external CDN dependencies).

### 2. Backend API (`FastAPI` + `SQLite`)
```bash
cd backend
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### 3. React + Vite Frontend
```bash
cd frontend
npm install
npm run dev
```
