import React, { useEffect, useState } from 'react';
import {
  AdaptiveAppShell,
  AdaptiveLayoutRenderer,
  Button,
  FormField,
  Input,
  Modal,
  Select,
  Toast,
  EntityRecord,
  EntitySpecData,
  PageSpecData,
} from './ui_kit';

const BLUEPRINT = {
  "app_name": "ShipMate Hackers",
  "product_tagline": "Find your 48-hour hackathon squad, pitch bold prototypes, and claim bounties",
  "domain": {
    "product_kind": "University Hackathon Team Discovery & Project Pitch Feed",
    "archetype": "community_feed",
    "audience": {
      "who": "Student hackers, designers, and ML builders forming 48-hour sprint teams",
      "context_of_use": "High-energy campus hacking hall on laptops and phones",
      "device_likely_used": "hybrid",
      "tech_comfort": "high"
    },
    "core_jobs": [
      "Post and browse live 48-hour hackathon project pitches seeking teammates",
      "Filter student builders by role (Frontend, Rust, ML, Product Design) and track",
      "Check the live hackathon track leaderboard and demo submission countdown"
    ],
    "primary_object": "team_pitch",
    "tone": "playful",
    "data_shape": "feed",
    "needs_automation": false,
    "rationale": "Hackathon team formation thrives on a social pitch feed, skill-badge directory cards, and a live prize-track leaderboard with bold campus energy."
  },
  "entities": [
    {
      "name": "team_pitch",
      "singular_label": "Team Pitch",
      "plural_label": "Team Pitches",
      "fields": [
        {
          "name": "project_title",
          "label": "Project Pitch Name",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "prize_track",
          "label": "Prize Track",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "AI Agents & Tooling",
            "Climate & Hardware",
            "Creative Web & Spatial",
            "Open Source Infrastructure"
          ],
          "default_value": null
        },
        {
          "name": "needed_role",
          "label": "Seeking Teammate Role",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Full-Stack TypeScript",
            "PyTorch / Systems ML",
            "UI/UX & Motion Designer",
            "Embedded / Rust"
          ],
          "default_value": null
        },
        {
          "name": "open_spots",
          "label": "Open Squad Spots",
          "field_type": "integer",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": 2
        },
        {
          "name": "discord_handle",
          "label": "Table / Discord Tag",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        }
      ],
      "relationships": []
    },
    {
      "name": "hacker_profile",
      "singular_label": "Hacker Profile",
      "plural_label": "Hacker Profiles",
      "fields": [
        {
          "name": "hacker_name",
          "label": "Builder Name",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "university",
          "label": "Campus / School",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "primary_stack",
          "label": "Superpower Stack",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "bounty_points",
          "label": "Hackathon Rep Score",
          "field_type": "integer",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": 120
        }
      ],
      "relationships": []
    }
  ],
  "pages": [
    {
      "id": "live-pitch-feed",
      "title": "Live Squad Pitch Feed",
      "route": "/live-pitch-feed",
      "layout": "feed",
      "entities_used": [
        "team_pitch"
      ],
      "primary_actions": [
        "Post Squad Pitch",
        "Filter by Prize Track"
      ],
      "empty_state": {
        "headline": "No Hackathon Pitches Posted Yet",
        "body": "Drop a 60-second pitch for what you're building this weekend and tag the roles your squad needs.",
        "cta_label": "Post First Squad Pitch",
        "cta_action_id": "create_team_pitch"
      }
    },
    {
      "id": "hacker-directory",
      "title": "Free-Agent Builders",
      "route": "/hacker-directory",
      "layout": "card_grid",
      "entities_used": [
        "hacker_profile"
      ],
      "primary_actions": [
        "Create Builder Card"
      ],
      "empty_state": {
        "headline": "No Free-Agent Hackers Listed",
        "body": "Add your builder card so teams can invite you to their table.",
        "cta_label": "Join Builder Directory",
        "cta_action_id": "create_hacker_profile"
      }
    },
    {
      "id": "bounty-leaderboard",
      "title": "Track Leaderboard",
      "route": "/bounty-leaderboard",
      "layout": "leaderboard",
      "entities_used": [
        "hacker_profile"
      ],
      "primary_actions": [
        "Award Mentor Upvote"
      ],
      "empty_state": {
        "headline": "Leaderboard Opens at Kickoff",
        "body": "Register builders and ship checkpoints to climb the campus ranks.",
        "cta_label": "Register Builder",
        "cta_action_id": "create_hacker_profile"
      }
    }
  ],
  "navigation": {
    "pattern": "top_tabs",
    "items": [
      {
        "page_id": "live-pitch-feed",
        "label": "Squad Pitch Feed",
        "icon": "zap"
      },
      {
        "page_id": "hacker-directory",
        "label": "Builder Directory",
        "icon": "users"
      },
      {
        "page_id": "bounty-leaderboard",
        "label": "Leaderboard",
        "icon": "award"
      }
    ]
  },
  "home_page_id": "live-pitch-feed",
  "automations": []
} as const;
const DESIGN_DIRECTION = {
  "direction_id": "campus_energy",
  "palette": {
    "primary": "#1D4ED8",
    "primary_foreground": "#FFFFFF",
    "accent": "#9A4406",
    "neutral_ramp": [
      "#F8FAFF",
      "#EEF2FF",
      "#E0E7FF",
      "#C7D2FE",
      "#94A3B8",
      "#64748B",
      "#475569",
      "#1E293B",
      "#111827"
    ],
    "surface": "#F8FAFF",
    "surface_elevated": "#FFFFFF",
    "border": "#5B6B82",
    "text": "#111827",
    "text_muted": "#374151",
    "focus_ring": "#1D4ED8",
    "success": "#157347",
    "warning": "#92400E",
    "danger": "#B91C1C"
  },
  "color_mode": "both",
  "typography": {
    "heading_font": "Outfit",
    "body_font": "DM Sans",
    "mono_font": "Fira Code",
    "scale_ratio": 1.26
  },
  "shape": {
    "radius_class": "pill",
    "border_style": "crisp",
    "shadow_style": "layered"
  },
  "density": "comfortable",
  "motion": "lively",
  "iconography": "solid",
  "brand_mark": {
    "kind": "geometric_glyph",
    "glyph_primitive": "compass_star",
    "monogram_letters": "SM"
  },
  "copy_voice": "Energetic, collaborative, peer-to-peer student builder language.",
  "rationale": "Electric cobalt primaries, Outfit display type, and pill badges capture the collaborative urgency of a university hackathon pitch floor."
} as const;
const SAMPLE_SEED_DATA: Record<string, EntityRecord[]> = {
  "team_pitch": [
    {
      "id": "pitch-1",
      "project_title": "EchoBraille: Real-Time Haptic Lecture Notes",
      "prize_track": "Climate & Hardware",
      "needed_role": "Embedded / Rust",
      "open_spots": 1,
      "discord_handle": "Table B14 \u00b7 @maya_hw"
    },
    {
      "id": "pitch-2",
      "project_title": "PatchGraph: Autonomous PR Root-Cause Visualizer",
      "prize_track": "AI Agents & Tooling",
      "needed_role": "UI/UX & Motion Designer",
      "open_spots": 2,
      "discord_handle": "Table A04 \u00b7 @devon_ml"
    },
    {
      "id": "pitch-3",
      "project_title": "MeshDrop: Zero-Server Local Campus AirDrop",
      "prize_track": "Open Source Infrastructure",
      "needed_role": "Full-Stack TypeScript",
      "open_spots": 1,
      "discord_handle": "Table C09 \u00b7 @sara_net"
    }
  ],
  "hacker_profile": [
    {
      "id": "hk-1",
      "hacker_name": "Maya Lin",
      "university": "Waterloo Engineering",
      "primary_stack": "Rust, STM32, WebAudio",
      "bounty_points": 340
    },
    {
      "id": "hk-2",
      "hacker_name": "Devon Brooks",
      "university": "Georgia Tech CS",
      "primary_stack": "PyTorch, GraphQL, React",
      "bounty_points": 295
    }
  ]
};
const BRAND_SVG_MARKUP = "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"12\" cy=\"12\" r=\"8.5\" stroke=\"currentColor\" stroke-width=\"2\" fill=\"none\"/><path d=\"M15.5 8.5L13.5 13.5L8.5 15.5L10.5 10.5L15.5 8.5Z\" stroke=\"currentColor\" stroke-width=\"1.8\" fill=\"none\"/></svg>";
const NUMERIC_TYPES = new Set(['integer', 'float', 'currency']);

export default function App(): React.ReactElement {
  const [activePageId, setActivePageId] = useState<string>(BLUEPRINT.home_page_id);
  const [recordsByEntity, setRecordsByEntity] = useState<Record<string, EntityRecord[]>>(() => {
    const initial: Record<string, EntityRecord[]> = {};
    for (const ent of BLUEPRINT.entities) {
      initial[ent.name] = [];
    }
    return initial;
  });
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formState, setFormState] = useState<Record<string, string | number | boolean>>({});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const pages = BLUEPRINT.pages as unknown as PageSpecData[];
  const entities = BLUEPRINT.entities as unknown as EntitySpecData[];
  const activePage = pages.find((p) => p.id === activePageId) || pages[0];
  const primaryEntityName = activePage.entities_used[0] || entities[0].name;
  const activeEntity = entities.find((e) => e.name === primaryEntityName) || entities[0];
  const activeRecords = recordsByEntity[activeEntity.name] || [];

  useEffect(() => {
    for (const ent of entities) {
      fetch(`/api/${ent.name}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data: EntityRecord[] | null) => {
          if (Array.isArray(data) && data.length > 0) {
            setRecordsByEntity((prev) => ({ ...prev, [ent.name]: data }));
          }
        })
        .catch(() => {
          // Offline mode uses in-memory state
        });
    }
  }, []);

  const openCreateModal = (): void => {
    const defaults: Record<string, string | number | boolean> = {};
    for (const fld of activeEntity.fields) {
      if (fld.field_type === 'boolean') {
        defaults[fld.name] = Boolean(fld.default_value ?? false);
      } else if (NUMERIC_TYPES.has(fld.field_type)) {
        defaults[fld.name] = Number(fld.default_value ?? 0);
      } else if (fld.field_type === 'enum' && fld.enum_values && fld.enum_values.length > 0) {
        defaults[fld.name] = fld.enum_values[0];
      } else {
        defaults[fld.name] = String(fld.default_value ?? '');
      }
    }
    setFormState(defaults);
    setIsModalOpen(true);
  };

  const handleCreateRecord = (): void => {
    const newRecord: EntityRecord = {
      id: `${activeEntity.name}-${Date.now()}`,
      ...formState,
    };
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: [newRecord, ...(prev[activeEntity.name] || [])],
    }));
    fetch(`/api/${activeEntity.name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formState),
    }).catch(() => undefined);
    setIsModalOpen(false);
    setToastMsg(`Saved ${activeEntity.singular_label}`);
  };

  const handleLoadSampleSeedData = (): void => {
    setRecordsByEntity(SAMPLE_SEED_DATA);
    fetch('/api/seed', { method: 'POST' }).catch(() => undefined);
    setToastMsg('Loaded domain sample records');
  };

  const handleDeleteRecord = (recordId: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).filter((r) => String(r.id) !== recordId),
    }));
    fetch(`/api/${activeEntity.name}/${recordId}`, {
      method: 'DELETE',
    }).catch(() => undefined);
    setToastMsg(`Removed ${activeEntity.singular_label}`);
  };

  const handleToggleBoolean = (recordId: string, fieldName: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).map((r) =>
        String(r.id) === recordId ? { ...r, [fieldName]: !r[fieldName] } : r
      ),
    }));
  };

  return (
    <div className="min-h-screen bg-surface text-text font-body">
      <AdaptiveAppShell
        pattern={BLUEPRINT.navigation.pattern}
        appName={BLUEPRINT.app_name}
        tagline={BLUEPRINT.product_tagline}
        brandMark={
          <span
            className="inline-flex items-center"
            dangerouslySetInnerHTML={{ __html: BRAND_SVG_MARKUP }}
          />
        }
        navItems={BLUEPRINT.navigation.items.map((item) => ({
          page_id: item.page_id,
          label: item.label,
          icon: item.icon,
        }))}
        activePageId={activePage.id}
        onSelectPage={setActivePageId}
        primaryAction={
          <div className="flex items-center gap-2">
            {activeRecords.length === 0 && (
              <Button variant="secondary" onClick={handleLoadSampleSeedData}>
                Load Sample Data
              </Button>
            )}
            <Button variant="primary" onClick={openCreateModal}>
              + {activePage.primary_actions[0] || `New ${activeEntity.singular_label}`}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {toastMsg && (
            <div className="flex justify-between items-center">
              <Toast message={toastMsg} tone="success" />
              <Button variant="ghost" onClick={() => setToastMsg(null)}>Dismiss</Button>
            </div>
          )}
          <AdaptiveLayoutRenderer
            page={activePage}
            entity={activeEntity}
            records={activeRecords}
            onOpenCreate={openCreateModal}
            onDeleteRecord={handleDeleteRecord}
            onToggleBoolean={handleToggleBoolean}
          />
        </div>
      </AdaptiveAppShell>

      <Modal
        open={isModalOpen}
        title={`Add ${activeEntity.singular_label}`}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-3">
          {activeEntity.fields.map((fld) => (
            <FormField key={fld.name} label={fld.label} required={fld.required}>
              {fld.field_type === 'enum' && fld.enum_values ? (
                <Select
                  value={String(formState[fld.name] ?? fld.enum_values[0] ?? '')}
                  options={fld.enum_values.map((v) => ({ value: v, label: v }))}
                  onChange={(val) => setFormState((prev) => ({ ...prev, [fld.name]: val }))}
                />
              ) : (
                <Input
                  type={
                    NUMERIC_TYPES.has(fld.field_type)
                      ? 'number'
                      : fld.field_type === 'date'
                        ? 'date'
                        : 'text'
                  }
                  value={String(formState[fld.name] ?? '')}
                  placeholder={`Enter ${fld.label}`}
                  onChange={(val) =>
                    setFormState((prev) => ({
                      ...prev,
                      [fld.name]: NUMERIC_TYPES.has(fld.field_type) ? Number(val) : val,
                    }))
                  }
                />
              )}
            </FormField>
          ))}
          <div className="flex justify-end gap-2 pt-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCreateRecord}>
              Save {activeEntity.singular_label}
            </Button>
          </div>
        </div>
      </Modal>
      
    </div>
  );
}
