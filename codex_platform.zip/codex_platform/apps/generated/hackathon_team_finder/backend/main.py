"""FastAPI backend for ShipMate Hackers — Find your 48-hour hackathon squad, pitch bold prototypes, and claim bounties."""

import json
from typing import Any, Optional
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import TeamPitchModel, HackerProfileModel
from seed import seed_database

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='ShipMate Hackers',
    description='Find your 48-hour hackathon squad, pitch bold prototypes, and claim bounties',
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class TeamPitchCreate(BaseModel):
    project_title: str = ''
    prize_track: str = 'AI Agents & Tooling'
    needed_role: str = 'Full-Stack TypeScript'
    open_spots: int = 2
    discord_handle: str = ''

class TeamPitchUpdate(BaseModel):
    project_title: Optional[str] = None
    prize_track: Optional[str] = None
    needed_role: Optional[str] = None
    open_spots: Optional[int] = None
    discord_handle: Optional[str] = None

def _serialize_team_pitch(item: TeamPitchModel) -> dict[str, Any]:
    return {"id": item.id, "project_title": getattr(item, "project_title"), "prize_track": getattr(item, "prize_track"), "needed_role": getattr(item, "needed_role"), "open_spots": getattr(item, "open_spots"), "discord_handle": getattr(item, "discord_handle")}

@app.get("/api/team_pitch")
def list_team_pitch(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(TeamPitchModel).order_by(TeamPitchModel.created_at.desc()).all()
    return [_serialize_team_pitch(r) for r in rows]

@app.post("/api/team_pitch", status_code=201)
def create_team_pitch(
    payload: TeamPitchCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = TeamPitchModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_team_pitch(record)

@app.put("/api/team_pitch/{item_id}")
def update_team_pitch(
    item_id: str, payload: TeamPitchUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(TeamPitchModel).filter(TeamPitchModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Team Pitch not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_team_pitch(record)

@app.delete("/api/team_pitch/{item_id}")
def delete_team_pitch(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(TeamPitchModel).filter(TeamPitchModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Team Pitch not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class HackerProfileCreate(BaseModel):
    hacker_name: str = ''
    university: str = ''
    primary_stack: str = ''
    bounty_points: int = 120

class HackerProfileUpdate(BaseModel):
    hacker_name: Optional[str] = None
    university: Optional[str] = None
    primary_stack: Optional[str] = None
    bounty_points: Optional[int] = None

def _serialize_hacker_profile(item: HackerProfileModel) -> dict[str, Any]:
    return {"id": item.id, "hacker_name": getattr(item, "hacker_name"), "university": getattr(item, "university"), "primary_stack": getattr(item, "primary_stack"), "bounty_points": getattr(item, "bounty_points")}

@app.get("/api/hacker_profile")
def list_hacker_profile(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(HackerProfileModel).order_by(HackerProfileModel.created_at.desc()).all()
    return [_serialize_hacker_profile(r) for r in rows]

@app.post("/api/hacker_profile", status_code=201)
def create_hacker_profile(
    payload: HackerProfileCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = HackerProfileModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_hacker_profile(record)

@app.put("/api/hacker_profile/{item_id}")
def update_hacker_profile(
    item_id: str, payload: HackerProfileUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(HackerProfileModel).filter(HackerProfileModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Hacker Profile not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_hacker_profile(record)

@app.delete("/api/hacker_profile/{item_id}")
def delete_hacker_profile(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(HackerProfileModel).filter(HackerProfileModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Hacker Profile not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

@app.post("/api/seed")
def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:
    inserted = seed_database(db)
    return {"status": "seeded", "inserted": inserted}

@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {
        "status": "healthy",
        "app": 'ShipMate Hackers',
        "archetype": 'community_feed',
    }
