"""Optional sample seed data loader for ShipMate Hackers."""

import json
from sqlalchemy.orm import Session
from database import Base, SessionLocal, engine
from models import TeamPitchModel, HackerProfileModel

SAMPLE_SEED_DATA = json.loads(r'''{
  "team_pitch": [
    {
      "id": "pitch-1",
      "project_title": "EchoBraille: Real-Time Haptic Lecture Notes",
      "prize_track": "Climate & Hardware",
      "needed_role": "Embedded / Rust",
      "open_spots": 1,
      "discord_handle": "Table B14 \u00b7 @maya_hw"
    },
    {
      "id": "pitch-2",
      "project_title": "PatchGraph: Autonomous PR Root-Cause Visualizer",
      "prize_track": "AI Agents & Tooling",
      "needed_role": "UI/UX & Motion Designer",
      "open_spots": 2,
      "discord_handle": "Table A04 \u00b7 @devon_ml"
    },
    {
      "id": "pitch-3",
      "project_title": "MeshDrop: Zero-Server Local Campus AirDrop",
      "prize_track": "Open Source Infrastructure",
      "needed_role": "Full-Stack TypeScript",
      "open_spots": 1,
      "discord_handle": "Table C09 \u00b7 @sara_net"
    }
  ],
  "hacker_profile": [
    {
      "id": "hk-1",
      "hacker_name": "Maya Lin",
      "university": "Waterloo Engineering",
      "primary_stack": "Rust, STM32, WebAudio",
      "bounty_points": 340
    },
    {
      "id": "hk-2",
      "hacker_name": "Devon Brooks",
      "university": "Georgia Tech CS",
      "primary_stack": "PyTorch, GraphQL, React",
      "bounty_points": 295
    }
  ]
}''')


def seed_database(db: Session) -> dict[str, int]:
    """Inserts domain sample records if tables are currently empty."""
    inserted: dict[str, int] = {}
    records_team_pitch = SAMPLE_SEED_DATA.get("team_pitch", [])
    existing_team_pitch = db.query(TeamPitchModel).count()
    count_team_pitch = 0
    if existing_team_pitch == 0:
        for row in records_team_pitch:
            allowed = ['project_title', 'prize_track', 'needed_role', 'open_spots', 'discord_handle']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(TeamPitchModel(**payload))
            count_team_pitch += 1
    inserted["team_pitch"] = count_team_pitch
    records_hacker_profile = SAMPLE_SEED_DATA.get("hacker_profile", [])
    existing_hacker_profile = db.query(HackerProfileModel).count()
    count_hacker_profile = 0
    if existing_hacker_profile == 0:
        for row in records_hacker_profile:
            allowed = ['hacker_name', 'university', 'primary_stack', 'bounty_points']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(HackerProfileModel(**payload))
            count_hacker_profile += 1
    inserted["hacker_profile"] = count_hacker_profile
    db.commit()
    return inserted


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as session:
        result = seed_database(session)
        print("Seeded sample records:", result)
