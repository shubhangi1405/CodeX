"""Domain SQLAlchemy ORM models for ShipMate Hackers."""

from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from database import Base

class TeamPitchModel(Base):
    __tablename__ = "team_pitchs"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    project_title = Column(String, nullable=False, default='')
    prize_track = Column(String, nullable=False, default='AI Agents & Tooling')
    needed_role = Column(String, nullable=False, default='Full-Stack TypeScript')
    open_spots = Column(Integer, nullable=False, default=2)
    discord_handle = Column(String, nullable=False, default='')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class HackerProfileModel(Base):
    __tablename__ = "hacker_profiles"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    hacker_name = Column(String, nullable=False, default='')
    university = Column(String, nullable=False, default='')
    primary_stack = Column(String, nullable=False, default='')
    bounty_points = Column(Integer, nullable=False, default=120)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
