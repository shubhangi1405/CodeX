"""Domain SQLAlchemy ORM models for TimeFlow Calendar & Reminders."""

from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from database import Base

class CalendarEventModel(Base):
    __tablename__ = "calendar_events"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    owner_id = Column(String, nullable=True)
    event_title = Column(String, nullable=False, default='')
    event_date = Column(String, nullable=False, default='')
    time_slot = Column(String, nullable=False, default='')
    category = Column(String, nullable=False, default='Work')
    location = Column(String, nullable=False, default='')
    notes = Column(String, nullable=False, default='')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class ReminderTaskModel(Base):
    __tablename__ = "reminder_tasks"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    owner_id = Column(String, nullable=True)
    task_title = Column(String, nullable=False, default='')
    due_date = Column(String, nullable=False, default='')
    priority = Column(String, nullable=False, default='High')
    status = Column(String, nullable=False, default='Pending')
    reminder_time = Column(String, nullable=False, default='')
    repeat_frequency = Column(String, nullable=False, default='None')
    event_id = Column(String, nullable=False, default='')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class UserModel(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    display_name = Column(String, nullable=False, default='')
    role = Column(String, nullable=False, default='member')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class SessionTokenModel(Base):
    __tablename__ = "session_tokens"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    token = Column(String, unique=True, nullable=False)
    user_id = Column(String, nullable=False)
    revoked = Column(Boolean, default=False, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
