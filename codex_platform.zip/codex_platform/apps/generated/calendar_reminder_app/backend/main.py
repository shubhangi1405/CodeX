"""FastAPI backend for TimeFlow Calendar & Reminders — Punctual schedule management, weekly calendar agenda, and priority task reminders."""

import json
import time
from datetime import datetime, timezone
from typing import Any, Optional
from fastapi import Depends, FastAPI, HTTPException, Header, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import CalendarEventModel, ReminderTaskModel, UserModel, SessionTokenModel
from seed import seed_database
from auth import (
    create_session,
    get_current_user,
    get_current_user_optional,
    hash_password,
    revoke_session,
    verify_password,
)

THREAT_MODEL_JSON = json.loads(r'''{
  "assets": [
    "TimeFlow Calendar & Reminders SQLite Database",
    "Calendar Event Records",
    "Session Tokens"
  ],
  "trust_boundaries": [
    "Public Internet <-> Reverse Proxy / Vite Frontend",
    "Frontend Client <-> FastAPI Endpoints",
    "Application Layer <-> SQLite Persistence Engine"
  ],
  "threats": [
    {
      "id": "t-auth-bypass",
      "category": "spoofing",
      "asset": "User Authentication & Session Tokens",
      "threat_description": "Adversary attempts brute force or credential stuffing on login endpoint.",
      "attacker_profile": "External malicious actor or automated botnet",
      "attack_path": "Repeated POST requests to authentication endpoint with dictionary passwords.",
      "mitigation": "PBKDF2-HMAC-SHA256 password hashing with salt and in-memory rate limiting.",
      "residual_risk": "low"
    },
    {
      "id": "t-idor-tampering",
      "category": "elevation_of_privilege",
      "asset": "Calendar Event Data Records",
      "threat_description": "User A attempts to modify or delete User B private records by guessing record IDs.",
      "attacker_profile": "Authenticated standard user",
      "attack_path": "Submitting PUT/DELETE requests referencing other tenants record identifiers.",
      "mitigation": "Server-side owner_id verification and RBAC role validation before mutation.",
      "residual_risk": "low"
    },
    {
      "id": "t-data-leakage",
      "category": "information_disclosure",
      "asset": "Account and Exported Data",
      "threat_description": "Unauthorized retrieval of sensitive workspace information.",
      "attacker_profile": "Unauthenticated external network eavesdropper",
      "attack_path": "Interception of API payloads or token theft via XSS.",
      "mitigation": "Strict CORS headers, X-Content-Type-Options, and secure session management.",
      "residual_risk": "low"
    }
  ]
}''')
_CLIENT_REQUEST_TIMESTAMPS: dict[str, list[float]] = {}

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='TimeFlow Calendar & Reminders',
    description='Punctual schedule management, weekly calendar agenda, and priority task reminders',
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware('http')
async def security_and_rate_limit_middleware(request, call_next):
    client_ip = request.client.host if request.client else '127.0.0.1'
    path = request.url.path
    if path.startswith('/api/auth/') and request.method == 'POST':
        now = time.time()
        bucket = _CLIENT_REQUEST_TIMESTAMPS.setdefault(client_ip, [])
        bucket[:] = [t for t in bucket if now - t < 60.0]
        if len(bucket) >= 40:
            return Response(
                content=json.dumps({"detail": "Rate limit exceeded. Please wait before retrying."}),
                status_code=429,
                media_type="application/json",
            )
        bucket.append(now)

    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return response

class CalendarEventCreate(BaseModel):
    event_title: str = ''
    event_date: str = ''
    time_slot: str = ''
    category: str = 'Work'
    location: str = ''
    notes: str = ''

class CalendarEventUpdate(BaseModel):
    event_title: Optional[str] = None
    event_date: Optional[str] = None
    time_slot: Optional[str] = None
    category: Optional[str] = None
    location: Optional[str] = None
    notes: Optional[str] = None

def _serialize_calendar_event(item: CalendarEventModel) -> dict[str, Any]:
    d = {"id": item.id, "event_title": getattr(item, "event_title"), "event_date": getattr(item, "event_date"), "time_slot": getattr(item, "time_slot"), "category": getattr(item, "category"), "location": getattr(item, "location"), "notes": getattr(item, "notes")}
    if hasattr(item, "owner_id") and item.owner_id: d["owner_id"] = item.owner_id

    return d

@app.get("/api/calendar_event")
def list_calendar_event(
    mine_only: bool = False,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> list[dict[str, Any]]:
    query = db.query(CalendarEventModel)
    if mine_only:
        if not current_user:
            raise HTTPException(status_code=401, detail="Authentication required for personal records")
        query = query.filter(CalendarEventModel.owner_id == current_user.id)
    rows = query.order_by(CalendarEventModel.created_at.desc()).all()
    return [_serialize_calendar_event(r) for r in rows]

@app.post("/api/calendar_event", status_code=201)
def create_calendar_event(
    payload: CalendarEventCreate,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    data = payload.model_dump()
    if current_user:
        data["owner_id"] = current_user.id
    record = CalendarEventModel(**data)
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_calendar_event(record)

@app.put("/api/calendar_event/{item_id}")
def update_calendar_event(
    item_id: str, payload: CalendarEventUpdate,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    record = db.query(CalendarEventModel).filter(CalendarEventModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Calendar Event not found"
        )
    if hasattr(record, "owner_id") and record.owner_id and current_user:
        if record.owner_id != current_user.id and getattr(current_user, "role", "") not in ("admin", "manager"):
            raise HTTPException(status_code=403, detail="Forbidden: you do not own this record")
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_calendar_event(record)

@app.delete("/api/calendar_event/{item_id}")
def delete_calendar_event(
    item_id: str,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, str]:
    record = db.query(CalendarEventModel).filter(CalendarEventModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Calendar Event not found"
        )
    if hasattr(record, "owner_id") and record.owner_id and current_user:
        if record.owner_id != current_user.id and getattr(current_user, "role", "") not in ("admin", "manager"):
            raise HTTPException(status_code=403, detail="Forbidden: you do not own this record")
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class ReminderTaskCreate(BaseModel):
    task_title: str = ''
    due_date: str = ''
    priority: str = 'High'
    status: str = 'Pending'
    reminder_time: str = ''
    repeat_frequency: str = 'None'
    event_id: str = ''

class ReminderTaskUpdate(BaseModel):
    task_title: Optional[str] = None
    due_date: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None
    reminder_time: Optional[str] = None
    repeat_frequency: Optional[str] = None
    event_id: Optional[str] = None

def _serialize_reminder_task(item: ReminderTaskModel) -> dict[str, Any]:
    d = {"id": item.id, "task_title": getattr(item, "task_title"), "due_date": getattr(item, "due_date"), "priority": getattr(item, "priority"), "status": getattr(item, "status"), "reminder_time": getattr(item, "reminder_time"), "repeat_frequency": getattr(item, "repeat_frequency"), "event_id": getattr(item, "event_id")}
    if hasattr(item, "owner_id") and item.owner_id: d["owner_id"] = item.owner_id

    return d

@app.get("/api/reminder_task")
def list_reminder_task(
    mine_only: bool = False,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> list[dict[str, Any]]:
    query = db.query(ReminderTaskModel)
    if mine_only:
        if not current_user:
            raise HTTPException(status_code=401, detail="Authentication required for personal records")
        query = query.filter(ReminderTaskModel.owner_id == current_user.id)
    rows = query.order_by(ReminderTaskModel.created_at.desc()).all()
    return [_serialize_reminder_task(r) for r in rows]

@app.post("/api/reminder_task", status_code=201)
def create_reminder_task(
    payload: ReminderTaskCreate,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    data = payload.model_dump()
    if current_user:
        data["owner_id"] = current_user.id
    record = ReminderTaskModel(**data)
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_reminder_task(record)

@app.put("/api/reminder_task/{item_id}")
def update_reminder_task(
    item_id: str, payload: ReminderTaskUpdate,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    record = db.query(ReminderTaskModel).filter(ReminderTaskModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Reminder Task not found"
        )
    if hasattr(record, "owner_id") and record.owner_id and current_user:
        if record.owner_id != current_user.id and getattr(current_user, "role", "") not in ("admin", "manager"):
            raise HTTPException(status_code=403, detail="Forbidden: you do not own this record")
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_reminder_task(record)

@app.delete("/api/reminder_task/{item_id}")
def delete_reminder_task(
    item_id: str,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, str]:
    record = db.query(ReminderTaskModel).filter(ReminderTaskModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Reminder Task not found"
        )
    if hasattr(record, "owner_id") and record.owner_id and current_user:
        if record.owner_id != current_user.id and getattr(current_user, "role", "") not in ("admin", "manager"):
            raise HTTPException(status_code=403, detail="Forbidden: you do not own this record")
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class RegisterRequest(BaseModel):
    email: str
    password: str
    display_name: Optional[str] = ''
    role: Optional[str] = 'member'

class LoginRequest(BaseModel):
    email: str
    password: str

class ResetPasswordRequest(BaseModel):
    email: str
    new_password: str

@app.post("/api/auth/register", status_code=201)
def api_auth_register(payload: RegisterRequest, db: Session = Depends(get_db)) -> dict[str, Any]:
    if not payload.email or "@" not in payload.email:
        raise HTTPException(status_code=422, detail="Valid email required")
    if len(payload.password) < 8:
        raise HTTPException(status_code=422, detail="Password must be at least 8 characters")
    existing = db.query(UserModel).filter(UserModel.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")
    u = UserModel(
        email=payload.email,
        password_hash=hash_password(payload.password),
        display_name=payload.display_name or payload.email.split("@")[0],
        role=payload.role or 'member',
    )
    db.add(u)
    db.commit()
    db.refresh(u)
    token = create_session(db, u.id)
    return {"token": token, "user": {"id": u.id, "email": u.email, "display_name": u.display_name, "role": u.role}}

@app.post("/api/auth/login")
def api_auth_login(payload: LoginRequest, db: Session = Depends(get_db)) -> dict[str, Any]:
    u = db.query(UserModel).filter(UserModel.email == payload.email).first()
    if not u or not verify_password(payload.password, u.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_session(db, u.id)
    return {"token": token, "user": {"id": u.id, "email": u.email, "display_name": u.display_name, "role": u.role}}

@app.post("/api/auth/logout")
def api_auth_logout(
    current_user: UserModel = Depends(get_current_user),
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
) -> dict[str, str]:
    if authorization and authorization.lower().startswith('bearer '):
        revoke_session(db, authorization[7:].strip())
    return {"status": "logged_out"}

@app.get("/api/auth/me")
def api_auth_me(current_user: UserModel = Depends(get_current_user)) -> dict[str, Any]:
    return {"id": current_user.id, "email": current_user.email, "display_name": current_user.display_name, "role": current_user.role}

@app.post("/api/auth/reset-password")
def api_auth_reset_password(payload: ResetPasswordRequest, db: Session = Depends(get_db)) -> dict[str, str]:
    if len(payload.new_password) < 8:
        raise HTTPException(status_code=422, detail="Password must be at least 8 characters")
    u = db.query(UserModel).filter(UserModel.email == payload.email).first()
    if not u:
        raise HTTPException(status_code=404, detail="Account not found")
    u.password_hash = hash_password(payload.new_password)
    db.commit()
    return {"status": "password_reset_success"}

@app.get("/api/auth/status")
def api_auth_status() -> dict[str, Any]:
    return {
        "auth_required": True,
        "strategy": "token_session",
        "rationale": 'Standard session authentication for user workspaces.',
    }

@app.get("/api/privacy/export")
def api_privacy_export(
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "application": 'TimeFlow Calendar & Reminders',
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "user": {"id": current_user.id, "email": current_user.email} if current_user else None,
        "records": {},
    }
    q_calendar_event = db.query(CalendarEventModel)
    if current_user and hasattr(CalendarEventModel, 'owner_id'):
        q_calendar_event = q_calendar_event.filter(CalendarEventModel.owner_id == current_user.id)
    payload["records"]["calendar_event"] = [_serialize_calendar_event(r) for r in q_calendar_event.all()]
    q_reminder_task = db.query(ReminderTaskModel)
    if current_user and hasattr(ReminderTaskModel, 'owner_id'):
        q_reminder_task = q_reminder_task.filter(ReminderTaskModel.owner_id == current_user.id)
    payload["records"]["reminder_task"] = [_serialize_reminder_task(r) for r in q_reminder_task.all()]
    return payload

@app.delete("/api/privacy/account")
def api_privacy_account_deletion(
    current_user: Any = Depends(get_current_user)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    if hasattr(CalendarEventModel, 'owner_id'):
        db.query(CalendarEventModel).filter(CalendarEventModel.owner_id == current_user.id).delete()
    if hasattr(ReminderTaskModel, 'owner_id'):
        db.query(ReminderTaskModel).filter(ReminderTaskModel.owner_id == current_user.id).delete()
    db.query(SessionTokenModel).filter(SessionTokenModel.user_id == current_user.id).delete()
    db.query(UserModel).filter(UserModel.id == current_user.id).delete()
    db.commit()
    return {"status": "account_and_records_deleted", "user_id": current_user.id}

@app.get("/api/security/threat-model")
def api_security_threat_model() -> dict[str, Any]:
    return THREAT_MODEL_JSON

@app.get("/api/analytics/summary")
def api_analytics_summary(db: Session = Depends(get_db)) -> dict[str, Any]:
    counts: dict[str, int] = {}
    total_count = 0
    c_calendar_event = db.query(CalendarEventModel).count()
    counts["calendar_event"] = c_calendar_event
    total_count += c_calendar_event
    c_reminder_task = db.query(ReminderTaskModel).count()
    counts["reminder_task"] = c_reminder_task
    total_count += c_reminder_task
    rows_calendar_event = db.query(CalendarEventModel).all()
    dist_map: dict[str, int] = {}
    for r in rows_calendar_event:
        val = str(getattr(r, "category", "Unknown") or "Unknown")
        dist_map[val] = dist_map.get(val, 0) + 1
    primary_chart_data = [{"label": k, "value": v} for k, v in dist_map.items()]
    return {
        "app": 'TimeFlow Calendar & Reminders',
        "total_records": total_count,
        "counts_by_entity": counts,
        "primary_chart_type": 'bar',
        "primary_chart_data": primary_chart_data,
        "secondary_chart_type": 'donut',
        'kpis': [
            {"id": 'primary_volume', "label": 'Total Calendar Events', "unit": 'items', "value": total_count, "target": None},
            {"id": 'utilization', "label": 'Capacity Utilization', "unit": '%', "value": total_count, "target": 85.0},
            {"id": 'flagged_records', "label": 'Attention Required', "unit": 'flags', "value": total_count, "target": None},
        ],
    }

@app.post("/api/seed")
def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:
    inserted = seed_database(db)
    return {"status": "seeded", "inserted": inserted}

@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {
        "status": "healthy",
        "app": 'TimeFlow Calendar & Reminders',
        "archetype": 'booking_scheduler',
    }
