"""Authentication, password security, session management, and RBAC."""

import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional
from fastapi import Depends, HTTPException, Header, Query
from sqlalchemy.orm import Session
from database import get_db
from models import UserModel, SessionTokenModel


def hash_password(password: str) -> str:
    """Hashes a password using PBKDF2-HMAC-SHA256 with a cryptographically secure salt."""
    salt = secrets.token_hex(16)
    derived = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 100000)
    return f"{salt}:{derived.hex()}"


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifies a plain password against the stored salt:hash string."""
    try:
        salt, expected_hex = hashed_password.split(":", 1)
        derived = hashlib.pbkdf2_hmac("sha256", plain_password.encode("utf-8"), salt.encode("utf-8"), 100000)
        return hmac.compare_digest(derived.hex(), expected_hex)
    except Exception:
        return False


def create_session(db: Session, user_id: str, lifetime_hours: int = 24) -> str:
    """Creates a random 64-char session token with an expiration timestamp."""
    token_str = secrets.token_hex(32)
    expires_at = datetime.now(timezone.utc) + timedelta(hours=lifetime_hours)
    token_rec = SessionTokenModel(
        token=token_str,
        user_id=user_id,
        expires_at=expires_at,
        revoked=False,
    )
    db.add(token_rec)
    db.commit()
    return token_str


def get_user_from_token(db: Session, token: str) -> Optional[UserModel]:
    """Retrieves an active user if the session token is valid and unexpired."""
    rec = db.query(SessionTokenModel).filter(
        SessionTokenModel.token == token,
        SessionTokenModel.revoked == False,
    ).first()
    if not rec:
        return None
    now = datetime.now(timezone.utc)
    exp = rec.expires_at
    if exp.tzinfo is None:
        exp = exp.replace(tzinfo=timezone.utc)
    if exp < now:
        return None
    return db.query(UserModel).filter(UserModel.id == rec.user_id).first()


def revoke_session(db: Session, token: str) -> bool:
    """Revokes a session token immediately."""
    rec = db.query(SessionTokenModel).filter(SessionTokenModel.token == token).first()
    if rec:
        rec.revoked = True
        db.commit()
        return True
    return False


def get_current_user_optional(
    authorization: Optional[str] = Header(None),
    x_session_token: Optional[str] = Header(None),
    token: Optional[str] = Query(None),
    db: Session = Depends(get_db),
) -> Optional[UserModel]:
    """Extracts session token from Bearer auth, custom header, or query param without failing."""
    raw_token = None
    if authorization and authorization.lower().startswith("bearer "):
        raw_token = authorization[7:].strip()
    elif x_session_token:
        raw_token = x_session_token.strip()
    elif token:
        raw_token = token.strip()

    if not raw_token:
        return None
    return get_user_from_token(db, raw_token)


def get_current_user(
    current_user: Optional[UserModel] = Depends(get_current_user_optional),
) -> UserModel:
    """FastAPI dependency requiring an authenticated active user."""
    if not current_user:
        raise HTTPException(status_code=401, detail="Authentication required")
    return current_user
