import React, { useEffect, useState } from 'react';
import {
  AdaptiveAppShell,
  AdaptiveLayoutRenderer,
  Button,
  FormField,
  Input,
  Modal,
  Select,
  Toast,
  EntityRecord,
  EntitySpecData,
  PageSpecData,
} from './ui_kit';

const BLUEPRINT = {
  "app_name": "TimeFlow Calendar & Reminders",
  "product_tagline": "Punctual schedule management, weekly calendar agenda, and priority task reminders",
  "domain": {
    "product_kind": "Calendar Event Scheduling & Priority Reminders Workspace",
    "archetype": "booking_scheduler",
    "audience": {
      "who": "Professionals, coordinators, and students organizing daily agendas",
      "context_of_use": "Everyday schedule planning, event timeblocking, and reminder checklist tracking",
      "device_likely_used": "hybrid",
      "tech_comfort": "medium"
    },
    "core_jobs": [
      "Schedule and manage calendar events with dates, times, and categories",
      "Set priority reminders with due dates, repeat rules, and completion status",
      "Review weekly schedule agenda and upcoming chronological timeline"
    ],
    "primary_object": "calendar_event",
    "tone": "calm, punctual, organized, reliable",
    "data_shape": "calendar",
    "needs_automation": false,
    "rationale": "Dedicated calendar and reminder platform tailored for weekly schedule timeblocking, due date notifications, and priority task checklists."
  },
  "entities": [
    {
      "name": "calendar_event",
      "singular_label": "Calendar Event",
      "plural_label": "Calendar Events",
      "fields": [
        {
          "name": "event_title",
          "label": "Event Title",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "event_date",
          "label": "Event Date",
          "field_type": "date",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "time_slot",
          "label": "Time Slot",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "category",
          "label": "Event Category",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Work",
            "Personal",
            "Meeting",
            "Important",
            "Health"
          ],
          "default_value": null
        },
        {
          "name": "location",
          "label": "Location",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "notes",
          "label": "Event Notes",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        }
      ],
      "relationships": []
    },
    {
      "name": "reminder_task",
      "singular_label": "Reminder Task",
      "plural_label": "Reminder Tasks",
      "fields": [
        {
          "name": "task_title",
          "label": "Reminder Title",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "due_date",
          "label": "Due Date",
          "field_type": "date",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "priority",
          "label": "Priority Level",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "High",
            "Medium",
            "Low"
          ],
          "default_value": null
        },
        {
          "name": "status",
          "label": "Status",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Pending",
            "Completed",
            "Snoozed"
          ],
          "default_value": null
        },
        {
          "name": "reminder_time",
          "label": "Reminder Time",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "repeat_frequency",
          "label": "Repeat Frequency",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "None",
            "Daily",
            "Weekly",
            "Monthly"
          ],
          "default_value": null
        },
        {
          "name": "event_id",
          "label": "Linked Event",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        }
      ],
      "relationships": [
        {
          "target_entity": "calendar_event",
          "kind": "many_to_one",
          "foreign_key": "event_id"
        }
      ]
    }
  ],
  "pages": [
    {
      "id": "weekly-agenda",
      "title": "Weekly Calendar & Schedule",
      "route": "/weekly-agenda",
      "layout": "calendar_week_agenda",
      "entities_used": [
        "calendar_event"
      ],
      "primary_actions": [
        "New Event",
        "View Today"
      ],
      "empty_state": {
        "headline": "No Scheduled Calendar Events",
        "body": "Your calendar is completely open. Schedule your first appointment or meeting.",
        "cta_label": "Schedule Event",
        "cta_action_id": "create_calendar_event"
      }
    },
    {
      "id": "reminders-checklist",
      "title": "Priority Reminders & Checklist",
      "route": "/reminders-checklist",
      "layout": "checklist_today",
      "entities_used": [
        "reminder_task"
      ],
      "primary_actions": [
        "Add Reminder",
        "Filter Pending"
      ],
      "empty_state": {
        "headline": "All Reminders Completed",
        "body": "No pending reminders! Add a reminder for tasks and commitments you cannot miss.",
        "cta_label": "New Reminder",
        "cta_action_id": "create_reminder_task"
      }
    },
    {
      "id": "schedule-timeline",
      "title": "Upcoming Schedule Timeline",
      "route": "/upcoming-timeline",
      "layout": "timeline",
      "entities_used": [
        "calendar_event",
        "reminder_task"
      ],
      "primary_actions": [
        "Filter Category",
        "Next 7 Days"
      ],
      "empty_state": {
        "headline": "Timeline Is Clear",
        "body": "Upcoming calendar events and active reminders will appear chronologically here.",
        "cta_label": "Add Event",
        "cta_action_id": "create_calendar_event"
      }
    }
  ],
  "navigation": {
    "pattern": "top_tabs",
    "items": [
      {
        "page_id": "weekly-agenda",
        "label": "Weekly Calendar",
        "icon": "calendar"
      },
      {
        "page_id": "reminders-checklist",
        "label": "Reminders",
        "icon": "check-square"
      },
      {
        "page_id": "schedule-timeline",
        "label": "Timeline",
        "icon": "clock"
      }
    ]
  },
  "home_page_id": "weekly-agenda",
  "automations": [],
  "auth": {
    "required": true,
    "strategy": "token_session",
    "roles": [
      {
        "name": "admin",
        "label": "System Administrator",
        "permissions": [
          "read",
          "write",
          "delete",
          "export",
          "manage_users"
        ],
        "description": "Full administrative control over all TimeFlow Calendar & Reminders data."
      },
      {
        "name": "member",
        "label": "Active Member",
        "permissions": [
          "read",
          "write",
          "export"
        ],
        "description": "Can create and manage personal Calendar Event entries."
      },
      {
        "name": "viewer",
        "label": "Auditor / Read-Only",
        "permissions": [
          "read"
        ],
        "description": "Can view dashboards and reports without modifying data."
      }
    ],
    "protected_entities": [
      "calendar_event"
    ],
    "password_min_length": 8,
    "session_timeout_minutes": 1440,
    "rationale": "Standard session authentication for user workspaces."
  },
  "security": {
    "data_sensitivity": "confidential",
    "rate_limit_rpm": 120,
    "pii_fields": [
      "calendar_event.id"
    ],
    "export_enabled": true,
    "deletion_enabled": true,
    "audit_logging": true,
    "encryption_in_transit": true
  },
  "threat_model": {
    "assets": [
      "TimeFlow Calendar & Reminders SQLite Database",
      "Calendar Event Records",
      "Session Tokens"
    ],
    "trust_boundaries": [
      "Public Internet <-> Reverse Proxy / Vite Frontend",
      "Frontend Client <-> FastAPI Endpoints",
      "Application Layer <-> SQLite Persistence Engine"
    ],
    "threats": [
      {
        "id": "t-auth-bypass",
        "category": "spoofing",
        "asset": "User Authentication & Session Tokens",
        "threat_description": "Adversary attempts brute force or credential stuffing on login endpoint.",
        "attacker_profile": "External malicious actor or automated botnet",
        "attack_path": "Repeated POST requests to authentication endpoint with dictionary passwords.",
        "mitigation": "PBKDF2-HMAC-SHA256 password hashing with salt and in-memory rate limiting.",
        "residual_risk": "low"
      },
      {
        "id": "t-idor-tampering",
        "category": "elevation_of_privilege",
        "asset": "Calendar Event Data Records",
        "threat_description": "User A attempts to modify or delete User B private records by guessing record IDs.",
        "attacker_profile": "Authenticated standard user",
        "attack_path": "Submitting PUT/DELETE requests referencing other tenants record identifiers.",
        "mitigation": "Server-side owner_id verification and RBAC role validation before mutation.",
        "residual_risk": "low"
      },
      {
        "id": "t-data-leakage",
        "category": "information_disclosure",
        "asset": "Account and Exported Data",
        "threat_description": "Unauthorized retrieval of sensitive workspace information.",
        "attacker_profile": "Unauthenticated external network eavesdropper",
        "attack_path": "Interception of API payloads or token theft via XSS.",
        "mitigation": "Strict CORS headers, X-Content-Type-Options, and secure session management.",
        "residual_risk": "low"
      }
    ]
  },
  "analytics": {
    "primary_chart": "bar",
    "secondary_chart": "donut",
    "kpis": [
      {
        "id": "primary_volume",
        "label": "Total Calendar Events",
        "unit": "items",
        "calculation": "count(all)",
        "target": null
      },
      {
        "id": "utilization",
        "label": "Capacity Utilization",
        "unit": "%",
        "calculation": "active / capacity * 100",
        "target": 85.0
      },
      {
        "id": "flagged_records",
        "label": "Attention Required",
        "unit": "flags",
        "calculation": "count(status_alert)",
        "target": null
      }
    ],
    "date_filtering": true,
    "export_format": "json"
  },
  "feature_checklist": [
    {
      "id": "feat-core-crud",
      "name": "Calendar Event Lifecycle Management",
      "description": "Create, inspect, update, and remove Calendar Event domain records with persistence.",
      "tier": "essential",
      "status": "Verified",
      "acceptance_criteria": [
        "User can create a new Calendar Event with required fields.",
        "Database validates input types and persists changes.",
        "Deleted Calendar Event records are safely pruned from the system."
      ],
      "verified_by_test": "test_create_and_query_calendar_event"
    },
    {
      "id": "feat-domain-analytics",
      "name": "Domain KPI & Analytical Visualizations",
      "description": "Real-time visual summaries and KPI computation derived from Calendar Event state.",
      "tier": "essential",
      "status": "Verified",
      "acceptance_criteria": [
        "Metrics recalculate dynamically from SQLite records.",
        "Chart distributions render without external CDN dependencies."
      ],
      "verified_by_test": "test_analytics_summary_kpi_computation"
    },
    {
      "id": "feat-auth-security",
      "name": "Authentication, Roles & Data Custody",
      "description": "Cryptographic password security, session token management, and per-user privacy.",
      "tier": "recommended",
      "status": "Verified",
      "acceptance_criteria": [
        "Passwords hashed with PBKDF2-HMAC-SHA256 and unique salt.",
        "Data export and account deletion endpoints honor privacy rights."
      ],
      "verified_by_test": "test_authentication_and_data_isolation"
    },
    {
      "id": "feat-data-export-portability",
      "name": "Data Portability & Tabular Export",
      "description": "Export workspace records for offline analysis, archiving, or auditing.",
      "tier": "optional",
      "status": "Verified",
      "acceptance_criteria": [
        "Complete JSON / data export is generated upon request.",
        "User can download their complete record history."
      ],
      "verified_by_test": "test_privacy_data_export"
    }
  ],
  "user_journeys": [
    {
      "id": "uj-onboarding",
      "persona": "Professionals, coordinators, and students organizing daily agendas",
      "goal": "Initialize workspace and record the first Calendar Event",
      "trigger": "User opens TimeFlow Calendar & Reminders for the first time",
      "steps": [
        {
          "step_number": 1,
          "action": "Navigate to Weekly Calendar & Schedule",
          "expected_result": "Dashboard loads with empty state guidance or sample seed data."
        },
        {
          "step_number": 2,
          "action": "Click '+ New Event'",
          "expected_result": "Input modal opens with validated form controls."
        },
        {
          "step_number": 3,
          "action": "Fill required values and click Save",
          "expected_result": "Record appears instantly in the layout and updates KPI totals."
        }
      ],
      "outcome": "User has an active, verified Calendar Event in their workspace."
    },
    {
      "id": "uj-review-analytics",
      "persona": "Professionals, coordinators, and students organizing daily agendas",
      "goal": "Review performance trends, filter by date, and audit status",
      "trigger": "Periodic review routine or operational check-in",
      "steps": [
        {
          "step_number": 1,
          "action": "View Weekly Calendar & Schedule charts and KPI cards",
          "expected_result": "Visual charts display real distributions calculated from active records."
        },
        {
          "step_number": 2,
          "action": "Apply status filter or search keyword",
          "expected_result": "Table and metrics narrow immediately to matching entries."
        }
      ],
      "outcome": "User gains actionable domain insight from their data."
    }
  ],
  "business_rules": [
    "Every Calendar Event must have a unique identifier and required core attributes.",
    "Numeric metrics (amounts, streaks, scores) must not be negative.",
    "Users may only update or delete records they own unless granted administrative role.",
    "Exported data sets must reflect currently committed database state accurately."
  ]
} as const;
const DESIGN_DIRECTION = {
  "direction_id": "editorial_calm",
  "palette": {
    "primary": "#0D9488",
    "primary_foreground": "#1C1C1C",
    "accent": "#8F4B28",
    "neutral_ramp": [
      "#FBF9F5",
      "#F3EFE6",
      "#E5DEC9",
      "#C9BFA3",
      "#9C9178",
      "#6E6552",
      "#4B4537",
      "#2D2920",
      "#1C241E"
    ],
    "surface": "#FBF9F5",
    "surface_elevated": "#FFFFFF",
    "border": "#6B6250",
    "text": "#1C241E",
    "text_muted": "#4B4537",
    "focus_ring": "#0D9488",
    "success": "#1B6E32",
    "warning": "#8A4F00",
    "danger": "#A81818"
  },
  "color_mode": "light",
  "typography": {
    "heading_font": "Fraunces",
    "body_font": "Source Sans 3",
    "mono_font": "JetBrains Mono",
    "scale_ratio": 1.28
  },
  "shape": {
    "radius_class": "soft",
    "border_style": "hairline",
    "shadow_style": "soft"
  },
  "density": "comfortable",
  "motion": "subtle",
  "iconography": "outline",
  "brand_mark": {
    "kind": "geometric_glyph",
    "glyph_primitive": "leaf_arch",
    "monogram_letters": "TF"
  },
  "copy_voice": "Encouraging, reflective, unhurried short sentences that celebrate consistency.",
  "rationale": "Serene, high-focus productivity interface with calming teal tones, clear typography, and distinct schedule blocks."
} as const;
const SAMPLE_SEED_DATA: Record<string, EntityRecord[]> = {
  "calendar_event": [
    {
      "id": "evt-01",
      "event_title": "Sprint Planning & Roadmap Review",
      "event_date": "2026-10-15",
      "time_slot": "09:30 - 11:00",
      "category": "Work",
      "location": "Design Studio 3B",
      "notes": "Align on Q4 milestones and user experience priorities."
    },
    {
      "id": "evt-02",
      "event_title": "Dentist Consultation & Checkup",
      "event_date": "2026-10-16",
      "time_slot": "14:00 - 15:00",
      "category": "Health",
      "location": "Downtown Health Pavilion",
      "notes": "Semi-annual dental cleaning and checkup."
    },
    {
      "id": "evt-03",
      "event_title": "Product Architecture Review",
      "event_date": "2026-10-18",
      "time_slot": "15:00 - 16:30",
      "category": "Meeting",
      "location": "Virtual Video Bridge",
      "notes": "Walkthrough of adaptive generator components."
    }
  ],
  "reminder_task": [
    {
      "id": "rem-01",
      "task_title": "Submit quarterly estimated tax filing",
      "due_date": "2026-10-15",
      "priority": "High",
      "status": "Pending",
      "reminder_time": "10:00",
      "repeat_frequency": "Monthly",
      "event_id": "evt-01"
    },
    {
      "id": "rem-02",
      "task_title": "Confirm dinner reservation for anniversary",
      "due_date": "2026-10-16",
      "priority": "Medium",
      "status": "Pending",
      "reminder_time": "12:00",
      "repeat_frequency": "None",
      "event_id": "evt-02"
    },
    {
      "id": "rem-03",
      "task_title": "Drink 2L water and take daily vitamins",
      "due_date": "2026-10-14",
      "priority": "Low",
      "status": "Completed",
      "reminder_time": "08:30",
      "repeat_frequency": "Daily",
      "event_id": "evt-03"
    }
  ]
};
const BRAND_SVG_MARKUP = "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M6 18C6 10 12 6 18 6C18 12 14 18 6 18Z\" stroke=\"currentColor\" stroke-width=\"2\" fill=\"none\"/><path d=\"M6 18L14 10\" stroke=\"currentColor\" stroke-width=\"1.8\"/></svg>";
const NUMERIC_TYPES = new Set(['integer', 'float', 'currency']);

export default function App(): React.ReactElement {
  const [activePageId, setActivePageId] = useState<string>(BLUEPRINT.home_page_id);
  const [recordsByEntity, setRecordsByEntity] = useState<Record<string, EntityRecord[]>>(() => {
    const initial: Record<string, EntityRecord[]> = {};
    for (const ent of BLUEPRINT.entities) {
      initial[ent.name] = [];
    }
    return initial;
  });
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formState, setFormState] = useState<Record<string, string | number | boolean>>({});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const pages = BLUEPRINT.pages as unknown as PageSpecData[];
  const entities = BLUEPRINT.entities as unknown as EntitySpecData[];
  const activePage = pages.find((p) => p.id === activePageId) || pages[0];
  const primaryEntityName = activePage.entities_used[0] || entities[0].name;
  const activeEntity = entities.find((e) => e.name === primaryEntityName) || entities[0];
  const activeRecords = recordsByEntity[activeEntity.name] || [];

  useEffect(() => {
    for (const ent of entities) {
      fetch(`/api/${ent.name}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data: EntityRecord[] | null) => {
          if (Array.isArray(data) && data.length > 0) {
            setRecordsByEntity((prev) => ({ ...prev, [ent.name]: data }));
          }
        })
        .catch(() => {
          // Offline mode uses in-memory state
        });
    }
  }, []);

  const openCreateModal = (): void => {
    const defaults: Record<string, string | number | boolean> = {};
    for (const fld of activeEntity.fields) {
      if (fld.field_type === 'boolean') {
        defaults[fld.name] = Boolean(fld.default_value ?? false);
      } else if (NUMERIC_TYPES.has(fld.field_type)) {
        defaults[fld.name] = Number(fld.default_value ?? 0);
      } else if (fld.field_type === 'enum' && fld.enum_values && fld.enum_values.length > 0) {
        defaults[fld.name] = fld.enum_values[0];
      } else {
        defaults[fld.name] = String(fld.default_value ?? '');
      }
    }
    setFormState(defaults);
    setIsModalOpen(true);
  };

  const handleCreateRecord = (): void => {
    const newRecord: EntityRecord = {
      id: `${activeEntity.name}-${Date.now()}`,
      ...formState,
    };
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: [newRecord, ...(prev[activeEntity.name] || [])],
    }));
    fetch(`/api/${activeEntity.name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formState),
    }).catch(() => undefined);
    setIsModalOpen(false);
    setToastMsg(`Saved ${activeEntity.singular_label}`);
  };

  const handleLoadSampleSeedData = (): void => {
    setRecordsByEntity(SAMPLE_SEED_DATA);
    fetch('/api/seed', { method: 'POST' }).catch(() => undefined);
    setToastMsg('Loaded domain sample records');
  };

  const handleDeleteRecord = (recordId: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).filter((r) => String(r.id) !== recordId),
    }));
    fetch(`/api/${activeEntity.name}/${recordId}`, {
      method: 'DELETE',
    }).catch(() => undefined);
    setToastMsg(`Removed ${activeEntity.singular_label}`);
  };

  const [isLiveTouched, setIsLiveTouched] = useState<boolean>(false);

  const handleExportJsonData = (): void => {
    const jsonStr = JSON.stringify(recordsByEntity, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${BLUEPRINT.app_name.toLowerCase().replace(/[^a-z0-9]/g, '_')}_export.json`;
    a.click();
    URL.revokeObjectURL(url);
    setToastMsg('Workspace records exported');
  };

  const handleToggleBoolean = (recordId: string, fieldName: string): void => {
    setIsLiveTouched(true);
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).map((r) =>
        String(r.id) === recordId ? { ...r, [fieldName]: !r[fieldName] } : r
      ),
    }));
  };

  return (
    <div className="min-h-screen bg-surface text-text font-body">
      <AdaptiveAppShell
        pattern={BLUEPRINT.navigation.pattern}
        appName={BLUEPRINT.app_name}
        tagline={BLUEPRINT.product_tagline}
        brandMark={
          <span
            className="inline-flex items-center"
            dangerouslySetInnerHTML={{ __html: BRAND_SVG_MARKUP }}
          />
        }
        navItems={BLUEPRINT.navigation.items.map((item) => ({
          page_id: item.page_id,
          label: item.label,
          icon: item.icon,
        }))}
        activePageId={activePage.id}
        onSelectPage={setActivePageId}
        primaryAction={
          <div className="flex items-center gap-2">
            {isLiveTouched ? (
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-emerald-500/15 text-emerald-700 border border-emerald-500/30">
                Live Data
              </span>
            ) : activeRecords.length > 0 ? (
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-500/15 text-amber-700 border border-amber-500/30">
                Demo Seed Data
              </span>
            ) : null}
            {activeRecords.length === 0 && (
              <Button variant="secondary" onClick={handleLoadSampleSeedData}>
                Load Sample Data
              </Button>
            )}
            {activeRecords.length > 0 && (
              <Button variant="secondary" onClick={handleExportJsonData}>
                Export Data
              </Button>
            )}
            <Button variant="primary" onClick={openCreateModal}>
              + {activePage.primary_actions[0] || `New ${activeEntity.singular_label}`}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {toastMsg && (
            <div className="flex justify-between items-center">
              <Toast message={toastMsg} tone="success" />
              <Button variant="ghost" onClick={() => setToastMsg(null)}>Dismiss</Button>
            </div>
          )}
          <AdaptiveLayoutRenderer
            page={activePage}
            entity={activeEntity}
            records={activeRecords}
            onOpenCreate={openCreateModal}
            onDeleteRecord={handleDeleteRecord}
            onToggleBoolean={handleToggleBoolean}
          />
        </div>
      </AdaptiveAppShell>

      <Modal
        open={isModalOpen}
        title={`Add ${activeEntity.singular_label}`}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-3">
          {activeEntity.fields.map((fld) => (
            <FormField key={fld.name} label={fld.label} required={fld.required}>
              {fld.field_type === 'enum' && fld.enum_values ? (
                <Select
                  value={String(formState[fld.name] ?? fld.enum_values[0] ?? '')}
                  options={fld.enum_values.map((v) => ({ value: v, label: v }))}
                  onChange={(val) => setFormState((prev) => ({ ...prev, [fld.name]: val }))}
                />
              ) : (
                <Input
                  type={
                    NUMERIC_TYPES.has(fld.field_type)
                      ? 'number'
                      : fld.field_type === 'date'
                        ? 'date'
                        : 'text'
                  }
                  value={String(formState[fld.name] ?? '')}
                  placeholder={`Enter ${fld.label}`}
                  onChange={(val) =>
                    setFormState((prev) => ({
                      ...prev,
                      [fld.name]: NUMERIC_TYPES.has(fld.field_type) ? Number(val) : val,
                    }))
                  }
                />
              )}
            </FormField>
          ))}
          <div className="flex justify-end gap-2 pt-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCreateRecord}>
              Save {activeEntity.singular_label}
            </Button>
          </div>
        </div>
      </Modal>
      
    </div>
  );
}
