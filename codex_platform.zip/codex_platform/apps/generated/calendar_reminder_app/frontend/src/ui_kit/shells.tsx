import React, { useState } from 'react';
import { AppIcon, BrandGlyph } from './icons';
import { Badge, Button, Dialog, Input } from './primitives';

export interface NavShellItem {
  pageId: string;
  label: string;
  icon: string;
}

export interface ShellBrand {
  appName: string;
  tagline: string;
  glyphPrimitive: string;
  monogram: string;
}

export interface NavigationShellProps {
  pattern:
    | 'sidebar'
    | 'top_tabs'
    | 'bottom_tabs'
    | 'command_palette_plus_minimal_top'
    | 'split_master_detail';
  brand: ShellBrand;
  items: NavShellItem[];
  activePageId: string;
  onNavigate: (pageId: string) => void;
  primaryActionLabel?: string;
  onPrimaryAction?: () => void;
  children: React.ReactNode;
}

const BrandHeaderMark: React.FC<{ brand: ShellBrand }> = ({ brand }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
    <div
      style={{
        width: '2.15rem',
        height: '2.15rem',
        borderRadius: 'var(--app-radius-control)',
        backgroundColor: 'var(--app-primary)',
        color: 'var(--app-primary-fg)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontWeight: 700,
        fontSize: '0.78rem',
      }}
    >
      <BrandGlyph primitive={brand.glyphPrimitive} size={17} />
    </div>
    <div>
      <div
        style={{
          fontFamily: 'var(--app-font-heading)',
          fontWeight: 700,
          fontSize: '0.98rem',
          color: 'var(--app-text)',
          lineHeight: 1.2,
        }}
      >
        {brand.appName}
      </div>
      <div style={{ fontSize: '0.72rem', color: 'var(--app-text-muted)' }}>{brand.tagline}</div>
    </div>
  </div>
);

export const SidebarShell: React.FC<Omit<NavigationShellProps, 'pattern'>> = ({
  brand,
  items,
  activePageId,
  onNavigate,
  primaryActionLabel,
  onPrimaryAction,
  children,
}) => (
  <div
    data-shell="sidebar"
    style={{
      minHeight: '100vh',
      display: 'grid',
      gridTemplateColumns: '15.5rem 1fr',
      backgroundColor: 'var(--app-surface)',
      color: 'var(--app-text)',
    }}
  >
    <aside
      style={{
        backgroundColor: 'var(--app-surface-elevated)',
        borderRight: '1px solid var(--app-border)',
        padding: '1.25rem 1rem',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
      }}
    >
      <div>
        <div style={{ marginBottom: '1.5rem' }}>
          <BrandHeaderMark brand={brand} />
        </div>
        <nav aria-label="Primary Sidebar Navigation" style={{ display: 'grid', gap: '0.35rem' }}>
          {items.map((item) => {
            const active = item.pageId === activePageId;
            return (
              <button
                key={item.pageId}
                type="button"
                onClick={() => onNavigate(item.pageId)}
                aria-current={active ? 'page' : undefined}
                style={{
                  backgroundColor: active ? 'var(--app-primary)' : 'transparent',
                  color: active ? 'var(--app-primary-fg)' : 'var(--app-text)',
                  borderRadius: 'var(--app-radius-control)',
                  padding: '0.55rem 0.75rem',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.6rem',
                  fontWeight: active ? 600 : 500,
                  fontSize: '0.84rem',
                  cursor: 'pointer',
                  textAlign: 'left',
                }}
              >
                <AppIcon name={item.icon} size={16} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
      {primaryActionLabel && onPrimaryAction && (
        <Button variant="primary" icon="plus-circle" onClick={onPrimaryAction}>
          {primaryActionLabel}
        </Button>
      )}
    </aside>
    <main style={{ padding: '1.75rem 2rem', overflowY: 'auto' }}>{children}</main>
  </div>
);

export const TopTabsShell: React.FC<Omit<NavigationShellProps, 'pattern'>> = ({
  brand,
  items,
  activePageId,
  onNavigate,
  primaryActionLabel,
  onPrimaryAction,
  children,
}) => (
  <div
    data-shell="top_tabs"
    style={{
      minHeight: '100vh',
      backgroundColor: 'var(--app-surface)',
      color: 'var(--app-text)',
    }}
  >
    <header
      style={{
        backgroundColor: 'var(--app-surface-elevated)',
        borderBottom: '1px solid var(--app-border)',
        padding: '0.9rem 2rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '1rem',
      }}
    >
      <BrandHeaderMark brand={brand} />
      <nav aria-label="Primary Top Navigation" style={{ display: 'flex', gap: '0.4rem' }}>
        {items.map((item) => {
          const active = item.pageId === activePageId;
          return (
            <button
              key={item.pageId}
              type="button"
              onClick={() => onNavigate(item.pageId)}
              aria-current={active ? 'page' : undefined}
              style={{
                backgroundColor: active ? 'var(--app-primary)' : 'transparent',
                color: active ? 'var(--app-primary-fg)' : 'var(--app-text-muted)',
                borderRadius: 'var(--app-radius-control)',
                padding: '0.45rem 0.85rem',
                border: active ? '1px solid var(--app-primary)' : '1px solid transparent',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.45rem',
                fontWeight: 600,
                fontSize: '0.82rem',
                cursor: 'pointer',
              }}
            >
              <AppIcon name={item.icon} size={15} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
      {primaryActionLabel && onPrimaryAction && (
        <Button variant="primary" icon="plus-circle" onClick={onPrimaryAction}>
          {primaryActionLabel}
        </Button>
      )}
    </header>
    <main style={{ maxWidth: '76rem', margin: '0 auto', padding: '1.75rem 2rem' }}>{children}</main>
  </div>
);

export const BottomTabsShell: React.FC<Omit<NavigationShellProps, 'pattern'>> = ({
  brand,
  items,
  activePageId,
  onNavigate,
  primaryActionLabel,
  onPrimaryAction,
  children,
}) => (
  <div
    data-shell="bottom_tabs"
    style={{
      minHeight: '100vh',
      backgroundColor: 'var(--app-surface)',
      color: 'var(--app-text)',
      paddingBottom: '5rem',
    }}
  >
    <header
      style={{
        backgroundColor: 'var(--app-surface-elevated)',
        borderBottom: '1px solid var(--app-border)',
        padding: '0.85rem 1.5rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}
    >
      <BrandHeaderMark brand={brand} />
      {primaryActionLabel && onPrimaryAction && (
        <Button variant="primary" icon="plus-circle" onClick={onPrimaryAction}>
          {primaryActionLabel}
        </Button>
      )}
    </header>
    <main style={{ maxWidth: '58rem', margin: '0 auto', padding: '1.5rem' }}>{children}</main>
    <nav
      aria-label="Primary Bottom Navigation"
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: 'var(--app-surface-elevated)',
        borderTop: '1px solid var(--app-border)',
        display: 'flex',
        justifyContent: 'space-around',
        padding: '0.5rem 1rem',
        zIndex: 30,
      }}
    >
      {items.map((item) => {
        const active = item.pageId === activePageId;
        return (
          <button
            key={item.pageId}
            type="button"
            onClick={() => onNavigate(item.pageId)}
            aria-current={active ? 'page' : undefined}
            style={{
              backgroundColor: active ? 'var(--app-primary)' : 'transparent',
              color: active ? 'var(--app-primary-fg)' : 'var(--app-text-muted)',
              borderRadius: 'var(--app-radius-control)',
              padding: '0.45rem 1rem',
              border: 'none',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '0.2rem',
              fontWeight: 600,
              fontSize: '0.74rem',
              cursor: 'pointer',
            }}
          >
            <AppIcon name={item.icon} size={17} />
            <span>{item.label}</span>
          </button>
        );
      })}
    </nav>
  </div>
);

export const CommandMinimalShell: React.FC<Omit<NavigationShellProps, 'pattern'>> = ({
  brand,
  items,
  activePageId,
  onNavigate,
  primaryActionLabel,
  onPrimaryAction,
  children,
}) => {
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredItems = items.filter((i) =>
    i.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div
      data-shell="command_palette_plus_minimal_top"
      style={{
        minHeight: '100vh',
        backgroundColor: 'var(--app-surface)',
        color: 'var(--app-text)',
      }}
    >
      <header
        style={{
          backgroundColor: 'var(--app-surface-elevated)',
          borderBottom: '1px solid var(--app-border)',
          padding: '0.65rem 1.5rem',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '1rem',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <BrandHeaderMark brand={brand} />
          <div style={{ display: 'flex', gap: '0.35rem' }}>
            {items.map((item) => {
              const active = item.pageId === activePageId;
              return (
                <button
                  key={item.pageId}
                  type="button"
                  onClick={() => onNavigate(item.pageId)}
                  style={{
                    backgroundColor: active ? 'var(--app-primary)' : 'transparent',
                    color: active ? 'var(--app-primary-fg)' : 'var(--app-text-muted)',
                    borderRadius: 'var(--app-radius-control)',
                    padding: '0.3rem 0.65rem',
                    border: '1px solid var(--app-border)',
                    fontFamily: 'var(--app-font-mono)',
                    fontSize: '0.75rem',
                    cursor: 'pointer',
                  }}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <Button variant="secondary" icon="search" onClick={() => setPaletteOpen(true)}>
            Command (Ctrl+K)
          </Button>
          {primaryActionLabel && onPrimaryAction && (
            <Button variant="primary" icon="plus-circle" onClick={onPrimaryAction}>
              {primaryActionLabel}
            </Button>
          )}
        </div>
      </header>
      <main style={{ padding: '1.25rem 1.5rem' }}>{children}</main>
      <Dialog
        open={paletteOpen}
        title="Command & Navigation Palette"
        onClose={() => setPaletteOpen(false)}
      >
        <div style={{ display: 'grid', gap: '0.75rem' }}>
          <Input
            label="Jump to view or run action"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Type view name..."
          />
          <div style={{ display: 'grid', gap: '0.35rem' }}>
            {filteredItems.map((item) => (
              <button
                key={item.pageId}
                type="button"
                onClick={() => {
                  onNavigate(item.pageId);
                  setPaletteOpen(false);
                }}
                style={{
                  backgroundColor: 'var(--app-surface)',
                  color: 'var(--app-text)',
                  border: '1px solid var(--app-border)',
                  borderRadius: 'var(--app-radius-control)',
                  padding: '0.55rem 0.75rem',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer',
                }}
              >
                <span>{item.label}</span>
                <Badge>{item.pageId}</Badge>
              </button>
            ))}
          </div>
        </div>
      </Dialog>
    </div>
  );
};

export const SplitMasterDetailShell: React.FC<Omit<NavigationShellProps, 'pattern'>> = ({
  brand,
  items,
  activePageId,
  onNavigate,
  primaryActionLabel,
  onPrimaryAction,
  children,
}) => (
  <div
    data-shell="split_master_detail"
    style={{
      minHeight: '100vh',
      display: 'grid',
      gridTemplateColumns: '18rem 1fr',
      backgroundColor: 'var(--app-surface)',
      color: 'var(--app-text)',
    }}
  >
    <aside
      style={{
        backgroundColor: 'var(--app-surface-elevated)',
        borderRight: '1px solid var(--app-border)',
        padding: '1.25rem',
        display: 'flex',
        flexDirection: 'column',
        gap: '1.25rem',
      }}
    >
      <BrandHeaderMark brand={brand} />
      <div style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--app-text-muted)' }}>
        WORKSPACES & COLLECTIONS
      </div>
      <nav aria-label="Master Detail Navigation" style={{ display: 'grid', gap: '0.45rem' }}>
        {items.map((item) => {
          const active = item.pageId === activePageId;
          return (
            <button
              key={item.pageId}
              type="button"
              onClick={() => onNavigate(item.pageId)}
              aria-current={active ? 'page' : undefined}
              style={{
                backgroundColor: active ? 'var(--app-primary)' : 'var(--app-surface)',
                color: active ? 'var(--app-primary-fg)' : 'var(--app-text)',
                border: '1px solid var(--app-border)',
                borderRadius: 'var(--app-radius-card)',
                padding: '0.7rem 0.85rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                fontWeight: 600,
                fontSize: '0.84rem',
                cursor: 'pointer',
              }}
            >
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                <AppIcon name={item.icon} size={16} />
                {item.label}
              </span>
              <Badge tone={active ? 'primary' : 'default'}>View</Badge>
            </button>
          );
        })}
      </nav>
      {primaryActionLabel && onPrimaryAction && (
        <div style={{ marginTop: 'auto' }}>
          <Button variant="primary" icon="plus-circle" onClick={onPrimaryAction}>
            {primaryActionLabel}
          </Button>
        </div>
      )}
    </aside>
    <main style={{ padding: '1.75rem 2rem', overflowY: 'auto' }}>{children}</main>
  </div>
);

export const NavigationShell: React.FC<NavigationShellProps> = ({ pattern, ...rest }) => {
  switch (pattern) {
    case 'sidebar':
      return <SidebarShell {...rest} />;
    case 'top_tabs':
      return <TopTabsShell {...rest} />;
    case 'bottom_tabs':
      return <BottomTabsShell {...rest} />;
    case 'command_palette_plus_minimal_top':
      return <CommandMinimalShell {...rest} />;
    case 'split_master_detail':
      return <SplitMasterDetailShell {...rest} />;
    default:
      return <SidebarShell {...rest} />;
  }
};
