import React from 'react';

export interface IconProps {
  name: string;
  size?: number;
  className?: string;
}

export const AppIcon: React.FC<IconProps> = ({ name, size = 18, className = '' }) => {
  const clean = name.trim().toLowerCase();
  const common = {
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 2,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    className,
    'aria-hidden': true,
  };

  switch (clean) {
    case 'check-circle':
    case 'check-square':
      return (
        <svg {...common}>
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
          <polyline points="22 4 12 14.01 9 11.01" />
        </svg>
      );
    case 'flame':
    case 'zap':
      return (
        <svg {...common}>
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
        </svg>
      );
    case 'calendar':
    case 'clock':
      return (
        <svg {...common}>
          <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
          <line x1="16" y1="2" x2="16" y2="6" />
          <line x1="8" y1="2" x2="8" y2="6" />
          <line x1="3" y1="10" x2="21" y2="10" />
        </svg>
      );
    case 'shield':
    case 'lock':
      return (
        <svg {...common}>
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
        </svg>
      );
    case 'terminal':
    case 'code':
    case 'server':
      return (
        <svg {...common}>
          <polyline points="4 17 10 11 4 5" />
          <line x1="12" y1="19" x2="20" y2="19" />
        </svg>
      );
    case 'users':
    case 'user':
      return (
        <svg {...common}>
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
          <circle cx="9" cy="7" r="4" />
          <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
          <path d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
      );
    case 'package':
    case 'box':
    case 'shopping-bag':
    case 'utensils':
      return (
        <svg {...common}>
          <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
          <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
          <line x1="12" y1="22.08" x2="12" y2="12" />
        </svg>
      );
    case 'dollar-sign':
    case 'credit-card':
    case 'receipt':
      return (
        <svg {...common}>
          <rect x="1" y="4" width="22" height="16" rx="2" ry="2" />
          <line x1="1" y1="10" x2="23" y2="10" />
        </svg>
      );
    case 'bar-chart-2':
    case 'pie-chart':
    case 'trending-up':
    case 'activity':
      return (
        <svg {...common}>
          <line x1="18" y1="20" x2="18" y2="10" />
          <line x1="12" y1="20" x2="12" y2="4" />
          <line x1="6" y1="20" x2="6" y2="14" />
        </svg>
      );
    case 'map-pin':
    case 'compass':
    case 'globe':
      return (
        <svg {...common}>
          <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
          <circle cx="12" cy="10" r="3" />
        </svg>
      );
    case 'heart':
    case 'stethoscope':
      return (
        <svg {...common}>
          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
        </svg>
      );
    case 'plus-circle':
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="10" />
          <line x1="12" y1="8" x2="12" y2="16" />
          <line x1="8" y1="12" x2="16" y2="12" />
        </svg>
      );
    case 'search':
    case 'filter':
      return (
        <svg {...common}>
          <circle cx="11" cy="11" r="8" />
          <line x1="21" y1="21" x2="16.65" y2="16.65" />
        </svg>
      );
    default:
      return (
        <svg {...common}>
          <rect x="3" y="3" width="7" height="7" />
          <rect x="14" y="3" width="7" height="7" />
          <rect x="14" y="14" width="7" height="7" />
          <rect x="3" y="14" width="7" height="7" />
        </svg>
      );
  }
};

export const BrandGlyph: React.FC<{ primitive: string; size?: number }> = ({
  primitive,
  size = 20,
}) => {
  const common = {
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 2,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    'aria-hidden': true,
  };

  switch (primitive) {
    case 'leaf_arch':
      return (
        <svg {...common}>
          <path d="M6 18C6 10 12 6 18 6C18 12 14 18 6 18Z" />
          <path d="M6 18L14 10" />
        </svg>
      );
    case 'bars_ascending':
      return (
        <svg {...common}>
          <rect x="5" y="13" width="3" height="6" rx="1" fill="currentColor" />
          <rect x="10.5" y="9" width="3" height="10" rx="1" fill="currentColor" />
          <rect x="16" y="5" width="3" height="14" rx="1" fill="currentColor" />
        </svg>
      );
    case 'shield_crest':
      return (
        <svg {...common}>
          <path d="M12 3L19 6V11.5C19 16 15.8 19.6 12 21C8.2 19.6 5 16 5 11.5V6L12 3Z" />
          <circle cx="12" cy="11.5" r="2" fill="currentColor" />
        </svg>
      );
    case 'spark_diamond':
      return (
        <svg {...common}>
          <path d="M12 3L14.8 9.2L21 12L14.8 14.8L12 21L9.2 14.8L3 12L9.2 9.2L12 3Z" />
        </svg>
      );
    case 'pulse_wave':
      return (
        <svg {...common}>
          <path d="M3 12H7L9.5 6L14.5 18L17 12H21" />
        </svg>
      );
    case 'cube_iso':
      return (
        <svg {...common}>
          <path d="M12 3L20 7.5V16.5L12 21L4 16.5V7.5L12 3Z" />
          <path d="M4 7.5L12 12L20 7.5M12 12V21" />
        </svg>
      );
    case 'compass_star':
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="8.5" />
          <path d="M15.5 8.5L13.5 13.5L8.5 15.5L10.5 10.5L15.5 8.5Z" />
        </svg>
      );
    case 'court_lines':
      return (
        <svg {...common}>
          <rect x="4" y="5" width="16" height="14" rx="2" />
          <line x1="12" y1="5" x2="12" y2="19" />
          <circle cx="12" cy="12" r="2.5" />
        </svg>
      );
    case 'hex_grid':
      return (
        <svg {...common}>
          <polygon points="12,3 19,7 19,15 12,19 5,15 5,7" />
          <circle cx="12" cy="11" r="2.5" fill="currentColor" />
        </svg>
      );
    case 'book_open':
      return (
        <svg {...common}>
          <path d="M3 6C3 6 7 4.5 12 6.5C17 4.5 21 6 21 6V18.5C21 18.5 17 17 12 19C7 17 3 18.5 3 18.5V6Z" />
          <line x1="12" y1="6.5" x2="12" y2="19" />
        </svg>
      );
    default:
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="8" />
          <circle cx="12" cy="12" r="3" fill="currentColor" />
        </svg>
      );
  }
};
