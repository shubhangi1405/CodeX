import React, { useEffect, useState } from 'react';
import {
  AdaptiveAppShell,
  AdaptiveLayoutRenderer,
  Button,
  FormField,
  Input,
  Modal,
  Select,
  Toast,
  EntityRecord,
  EntitySpecData,
  PageSpecData,
} from './ui_kit';

const BLUEPRINT = {
  "app_name": "BastionPulse SIEM",
  "product_tagline": "Low-latency security telemetry stream, anomaly triage, and rule containment",
  "domain": {
    "product_kind": "Real-Time Security Telemetry & SIEM Event Log Viewer",
    "archetype": "ops_monitoring",
    "audience": {
      "who": "SOC analysts, incident responders, and infrastructure security engineers",
      "context_of_use": "Low-light security operations center with keyboard-driven triage",
      "device_likely_used": "desktop",
      "tech_comfort": "high"
    },
    "core_jobs": [
      "Tail and filter live security event streams by severity and source host",
      "Investigate suspicious authentication or firewall anomalies in real time",
      "Escalate and track active containment rules across production clusters"
    ],
    "primary_object": "security_event",
    "tone": "technical",
    "data_shape": "time-series",
    "needs_automation": false,
    "rationale": "Security operators triaging live threats in a SOC require a dark, low-glare monospace log stream with command-palette navigation and severity filtering."
  },
  "entities": [
    {
      "name": "security_event",
      "singular_label": "Security Event",
      "plural_label": "Security Events",
      "fields": [
        {
          "name": "timestamp_utc",
          "label": "Timestamp (UTC)",
          "field_type": "datetime",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "severity",
          "label": "Severity",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "CRITICAL",
            "HIGH",
            "WARN",
            "INFO"
          ],
          "default_value": null
        },
        {
          "name": "source_service",
          "label": "Source Host / Service",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "event_signature",
          "label": "Event Signature",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "source_ip",
          "label": "Origin IP Address",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        }
      ],
      "relationships": []
    },
    {
      "name": "detection_rule",
      "singular_label": "Detection Rule",
      "plural_label": "Detection Rules",
      "fields": [
        {
          "name": "rule_code",
          "label": "Rule Identifier",
          "field_type": "string",
          "required": true,
          "unique": true,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "mitre_tactic",
          "label": "MITRE ATT&CK Tactic",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Initial Access",
            "Privilege Escalation",
            "Credential Access",
            "Exfiltration"
          ],
          "default_value": null
        },
        {
          "name": "enforcement_mode",
          "label": "Enforcement Mode",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Block & Page",
            "Alert Only",
            "Shadow Audit"
          ],
          "default_value": null
        }
      ],
      "relationships": []
    }
  ],
  "pages": [
    {
      "id": "live-telemetry-stream",
      "title": "Live Telemetry Stream",
      "route": "/live-telemetry-stream",
      "layout": "log_stream",
      "entities_used": [
        "security_event"
      ],
      "primary_actions": [
        "Ingest Telemetry Event",
        "Isolate Host"
      ],
      "empty_state": {
        "headline": "Telemetry Stream Listening on All Collectors",
        "body": "No security events match the active severity filter. Emit a test event or broaden your query window.",
        "cta_label": "Emit Test Security Event",
        "cta_action_id": "create_security_event"
      }
    },
    {
      "id": "incident-timeline",
      "title": "Attack Chain Timeline",
      "route": "/incident-timeline",
      "layout": "timeline",
      "entities_used": [
        "security_event"
      ],
      "primary_actions": [
        "Correlate IOCs",
        "Log Incident Event"
      ],
      "empty_state": {
        "headline": "No Active Incident Chains",
        "body": "Correlated high-severity events will appear chronologically here.",
        "cta_label": "Record Incident Event",
        "cta_action_id": "create_security_event"
      }
    },
    {
      "id": "detection-rules",
      "title": "Detection Rules Matrix",
      "route": "/detection-rules",
      "layout": "data_table_with_filters",
      "entities_used": [
        "detection_rule"
      ],
      "primary_actions": [
        "Deploy Detection Rule"
      ],
      "empty_state": {
        "headline": "No Custom Detection Rules Armed",
        "body": "Author a MITRE ATT&CK rule to flag anomalous authentication patterns.",
        "cta_label": "Author Detection Rule",
        "cta_action_id": "create_detection_rule"
      }
    }
  ],
  "navigation": {
    "pattern": "command_palette_plus_minimal_top",
    "items": [
      {
        "page_id": "live-telemetry-stream",
        "label": "Telemetry Stream",
        "icon": "terminal"
      },
      {
        "page_id": "incident-timeline",
        "label": "Attack Timeline",
        "icon": "activity"
      },
      {
        "page_id": "detection-rules",
        "label": "Detection Rules",
        "icon": "shield"
      }
    ]
  },
  "home_page_id": "live-telemetry-stream",
  "automations": []
} as const;
const DESIGN_DIRECTION = {
  "direction_id": "console_dark",
  "palette": {
    "primary": "#14B8A6",
    "primary_foreground": "#081018",
    "accent": "#FBBF24",
    "neutral_ramp": [
      "#0B0F17",
      "#111827",
      "#1F2937",
      "#374151",
      "#4B5563",
      "#6B7280",
      "#9CA3AF",
      "#D1D5DB",
      "#F9FAFB"
    ],
    "surface": "#0B0F17",
    "surface_elevated": "#141C2B",
    "border": "#64748B",
    "text": "#F1F5F9",
    "text_muted": "#94A3B8",
    "focus_ring": "#14B8A6",
    "success": "#34D399",
    "warning": "#FBBF24",
    "danger": "#F87171"
  },
  "color_mode": "dark",
  "typography": {
    "heading_font": "Space Grotesk",
    "body_font": "Inter",
    "mono_font": "JetBrains Mono",
    "scale_ratio": 1.18
  },
  "shape": {
    "radius_class": "sharp",
    "border_style": "hairline",
    "shadow_style": "none"
  },
  "density": "compact",
  "motion": "none",
  "iconography": "outline",
  "brand_mark": {
    "kind": "geometric_glyph",
    "glyph_primitive": "shield_crest",
    "monogram_letters": "BP"
  },
  "copy_voice": "Terse, technical, operator-grade telemetry terminology (severity, source, ack).",
  "rationale": "Near-black carbon surfaces, JetBrains Mono timestamps, and high-visibility teal/amber severity badges prevent eye strain in 24/7 SOC rooms."
} as const;
const SAMPLE_SEED_DATA: Record<string, EntityRecord[]> = {
  "security_event": [
    {
      "id": "evt-901",
      "timestamp_utc": "2026-10-13T04:12:09Z",
      "severity": "CRITICAL",
      "source_service": "auth-gateway-prod-02",
      "event_signature": "SSH brute-force burst (48 failed root attempts in 10s)",
      "source_ip": "198.51.100.74"
    },
    {
      "id": "evt-902",
      "timestamp_utc": "2026-10-13T04:14:22Z",
      "severity": "HIGH",
      "source_service": "k8s-ingress-us-east",
      "event_signature": "WAF blocked SQL union injection payload on /v2/checkout",
      "source_ip": "203.0.113.19"
    },
    {
      "id": "evt-903",
      "timestamp_utc": "2026-10-13T04:15:01Z",
      "severity": "WARN",
      "source_service": "iam-token-issuer",
      "event_signature": "Unusual cross-region OAuth refresh token rotation",
      "source_ip": "192.0.2.118"
    }
  ],
  "detection_rule": [
    {
      "id": "rule-01",
      "rule_code": "SIG-AUTH-409",
      "mitre_tactic": "Credential Access",
      "enforcement_mode": "Block & Page"
    }
  ]
};
const BRAND_SVG_MARKUP = "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 3L19 6V11.5C19 16 15.8 19.6 12 21C8.2 19.6 5 16 5 11.5V6L12 3Z\" stroke=\"currentColor\" stroke-width=\"2\" fill=\"none\"/><circle cx=\"12\" cy=\"11.5\" r=\"2.2\" fill=\"currentColor\"/></svg>";
const NUMERIC_TYPES = new Set(['integer', 'float', 'currency']);

export default function App(): React.ReactElement {
  const [activePageId, setActivePageId] = useState<string>(BLUEPRINT.home_page_id);
  const [recordsByEntity, setRecordsByEntity] = useState<Record<string, EntityRecord[]>>(() => {
    const initial: Record<string, EntityRecord[]> = {};
    for (const ent of BLUEPRINT.entities) {
      initial[ent.name] = [];
    }
    return initial;
  });
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formState, setFormState] = useState<Record<string, string | number | boolean>>({});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const pages = BLUEPRINT.pages as unknown as PageSpecData[];
  const entities = BLUEPRINT.entities as unknown as EntitySpecData[];
  const activePage = pages.find((p) => p.id === activePageId) || pages[0];
  const primaryEntityName = activePage.entities_used[0] || entities[0].name;
  const activeEntity = entities.find((e) => e.name === primaryEntityName) || entities[0];
  const activeRecords = recordsByEntity[activeEntity.name] || [];

  useEffect(() => {
    for (const ent of entities) {
      fetch(`/api/${ent.name}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data: EntityRecord[] | null) => {
          if (Array.isArray(data) && data.length > 0) {
            setRecordsByEntity((prev) => ({ ...prev, [ent.name]: data }));
          }
        })
        .catch(() => {
          // Offline mode uses in-memory state
        });
    }
  }, []);

  const openCreateModal = (): void => {
    const defaults: Record<string, string | number | boolean> = {};
    for (const fld of activeEntity.fields) {
      if (fld.field_type === 'boolean') {
        defaults[fld.name] = Boolean(fld.default_value ?? false);
      } else if (NUMERIC_TYPES.has(fld.field_type)) {
        defaults[fld.name] = Number(fld.default_value ?? 0);
      } else if (fld.field_type === 'enum' && fld.enum_values && fld.enum_values.length > 0) {
        defaults[fld.name] = fld.enum_values[0];
      } else {
        defaults[fld.name] = String(fld.default_value ?? '');
      }
    }
    setFormState(defaults);
    setIsModalOpen(true);
  };

  const handleCreateRecord = (): void => {
    const newRecord: EntityRecord = {
      id: `${activeEntity.name}-${Date.now()}`,
      ...formState,
    };
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: [newRecord, ...(prev[activeEntity.name] || [])],
    }));
    fetch(`/api/${activeEntity.name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formState),
    }).catch(() => undefined);
    setIsModalOpen(false);
    setToastMsg(`Saved ${activeEntity.singular_label}`);
  };

  const handleLoadSampleSeedData = (): void => {
    setRecordsByEntity(SAMPLE_SEED_DATA);
    fetch('/api/seed', { method: 'POST' }).catch(() => undefined);
    setToastMsg('Loaded domain sample records');
  };

  const handleDeleteRecord = (recordId: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).filter((r) => String(r.id) !== recordId),
    }));
    fetch(`/api/${activeEntity.name}/${recordId}`, {
      method: 'DELETE',
    }).catch(() => undefined);
    setToastMsg(`Removed ${activeEntity.singular_label}`);
  };

  const handleToggleBoolean = (recordId: string, fieldName: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).map((r) =>
        String(r.id) === recordId ? { ...r, [fieldName]: !r[fieldName] } : r
      ),
    }));
  };

  return (
    <div className="min-h-screen bg-surface text-text font-body">
      <AdaptiveAppShell
        pattern={BLUEPRINT.navigation.pattern}
        appName={BLUEPRINT.app_name}
        tagline={BLUEPRINT.product_tagline}
        brandMark={
          <span
            className="inline-flex items-center"
            dangerouslySetInnerHTML={{ __html: BRAND_SVG_MARKUP }}
          />
        }
        navItems={BLUEPRINT.navigation.items.map((item) => ({
          page_id: item.page_id,
          label: item.label,
          icon: item.icon,
        }))}
        activePageId={activePage.id}
        onSelectPage={setActivePageId}
        primaryAction={
          <div className="flex items-center gap-2">
            {activeRecords.length === 0 && (
              <Button variant="secondary" onClick={handleLoadSampleSeedData}>
                Load Sample Data
              </Button>
            )}
            <Button variant="primary" onClick={openCreateModal}>
              + {activePage.primary_actions[0] || `New ${activeEntity.singular_label}`}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {toastMsg && (
            <div className="flex justify-between items-center">
              <Toast message={toastMsg} tone="success" />
              <Button variant="ghost" onClick={() => setToastMsg(null)}>Dismiss</Button>
            </div>
          )}
          <AdaptiveLayoutRenderer
            page={activePage}
            entity={activeEntity}
            records={activeRecords}
            onOpenCreate={openCreateModal}
            onDeleteRecord={handleDeleteRecord}
            onToggleBoolean={handleToggleBoolean}
          />
        </div>
      </AdaptiveAppShell>

      <Modal
        open={isModalOpen}
        title={`Add ${activeEntity.singular_label}`}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-3">
          {activeEntity.fields.map((fld) => (
            <FormField key={fld.name} label={fld.label} required={fld.required}>
              {fld.field_type === 'enum' && fld.enum_values ? (
                <Select
                  value={String(formState[fld.name] ?? fld.enum_values[0] ?? '')}
                  options={fld.enum_values.map((v) => ({ value: v, label: v }))}
                  onChange={(val) => setFormState((prev) => ({ ...prev, [fld.name]: val }))}
                />
              ) : (
                <Input
                  type={
                    NUMERIC_TYPES.has(fld.field_type)
                      ? 'number'
                      : fld.field_type === 'date'
                        ? 'date'
                        : 'text'
                  }
                  value={String(formState[fld.name] ?? '')}
                  placeholder={`Enter ${fld.label}`}
                  onChange={(val) =>
                    setFormState((prev) => ({
                      ...prev,
                      [fld.name]: NUMERIC_TYPES.has(fld.field_type) ? Number(val) : val,
                    }))
                  }
                />
              )}
            </FormField>
          ))}
          <div className="flex justify-end gap-2 pt-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCreateRecord}>
              Save {activeEntity.singular_label}
            </Button>
          </div>
        </div>
      </Modal>
      
    </div>
  );
}
