"""Optional sample seed data loader for BastionPulse SIEM."""

import json
from sqlalchemy.orm import Session
from database import Base, SessionLocal, engine
from models import SecurityEventModel, DetectionRuleModel

SAMPLE_SEED_DATA = json.loads(r'''{
  "security_event": [
    {
      "id": "evt-901",
      "timestamp_utc": "2026-10-13T04:12:09Z",
      "severity": "CRITICAL",
      "source_service": "auth-gateway-prod-02",
      "event_signature": "SSH brute-force burst (48 failed root attempts in 10s)",
      "source_ip": "198.51.100.74"
    },
    {
      "id": "evt-902",
      "timestamp_utc": "2026-10-13T04:14:22Z",
      "severity": "HIGH",
      "source_service": "k8s-ingress-us-east",
      "event_signature": "WAF blocked SQL union injection payload on /v2/checkout",
      "source_ip": "203.0.113.19"
    },
    {
      "id": "evt-903",
      "timestamp_utc": "2026-10-13T04:15:01Z",
      "severity": "WARN",
      "source_service": "iam-token-issuer",
      "event_signature": "Unusual cross-region OAuth refresh token rotation",
      "source_ip": "192.0.2.118"
    }
  ],
  "detection_rule": [
    {
      "id": "rule-01",
      "rule_code": "SIG-AUTH-409",
      "mitre_tactic": "Credential Access",
      "enforcement_mode": "Block & Page"
    }
  ]
}''')


def seed_database(db: Session) -> dict[str, int]:
    """Inserts domain sample records if tables are currently empty."""
    inserted: dict[str, int] = {}
    records_security_event = SAMPLE_SEED_DATA.get("security_event", [])
    existing_security_event = db.query(SecurityEventModel).count()
    count_security_event = 0
    if existing_security_event == 0:
        for row in records_security_event:
            allowed = ['timestamp_utc', 'severity', 'source_service', 'event_signature', 'source_ip']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(SecurityEventModel(**payload))
            count_security_event += 1
    inserted["security_event"] = count_security_event
    records_detection_rule = SAMPLE_SEED_DATA.get("detection_rule", [])
    existing_detection_rule = db.query(DetectionRuleModel).count()
    count_detection_rule = 0
    if existing_detection_rule == 0:
        for row in records_detection_rule:
            allowed = ['rule_code', 'mitre_tactic', 'enforcement_mode']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(DetectionRuleModel(**payload))
            count_detection_rule += 1
    inserted["detection_rule"] = count_detection_rule
    db.commit()
    return inserted


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as session:
        result = seed_database(session)
        print("Seeded sample records:", result)
