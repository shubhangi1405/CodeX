"""Domain SQLAlchemy ORM models for BastionPulse SIEM."""

from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from database import Base

class SecurityEventModel(Base):
    __tablename__ = "security_events"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    timestamp_utc = Column(String, nullable=False, default='')
    severity = Column(String, nullable=False, default='CRITICAL')
    source_service = Column(String, nullable=False, default='')
    event_signature = Column(String, nullable=False, default='')
    source_ip = Column(String, nullable=False, default='')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class DetectionRuleModel(Base):
    __tablename__ = "detection_rules"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    rule_code = Column(String, nullable=False, default='')
    mitre_tactic = Column(String, nullable=False, default='Initial Access')
    enforcement_mode = Column(String, nullable=False, default='Block & Page')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
