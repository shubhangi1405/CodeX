"""FastAPI backend for BastionPulse SIEM — Low-latency security telemetry stream, anomaly triage, and rule containment."""

import json
from typing import Any, Optional
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import SecurityEventModel, DetectionRuleModel
from seed import seed_database

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='BastionPulse SIEM',
    description='Low-latency security telemetry stream, anomaly triage, and rule containment',
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class SecurityEventCreate(BaseModel):
    timestamp_utc: str = ''
    severity: str = 'CRITICAL'
    source_service: str = ''
    event_signature: str = ''
    source_ip: str = ''

class SecurityEventUpdate(BaseModel):
    timestamp_utc: Optional[str] = None
    severity: Optional[str] = None
    source_service: Optional[str] = None
    event_signature: Optional[str] = None
    source_ip: Optional[str] = None

def _serialize_security_event(item: SecurityEventModel) -> dict[str, Any]:
    return {"id": item.id, "timestamp_utc": getattr(item, "timestamp_utc"), "severity": getattr(item, "severity"), "source_service": getattr(item, "source_service"), "event_signature": getattr(item, "event_signature"), "source_ip": getattr(item, "source_ip")}

@app.get("/api/security_event")
def list_security_event(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(SecurityEventModel).order_by(SecurityEventModel.created_at.desc()).all()
    return [_serialize_security_event(r) for r in rows]

@app.post("/api/security_event", status_code=201)
def create_security_event(
    payload: SecurityEventCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = SecurityEventModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_security_event(record)

@app.put("/api/security_event/{item_id}")
def update_security_event(
    item_id: str, payload: SecurityEventUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(SecurityEventModel).filter(SecurityEventModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Security Event not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_security_event(record)

@app.delete("/api/security_event/{item_id}")
def delete_security_event(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(SecurityEventModel).filter(SecurityEventModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Security Event not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class DetectionRuleCreate(BaseModel):
    rule_code: str = ''
    mitre_tactic: str = 'Initial Access'
    enforcement_mode: str = 'Block & Page'

class DetectionRuleUpdate(BaseModel):
    rule_code: Optional[str] = None
    mitre_tactic: Optional[str] = None
    enforcement_mode: Optional[str] = None

def _serialize_detection_rule(item: DetectionRuleModel) -> dict[str, Any]:
    return {"id": item.id, "rule_code": getattr(item, "rule_code"), "mitre_tactic": getattr(item, "mitre_tactic"), "enforcement_mode": getattr(item, "enforcement_mode")}

@app.get("/api/detection_rule")
def list_detection_rule(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(DetectionRuleModel).order_by(DetectionRuleModel.created_at.desc()).all()
    return [_serialize_detection_rule(r) for r in rows]

@app.post("/api/detection_rule", status_code=201)
def create_detection_rule(
    payload: DetectionRuleCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = DetectionRuleModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_detection_rule(record)

@app.put("/api/detection_rule/{item_id}")
def update_detection_rule(
    item_id: str, payload: DetectionRuleUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(DetectionRuleModel).filter(DetectionRuleModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Detection Rule not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_detection_rule(record)

@app.delete("/api/detection_rule/{item_id}")
def delete_detection_rule(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(DetectionRuleModel).filter(DetectionRuleModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Detection Rule not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

@app.post("/api/seed")
def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:
    inserted = seed_database(db)
    return {"status": "seeded", "inserted": inserted}

@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {
        "status": "healthy",
        "app": 'BastionPulse SIEM',
        "archetype": 'ops_monitoring',
    }
