# BastionPulse SIEM

> Low-latency security telemetry stream, anomaly triage, and rule containment

## Product & Domain Summary
- **Product Kind**: Real-Time Security Telemetry & SIEM Event Log Viewer
- **Archetype**: `ops_monitoring`
- **Primary Object**: `security_event`
- **Target Audience**: SOC analysts, incident responders, and infrastructure security engineers (Low-light security operations center with keyboard-driven triage)
- **Navigation Pattern**: `command_palette_plus_minimal_top`
- **Home Page**: `live-telemetry-stream` (`log_stream`)

## Design Direction (`console_dark`)
- **Color Mode**: `dark` | **Primary**: `#14B8A6` | **Surface**: `#0B0F17`
- **Typography**: Heading `Space Grotesk` · Body `Inter` · Mono `JetBrains Mono`
- **Shape & Density**: Radius `sharp` · Density `compact`
- **Rationale**: Near-black carbon surfaces, JetBrains Mono timestamps, and high-visibility teal/amber severity badges prevent eye strain in 24/7 SOC rooms.

## Domain Entities
- **Security Events** (`security_event`): `timestamp_utc` (datetime), `severity` (enum), `source_service` (string), `event_signature` (string), `source_ip` (string)
- **Detection Rules** (`detection_rule`): `rule_code` (string), `mitre_tactic` (enum), `enforcement_mode` (enum)

## Application Screens
- **Live Telemetry Stream** (`/live-telemetry-stream`) — Layout: `log_stream`
- **Attack Chain Timeline** (`/incident-timeline`) — Layout: `timeline`
- **Detection Rules Matrix** (`/detection-rules`) — Layout: `data_table_with_filters`

## API Endpoints
- `GET /api/security_event`
- `POST /api/security_event`
- `PUT /api/security_event/{item_id}`
- `DELETE /api/security_event/{item_id}`
- `GET /api/detection_rule`
- `POST /api/detection_rule`
- `PUT /api/detection_rule/{item_id}`
- `DELETE /api/detection_rule/{item_id}`
- `POST /api/seed`
- `GET /api/health`

## SQLAlchemy Models
- `SecurityEventModel`
- `DetectionRuleModel`

## Local Execution

### 1. Instant Standalone UI
Open `standalone_app.html` directly in any browser (zero external CDN dependencies).

### 2. Backend API (`FastAPI` + `SQLite`)
```bash
cd backend
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### 3. React + Vite Frontend
```bash
cd frontend
npm install
npm run dev
```
