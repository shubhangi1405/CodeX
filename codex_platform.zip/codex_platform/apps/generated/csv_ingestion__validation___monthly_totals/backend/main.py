"""FastAPI backend for CSV Ingestion, Validation & Monthly Totals — Deterministic CSV batch ingestion, validation, and monthly revenue aggregation."""

import json
import time
from datetime import datetime, timezone
from typing import Any, Optional
from fastapi import Depends, FastAPI, HTTPException, Header, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import TransactionBatchModel, RejectedRecordModel, AutomationExecutionModel
from seed import seed_database
def get_current_user_optional() -> Optional[Any]:
    return None
from engine import execute_automation_pipeline

THREAT_MODEL_JSON = json.loads(r'''{
  "assets": [
    "LedgerFlow Monthly Totals SQLite Database",
    "Transaction Batch Records",
    "Session Tokens"
  ],
  "trust_boundaries": [
    "Public Internet <-> Reverse Proxy / Vite Frontend",
    "Frontend Client <-> FastAPI Endpoints",
    "Application Layer <-> SQLite Persistence Engine"
  ],
  "threats": [
    {
      "id": "t-auth-bypass",
      "category": "spoofing",
      "asset": "User Authentication & Session Tokens",
      "threat_description": "Adversary attempts brute force or credential stuffing on login endpoint.",
      "attacker_profile": "External malicious actor or automated botnet",
      "attack_path": "Repeated POST requests to authentication endpoint with dictionary passwords.",
      "mitigation": "PBKDF2-HMAC-SHA256 password hashing with salt and in-memory rate limiting.",
      "residual_risk": "low"
    },
    {
      "id": "t-idor-tampering",
      "category": "elevation_of_privilege",
      "asset": "Transaction Batch Data Records",
      "threat_description": "User A attempts to modify or delete User B private records by guessing record IDs.",
      "attacker_profile": "Authenticated standard user",
      "attack_path": "Submitting PUT/DELETE requests referencing other tenants record identifiers.",
      "mitigation": "Server-side owner_id verification and RBAC role validation before mutation.",
      "residual_risk": "low"
    },
    {
      "id": "t-data-leakage",
      "category": "information_disclosure",
      "asset": "Account and Exported Data",
      "threat_description": "Unauthorized retrieval of sensitive workspace information.",
      "attacker_profile": "Unauthenticated external network eavesdropper",
      "attack_path": "Interception of API payloads or token theft via XSS.",
      "mitigation": "Strict CORS headers, X-Content-Type-Options, and secure session management.",
      "residual_risk": "low"
    }
  ]
}''')
_CLIENT_REQUEST_TIMESTAMPS: dict[str, list[float]] = {}

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='CSV Ingestion, Validation & Monthly Totals',
    description='Deterministic CSV batch ingestion, validation, and monthly revenue aggregation',
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware('http')
async def security_and_rate_limit_middleware(request, call_next):
    client_ip = request.client.host if request.client else '127.0.0.1'
    path = request.url.path
    if path.startswith('/api/auth/') and request.method == 'POST':
        now = time.time()
        bucket = _CLIENT_REQUEST_TIMESTAMPS.setdefault(client_ip, [])
        bucket[:] = [t for t in bucket if now - t < 60.0]
        if len(bucket) >= 40:
            return Response(
                content=json.dumps({"detail": "Rate limit exceeded. Please wait before retrying."}),
                status_code=429,
                media_type="application/json",
            )
        bucket.append(now)

    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return response

class TransactionBatchCreate(BaseModel):
    batch_code: str = ''
    reporting_month: str = ''
    source_csv_file: str = ''
    total_amount: float = 0.0
    valid_rows: int = 0
    status: str = 'Verified'

class TransactionBatchUpdate(BaseModel):
    batch_code: Optional[str] = None
    reporting_month: Optional[str] = None
    source_csv_file: Optional[str] = None
    total_amount: Optional[float] = None
    valid_rows: Optional[int] = None
    status: Optional[str] = None

def _serialize_transaction_batch(item: TransactionBatchModel) -> dict[str, Any]:
    d = {"id": item.id, "batch_code": getattr(item, "batch_code"), "reporting_month": getattr(item, "reporting_month"), "source_csv_file": getattr(item, "source_csv_file"), "total_amount": getattr(item, "total_amount"), "valid_rows": getattr(item, "valid_rows"), "status": getattr(item, "status")}

    return d

@app.get("/api/transaction_batch")
def list_transaction_batch(
    mine_only: bool = False,
    current_user: Optional[Any] = None
,    db: Session = Depends(get_db),
) -> list[dict[str, Any]]:
    query = db.query(TransactionBatchModel)
    rows = query.order_by(TransactionBatchModel.created_at.desc()).all()
    return [_serialize_transaction_batch(r) for r in rows]

@app.post("/api/transaction_batch", status_code=201)
def create_transaction_batch(
    payload: TransactionBatchCreate,
    current_user: Optional[Any] = None
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    data = payload.model_dump()
    record = TransactionBatchModel(**data)
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_transaction_batch(record)

@app.put("/api/transaction_batch/{item_id}")
def update_transaction_batch(
    item_id: str, payload: TransactionBatchUpdate,
    current_user: Optional[Any] = None
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    record = db.query(TransactionBatchModel).filter(TransactionBatchModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Transaction Batch not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_transaction_batch(record)

@app.delete("/api/transaction_batch/{item_id}")
def delete_transaction_batch(
    item_id: str,
    current_user: Optional[Any] = None
,    db: Session = Depends(get_db),
) -> dict[str, str]:
    record = db.query(TransactionBatchModel).filter(TransactionBatchModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Transaction Batch not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class RejectedRecordCreate(BaseModel):
    row_number: int = 0
    rejection_reason: str = ''
    raw_payload: str = ''
    batch_id: str = ''

class RejectedRecordUpdate(BaseModel):
    row_number: Optional[int] = None
    rejection_reason: Optional[str] = None
    raw_payload: Optional[str] = None
    batch_id: Optional[str] = None

def _serialize_rejected_record(item: RejectedRecordModel) -> dict[str, Any]:
    d = {"id": item.id, "row_number": getattr(item, "row_number"), "rejection_reason": getattr(item, "rejection_reason"), "raw_payload": getattr(item, "raw_payload"), "batch_id": getattr(item, "batch_id")}

    return d

@app.get("/api/rejected_record")
def list_rejected_record(
    mine_only: bool = False,
    current_user: Optional[Any] = None
,    db: Session = Depends(get_db),
) -> list[dict[str, Any]]:
    query = db.query(RejectedRecordModel)
    rows = query.order_by(RejectedRecordModel.created_at.desc()).all()
    return [_serialize_rejected_record(r) for r in rows]

@app.post("/api/rejected_record", status_code=201)
def create_rejected_record(
    payload: RejectedRecordCreate,
    current_user: Optional[Any] = None
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    data = payload.model_dump()
    record = RejectedRecordModel(**data)
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_rejected_record(record)

@app.put("/api/rejected_record/{item_id}")
def update_rejected_record(
    item_id: str, payload: RejectedRecordUpdate,
    current_user: Optional[Any] = None
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    record = db.query(RejectedRecordModel).filter(RejectedRecordModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Rejected Record not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_rejected_record(record)

@app.delete("/api/rejected_record/{item_id}")
def delete_rejected_record(
    item_id: str,
    current_user: Optional[Any] = None
,    db: Session = Depends(get_db),
) -> dict[str, str]:
    record = db.query(RejectedRecordModel).filter(RejectedRecordModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Rejected Record not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

@app.get("/api/auth/status")
def api_auth_status() -> dict[str, Any]:
    return {
        "auth_required": False,
        "strategy": "none",
        "rationale": 'Local tabular processing utility with client-side data custody.',
    }

@app.get("/api/privacy/export")
def api_privacy_export(
    current_user: Optional[Any] = None
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "application": 'CSV Ingestion, Validation & Monthly Totals',
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "user": {"id": current_user.id, "email": current_user.email} if current_user else None,
        "records": {},
    }
    q_transaction_batch = db.query(TransactionBatchModel)
    if current_user and hasattr(TransactionBatchModel, 'owner_id'):
        q_transaction_batch = q_transaction_batch.filter(TransactionBatchModel.owner_id == current_user.id)
    payload["records"]["transaction_batch"] = [_serialize_transaction_batch(r) for r in q_transaction_batch.all()]
    q_rejected_record = db.query(RejectedRecordModel)
    if current_user and hasattr(RejectedRecordModel, 'owner_id'):
        q_rejected_record = q_rejected_record.filter(RejectedRecordModel.owner_id == current_user.id)
    payload["records"]["rejected_record"] = [_serialize_rejected_record(r) for r in q_rejected_record.all()]
    return payload

@app.delete("/api/privacy/account")
def api_privacy_account_deletion(
    current_user: Optional[Any] = None
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    return {"status": "no_account_required_public_app"}

@app.get("/api/security/threat-model")
def api_security_threat_model() -> dict[str, Any]:
    return THREAT_MODEL_JSON

@app.get("/api/analytics/summary")
def api_analytics_summary(db: Session = Depends(get_db)) -> dict[str, Any]:
    counts: dict[str, int] = {}
    total_count = 0
    c_transaction_batch = db.query(TransactionBatchModel).count()
    counts["transaction_batch"] = c_transaction_batch
    total_count += c_transaction_batch
    c_rejected_record = db.query(RejectedRecordModel).count()
    counts["rejected_record"] = c_rejected_record
    total_count += c_rejected_record
    rows_transaction_batch = db.query(TransactionBatchModel).all()
    dist_map: dict[str, int] = {}
    for r in rows_transaction_batch:
        val = str(getattr(r, "status", "Unknown") or "Unknown")
        dist_map[val] = dist_map.get(val, 0) + 1
    primary_chart_data = [{"label": k, "value": v} for k, v in dist_map.items()]
    return {
        "app": 'CSV Ingestion, Validation & Monthly Totals',
        "total_records": total_count,
        "counts_by_entity": counts,
        "primary_chart_type": 'bar',
        "primary_chart_data": primary_chart_data,
        "secondary_chart_type": 'metric_card',
        'kpis': [
            {"id": 'total_entries', "label": 'Total Transaction Batches', "unit": 'records', "value": total_count, "target": None},
            {"id": 'active_entries', "label": 'Active Status Ratio', "unit": '%', "value": total_count, "target": None},
            {"id": 'verification_score', "label": 'Audit Score', "unit": '%', "value": total_count, "target": 98.0},
        ],
    }

@app.post("/api/seed")
def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:
    inserted = seed_database(db)
    return {"status": "seeded", "inserted": inserted}

@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {
        "status": "healthy",
        "app": 'CSV Ingestion, Validation & Monthly Totals',
        "archetype": 'analytics_dashboard',
    }

@app.post("/api/automations/run")
def run_domain_automation(db: Session = Depends(get_db)) -> dict[str, Any]:
    rows = db.query(TransactionBatchModel).all()
    serialized = [_serialize_transaction_batch(r) for r in rows]
    summary = execute_automation_pipeline(serialized)
    rec = AutomationExecutionModel(
        automation_id='auto-monthly-csv',
        status="completed",
        summary_json=json.dumps(summary),
    )
    db.add(rec)
    db.commit()
    return summary
