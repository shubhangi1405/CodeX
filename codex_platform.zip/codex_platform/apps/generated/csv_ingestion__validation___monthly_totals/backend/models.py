"""Domain SQLAlchemy ORM models for CSV Ingestion, Validation & Monthly Totals."""

from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from database import Base

class TransactionBatchModel(Base):
    __tablename__ = "transaction_batchs"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    batch_code = Column(String, nullable=False, default='')
    reporting_month = Column(String, nullable=False, default='')
    source_csv_file = Column(String, nullable=False, default='')
    total_amount = Column(Float, nullable=False, default=0.0)
    valid_rows = Column(Integer, nullable=False, default=0)
    status = Column(String, nullable=False, default='Verified')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class RejectedRecordModel(Base):
    __tablename__ = "rejected_records"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    row_number = Column(Integer, nullable=False, default=0)
    rejection_reason = Column(String, nullable=False, default='')
    raw_payload = Column(Text, nullable=False, default='')
    batch_id = Column(String, nullable=False, default='')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class AutomationExecutionModel(Base):
    __tablename__ = "automation_executions"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    automation_id = Column(String, nullable=False)
    status = Column(String, nullable=False, default='completed')
    summary_json = Column(Text, nullable=False, default='{}')
    executed_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
