"""Optional sample seed data loader for CSV Ingestion, Validation & Monthly Totals."""

import json
from sqlalchemy.orm import Session
from database import Base, SessionLocal, engine
from models import TransactionBatchModel, RejectedRecordModel

SAMPLE_SEED_DATA = json.loads(r'''{
  "transaction_batch": [
    {
      "id": "batch-2026-01",
      "batch_code": "BATCH-2026-01-NA",
      "reporting_month": "2026-01",
      "source_csv_file": "january_NorthAmerica_ledger.csv",
      "total_amount": 48290.5,
      "valid_rows": 312,
      "status": "Verified"
    },
    {
      "id": "batch-2026-02",
      "batch_code": "BATCH-2026-02-NA",
      "reporting_month": "2026-02",
      "source_csv_file": "february_NorthAmerica_ledger.csv",
      "total_amount": 53910.0,
      "valid_rows": 348,
      "status": "Verified"
    },
    {
      "id": "batch-2026-03",
      "batch_code": "BATCH-2026-03-EU",
      "reporting_month": "2026-03",
      "source_csv_file": "march_EMEA_settlements.csv",
      "total_amount": 61450.75,
      "valid_rows": 405,
      "status": "Pending Review"
    }
  ],
  "rejected_record": [
    {
      "id": "rej-101",
      "row_number": 42,
      "rejection_reason": "Missing required column: date",
      "raw_payload": ",1450.00,USD,Enterprise Renewal",
      "batch_id": "BATCH-2026-03-EU"
    }
  ]
}''')


def seed_database(db: Session) -> dict[str, int]:
    """Inserts domain sample records if tables are currently empty."""
    inserted: dict[str, int] = {}
    records_transaction_batch = SAMPLE_SEED_DATA.get("transaction_batch", [])
    existing_transaction_batch = db.query(TransactionBatchModel).count()
    count_transaction_batch = 0
    if existing_transaction_batch == 0:
        for row in records_transaction_batch:
            allowed = ['batch_code', 'reporting_month', 'source_csv_file', 'total_amount', 'valid_rows', 'status']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(TransactionBatchModel(**payload))
            count_transaction_batch += 1
    inserted["transaction_batch"] = count_transaction_batch
    records_rejected_record = SAMPLE_SEED_DATA.get("rejected_record", [])
    existing_rejected_record = db.query(RejectedRecordModel).count()
    count_rejected_record = 0
    if existing_rejected_record == 0:
        for row in records_rejected_record:
            allowed = ['row_number', 'rejection_reason', 'raw_payload', 'batch_id']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(RejectedRecordModel(**payload))
            count_rejected_record += 1
    inserted["rejected_record"] = count_rejected_record
    db.commit()
    return inserted


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as session:
        result = seed_database(session)
        print("Seeded sample records:", result)
