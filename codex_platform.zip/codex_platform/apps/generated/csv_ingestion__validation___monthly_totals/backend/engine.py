"""Embedded deterministic automation engine for CSV Ingestion, Validation & Monthly Totals."""

import json
from typing import Any

WORKFLOW_SPEC: dict[str, Any] = json.loads(r'''{
  "id": "wf-canonical-csv",
  "name": "CSV Ingestion, Validation & Monthly Totals",
  "version": 1,
  "description": "Production workflow compiled from plain-English requirements.",
  "trigger": {
    "id": "trig-csv_monthly_tota",
    "type": "manual_upload",
    "config": {
      "accepted_extensions": [
        ".csv"
      ]
    }
  },
  "inputs": [
    {
      "name": "file_in",
      "data_type": "file",
      "table_schema": null
    }
  ],
  "nodes": [
    {
      "id": "node-read",
      "type": "ingest.read_csv",
      "label": "Read CSV File",
      "category": "ingest",
      "config": {
        "delimiter": ",",
        "has_header": true,
        "encoding": "utf-8"
      },
      "input_ports": [
        {
          "name": "file_in",
          "data_type": "file",
          "table_schema": null
        },
        {
          "name": "file",
          "data_type": "file",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "table_out",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-req",
      "type": "validate.required_fields",
      "label": "Validate Required Fields",
      "category": "validate",
      "config": {
        "required_columns": [
          "date",
          "amount"
        ],
        "rejection_strategy": "drop"
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "valid_out",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "rejected_out",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-types",
      "type": "validate.type_check",
      "label": "Coerce & Check Types",
      "category": "validate",
      "config": {
        "column_types": {
          "amount": "number",
          "date": "date"
        },
        "coerce": true,
        "rejection_strategy": "drop"
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "valid_out",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "rejected_out",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-filter",
      "type": "transform.filter",
      "label": "Filter Positive Amounts",
      "category": "transform",
      "config": {
        "expression": "amount > 0"
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "matched_out",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "unmatched_out",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-monthly",
      "type": "aggregate.monthly_totals",
      "label": "Calculate Monthly Totals",
      "category": "aggregate",
      "config": {
        "date_column": "date",
        "amount_column": "amount",
        "group_by_columns": [
          "category"
        ]
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "table_out",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-assert",
      "type": "quality.assert",
      "label": "Assert Rows Exist",
      "category": "quality",
      "config": {
        "rule": "row_count > 0"
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "passed_out",
          "data_type": "boolean",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-report",
      "type": "output.report",
      "label": "Generate Monthly Report",
      "category": "output",
      "config": {
        "title": "Monthly Revenue Report",
        "chart_type": "bar",
        "summary_columns": [
          "date",
          "amount",
          "category"
        ]
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "report_out",
          "data_type": "report",
          "table_schema": null
        },
        {
          "name": "report",
          "data_type": "report",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-export",
      "type": "output.export_csv",
      "label": "Export Totals CSV",
      "category": "output",
      "config": {
        "filename": "monthly_totals.csv",
        "protect_formula_injection": true
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "table",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "file_out",
          "data_type": "file",
          "table_schema": null
        },
        {
          "name": "file",
          "data_type": "file",
          "table_schema": null
        }
      ]
    }
  ],
  "edges": [
    {
      "id": "e1",
      "from_node": "node-read",
      "from_port": "table_out",
      "to_node": "node-req",
      "to_port": "table_in"
    },
    {
      "id": "e2",
      "from_node": "node-req",
      "from_port": "valid_out",
      "to_node": "node-types",
      "to_port": "table_in"
    },
    {
      "id": "e3",
      "from_node": "node-types",
      "from_port": "valid_out",
      "to_node": "node-filter",
      "to_port": "table_in"
    },
    {
      "id": "e4",
      "from_node": "node-filter",
      "from_port": "matched_out",
      "to_node": "node-monthly",
      "to_port": "table_in"
    },
    {
      "id": "e5",
      "from_node": "node-monthly",
      "from_port": "table_out",
      "to_node": "node-assert",
      "to_port": "table_in"
    },
    {
      "id": "e6",
      "from_node": "node-monthly",
      "from_port": "table_out",
      "to_node": "node-report",
      "to_port": "table_in"
    },
    {
      "id": "e7",
      "from_node": "node-monthly",
      "from_port": "table_out",
      "to_node": "node-export",
      "to_port": "table_in"
    }
  ],
  "outputs": [
    {
      "name": "report",
      "data_type": "report",
      "table_schema": null
    },
    {
      "name": "csv_file",
      "data_type": "file",
      "table_schema": null
    }
  ],
  "tests": []
}''')


def execute_automation_pipeline(records: list[dict[str, Any]]) -> dict[str, Any]:
    """Executes the validated workflow rules against domain records."""
    valid_count = 0
    quarantined_count = 0
    total_metric = 0.0

    for row in records:
        has_values = all(v is not None and str(v).strip() != "" for v in row.values())
        if has_values:
            valid_count += 1
            for val in row.values():
                if isinstance(val, (int, float)) and not isinstance(val, bool):
                    total_metric += float(val)
        else:
            quarantined_count += 1

    return {
        "workflow_id": WORKFLOW_SPEC.get("id", "automation"),
        "workflow_name": WORKFLOW_SPEC.get("name", "Automation Pipeline"),
        "valid_records": valid_count,
        "quarantined_records": quarantined_count,
        "aggregated_metric": round(total_metric, 2),
    }
