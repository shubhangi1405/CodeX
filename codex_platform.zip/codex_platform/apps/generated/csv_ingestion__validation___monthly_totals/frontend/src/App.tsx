import React, { useEffect, useState } from 'react';
import {
  AdaptiveAppShell,
  AdaptiveLayoutRenderer,
  Button,
  FormField,
  Input,
  Modal,
  Select,
  Toast,
  EntityRecord,
  EntitySpecData,
  PageSpecData,
} from './ui_kit';

const BLUEPRINT = {
  "app_name": "CSV Ingestion, Validation & Monthly Totals",
  "product_tagline": "Deterministic CSV batch ingestion, validation, and monthly revenue aggregation",
  "domain": {
    "product_kind": "Tabular File Ingestion & Monthly Revenue Reconciliation",
    "archetype": "analytics_dashboard",
    "audience": {
      "who": "Finance analysts and revenue operations controllers",
      "context_of_use": "Desktop reconciliation workstation during monthly close",
      "device_likely_used": "desktop",
      "tech_comfort": "high"
    },
    "core_jobs": [
      "Review monthly aggregated revenue totals and batch KPIs",
      "Import tabular transaction batches and inspect validation rules",
      "Audit rejected transaction rows for missing dates or negative amounts"
    ],
    "primary_object": "transaction_batch",
    "tone": "analytical",
    "data_shape": "tabular",
    "needs_automation": true,
    "rationale": "This product is explicitly an automated tabular CSV ingestion and monthly aggregation pipeline for finance analysts who need high-density KPI charts and deterministic batch validation."
  },
  "entities": [
    {
      "name": "transaction_batch",
      "singular_label": "Transaction Batch",
      "plural_label": "Transaction Batches",
      "fields": [
        {
          "name": "batch_code",
          "label": "Batch Code",
          "field_type": "string",
          "required": true,
          "unique": true,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "reporting_month",
          "label": "Reporting Month",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "source_csv_file",
          "label": "Source CSV File",
          "field_type": "file_ingest",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "total_amount",
          "label": "Total Verified Revenue",
          "field_type": "currency",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "valid_rows",
          "label": "Valid Rows",
          "field_type": "integer",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "status",
          "label": "Reconciliation Status",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Verified",
            "Pending Review",
            "Quarantined"
          ],
          "default_value": null
        }
      ],
      "relationships": []
    },
    {
      "name": "rejected_record",
      "singular_label": "Rejected Record",
      "plural_label": "Rejected Records",
      "fields": [
        {
          "name": "row_number",
          "label": "CSV Row Number",
          "field_type": "integer",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "rejection_reason",
          "label": "Validation Rule Failure",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "raw_payload",
          "label": "Raw Row Values",
          "field_type": "text",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "batch_id",
          "label": "Parent Batch",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        }
      ],
      "relationships": [
        {
          "target_entity": "transaction_batch",
          "kind": "many_to_one",
          "foreign_key": "batch_id"
        }
      ]
    }
  ],
  "pages": [
    {
      "id": "monthly-kpis",
      "title": "Monthly Revenue KPIs",
      "route": "/monthly-kpis",
      "layout": "stat_tiles_with_charts",
      "entities_used": [
        "transaction_batch"
      ],
      "primary_actions": [
        "Import CSV Batch",
        "Export Reconciled Summary"
      ],
      "empty_state": {
        "headline": "No Monthly Transaction Batches Reconciled Yet",
        "body": "Import your first CSV transaction batch to compute verified monthly revenue totals and inspect row-level validation metrics.",
        "cta_label": "Import First CSV Batch",
        "cta_action_id": "create_transaction_batch"
      }
    },
    {
      "id": "batch-ledger",
      "title": "Batch Ledger Table",
      "route": "/batch-ledger",
      "layout": "data_table_with_filters",
      "entities_used": [
        "transaction_batch"
      ],
      "primary_actions": [
        "Filter by Reporting Month",
        "Import CSV Batch"
      ],
      "empty_state": {
        "headline": "Ledger Table Is Empty",
        "body": "Add a transaction batch record to inspect monthly reconciliation rows.",
        "cta_label": "Add Batch Record",
        "cta_action_id": "create_transaction_batch"
      }
    },
    {
      "id": "rejected-quarantine",
      "title": "Rejected Row Quarantine",
      "route": "/rejected-quarantine",
      "layout": "data_table_with_filters",
      "entities_used": [
        "rejected_record"
      ],
      "primary_actions": [
        "Log Quarantined Row",
        "Clear Resolved Exceptions"
      ],
      "empty_state": {
        "headline": "Zero Quarantined Rows",
        "body": "All imported CSV rows passed required-field and numeric type validation.",
        "cta_label": "Log Exception Sample",
        "cta_action_id": "create_rejected_record"
      }
    }
  ],
  "navigation": {
    "pattern": "top_tabs",
    "items": [
      {
        "page_id": "monthly-kpis",
        "label": "Monthly Revenue KPIs",
        "icon": "bar-chart-2"
      },
      {
        "page_id": "batch-ledger",
        "label": "Batch Ledger Table",
        "icon": "upload"
      },
      {
        "page_id": "rejected-quarantine",
        "label": "Rejected Quarantine",
        "icon": "alert-triangle"
      }
    ]
  },
  "home_page_id": "monthly-kpis",
  "automations": [
    {
      "id": "auto-monthly-csv",
      "name": "CSV Validation & Monthly Aggregation Pipeline",
      "workflow_id": "wf-canonical-csv",
      "trigger_entity": "transaction_batch"
    }
  ],
  "auth": {
    "required": false,
    "strategy": "local_offline",
    "roles": [],
    "protected_entities": [],
    "password_min_length": 8,
    "session_timeout_minutes": 1440,
    "rationale": "Local tabular processing utility with client-side data custody."
  },
  "security": {
    "data_sensitivity": "internal",
    "rate_limit_rpm": 120,
    "pii_fields": [
      "transaction_batch.id"
    ],
    "export_enabled": true,
    "deletion_enabled": true,
    "audit_logging": true,
    "encryption_in_transit": true
  },
  "threat_model": {
    "assets": [
      "LedgerFlow Monthly Totals SQLite Database",
      "Transaction Batch Records",
      "Session Tokens"
    ],
    "trust_boundaries": [
      "Public Internet <-> Reverse Proxy / Vite Frontend",
      "Frontend Client <-> FastAPI Endpoints",
      "Application Layer <-> SQLite Persistence Engine"
    ],
    "threats": [
      {
        "id": "t-auth-bypass",
        "category": "spoofing",
        "asset": "User Authentication & Session Tokens",
        "threat_description": "Adversary attempts brute force or credential stuffing on login endpoint.",
        "attacker_profile": "External malicious actor or automated botnet",
        "attack_path": "Repeated POST requests to authentication endpoint with dictionary passwords.",
        "mitigation": "PBKDF2-HMAC-SHA256 password hashing with salt and in-memory rate limiting.",
        "residual_risk": "low"
      },
      {
        "id": "t-idor-tampering",
        "category": "elevation_of_privilege",
        "asset": "Transaction Batch Data Records",
        "threat_description": "User A attempts to modify or delete User B private records by guessing record IDs.",
        "attacker_profile": "Authenticated standard user",
        "attack_path": "Submitting PUT/DELETE requests referencing other tenants record identifiers.",
        "mitigation": "Server-side owner_id verification and RBAC role validation before mutation.",
        "residual_risk": "low"
      },
      {
        "id": "t-data-leakage",
        "category": "information_disclosure",
        "asset": "Account and Exported Data",
        "threat_description": "Unauthorized retrieval of sensitive workspace information.",
        "attacker_profile": "Unauthenticated external network eavesdropper",
        "attack_path": "Interception of API payloads or token theft via XSS.",
        "mitigation": "Strict CORS headers, X-Content-Type-Options, and secure session management.",
        "residual_risk": "low"
      }
    ]
  },
  "analytics": {
    "primary_chart": "bar",
    "secondary_chart": "metric_card",
    "kpis": [
      {
        "id": "total_entries",
        "label": "Total Transaction Batches",
        "unit": "records",
        "calculation": "count(all)",
        "target": null
      },
      {
        "id": "active_entries",
        "label": "Active Status Ratio",
        "unit": "%",
        "calculation": "active / total * 100",
        "target": null
      },
      {
        "id": "verification_score",
        "label": "Audit Score",
        "unit": "%",
        "calculation": "valid / total * 100",
        "target": 98.0
      }
    ],
    "date_filtering": true,
    "export_format": "json"
  },
  "feature_checklist": [
    {
      "id": "feat-core-crud",
      "name": "Transaction Batch Lifecycle Management",
      "description": "Create, inspect, update, and remove Transaction Batch domain records with persistence.",
      "tier": "essential",
      "status": "Verified",
      "acceptance_criteria": [
        "User can create a new Transaction Batch with required fields.",
        "Database validates input types and persists changes.",
        "Deleted Transaction Batch records are safely pruned from the system."
      ],
      "verified_by_test": "test_create_and_query_transaction_batch"
    },
    {
      "id": "feat-domain-analytics",
      "name": "Domain KPI & Analytical Visualizations",
      "description": "Real-time visual summaries and KPI computation derived from Transaction Batch state.",
      "tier": "essential",
      "status": "Verified",
      "acceptance_criteria": [
        "Metrics recalculate dynamically from SQLite records.",
        "Chart distributions render without external CDN dependencies."
      ],
      "verified_by_test": "test_analytics_summary_kpi_computation"
    },
    {
      "id": "feat-auth-security",
      "name": "Authentication, Roles & Data Custody",
      "description": "Cryptographic password security, session token management, and per-user privacy.",
      "tier": "recommended",
      "status": "Verified",
      "acceptance_criteria": [
        "Passwords hashed with PBKDF2-HMAC-SHA256 and unique salt.",
        "Data export and account deletion endpoints honor privacy rights."
      ],
      "verified_by_test": "test_authentication_and_data_isolation"
    },
    {
      "id": "feat-data-export-portability",
      "name": "Data Portability & Tabular Export",
      "description": "Export workspace records for offline analysis, archiving, or auditing.",
      "tier": "optional",
      "status": "Verified",
      "acceptance_criteria": [
        "Complete JSON / data export is generated upon request.",
        "User can download their complete record history."
      ],
      "verified_by_test": "test_privacy_data_export"
    }
  ],
  "user_journeys": [
    {
      "id": "uj-onboarding",
      "persona": "Finance analysts and revenue operations controllers",
      "goal": "Initialize workspace and record the first Transaction Batch",
      "trigger": "User opens LedgerFlow Monthly Totals for the first time",
      "steps": [
        {
          "step_number": 1,
          "action": "Navigate to Monthly Revenue KPIs",
          "expected_result": "Dashboard loads with empty state guidance or sample seed data."
        },
        {
          "step_number": 2,
          "action": "Click '+ Import CSV Batch'",
          "expected_result": "Input modal opens with validated form controls."
        },
        {
          "step_number": 3,
          "action": "Fill required values and click Save",
          "expected_result": "Record appears instantly in the layout and updates KPI totals."
        }
      ],
      "outcome": "User has an active, verified Transaction Batch in their workspace."
    },
    {
      "id": "uj-review-analytics",
      "persona": "Finance analysts and revenue operations controllers",
      "goal": "Review performance trends, filter by date, and audit status",
      "trigger": "Periodic review routine or operational check-in",
      "steps": [
        {
          "step_number": 1,
          "action": "View Monthly Revenue KPIs charts and KPI cards",
          "expected_result": "Visual charts display real distributions calculated from active records."
        },
        {
          "step_number": 2,
          "action": "Apply status filter or search keyword",
          "expected_result": "Table and metrics narrow immediately to matching entries."
        }
      ],
      "outcome": "User gains actionable domain insight from their data."
    }
  ],
  "business_rules": [
    "Every Transaction Batch must have a unique identifier and required core attributes.",
    "Numeric metrics (amounts, streaks, scores) must not be negative.",
    "Users may only update or delete records they own unless granted administrative role.",
    "Exported data sets must reflect currently committed database state accurately."
  ]
} as const;
const DESIGN_DIRECTION = {
  "direction_id": "ledger_precision",
  "palette": {
    "primary": "#0F3D5E",
    "primary_foreground": "#FFFFFF",
    "accent": "#0B6E66",
    "neutral_ramp": [
      "#F8FAFC",
      "#F1F5F9",
      "#E2E8F0",
      "#CBD5E1",
      "#94A3B8",
      "#64748B",
      "#475569",
      "#1E293B",
      "#0F172A"
    ],
    "surface": "#F8FAFC",
    "surface_elevated": "#FFFFFF",
    "border": "#52637A",
    "text": "#0F172A",
    "text_muted": "#334155",
    "focus_ring": "#0F3D5E",
    "success": "#156D3B",
    "warning": "#854D0E",
    "danger": "#991B1B"
  },
  "color_mode": "light",
  "typography": {
    "heading_font": "IBM Plex Sans",
    "body_font": "IBM Plex Sans",
    "mono_font": "IBM Plex Mono",
    "scale_ratio": 1.2
  },
  "shape": {
    "radius_class": "sharp",
    "border_style": "crisp",
    "shadow_style": "flat"
  },
  "density": "compact",
  "motion": "none",
  "iconography": "outline",
  "brand_mark": {
    "kind": "geometric_glyph",
    "glyph_primitive": "bars_ascending",
    "monogram_letters": "LF"
  },
  "copy_voice": "Exact, accounting-grade, noun-first labels with zero marketing fluff.",
  "rationale": "Finance analysts reconciling monthly CSV exports work in bright spreadsheets and need IBM Plex Sans tabular numerals, compact tables, and deep navy contrast."
} as const;
const SAMPLE_SEED_DATA: Record<string, EntityRecord[]> = {
  "transaction_batch": [
    {
      "id": "batch-2026-01",
      "batch_code": "BATCH-2026-01-NA",
      "reporting_month": "2026-01",
      "source_csv_file": "january_NorthAmerica_ledger.csv",
      "total_amount": 48290.5,
      "valid_rows": 312,
      "status": "Verified"
    },
    {
      "id": "batch-2026-02",
      "batch_code": "BATCH-2026-02-NA",
      "reporting_month": "2026-02",
      "source_csv_file": "february_NorthAmerica_ledger.csv",
      "total_amount": 53910.0,
      "valid_rows": 348,
      "status": "Verified"
    },
    {
      "id": "batch-2026-03",
      "batch_code": "BATCH-2026-03-EU",
      "reporting_month": "2026-03",
      "source_csv_file": "march_EMEA_settlements.csv",
      "total_amount": 61450.75,
      "valid_rows": 405,
      "status": "Pending Review"
    }
  ],
  "rejected_record": [
    {
      "id": "rej-101",
      "row_number": 42,
      "rejection_reason": "Missing required column: date",
      "raw_payload": ",1450.00,USD,Enterprise Renewal",
      "batch_id": "BATCH-2026-03-EU"
    }
  ]
};
const BRAND_SVG_MARKUP = "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"5\" y=\"13\" width=\"3\" height=\"6\" rx=\"1\" fill=\"currentColor\"/><rect x=\"10.5\" y=\"9\" width=\"3\" height=\"10\" rx=\"1\" fill=\"currentColor\"/><rect x=\"16\" y=\"5\" width=\"3\" height=\"14\" rx=\"1\" fill=\"currentColor\"/></svg>";
const NUMERIC_TYPES = new Set(['integer', 'float', 'currency']);

export default function App(): React.ReactElement {
  const [activePageId, setActivePageId] = useState<string>(BLUEPRINT.home_page_id);
  const [recordsByEntity, setRecordsByEntity] = useState<Record<string, EntityRecord[]>>(() => {
    const initial: Record<string, EntityRecord[]> = {};
    for (const ent of BLUEPRINT.entities) {
      initial[ent.name] = [];
    }
    return initial;
  });
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formState, setFormState] = useState<Record<string, string | number | boolean>>({});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const pages = BLUEPRINT.pages as unknown as PageSpecData[];
  const entities = BLUEPRINT.entities as unknown as EntitySpecData[];
  const activePage = pages.find((p) => p.id === activePageId) || pages[0];
  const primaryEntityName = activePage.entities_used[0] || entities[0].name;
  const activeEntity = entities.find((e) => e.name === primaryEntityName) || entities[0];
  const activeRecords = recordsByEntity[activeEntity.name] || [];

  useEffect(() => {
    for (const ent of entities) {
      fetch(`/api/${ent.name}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data: EntityRecord[] | null) => {
          if (Array.isArray(data) && data.length > 0) {
            setRecordsByEntity((prev) => ({ ...prev, [ent.name]: data }));
          }
        })
        .catch(() => {
          // Offline mode uses in-memory state
        });
    }
  }, []);

  const openCreateModal = (): void => {
    const defaults: Record<string, string | number | boolean> = {};
    for (const fld of activeEntity.fields) {
      if (fld.field_type === 'boolean') {
        defaults[fld.name] = Boolean(fld.default_value ?? false);
      } else if (NUMERIC_TYPES.has(fld.field_type)) {
        defaults[fld.name] = Number(fld.default_value ?? 0);
      } else if (fld.field_type === 'enum' && fld.enum_values && fld.enum_values.length > 0) {
        defaults[fld.name] = fld.enum_values[0];
      } else {
        defaults[fld.name] = String(fld.default_value ?? '');
      }
    }
    setFormState(defaults);
    setIsModalOpen(true);
  };

  const handleCreateRecord = (): void => {
    const newRecord: EntityRecord = {
      id: `${activeEntity.name}-${Date.now()}`,
      ...formState,
    };
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: [newRecord, ...(prev[activeEntity.name] || [])],
    }));
    fetch(`/api/${activeEntity.name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formState),
    }).catch(() => undefined);
    setIsModalOpen(false);
    setToastMsg(`Saved ${activeEntity.singular_label}`);
  };

  const handleLoadSampleSeedData = (): void => {
    setRecordsByEntity(SAMPLE_SEED_DATA);
    fetch('/api/seed', { method: 'POST' }).catch(() => undefined);
    setToastMsg('Loaded domain sample records');
  };

  const handleDeleteRecord = (recordId: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).filter((r) => String(r.id) !== recordId),
    }));
    fetch(`/api/${activeEntity.name}/${recordId}`, {
      method: 'DELETE',
    }).catch(() => undefined);
    setToastMsg(`Removed ${activeEntity.singular_label}`);
  };

  const [isLiveTouched, setIsLiveTouched] = useState<boolean>(false);

  const handleExportJsonData = (): void => {
    const jsonStr = JSON.stringify(recordsByEntity, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${BLUEPRINT.app_name.toLowerCase().replace(/[^a-z0-9]/g, '_')}_export.json`;
    a.click();
    URL.revokeObjectURL(url);
    setToastMsg('Workspace records exported');
  };

  const handleToggleBoolean = (recordId: string, fieldName: string): void => {
    setIsLiveTouched(true);
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).map((r) =>
        String(r.id) === recordId ? { ...r, [fieldName]: !r[fieldName] } : r
      ),
    }));
  };

  return (
    <div className="min-h-screen bg-surface text-text font-body">
      <AdaptiveAppShell
        pattern={BLUEPRINT.navigation.pattern}
        appName={BLUEPRINT.app_name}
        tagline={BLUEPRINT.product_tagline}
        brandMark={
          <span
            className="inline-flex items-center"
            dangerouslySetInnerHTML={{ __html: BRAND_SVG_MARKUP }}
          />
        }
        navItems={BLUEPRINT.navigation.items.map((item) => ({
          page_id: item.page_id,
          label: item.label,
          icon: item.icon,
        }))}
        activePageId={activePage.id}
        onSelectPage={setActivePageId}
        primaryAction={
          <div className="flex items-center gap-2">
            {isLiveTouched ? (
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-emerald-500/15 text-emerald-700 border border-emerald-500/30">
                Live Data
              </span>
            ) : activeRecords.length > 0 ? (
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-500/15 text-amber-700 border border-amber-500/30">
                Demo Seed Data
              </span>
            ) : null}
            {activeRecords.length === 0 && (
              <Button variant="secondary" onClick={handleLoadSampleSeedData}>
                Load Sample Data
              </Button>
            )}
            {activeRecords.length > 0 && (
              <Button variant="secondary" onClick={handleExportJsonData}>
                Export Data
              </Button>
            )}
            <Button variant="primary" onClick={openCreateModal}>
              + {activePage.primary_actions[0] || `New ${activeEntity.singular_label}`}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {toastMsg && (
            <div className="flex justify-between items-center">
              <Toast message={toastMsg} tone="success" />
              <Button variant="ghost" onClick={() => setToastMsg(null)}>Dismiss</Button>
            </div>
          )}
          <AdaptiveLayoutRenderer
            page={activePage}
            entity={activeEntity}
            records={activeRecords}
            onOpenCreate={openCreateModal}
            onDeleteRecord={handleDeleteRecord}
            onToggleBoolean={handleToggleBoolean}
          />
        </div>
      </AdaptiveAppShell>

      <Modal
        open={isModalOpen}
        title={`Add ${activeEntity.singular_label}`}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-3">
          {activeEntity.fields.map((fld) => (
            <FormField key={fld.name} label={fld.label} required={fld.required}>
              {fld.field_type === 'enum' && fld.enum_values ? (
                <Select
                  value={String(formState[fld.name] ?? fld.enum_values[0] ?? '')}
                  options={fld.enum_values.map((v) => ({ value: v, label: v }))}
                  onChange={(val) => setFormState((prev) => ({ ...prev, [fld.name]: val }))}
                />
              ) : (
                <Input
                  type={
                    NUMERIC_TYPES.has(fld.field_type)
                      ? 'number'
                      : fld.field_type === 'date'
                        ? 'date'
                        : 'text'
                  }
                  value={String(formState[fld.name] ?? '')}
                  placeholder={`Enter ${fld.label}`}
                  onChange={(val) =>
                    setFormState((prev) => ({
                      ...prev,
                      [fld.name]: NUMERIC_TYPES.has(fld.field_type) ? Number(val) : val,
                    }))
                  }
                />
              )}
            </FormField>
          ))}
          <div className="flex justify-end gap-2 pt-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCreateRecord}>
              Save {activeEntity.singular_label}
            </Button>
          </div>
        </div>
      </Modal>
      
    </div>
  );
}
