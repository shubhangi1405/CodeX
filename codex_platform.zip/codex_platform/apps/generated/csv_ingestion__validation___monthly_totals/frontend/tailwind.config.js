/** @type {import('tailwindcss').Config} */
// Direction: ledger_precision
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        app: {
          primary: "var(--app-primary)",
          "primary-fg": "var(--app-primary-fg)",
          accent: "var(--app-accent)",
          surface: "var(--app-surface)",
          elevated: "var(--app-surface-elevated)",
          border: "var(--app-border)",
          text: "var(--app-text)",
          muted: "var(--app-text-muted)",
          focus: "var(--app-focus-ring)",
          success: "var(--app-success)",
          warning: "var(--app-warning)",
          danger: "var(--app-danger)",
        },
      },
      fontFamily: {
        heading: ["var(--app-font-heading)"],
        body: ["var(--app-font-body)"],
        mono: ["var(--app-font-mono)"],
      },
      borderRadius: {
        "app-card": "var(--app-radius-card)",
        "app-control": "var(--app-radius-control)",
      },
      boxShadow: {
        "app-card": "var(--app-shadow-card)",
      },
      spacing: {
        "app-card": "var(--app-pad-card)",
        "app-grid": "var(--app-gap-grid)",
      },
    },
  },
  plugins: [],
};
