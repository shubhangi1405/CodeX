import datetime
from sqlalchemy import Column, DateTime, Float, Integer, JSON, String
from database import Base


class RunRecordModel(Base):
    __tablename__ = "runs"

    id = Column(String(64), primary_key=True, index=True)
    workflow_id = Column(String(64), index=True)
    workflow_version = Column(Integer, default=1)
    status = Column(String(32), default="success")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    total_duration_ms = Column(Float, default=0.0)
    input_hash = Column(String(64))
    output_hash = Column(String(64))
    node_results = Column(JSON, default=dict)


class ReportRecordModel(Base):
    __tablename__ = "reports"

    id = Column(String(64), primary_key=True, index=True)
    title = Column(String(128))
    generated_at = Column(DateTime, default=datetime.datetime.utcnow)
    total_revenue = Column(Float, default=0.0)
    total_records = Column(Integer, default=0)
    monthly_breakdown = Column(JSON, default=list)


class AuditRowModel(Base):
    __tablename__ = "rejected_audit"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(64), index=True)
    row_index = Column(Integer)
    reason = Column(String(255))
    row_data = Column(JSON)
