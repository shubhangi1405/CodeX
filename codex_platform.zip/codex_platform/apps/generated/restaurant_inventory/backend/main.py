"""FastAPI backend for MiseEnPlace Larder — Kitchen par-level tracking, walk-in cooler lots, and purveyor restock orders."""

import json
from typing import Any, Optional
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import PantryIngredientModel, PurveyorOrderModel
from seed import seed_database

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='MiseEnPlace Larder',
    description='Kitchen par-level tracking, walk-in cooler lots, and purveyor restock orders',
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class PantryIngredientCreate(BaseModel):
    ingredient_name: str = ''
    kitchen_station: str = 'Walk-In Produce'
    on_hand_qty: float = 0.0
    par_target: float = 0.0
    stock_status: str = 'At Par'

class PantryIngredientUpdate(BaseModel):
    ingredient_name: Optional[str] = None
    kitchen_station: Optional[str] = None
    on_hand_qty: Optional[float] = None
    par_target: Optional[float] = None
    stock_status: Optional[str] = None

def _serialize_pantry_ingredient(item: PantryIngredientModel) -> dict[str, Any]:
    return {"id": item.id, "ingredient_name": getattr(item, "ingredient_name"), "kitchen_station": getattr(item, "kitchen_station"), "on_hand_qty": getattr(item, "on_hand_qty"), "par_target": getattr(item, "par_target"), "stock_status": getattr(item, "stock_status")}

@app.get("/api/pantry_ingredient")
def list_pantry_ingredient(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(PantryIngredientModel).order_by(PantryIngredientModel.created_at.desc()).all()
    return [_serialize_pantry_ingredient(r) for r in rows]

@app.post("/api/pantry_ingredient", status_code=201)
def create_pantry_ingredient(
    payload: PantryIngredientCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = PantryIngredientModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_pantry_ingredient(record)

@app.put("/api/pantry_ingredient/{item_id}")
def update_pantry_ingredient(
    item_id: str, payload: PantryIngredientUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(PantryIngredientModel).filter(PantryIngredientModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Pantry Ingredient not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_pantry_ingredient(record)

@app.delete("/api/pantry_ingredient/{item_id}")
def delete_pantry_ingredient(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(PantryIngredientModel).filter(PantryIngredientModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Pantry Ingredient not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class PurveyorOrderCreate(BaseModel):
    purveyor_name: str = ''
    delivery_window: str = '05:30 AM Dock'
    order_total: float = 0.0

class PurveyorOrderUpdate(BaseModel):
    purveyor_name: Optional[str] = None
    delivery_window: Optional[str] = None
    order_total: Optional[float] = None

def _serialize_purveyor_order(item: PurveyorOrderModel) -> dict[str, Any]:
    return {"id": item.id, "purveyor_name": getattr(item, "purveyor_name"), "delivery_window": getattr(item, "delivery_window"), "order_total": getattr(item, "order_total")}

@app.get("/api/purveyor_order")
def list_purveyor_order(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(PurveyorOrderModel).order_by(PurveyorOrderModel.created_at.desc()).all()
    return [_serialize_purveyor_order(r) for r in rows]

@app.post("/api/purveyor_order", status_code=201)
def create_purveyor_order(
    payload: PurveyorOrderCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = PurveyorOrderModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_purveyor_order(record)

@app.put("/api/purveyor_order/{item_id}")
def update_purveyor_order(
    item_id: str, payload: PurveyorOrderUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(PurveyorOrderModel).filter(PurveyorOrderModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Purveyor Order not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_purveyor_order(record)

@app.delete("/api/purveyor_order/{item_id}")
def delete_purveyor_order(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(PurveyorOrderModel).filter(PurveyorOrderModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Purveyor Order not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

@app.post("/api/seed")
def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:
    inserted = seed_database(db)
    return {"status": "seeded", "inserted": inserted}

@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {
        "status": "healthy",
        "app": 'MiseEnPlace Larder',
        "archetype": 'inventory_stock',
    }
