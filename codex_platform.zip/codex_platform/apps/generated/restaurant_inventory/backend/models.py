"""Domain SQLAlchemy ORM models for MiseEnPlace Larder."""

from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from database import Base

class PantryIngredientModel(Base):
    __tablename__ = "pantry_ingredients"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    ingredient_name = Column(String, nullable=False, default='')
    kitchen_station = Column(String, nullable=False, default='Walk-In Produce')
    on_hand_qty = Column(Float, nullable=False, default=0.0)
    par_target = Column(Float, nullable=False, default=0.0)
    stock_status = Column(String, nullable=False, default='At Par')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class PurveyorOrderModel(Base):
    __tablename__ = "purveyor_orders"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    purveyor_name = Column(String, nullable=False, default='')
    delivery_window = Column(String, nullable=False, default='05:30 AM Dock')
    order_total = Column(Float, nullable=False, default=0.0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
