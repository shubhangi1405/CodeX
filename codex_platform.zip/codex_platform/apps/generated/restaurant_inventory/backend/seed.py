"""Optional sample seed data loader for MiseEnPlace Larder."""

import json
from sqlalchemy.orm import Session
from database import Base, SessionLocal, engine
from models import PantryIngredientModel, PurveyorOrderModel

SAMPLE_SEED_DATA = json.loads(r'''{
  "pantry_ingredient": [
    {
      "id": "ing-1",
      "ingredient_name": "San Marzano DOP Tomatoes (#10 Can)",
      "kitchen_station": "Dry Larder",
      "on_hand_qty": 6.0,
      "par_target": 18.0,
      "stock_status": "Order Tonight"
    },
    {
      "id": "ing-2",
      "ingredient_name": "Wild Halibut Fillet (Portioned 180g)",
      "kitchen_station": "Butcher & Seafood",
      "on_hand_qty": 4.0,
      "par_target": 24.0,
      "stock_status": "Critical 86 Risk"
    },
    {
      "id": "ing-3",
      "ingredient_name": "Cultured Normandy Unsalted Butter (kg)",
      "kitchen_station": "Dairy & Pastry Cooler",
      "on_hand_qty": 15.0,
      "par_target": 14.0,
      "stock_status": "At Par"
    }
  ],
  "purveyor_order": [
    {
      "id": "po-1",
      "purveyor_name": "Harbor Dayboat Fishery",
      "delivery_window": "05:30 AM Dock",
      "order_total": 685.0
    },
    {
      "id": "po-2",
      "purveyor_name": "Valle Verde Organic Growers",
      "delivery_window": "08:00 AM Produce",
      "order_total": 412.5
    }
  ]
}''')


def seed_database(db: Session) -> dict[str, int]:
    """Inserts domain sample records if tables are currently empty."""
    inserted: dict[str, int] = {}
    records_pantry_ingredient = SAMPLE_SEED_DATA.get("pantry_ingredient", [])
    existing_pantry_ingredient = db.query(PantryIngredientModel).count()
    count_pantry_ingredient = 0
    if existing_pantry_ingredient == 0:
        for row in records_pantry_ingredient:
            allowed = ['ingredient_name', 'kitchen_station', 'on_hand_qty', 'par_target', 'stock_status']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(PantryIngredientModel(**payload))
            count_pantry_ingredient += 1
    inserted["pantry_ingredient"] = count_pantry_ingredient
    records_purveyor_order = SAMPLE_SEED_DATA.get("purveyor_order", [])
    existing_purveyor_order = db.query(PurveyorOrderModel).count()
    count_purveyor_order = 0
    if existing_purveyor_order == 0:
        for row in records_purveyor_order:
            allowed = ['purveyor_name', 'delivery_window', 'order_total']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(PurveyorOrderModel(**payload))
            count_purveyor_order += 1
    inserted["purveyor_order"] = count_purveyor_order
    db.commit()
    return inserted


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as session:
        result = seed_database(session)
        print("Seeded sample records:", result)
