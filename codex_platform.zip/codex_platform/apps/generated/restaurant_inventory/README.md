# MiseEnPlace Larder

> Kitchen par-level tracking, walk-in cooler lots, and purveyor restock orders

## Product & Domain Summary
- **Product Kind**: Restaurant Kitchen Pantry, Cold-Storage & Purveyor Stock Manager
- **Archetype**: `inventory_stock`
- **Primary Object**: `pantry_ingredient`
- **Target Audience**: Executive chefs, sous chefs, and kitchen purchasing managers (Walk-in cooler par checks and prep-line restock ordering)
- **Navigation Pattern**: `split_master_detail`
- **Home Page**: `larder-inspector` (`master_detail`)

## Design Direction (`studio_craft`)
- **Color Mode**: `light` | **Primary**: `#4D6B14` | **Surface**: `#F7F4EF`
- **Typography**: Heading `Playfair Display` · Body `DM Sans` · Mono `JetBrains Mono`
- **Shape & Density**: Radius `round` · Density `spacious`
- **Rationale**: Herb-olive and terracotta tones paired with Playfair Display headings and split master-detail inspection fit a culinary larder and prep kitchen.

## Domain Entities
- **Pantry Ingredients** (`pantry_ingredient`): `ingredient_name` (string), `kitchen_station` (enum), `on_hand_qty` (float), `par_target` (float), `stock_status` (enum)
- **Purveyor Orders** (`purveyor_order`): `purveyor_name` (string), `delivery_window` (enum), `order_total` (currency)

## Application Screens
- **Walk-In Larder Inspector** (`/larder-inspector`) — Layout: `master_detail`
- **Nightly Restock Board** (`/restock-board`) — Layout: `kanban_board`
- **Purveyor Dock Schedule** (`/purveyor-deliveries`) — Layout: `data_table_with_filters`

## API Endpoints
- `GET /api/pantry_ingredient`
- `POST /api/pantry_ingredient`
- `PUT /api/pantry_ingredient/{item_id}`
- `DELETE /api/pantry_ingredient/{item_id}`
- `GET /api/purveyor_order`
- `POST /api/purveyor_order`
- `PUT /api/purveyor_order/{item_id}`
- `DELETE /api/purveyor_order/{item_id}`
- `POST /api/seed`
- `GET /api/health`

## SQLAlchemy Models
- `PantryIngredientModel`
- `PurveyorOrderModel`

## Local Execution

### 1. Instant Standalone UI
Open `standalone_app.html` directly in any browser (zero external CDN dependencies).

### 2. Backend API (`FastAPI` + `SQLite`)
```bash
cd backend
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### 3. React + Vite Frontend
```bash
cd frontend
npm install
npm run dev
```
