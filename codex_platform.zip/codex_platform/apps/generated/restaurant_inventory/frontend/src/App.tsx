import React, { useEffect, useState } from 'react';
import {
  AdaptiveAppShell,
  AdaptiveLayoutRenderer,
  Button,
  FormField,
  Input,
  Modal,
  Select,
  Toast,
  EntityRecord,
  EntitySpecData,
  PageSpecData,
} from './ui_kit';

const BLUEPRINT = {
  "app_name": "MiseEnPlace Larder",
  "product_tagline": "Kitchen par-level tracking, walk-in cooler lots, and purveyor restock orders",
  "domain": {
    "product_kind": "Restaurant Kitchen Pantry, Cold-Storage & Purveyor Stock Manager",
    "archetype": "inventory_stock",
    "audience": {
      "who": "Executive chefs, sous chefs, and kitchen purchasing managers",
      "context_of_use": "Walk-in cooler par checks and prep-line restock ordering",
      "device_likely_used": "tablet",
      "tech_comfort": "medium"
    },
    "core_jobs": [
      "Inspect ingredient par levels, cold-storage stations, and lot freshness in split view",
      "Flag low-stock perishables and place next-morning purveyor restock orders",
      "Track station prep depletion across produce, butcher, and dry pantry"
    ],
    "primary_object": "pantry_ingredient",
    "tone": "crafted",
    "data_shape": "relational",
    "needs_automation": false,
    "rationale": "Chefs walking the line with a tablet need a split master-detail pantry inspector and restock kanban board in warm culinary earth tones."
  },
  "entities": [
    {
      "name": "pantry_ingredient",
      "singular_label": "Pantry Ingredient",
      "plural_label": "Pantry Ingredients",
      "fields": [
        {
          "name": "ingredient_name",
          "label": "Ingredient Name",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "kitchen_station",
          "label": "Storage Station",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Walk-In Produce",
            "Butcher & Seafood",
            "Dairy & Pastry Cooler",
            "Dry Larder"
          ],
          "default_value": null
        },
        {
          "name": "on_hand_qty",
          "label": "On-Hand Quantity",
          "field_type": "float",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "par_target",
          "label": "Par Target",
          "field_type": "float",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "stock_status",
          "label": "Stock Status",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "At Par",
            "Order Tonight",
            "Critical 86 Risk"
          ],
          "default_value": null
        }
      ],
      "relationships": []
    },
    {
      "name": "purveyor_order",
      "singular_label": "Purveyor Order",
      "plural_label": "Purveyor Orders",
      "fields": [
        {
          "name": "purveyor_name",
          "label": "Farm / Purveyor",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "delivery_window",
          "label": "Delivery Dock Window",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "05:30 AM Dock",
            "08:00 AM Produce",
            "11:00 AM Specialty"
          ],
          "default_value": null
        },
        {
          "name": "order_total",
          "label": "Estimated Invoice",
          "field_type": "currency",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        }
      ],
      "relationships": []
    }
  ],
  "pages": [
    {
      "id": "larder-inspector",
      "title": "Walk-In Larder Inspector",
      "route": "/larder-inspector",
      "layout": "master_detail",
      "entities_used": [
        "pantry_ingredient"
      ],
      "primary_actions": [
        "Log Par Count",
        "Flag 86 Risk"
      ],
      "empty_state": {
        "headline": "Walk-In Larder Sheet Is Empty",
        "body": "Add your first produce, butcher, or dry-larder ingredient with its daily par target to start pre-service stock checks.",
        "cta_label": "Add First Ingredient",
        "cta_action_id": "create_pantry_ingredient"
      }
    },
    {
      "id": "restock-board",
      "title": "Nightly Restock Board",
      "route": "/restock-board",
      "layout": "kanban_board",
      "entities_used": [
        "pantry_ingredient"
      ],
      "primary_actions": [
        "Move to Tonight's Order"
      ],
      "empty_state": {
        "headline": "All Kitchen Stations Are At Par",
        "body": "Items below par target automatically appear in the nightly order lane.",
        "cta_label": "Record Ingredient Count",
        "cta_action_id": "create_pantry_ingredient"
      }
    },
    {
      "id": "purveyor-deliveries",
      "title": "Purveyor Dock Schedule",
      "route": "/purveyor-deliveries",
      "layout": "data_table_with_filters",
      "entities_used": [
        "purveyor_order"
      ],
      "primary_actions": [
        "Schedule Purveyor PO"
      ],
      "empty_state": {
        "headline": "No Morning Dock Deliveries Scheduled",
        "body": "Create a purveyor purchase order for tomorrow's 5:30 AM kitchen receiving.",
        "cta_label": "Create Purveyor PO",
        "cta_action_id": "create_purveyor_order"
      }
    }
  ],
  "navigation": {
    "pattern": "split_master_detail",
    "items": [
      {
        "page_id": "larder-inspector",
        "label": "Larder Inspector",
        "icon": "utensils"
      },
      {
        "page_id": "restock-board",
        "label": "Restock Lanes",
        "icon": "kanban"
      },
      {
        "page_id": "purveyor-deliveries",
        "label": "Purveyor Dock",
        "icon": "truck"
      }
    ]
  },
  "home_page_id": "larder-inspector",
  "automations": []
} as const;
const DESIGN_DIRECTION = {
  "direction_id": "studio_craft",
  "palette": {
    "primary": "#4D6B14",
    "primary_foreground": "#FFFFFF",
    "accent": "#3B5D11",
    "neutral_ramp": [
      "#F7F4EF",
      "#EFEAE1",
      "#E0D7C8",
      "#C7B9A5",
      "#9E8E78",
      "#736552",
      "#524637",
      "#362C21",
      "#211A14"
    ],
    "surface": "#F7F4EF",
    "surface_elevated": "#FFFFFF",
    "border": "#706250",
    "text": "#211A14",
    "text_muted": "#4A3F31",
    "focus_ring": "#4D6B14",
    "success": "#28662B",
    "warning": "#854D0E",
    "danger": "#9E1C1C"
  },
  "color_mode": "light",
  "typography": {
    "heading_font": "Playfair Display",
    "body_font": "DM Sans",
    "mono_font": "JetBrains Mono",
    "scale_ratio": 1.32
  },
  "shape": {
    "radius_class": "round",
    "border_style": "hairline",
    "shadow_style": "soft"
  },
  "density": "spacious",
  "motion": "subtle",
  "iconography": "duotone",
  "brand_mark": {
    "kind": "wordmark",
    "glyph_primitive": "cube_iso",
    "monogram_letters": "MP"
  },
  "copy_voice": "Crafted, tactile, culinary/editorial precision focused on stock provenance.",
  "rationale": "Herb-olive and terracotta tones paired with Playfair Display headings and split master-detail inspection fit a culinary larder and prep kitchen."
} as const;
const SAMPLE_SEED_DATA: Record<string, EntityRecord[]> = {
  "pantry_ingredient": [
    {
      "id": "ing-1",
      "ingredient_name": "San Marzano DOP Tomatoes (#10 Can)",
      "kitchen_station": "Dry Larder",
      "on_hand_qty": 6.0,
      "par_target": 18.0,
      "stock_status": "Order Tonight"
    },
    {
      "id": "ing-2",
      "ingredient_name": "Wild Halibut Fillet (Portioned 180g)",
      "kitchen_station": "Butcher & Seafood",
      "on_hand_qty": 4.0,
      "par_target": 24.0,
      "stock_status": "Critical 86 Risk"
    },
    {
      "id": "ing-3",
      "ingredient_name": "Cultured Normandy Unsalted Butter (kg)",
      "kitchen_station": "Dairy & Pastry Cooler",
      "on_hand_qty": 15.0,
      "par_target": 14.0,
      "stock_status": "At Par"
    }
  ],
  "purveyor_order": [
    {
      "id": "po-1",
      "purveyor_name": "Harbor Dayboat Fishery",
      "delivery_window": "05:30 AM Dock",
      "order_total": 685.0
    },
    {
      "id": "po-2",
      "purveyor_name": "Valle Verde Organic Growers",
      "delivery_window": "08:00 AM Produce",
      "order_total": 412.5
    }
  ]
};
const BRAND_SVG_MARKUP = "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 3L20 7.5V16.5L12 21L4 16.5V7.5L12 3Z\" stroke=\"currentColor\" stroke-width=\"2\" fill=\"none\"/><path d=\"M4 7.5L12 12L20 7.5M12 12V21\" stroke=\"currentColor\" stroke-width=\"1.8\" fill=\"none\"/></svg>";
const NUMERIC_TYPES = new Set(['integer', 'float', 'currency']);

export default function App(): React.ReactElement {
  const [activePageId, setActivePageId] = useState<string>(BLUEPRINT.home_page_id);
  const [recordsByEntity, setRecordsByEntity] = useState<Record<string, EntityRecord[]>>(() => {
    const initial: Record<string, EntityRecord[]> = {};
    for (const ent of BLUEPRINT.entities) {
      initial[ent.name] = [];
    }
    return initial;
  });
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formState, setFormState] = useState<Record<string, string | number | boolean>>({});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const pages = BLUEPRINT.pages as unknown as PageSpecData[];
  const entities = BLUEPRINT.entities as unknown as EntitySpecData[];
  const activePage = pages.find((p) => p.id === activePageId) || pages[0];
  const primaryEntityName = activePage.entities_used[0] || entities[0].name;
  const activeEntity = entities.find((e) => e.name === primaryEntityName) || entities[0];
  const activeRecords = recordsByEntity[activeEntity.name] || [];

  useEffect(() => {
    for (const ent of entities) {
      fetch(`/api/${ent.name}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data: EntityRecord[] | null) => {
          if (Array.isArray(data) && data.length > 0) {
            setRecordsByEntity((prev) => ({ ...prev, [ent.name]: data }));
          }
        })
        .catch(() => {
          // Offline mode uses in-memory state
        });
    }
  }, []);

  const openCreateModal = (): void => {
    const defaults: Record<string, string | number | boolean> = {};
    for (const fld of activeEntity.fields) {
      if (fld.field_type === 'boolean') {
        defaults[fld.name] = Boolean(fld.default_value ?? false);
      } else if (NUMERIC_TYPES.has(fld.field_type)) {
        defaults[fld.name] = Number(fld.default_value ?? 0);
      } else if (fld.field_type === 'enum' && fld.enum_values && fld.enum_values.length > 0) {
        defaults[fld.name] = fld.enum_values[0];
      } else {
        defaults[fld.name] = String(fld.default_value ?? '');
      }
    }
    setFormState(defaults);
    setIsModalOpen(true);
  };

  const handleCreateRecord = (): void => {
    const newRecord: EntityRecord = {
      id: `${activeEntity.name}-${Date.now()}`,
      ...formState,
    };
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: [newRecord, ...(prev[activeEntity.name] || [])],
    }));
    fetch(`/api/${activeEntity.name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formState),
    }).catch(() => undefined);
    setIsModalOpen(false);
    setToastMsg(`Saved ${activeEntity.singular_label}`);
  };

  const handleLoadSampleSeedData = (): void => {
    setRecordsByEntity(SAMPLE_SEED_DATA);
    fetch('/api/seed', { method: 'POST' }).catch(() => undefined);
    setToastMsg('Loaded domain sample records');
  };

  const handleDeleteRecord = (recordId: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).filter((r) => String(r.id) !== recordId),
    }));
    fetch(`/api/${activeEntity.name}/${recordId}`, {
      method: 'DELETE',
    }).catch(() => undefined);
    setToastMsg(`Removed ${activeEntity.singular_label}`);
  };

  const handleToggleBoolean = (recordId: string, fieldName: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).map((r) =>
        String(r.id) === recordId ? { ...r, [fieldName]: !r[fieldName] } : r
      ),
    }));
  };

  return (
    <div className="min-h-screen bg-surface text-text font-body">
      <AdaptiveAppShell
        pattern={BLUEPRINT.navigation.pattern}
        appName={BLUEPRINT.app_name}
        tagline={BLUEPRINT.product_tagline}
        brandMark={
          <span
            className="inline-flex items-center"
            dangerouslySetInnerHTML={{ __html: BRAND_SVG_MARKUP }}
          />
        }
        navItems={BLUEPRINT.navigation.items.map((item) => ({
          page_id: item.page_id,
          label: item.label,
          icon: item.icon,
        }))}
        activePageId={activePage.id}
        onSelectPage={setActivePageId}
        primaryAction={
          <div className="flex items-center gap-2">
            {activeRecords.length === 0 && (
              <Button variant="secondary" onClick={handleLoadSampleSeedData}>
                Load Sample Data
              </Button>
            )}
            <Button variant="primary" onClick={openCreateModal}>
              + {activePage.primary_actions[0] || `New ${activeEntity.singular_label}`}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {toastMsg && (
            <div className="flex justify-between items-center">
              <Toast message={toastMsg} tone="success" />
              <Button variant="ghost" onClick={() => setToastMsg(null)}>Dismiss</Button>
            </div>
          )}
          <AdaptiveLayoutRenderer
            page={activePage}
            entity={activeEntity}
            records={activeRecords}
            onOpenCreate={openCreateModal}
            onDeleteRecord={handleDeleteRecord}
            onToggleBoolean={handleToggleBoolean}
          />
        </div>
      </AdaptiveAppShell>

      <Modal
        open={isModalOpen}
        title={`Add ${activeEntity.singular_label}`}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-3">
          {activeEntity.fields.map((fld) => (
            <FormField key={fld.name} label={fld.label} required={fld.required}>
              {fld.field_type === 'enum' && fld.enum_values ? (
                <Select
                  value={String(formState[fld.name] ?? fld.enum_values[0] ?? '')}
                  options={fld.enum_values.map((v) => ({ value: v, label: v }))}
                  onChange={(val) => setFormState((prev) => ({ ...prev, [fld.name]: val }))}
                />
              ) : (
                <Input
                  type={
                    NUMERIC_TYPES.has(fld.field_type)
                      ? 'number'
                      : fld.field_type === 'date'
                        ? 'date'
                        : 'text'
                  }
                  value={String(formState[fld.name] ?? '')}
                  placeholder={`Enter ${fld.label}`}
                  onChange={(val) =>
                    setFormState((prev) => ({
                      ...prev,
                      [fld.name]: NUMERIC_TYPES.has(fld.field_type) ? Number(val) : val,
                    }))
                  }
                />
              )}
            </FormField>
          ))}
          <div className="flex justify-end gap-2 pt-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCreateRecord}>
              Save {activeEntity.singular_label}
            </Button>
          </div>
        </div>
      </Modal>
      
    </div>
  );
}
