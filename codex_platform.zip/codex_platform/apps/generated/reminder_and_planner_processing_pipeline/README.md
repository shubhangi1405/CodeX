# Reminder and Planner Processing Pipeline

> Punctual schedule management, weekly calendar agenda, and priority task reminders

## Product & Domain Summary
- **Product Kind**: Calendar Event Scheduling & Priority Reminders Workspace
- **Archetype**: `booking_scheduler`
- **Primary Object**: `calendar_event`
- **Target Audience**: Professionals, coordinators, and students organizing daily agendas (Everyday schedule planning, event timeblocking, and reminder checklist tracking)
- **Navigation Pattern**: `top_tabs`
- **Home Page**: `weekly-agenda` (`calendar_week_agenda`)

## Design Direction (`editorial_calm`)
- **Color Mode**: `light` | **Primary**: `#0D9488` | **Surface**: `#FBF9F5`
- **Typography**: Heading `Fraunces` · Body `Source Sans 3` · Mono `JetBrains Mono`
- **Shape & Density**: Radius `soft` · Density `comfortable`
- **Rationale**: Serene, high-focus productivity interface with calming teal tones, clear typography, and distinct schedule blocks.

## Domain Entities
- **Calendar Events** (`calendar_event`): `event_title` (string), `event_date` (date), `time_slot` (string), `category` (enum), `location` (string), `notes` (string)
- **Reminder Tasks** (`reminder_task`): `task_title` (string), `due_date` (date), `priority` (enum), `status` (enum), `reminder_time` (string), `repeat_frequency` (enum), `event_id` (string)

## Application Screens
- **Weekly Calendar & Schedule** (`/weekly-agenda`) — Layout: `calendar_week_agenda`
- **Priority Reminders & Checklist** (`/reminders-checklist`) — Layout: `checklist_today`
- **Upcoming Schedule Timeline** (`/upcoming-timeline`) — Layout: `timeline`

## API Endpoints
- `GET /api/calendar_event`
- `POST /api/calendar_event`
- `PUT /api/calendar_event/{item_id}`
- `DELETE /api/calendar_event/{item_id}`
- `GET /api/reminder_task`
- `POST /api/reminder_task`
- `PUT /api/reminder_task/{item_id}`
- `DELETE /api/reminder_task/{item_id}`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `POST /api/auth/reset-password`
- `GET /api/auth/status`
- `GET /api/privacy/export`
- `DELETE /api/privacy/account`
- `GET /api/security/threat-model`
- `GET /api/analytics/summary`
- `POST /api/seed`
- `GET /api/health`

## SQLAlchemy Models
- `CalendarEventModel`
- `ReminderTaskModel`

## Local Execution

### 1. Instant Standalone UI
Open `standalone_app.html` directly in any browser (zero external CDN dependencies).

### 2. Backend API (`FastAPI` + `SQLite`)
```bash
cd backend
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### 3. React + Vite Frontend
```bash
cd frontend
npm install
npm run dev
```
