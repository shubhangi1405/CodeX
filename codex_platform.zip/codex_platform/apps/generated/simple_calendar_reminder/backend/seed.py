"""Optional sample seed data loader for Simple Calendar Reminder."""

import json
from sqlalchemy.orm import Session
from database import Base, SessionLocal, engine
from models import CalendarEventModel, ReminderTaskModel, UserModel
from auth import hash_password

SAMPLE_SEED_DATA = json.loads(r'''{
  "calendar_event": [
    {
      "id": "evt-01",
      "event_title": "Sprint Planning & Roadmap Review",
      "event_date": "2026-10-15",
      "time_slot": "09:30 - 11:00",
      "category": "Work",
      "location": "Design Studio 3B",
      "notes": "Align on Q4 milestones and user experience priorities."
    },
    {
      "id": "evt-02",
      "event_title": "Dentist Consultation & Checkup",
      "event_date": "2026-10-16",
      "time_slot": "14:00 - 15:00",
      "category": "Health",
      "location": "Downtown Health Pavilion",
      "notes": "Semi-annual dental cleaning and checkup."
    },
    {
      "id": "evt-03",
      "event_title": "Product Architecture Review",
      "event_date": "2026-10-18",
      "time_slot": "15:00 - 16:30",
      "category": "Meeting",
      "location": "Virtual Video Bridge",
      "notes": "Walkthrough of adaptive generator components."
    }
  ],
  "reminder_task": [
    {
      "id": "rem-01",
      "task_title": "Submit quarterly estimated tax filing",
      "due_date": "2026-10-15",
      "priority": "High",
      "status": "Pending",
      "reminder_time": "10:00",
      "repeat_frequency": "Monthly",
      "event_id": "evt-01"
    },
    {
      "id": "rem-02",
      "task_title": "Confirm dinner reservation for anniversary",
      "due_date": "2026-10-16",
      "priority": "Medium",
      "status": "Pending",
      "reminder_time": "12:00",
      "repeat_frequency": "None",
      "event_id": "evt-02"
    },
    {
      "id": "rem-03",
      "task_title": "Drink 2L water and take daily vitamins",
      "due_date": "2026-10-14",
      "priority": "Low",
      "status": "Completed",
      "reminder_time": "08:30",
      "repeat_frequency": "Daily",
      "event_id": "evt-03"
    }
  ]
}''')


def seed_database(db: Session) -> dict[str, int]:
    """Inserts domain sample records if tables are currently empty."""
    inserted: dict[str, int] = {}
    if db.query(UserModel).count() == 0:
        admin_u = UserModel(
            id="usr-admin",
            email="admin@workspace.example",
            password_hash=hash_password("Password123!"),
            display_name="Admin Director",
            role="admin",
        )
        member_u = UserModel(
            id="usr-member",
            email="member@workspace.example",
            password_hash=hash_password("Password123!"),
            display_name="Active Member",
            role="member",
        )
        db.add_all([admin_u, member_u])
        db.commit()
        inserted["users"] = 2

    records_calendar_event = SAMPLE_SEED_DATA.get("calendar_event", [])
    existing_calendar_event = db.query(CalendarEventModel).count()
    count_calendar_event = 0
    if existing_calendar_event == 0:
        for row in records_calendar_event:
            allowed = ['event_title', 'event_date', 'time_slot', 'category', 'location', 'notes']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            if 'owner_id' not in payload:
                payload['owner_id'] = 'usr-member'
            db.add(CalendarEventModel(**payload))
            count_calendar_event += 1
    inserted["calendar_event"] = count_calendar_event
    records_reminder_task = SAMPLE_SEED_DATA.get("reminder_task", [])
    existing_reminder_task = db.query(ReminderTaskModel).count()
    count_reminder_task = 0
    if existing_reminder_task == 0:
        for row in records_reminder_task:
            allowed = ['task_title', 'due_date', 'priority', 'status', 'reminder_time', 'repeat_frequency', 'event_id']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            if 'owner_id' not in payload:
                payload['owner_id'] = 'usr-member'
            db.add(ReminderTaskModel(**payload))
            count_reminder_task += 1
    inserted["reminder_task"] = count_reminder_task
    db.commit()
    return inserted


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as session:
        result = seed_database(session)
        print("Seeded sample records:", result)
