"""Domain SQLAlchemy ORM models for SteadyCadence Rituals."""

from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from database import Base

class HabitRitualModel(Base):
    __tablename__ = "habit_rituals"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    ritual_name = Column(String, nullable=False, default='')
    time_of_day = Column(String, nullable=False, default='Morning')
    current_streak = Column(Integer, nullable=False, default=1)
    completed_today = Column(Boolean, nullable=False, default=False)
    cue_prompt = Column(String, nullable=True, default='')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class ReflectionNoteModel(Base):
    __tablename__ = "reflection_notes"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    entry_date = Column(String, nullable=False, default='')
    energy_level = Column(String, nullable=False, default='Rested')
    gratitude_takeaway = Column(Text, nullable=False, default='')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
