"""Optional sample seed data loader for SteadyCadence Rituals."""

import json
from sqlalchemy.orm import Session
from database import Base, SessionLocal, engine
from models import HabitRitualModel, ReflectionNoteModel

SAMPLE_SEED_DATA = json.loads(r'''{
  "habit_ritual": [
    {
      "id": "hab-1",
      "ritual_name": "20 Minutes Morning Reading (No Screens)",
      "time_of_day": "Morning",
      "current_streak": 14,
      "completed_today": true,
      "cue_prompt": "Right after pouring morning coffee"
    },
    {
      "id": "hab-2",
      "ritual_name": "Outdoor Mobility & Sunlight Walk",
      "time_of_day": "Midday",
      "current_streak": 9,
      "completed_today": false,
      "cue_prompt": "Before opening afternoon messages"
    },
    {
      "id": "hab-3",
      "ritual_name": "Evening Digital Sunset & Gratitude Note",
      "time_of_day": "Evening",
      "current_streak": 21,
      "completed_today": true,
      "cue_prompt": "At 9:30 PM lamp dimming"
    }
  ],
  "reflection_note": [
    {
      "id": "ref-1",
      "entry_date": "2026-10-12",
      "energy_level": "Rested",
      "gratitude_takeaway": "Leaving the phone in the hallway made morning reading effortless."
    }
  ]
}''')


def seed_database(db: Session) -> dict[str, int]:
    """Inserts domain sample records if tables are currently empty."""
    inserted: dict[str, int] = {}
    records_habit_ritual = SAMPLE_SEED_DATA.get("habit_ritual", [])
    existing_habit_ritual = db.query(HabitRitualModel).count()
    count_habit_ritual = 0
    if existing_habit_ritual == 0:
        for row in records_habit_ritual:
            allowed = ['ritual_name', 'time_of_day', 'current_streak', 'completed_today', 'cue_prompt']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(HabitRitualModel(**payload))
            count_habit_ritual += 1
    inserted["habit_ritual"] = count_habit_ritual
    records_reflection_note = SAMPLE_SEED_DATA.get("reflection_note", [])
    existing_reflection_note = db.query(ReflectionNoteModel).count()
    count_reflection_note = 0
    if existing_reflection_note == 0:
        for row in records_reflection_note:
            allowed = ['entry_date', 'energy_level', 'gratitude_takeaway']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(ReflectionNoteModel(**payload))
            count_reflection_note += 1
    inserted["reflection_note"] = count_reflection_note
    db.commit()
    return inserted


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as session:
        result = seed_database(session)
        print("Seeded sample records:", result)
