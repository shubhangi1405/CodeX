# RallySlot Courts

> Instant tennis, pickleball, and padel court reservations & club directory

## Product & Domain Summary
- **Product Kind**: Athletic Club & Community Sports Court Booking Scheduler
- **Archetype**: `booking_scheduler`
- **Primary Object**: `court_reservation`
- **Target Audience**: Tennis, pickleball, and padel players booking courts on mobile or kiosk (On-the-go court reservation between matches or at club desk)
- **Navigation Pattern**: `bottom_tabs`
- **Home Page**: `weekly-court-agenda` (`calendar_week_agenda`)

## Design Direction (`marketplace_warm`)
- **Color Mode**: `light` | **Primary**: `#B45309` | **Surface**: `#FAF8F5`
- **Typography**: Heading `Sora` · Body `Plus Jakarta Sans` · Mono `IBM Plex Mono`
- **Shape & Density**: Radius `round` · Density `comfortable`
- **Rationale**: Clay-court burnt amber accents, warm alabaster cards, and Sora geometric headings give players instant slot legibility on bright outdoor mobile screens.

## Domain Entities
- **Court Reservations** (`court_reservation`): `court_name` (enum), `booking_date` (date), `time_slot` (enum), `player_captain` (string), `court_fee` (currency)
- **Court Venues** (`court_venue`): `venue_title` (string), `surface_type` (enum), `lighting_status` (string), `hourly_rate` (currency)

## Application Screens
- **Weekly Court Agenda** (`/weekly-court-agenda`) — Layout: `calendar_week_agenda`
- **Courts & Surfaces** (`/court-directory`) — Layout: `card_grid`
- **Monthly Match Calendar** (`/monthly-tournaments`) — Layout: `calendar_month`

## API Endpoints
- `GET /api/court_reservation`
- `POST /api/court_reservation`
- `PUT /api/court_reservation/{item_id}`
- `DELETE /api/court_reservation/{item_id}`
- `GET /api/court_venue`
- `POST /api/court_venue`
- `PUT /api/court_venue/{item_id}`
- `DELETE /api/court_venue/{item_id}`
- `POST /api/seed`
- `GET /api/health`

## SQLAlchemy Models
- `CourtReservationModel`
- `CourtVenueModel`

## Local Execution

### 1. Instant Standalone UI
Open `standalone_app.html` directly in any browser (zero external CDN dependencies).

### 2. Backend API (`FastAPI` + `SQLite`)
```bash
cd backend
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### 3. React + Vite Frontend
```bash
cd frontend
npm install
npm run dev
```
