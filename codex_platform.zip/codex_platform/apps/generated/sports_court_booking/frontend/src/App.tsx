import React, { useEffect, useState } from 'react';
import {
  AdaptiveAppShell,
  AdaptiveLayoutRenderer,
  Button,
  FormField,
  Input,
  Modal,
  Select,
  Toast,
  EntityRecord,
  EntitySpecData,
  PageSpecData,
} from './ui_kit';

const BLUEPRINT = {
  "app_name": "RallySlot Courts",
  "product_tagline": "Instant tennis, pickleball, and padel court reservations & club directory",
  "domain": {
    "product_kind": "Athletic Club & Community Sports Court Booking Scheduler",
    "archetype": "booking_scheduler",
    "audience": {
      "who": "Tennis, pickleball, and padel players booking courts on mobile or kiosk",
      "context_of_use": "On-the-go court reservation between matches or at club desk",
      "device_likely_used": "mobile",
      "tech_comfort": "medium"
    },
    "core_jobs": [
      "Scan weekly court slot availability and reserve a court in seconds",
      "Browse club court surfaces, lighting, and indoor/outdoor amenities",
      "Manage upcoming player reservations and partner split bookings"
    ],
    "primary_object": "court_reservation",
    "tone": "energetic",
    "data_shape": "calendar",
    "needs_automation": false,
    "rationale": "Players opening a court booking app want an immediate weekly agenda calendar and venue cards with mobile bottom tabs, not data pipelines."
  },
  "entities": [
    {
      "name": "court_reservation",
      "singular_label": "Court Reservation",
      "plural_label": "Court Reservations",
      "fields": [
        {
          "name": "court_name",
          "label": "Court Name",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Court 1 - Championship Clay",
            "Court 2 - Hardcourt LED",
            "Court 3 - Covered Padel",
            "Court 4 - Pickleball Show"
          ],
          "default_value": null
        },
        {
          "name": "booking_date",
          "label": "Match Date",
          "field_type": "date",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "time_slot",
          "label": "Time Slot",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "07:00 - 08:30",
            "09:00 - 10:30",
            "17:30 - 19:00",
            "19:30 - 21:00"
          ],
          "default_value": null
        },
        {
          "name": "player_captain",
          "label": "Lead Player",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "court_fee",
          "label": "Court Fee",
          "field_type": "currency",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": 36.0
        }
      ],
      "relationships": []
    },
    {
      "name": "court_venue",
      "singular_label": "Court Venue",
      "plural_label": "Court Venues",
      "fields": [
        {
          "name": "venue_title",
          "label": "Court Title",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "surface_type",
          "label": "Surface Type",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Red Clay",
            "Cushioned Acrylic",
            "Panoramic Turf"
          ],
          "default_value": null
        },
        {
          "name": "lighting_status",
          "label": "Floodlights & Roof",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "hourly_rate",
          "label": "Hourly Rate",
          "field_type": "currency",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        }
      ],
      "relationships": []
    }
  ],
  "pages": [
    {
      "id": "weekly-court-agenda",
      "title": "Weekly Court Agenda",
      "route": "/weekly-court-agenda",
      "layout": "calendar_week_agenda",
      "entities_used": [
        "court_reservation"
      ],
      "primary_actions": [
        "Reserve Time Slot",
        "Filter by Surface"
      ],
      "empty_state": {
        "headline": "All Courts Open for This Week",
        "body": "Pick a morning rally or evening floodlit slot to lock in your next match reservation.",
        "cta_label": "Book First Court Slot",
        "cta_action_id": "create_court_reservation"
      }
    },
    {
      "id": "court-directory",
      "title": "Courts & Surfaces",
      "route": "/court-directory",
      "layout": "card_grid",
      "entities_used": [
        "court_venue"
      ],
      "primary_actions": [
        "Add Club Court"
      ],
      "empty_state": {
        "headline": "No Club Courts Listed Yet",
        "body": "Add your club's clay, hard, or padel courts with surface details.",
        "cta_label": "Add Club Court",
        "cta_action_id": "create_court_venue"
      }
    },
    {
      "id": "monthly-tournaments",
      "title": "Monthly Match Calendar",
      "route": "/monthly-tournaments",
      "layout": "calendar_month",
      "entities_used": [
        "court_reservation"
      ],
      "primary_actions": [
        "Schedule Match Slot"
      ],
      "empty_state": {
        "headline": "No Monthly Bookings Scheduled",
        "body": "Reserve a court slot to populate the monthly club calendar.",
        "cta_label": "Reserve Match Slot",
        "cta_action_id": "create_court_reservation"
      }
    }
  ],
  "navigation": {
    "pattern": "bottom_tabs",
    "items": [
      {
        "page_id": "weekly-court-agenda",
        "label": "Court Agenda",
        "icon": "calendar"
      },
      {
        "page_id": "court-directory",
        "label": "Club Courts",
        "icon": "map-pin"
      },
      {
        "page_id": "monthly-tournaments",
        "label": "Month View",
        "icon": "trophy"
      }
    ]
  },
  "home_page_id": "weekly-court-agenda",
  "automations": []
} as const;
const DESIGN_DIRECTION = {
  "direction_id": "marketplace_warm",
  "palette": {
    "primary": "#B45309",
    "primary_foreground": "#FFFFFF",
    "accent": "#065F46",
    "neutral_ramp": [
      "#FAF8F5",
      "#F3EFEA",
      "#E6DFD5",
      "#D0C5B6",
      "#A69988",
      "#786C5E",
      "#544B40",
      "#362F28",
      "#1F1A17"
    ],
    "surface": "#FAF8F5",
    "surface_elevated": "#FFFFFF",
    "border": "#706457",
    "text": "#1F1A17",
    "text_muted": "#4A4037",
    "focus_ring": "#B45309",
    "success": "#116944",
    "warning": "#8A4B08",
    "danger": "#A81818"
  },
  "color_mode": "light",
  "typography": {
    "heading_font": "Sora",
    "body_font": "Plus Jakarta Sans",
    "mono_font": "IBM Plex Mono",
    "scale_ratio": 1.25
  },
  "shape": {
    "radius_class": "round",
    "border_style": "hairline",
    "shadow_style": "soft"
  },
  "density": "comfortable",
  "motion": "subtle",
  "iconography": "duotone",
  "brand_mark": {
    "kind": "geometric_glyph",
    "glyph_primitive": "court_lines",
    "monogram_letters": "RS"
  },
  "copy_voice": "Welcoming, availability-first, concierge booking microcopy.",
  "rationale": "Clay-court burnt amber accents, warm alabaster cards, and Sora geometric headings give players instant slot legibility on bright outdoor mobile screens."
} as const;
const SAMPLE_SEED_DATA: Record<string, EntityRecord[]> = {
  "court_reservation": [
    {
      "id": "res-1",
      "court_name": "Court 1 - Championship Clay",
      "booking_date": "2026-10-14",
      "time_slot": "07:00 - 08:30",
      "player_captain": "Elena Rostova (Doubles)",
      "court_fee": 42.0
    },
    {
      "id": "res-2",
      "court_name": "Court 3 - Covered Padel",
      "booking_date": "2026-10-14",
      "time_slot": "17:30 - 19:00",
      "player_captain": "Marcus Vance & Team",
      "court_fee": 48.0
    },
    {
      "id": "res-3",
      "court_name": "Court 4 - Pickleball Show",
      "booking_date": "2026-10-15",
      "time_slot": "19:30 - 21:00",
      "player_captain": "Priya Nair (Ladder Match)",
      "court_fee": 32.0
    }
  ],
  "court_venue": [
    {
      "id": "ven-1",
      "venue_title": "Court 1 - Championship Clay",
      "surface_type": "Red Clay",
      "lighting_status": "Outdoor + 800 Lux LED",
      "hourly_rate": 28.0
    },
    {
      "id": "ven-2",
      "venue_title": "Court 3 - Covered Padel",
      "surface_type": "Panoramic Turf",
      "lighting_status": "Covered Canopy + Glass Walls",
      "hourly_rate": 32.0
    }
  ]
};
const BRAND_SVG_MARKUP = "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"4\" y=\"5\" width=\"16\" height=\"14\" rx=\"2\" stroke=\"currentColor\" stroke-width=\"2\" fill=\"none\"/><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\" stroke=\"currentColor\" stroke-width=\"1.8\"/><circle cx=\"12\" cy=\"12\" r=\"2.5\" stroke=\"currentColor\" stroke-width=\"1.8\" fill=\"none\"/></svg>";
const NUMERIC_TYPES = new Set(['integer', 'float', 'currency']);

export default function App(): React.ReactElement {
  const [activePageId, setActivePageId] = useState<string>(BLUEPRINT.home_page_id);
  const [recordsByEntity, setRecordsByEntity] = useState<Record<string, EntityRecord[]>>(() => {
    const initial: Record<string, EntityRecord[]> = {};
    for (const ent of BLUEPRINT.entities) {
      initial[ent.name] = [];
    }
    return initial;
  });
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formState, setFormState] = useState<Record<string, string | number | boolean>>({});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const pages = BLUEPRINT.pages as unknown as PageSpecData[];
  const entities = BLUEPRINT.entities as unknown as EntitySpecData[];
  const activePage = pages.find((p) => p.id === activePageId) || pages[0];
  const primaryEntityName = activePage.entities_used[0] || entities[0].name;
  const activeEntity = entities.find((e) => e.name === primaryEntityName) || entities[0];
  const activeRecords = recordsByEntity[activeEntity.name] || [];

  useEffect(() => {
    for (const ent of entities) {
      fetch(`/api/${ent.name}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data: EntityRecord[] | null) => {
          if (Array.isArray(data) && data.length > 0) {
            setRecordsByEntity((prev) => ({ ...prev, [ent.name]: data }));
          }
        })
        .catch(() => {
          // Offline mode uses in-memory state
        });
    }
  }, []);

  const openCreateModal = (): void => {
    const defaults: Record<string, string | number | boolean> = {};
    for (const fld of activeEntity.fields) {
      if (fld.field_type === 'boolean') {
        defaults[fld.name] = Boolean(fld.default_value ?? false);
      } else if (NUMERIC_TYPES.has(fld.field_type)) {
        defaults[fld.name] = Number(fld.default_value ?? 0);
      } else if (fld.field_type === 'enum' && fld.enum_values && fld.enum_values.length > 0) {
        defaults[fld.name] = fld.enum_values[0];
      } else {
        defaults[fld.name] = String(fld.default_value ?? '');
      }
    }
    setFormState(defaults);
    setIsModalOpen(true);
  };

  const handleCreateRecord = (): void => {
    const newRecord: EntityRecord = {
      id: `${activeEntity.name}-${Date.now()}`,
      ...formState,
    };
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: [newRecord, ...(prev[activeEntity.name] || [])],
    }));
    fetch(`/api/${activeEntity.name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formState),
    }).catch(() => undefined);
    setIsModalOpen(false);
    setToastMsg(`Saved ${activeEntity.singular_label}`);
  };

  const handleLoadSampleSeedData = (): void => {
    setRecordsByEntity(SAMPLE_SEED_DATA);
    fetch('/api/seed', { method: 'POST' }).catch(() => undefined);
    setToastMsg('Loaded domain sample records');
  };

  const handleDeleteRecord = (recordId: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).filter((r) => String(r.id) !== recordId),
    }));
    fetch(`/api/${activeEntity.name}/${recordId}`, {
      method: 'DELETE',
    }).catch(() => undefined);
    setToastMsg(`Removed ${activeEntity.singular_label}`);
  };

  const handleToggleBoolean = (recordId: string, fieldName: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).map((r) =>
        String(r.id) === recordId ? { ...r, [fieldName]: !r[fieldName] } : r
      ),
    }));
  };

  return (
    <div className="min-h-screen bg-surface text-text font-body">
      <AdaptiveAppShell
        pattern={BLUEPRINT.navigation.pattern}
        appName={BLUEPRINT.app_name}
        tagline={BLUEPRINT.product_tagline}
        brandMark={
          <span
            className="inline-flex items-center"
            dangerouslySetInnerHTML={{ __html: BRAND_SVG_MARKUP }}
          />
        }
        navItems={BLUEPRINT.navigation.items.map((item) => ({
          page_id: item.page_id,
          label: item.label,
          icon: item.icon,
        }))}
        activePageId={activePage.id}
        onSelectPage={setActivePageId}
        primaryAction={
          <div className="flex items-center gap-2">
            {activeRecords.length === 0 && (
              <Button variant="secondary" onClick={handleLoadSampleSeedData}>
                Load Sample Data
              </Button>
            )}
            <Button variant="primary" onClick={openCreateModal}>
              + {activePage.primary_actions[0] || `New ${activeEntity.singular_label}`}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {toastMsg && (
            <div className="flex justify-between items-center">
              <Toast message={toastMsg} tone="success" />
              <Button variant="ghost" onClick={() => setToastMsg(null)}>Dismiss</Button>
            </div>
          )}
          <AdaptiveLayoutRenderer
            page={activePage}
            entity={activeEntity}
            records={activeRecords}
            onOpenCreate={openCreateModal}
            onDeleteRecord={handleDeleteRecord}
            onToggleBoolean={handleToggleBoolean}
          />
        </div>
      </AdaptiveAppShell>

      <Modal
        open={isModalOpen}
        title={`Add ${activeEntity.singular_label}`}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-3">
          {activeEntity.fields.map((fld) => (
            <FormField key={fld.name} label={fld.label} required={fld.required}>
              {fld.field_type === 'enum' && fld.enum_values ? (
                <Select
                  value={String(formState[fld.name] ?? fld.enum_values[0] ?? '')}
                  options={fld.enum_values.map((v) => ({ value: v, label: v }))}
                  onChange={(val) => setFormState((prev) => ({ ...prev, [fld.name]: val }))}
                />
              ) : (
                <Input
                  type={
                    NUMERIC_TYPES.has(fld.field_type)
                      ? 'number'
                      : fld.field_type === 'date'
                        ? 'date'
                        : 'text'
                  }
                  value={String(formState[fld.name] ?? '')}
                  placeholder={`Enter ${fld.label}`}
                  onChange={(val) =>
                    setFormState((prev) => ({
                      ...prev,
                      [fld.name]: NUMERIC_TYPES.has(fld.field_type) ? Number(val) : val,
                    }))
                  }
                />
              )}
            </FormField>
          ))}
          <div className="flex justify-end gap-2 pt-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCreateRecord}>
              Save {activeEntity.singular_label}
            </Button>
          </div>
        </div>
      </Modal>
      
    </div>
  );
}
