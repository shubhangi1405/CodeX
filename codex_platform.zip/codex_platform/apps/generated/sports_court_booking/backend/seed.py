"""Optional sample seed data loader for RallySlot Courts."""

import json
from sqlalchemy.orm import Session
from database import Base, SessionLocal, engine
from models import CourtReservationModel, CourtVenueModel

SAMPLE_SEED_DATA = json.loads(r'''{
  "court_reservation": [
    {
      "id": "res-1",
      "court_name": "Court 1 - Championship Clay",
      "booking_date": "2026-10-14",
      "time_slot": "07:00 - 08:30",
      "player_captain": "Elena Rostova (Doubles)",
      "court_fee": 42.0
    },
    {
      "id": "res-2",
      "court_name": "Court 3 - Covered Padel",
      "booking_date": "2026-10-14",
      "time_slot": "17:30 - 19:00",
      "player_captain": "Marcus Vance & Team",
      "court_fee": 48.0
    },
    {
      "id": "res-3",
      "court_name": "Court 4 - Pickleball Show",
      "booking_date": "2026-10-15",
      "time_slot": "19:30 - 21:00",
      "player_captain": "Priya Nair (Ladder Match)",
      "court_fee": 32.0
    }
  ],
  "court_venue": [
    {
      "id": "ven-1",
      "venue_title": "Court 1 - Championship Clay",
      "surface_type": "Red Clay",
      "lighting_status": "Outdoor + 800 Lux LED",
      "hourly_rate": 28.0
    },
    {
      "id": "ven-2",
      "venue_title": "Court 3 - Covered Padel",
      "surface_type": "Panoramic Turf",
      "lighting_status": "Covered Canopy + Glass Walls",
      "hourly_rate": 32.0
    }
  ]
}''')


def seed_database(db: Session) -> dict[str, int]:
    """Inserts domain sample records if tables are currently empty."""
    inserted: dict[str, int] = {}
    records_court_reservation = SAMPLE_SEED_DATA.get("court_reservation", [])
    existing_court_reservation = db.query(CourtReservationModel).count()
    count_court_reservation = 0
    if existing_court_reservation == 0:
        for row in records_court_reservation:
            allowed = ['court_name', 'booking_date', 'time_slot', 'player_captain', 'court_fee']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(CourtReservationModel(**payload))
            count_court_reservation += 1
    inserted["court_reservation"] = count_court_reservation
    records_court_venue = SAMPLE_SEED_DATA.get("court_venue", [])
    existing_court_venue = db.query(CourtVenueModel).count()
    count_court_venue = 0
    if existing_court_venue == 0:
        for row in records_court_venue:
            allowed = ['venue_title', 'surface_type', 'lighting_status', 'hourly_rate']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(CourtVenueModel(**payload))
            count_court_venue += 1
    inserted["court_venue"] = count_court_venue
    db.commit()
    return inserted


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as session:
        result = seed_database(session)
        print("Seeded sample records:", result)
