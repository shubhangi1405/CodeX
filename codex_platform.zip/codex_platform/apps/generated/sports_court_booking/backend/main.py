"""FastAPI backend for RallySlot Courts — Instant tennis, pickleball, and padel court reservations & club directory."""

import json
from typing import Any, Optional
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import CourtReservationModel, CourtVenueModel
from seed import seed_database

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='RallySlot Courts',
    description='Instant tennis, pickleball, and padel court reservations & club directory',
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class CourtReservationCreate(BaseModel):
    court_name: str = 'Court 1 - Championship Clay'
    booking_date: str = ''
    time_slot: str = '07:00 - 08:30'
    player_captain: str = ''
    court_fee: float = 36.0

class CourtReservationUpdate(BaseModel):
    court_name: Optional[str] = None
    booking_date: Optional[str] = None
    time_slot: Optional[str] = None
    player_captain: Optional[str] = None
    court_fee: Optional[float] = None

def _serialize_court_reservation(item: CourtReservationModel) -> dict[str, Any]:
    return {"id": item.id, "court_name": getattr(item, "court_name"), "booking_date": getattr(item, "booking_date"), "time_slot": getattr(item, "time_slot"), "player_captain": getattr(item, "player_captain"), "court_fee": getattr(item, "court_fee")}

@app.get("/api/court_reservation")
def list_court_reservation(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(CourtReservationModel).order_by(CourtReservationModel.created_at.desc()).all()
    return [_serialize_court_reservation(r) for r in rows]

@app.post("/api/court_reservation", status_code=201)
def create_court_reservation(
    payload: CourtReservationCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = CourtReservationModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_court_reservation(record)

@app.put("/api/court_reservation/{item_id}")
def update_court_reservation(
    item_id: str, payload: CourtReservationUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(CourtReservationModel).filter(CourtReservationModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Court Reservation not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_court_reservation(record)

@app.delete("/api/court_reservation/{item_id}")
def delete_court_reservation(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(CourtReservationModel).filter(CourtReservationModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Court Reservation not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class CourtVenueCreate(BaseModel):
    venue_title: str = ''
    surface_type: str = 'Red Clay'
    lighting_status: str = ''
    hourly_rate: float = 0.0

class CourtVenueUpdate(BaseModel):
    venue_title: Optional[str] = None
    surface_type: Optional[str] = None
    lighting_status: Optional[str] = None
    hourly_rate: Optional[float] = None

def _serialize_court_venue(item: CourtVenueModel) -> dict[str, Any]:
    return {"id": item.id, "venue_title": getattr(item, "venue_title"), "surface_type": getattr(item, "surface_type"), "lighting_status": getattr(item, "lighting_status"), "hourly_rate": getattr(item, "hourly_rate")}

@app.get("/api/court_venue")
def list_court_venue(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(CourtVenueModel).order_by(CourtVenueModel.created_at.desc()).all()
    return [_serialize_court_venue(r) for r in rows]

@app.post("/api/court_venue", status_code=201)
def create_court_venue(
    payload: CourtVenueCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = CourtVenueModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_court_venue(record)

@app.put("/api/court_venue/{item_id}")
def update_court_venue(
    item_id: str, payload: CourtVenueUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(CourtVenueModel).filter(CourtVenueModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Court Venue not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_court_venue(record)

@app.delete("/api/court_venue/{item_id}")
def delete_court_venue(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(CourtVenueModel).filter(CourtVenueModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Court Venue not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

@app.post("/api/seed")
def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:
    inserted = seed_database(db)
    return {"status": "seeded", "inserted": inserted}

@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {
        "status": "healthy",
        "app": 'RallySlot Courts',
        "archetype": 'booking_scheduler',
    }
