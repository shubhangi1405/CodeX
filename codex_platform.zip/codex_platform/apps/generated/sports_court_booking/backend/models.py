"""Domain SQLAlchemy ORM models for RallySlot Courts."""

from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from database import Base

class CourtReservationModel(Base):
    __tablename__ = "court_reservations"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    court_name = Column(String, nullable=False, default='Court 1 - Championship Clay')
    booking_date = Column(String, nullable=False, default='')
    time_slot = Column(String, nullable=False, default='07:00 - 08:30')
    player_captain = Column(String, nullable=False, default='')
    court_fee = Column(Float, nullable=False, default=36.0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class CourtVenueModel(Base):
    __tablename__ = "court_venues"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    venue_title = Column(String, nullable=False, default='')
    surface_type = Column(String, nullable=False, default='Red Clay')
    lighting_status = Column(String, nullable=False, default='')
    hourly_rate = Column(Float, nullable=False, default=0.0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
