# Journaling Platform Analytics & Export Pipeline

> Unhurried daily habit check-ins, streak heatmaps, and mindful reflection

## Product & Domain Summary
- **Product Kind**: Personal Daily Habit & Ritual Consistency Tracker
- **Archetype**: `habit_or_goal_tracker`
- **Primary Object**: `habit_ritual`
- **Target Audience**: Mindful individuals building sustainable morning and evening routines (Calm morning check-in on laptop or phone with coffee)
- **Navigation Pattern**: `sidebar`
- **Home Page**: `today-rituals` (`checklist_today`)

## Design Direction (`playful_momentum`)
- **Color Mode**: `light` | **Primary**: `#1D4ED8` | **Surface**: `#FFFDF9`
- **Typography**: Heading `Plus Jakarta Sans` · Body `Plus Jakarta Sans` · Mono `Fira Code`
- **Shape & Density**: Radius `pill` · Density `comfortable`
- **Rationale**: High-energy coral accents, generous pill touch targets, and lively transitions make daily goal completion and community engagement rewarding. (Restyled: 'more playful') (Restyled: 'change the colour to blue and dark blue ... Chnage the font style')

## Domain Entities
- **Habit Rituals** (`habit_ritual`): `ritual_name` (string), `time_of_day` (enum), `current_streak` (integer), `completed_today` (boolean), `cue_prompt` (string)
- **Reflection Notes** (`reflection_note`): `entry_date` (date), `energy_level` (enum), `gratitude_takeaway` (text)

## Application Screens
- **Today's Ritual Checklist** (`/today-rituals`) — Layout: `checklist_today`
- **Consistency Heatmap & Streaks** (`/streak-heatmap`) — Layout: `heatmap_streaks`
- **Mindful Reflections** (`/mindful-journal`) — Layout: `feed`

## API Endpoints
- `GET /api/habit_ritual`
- `POST /api/habit_ritual`
- `PUT /api/habit_ritual/{item_id}`
- `DELETE /api/habit_ritual/{item_id}`
- `GET /api/reflection_note`
- `POST /api/reflection_note`
- `PUT /api/reflection_note/{item_id}`
- `DELETE /api/reflection_note/{item_id}`
- `POST /api/seed`
- `GET /api/health`

## SQLAlchemy Models
- `HabitRitualModel`
- `ReflectionNoteModel`

## Local Execution

### 1. Instant Standalone UI
Open `standalone_app.html` directly in any browser (zero external CDN dependencies).

### 2. Backend API (`FastAPI` + `SQLite`)
```bash
cd backend
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### 3. React + Vite Frontend
```bash
cd frontend
npm install
npm run dev
```
