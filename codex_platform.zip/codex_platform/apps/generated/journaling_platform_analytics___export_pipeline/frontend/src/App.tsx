import React, { useEffect, useState } from 'react';
import {
  AdaptiveAppShell,
  AdaptiveLayoutRenderer,
  Button,
  FormField,
  Input,
  Modal,
  Select,
  Toast,
  EntityRecord,
  EntitySpecData,
  PageSpecData,
} from './ui_kit';

const BLUEPRINT = {
  "app_name": "Journaling Platform Analytics & Export Pipeline",
  "product_tagline": "Unhurried daily habit check-ins, streak heatmaps, and mindful reflection",
  "domain": {
    "product_kind": "Personal Daily Habit & Ritual Consistency Tracker",
    "archetype": "habit_or_goal_tracker",
    "audience": {
      "who": "Mindful individuals building sustainable morning and evening routines",
      "context_of_use": "Calm morning check-in on laptop or phone with coffee",
      "device_likely_used": "hybrid",
      "tech_comfort": "medium"
    },
    "core_jobs": [
      "Check off today's rituals in one click from the daily checklist",
      "Review multi-week streak momentum and consistency heatmaps",
      "Reflect on ritual cues, target cadence, and personal notes"
    ],
    "primary_object": "habit_ritual",
    "tone": "calm",
    "data_shape": "time-series",
    "needs_automation": false,
    "rationale": "A personal habit tracker revolves around a frictionless daily ritual checklist and visual streak momentum rather than file uploads or enterprise tables."
  },
  "entities": [
    {
      "name": "habit_ritual",
      "singular_label": "Habit Ritual",
      "plural_label": "Habit Rituals",
      "fields": [
        {
          "name": "ritual_name",
          "label": "Ritual Title",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "time_of_day",
          "label": "Time of Day",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Morning",
            "Midday",
            "Evening",
            "Anytime"
          ],
          "default_value": null
        },
        {
          "name": "current_streak",
          "label": "Current Streak (Days)",
          "field_type": "integer",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": 1
        },
        {
          "name": "completed_today",
          "label": "Completed Today",
          "field_type": "boolean",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": false
        },
        {
          "name": "cue_prompt",
          "label": "Trigger Cue",
          "field_type": "string",
          "required": false,
          "unique": false,
          "enum_values": [],
          "default_value": null
        }
      ],
      "relationships": []
    },
    {
      "name": "reflection_note",
      "singular_label": "Reflection Note",
      "plural_label": "Reflection Notes",
      "fields": [
        {
          "name": "entry_date",
          "label": "Reflection Date",
          "field_type": "date",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "energy_level",
          "label": "Focus & Energy Level",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Rested",
            "Steady",
            "Stretched",
            "Recharging"
          ],
          "default_value": null
        },
        {
          "name": "gratitude_takeaway",
          "label": "Daily Takeaway",
          "field_type": "text",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        }
      ],
      "relationships": []
    }
  ],
  "pages": [
    {
      "id": "today-rituals",
      "title": "Today's Ritual Checklist",
      "route": "/today-rituals",
      "layout": "checklist_today",
      "entities_used": [
        "habit_ritual"
      ],
      "primary_actions": [
        "Complete Ritual",
        "Add New Ritual"
      ],
      "empty_state": {
        "headline": "Your Daily Ritual Canvas Is Quiet",
        "body": "Start small with one anchor habit for your morning or evening routine and check it off with a single tap each day.",
        "cta_label": "Create First Habit Ritual",
        "cta_action_id": "create_habit_ritual"
      }
    },
    {
      "id": "streak-heatmap",
      "title": "Consistency Heatmap & Streaks",
      "route": "/streak-heatmap",
      "layout": "heatmap_streaks",
      "entities_used": [
        "habit_ritual"
      ],
      "primary_actions": [
        "Log Ritual Check-In",
        "Adjust Cadence"
      ],
      "empty_state": {
        "headline": "No Streak Cells Logged Yet",
        "body": "Complete your first daily ritual to light up your consistency grid.",
        "cta_label": "Add Habit to Track",
        "cta_action_id": "create_habit_ritual"
      }
    },
    {
      "id": "mindful-journal",
      "title": "Mindful Reflections",
      "route": "/mindful-journal",
      "layout": "feed",
      "entities_used": [
        "reflection_note"
      ],
      "primary_actions": [
        "Write Evening Reflection"
      ],
      "empty_state": {
        "headline": "No Reflection Notes Written Yet",
        "body": "Capture a two-sentence note on what helped you stay consistent today.",
        "cta_label": "Write First Reflection",
        "cta_action_id": "create_reflection_note"
      }
    }
  ],
  "navigation": {
    "pattern": "sidebar",
    "items": [
      {
        "page_id": "today-rituals",
        "label": "Today's Rituals",
        "icon": "check-square"
      },
      {
        "page_id": "streak-heatmap",
        "label": "Streak Heatmap",
        "icon": "flame"
      },
      {
        "page_id": "mindful-journal",
        "label": "Reflections",
        "icon": "book-open"
      }
    ]
  },
  "home_page_id": "today-rituals",
  "automations": []
} as const;
const DESIGN_DIRECTION = {
  "direction_id": "playful_momentum",
  "palette": {
    "primary": "#1D4ED8",
    "primary_foreground": "#FFFFFF",
    "accent": "#B45309",
    "neutral_ramp": [
      "#FFFDF9",
      "#FDF6EC",
      "#F7E8D4",
      "#EBD2B2",
      "#C7AD8E",
      "#8C755C",
      "#5E4D3B",
      "#3B2E22",
      "#231815"
    ],
    "surface": "#FFFDF9",
    "surface_elevated": "#FFFFFF",
    "border": "#7A654F",
    "text": "#231815",
    "text_muted": "#524132",
    "focus_ring": "#1D4ED8",
    "success": "#157347",
    "warning": "#945200",
    "danger": "#B91C1C"
  },
  "color_mode": "light",
  "typography": {
    "heading_font": "Plus Jakarta Sans",
    "body_font": "Plus Jakarta Sans",
    "mono_font": "Fira Code",
    "scale_ratio": 1.3
  },
  "shape": {
    "radius_class": "pill",
    "border_style": "crisp",
    "shadow_style": "layered"
  },
  "density": "comfortable",
  "motion": "lively",
  "iconography": "solid",
  "brand_mark": {
    "kind": "geometric_glyph",
    "glyph_primitive": "spark_diamond",
    "monogram_letters": "SC"
  },
  "copy_voice": "Upbeat, energetic, action-first microcopy that rewards momentum.",
  "rationale": "High-energy coral accents, generous pill touch targets, and lively transitions make daily goal completion and community engagement rewarding. (Restyled: 'more playful') (Restyled: 'change the colour to blue and dark blue ... Chnage the font style')"
} as const;
const SAMPLE_SEED_DATA: Record<string, EntityRecord[]> = {
  "habit_ritual": [
    {
      "id": "hab-1",
      "ritual_name": "20 Minutes Morning Reading (No Screens)",
      "time_of_day": "Morning",
      "current_streak": 14,
      "completed_today": true,
      "cue_prompt": "Right after pouring morning coffee"
    },
    {
      "id": "hab-2",
      "ritual_name": "Outdoor Mobility & Sunlight Walk",
      "time_of_day": "Midday",
      "current_streak": 9,
      "completed_today": false,
      "cue_prompt": "Before opening afternoon messages"
    },
    {
      "id": "hab-3",
      "ritual_name": "Evening Digital Sunset & Gratitude Note",
      "time_of_day": "Evening",
      "current_streak": 21,
      "completed_today": true,
      "cue_prompt": "At 9:30 PM lamp dimming"
    }
  ],
  "reflection_note": [
    {
      "id": "ref-1",
      "entry_date": "2026-10-12",
      "energy_level": "Rested",
      "gratitude_takeaway": "Leaving the phone in the hallway made morning reading effortless."
    }
  ]
};
const BRAND_SVG_MARKUP = "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 3L14.8 9.2L21 12L14.8 14.8L12 21L9.2 14.8L3 12L9.2 9.2L12 3Z\" stroke=\"currentColor\" stroke-width=\"2\" fill=\"none\"/></svg>";
const NUMERIC_TYPES = new Set(['integer', 'float', 'currency']);

export default function App(): React.ReactElement {
  const [activePageId, setActivePageId] = useState<string>(BLUEPRINT.home_page_id);
  const [recordsByEntity, setRecordsByEntity] = useState<Record<string, EntityRecord[]>>(() => {
    const initial: Record<string, EntityRecord[]> = {};
    for (const ent of BLUEPRINT.entities) {
      initial[ent.name] = [];
    }
    return initial;
  });
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formState, setFormState] = useState<Record<string, string | number | boolean>>({});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const pages = BLUEPRINT.pages as unknown as PageSpecData[];
  const entities = BLUEPRINT.entities as unknown as EntitySpecData[];
  const activePage = pages.find((p) => p.id === activePageId) || pages[0];
  const primaryEntityName = activePage.entities_used[0] || entities[0].name;
  const activeEntity = entities.find((e) => e.name === primaryEntityName) || entities[0];
  const activeRecords = recordsByEntity[activeEntity.name] || [];

  useEffect(() => {
    for (const ent of entities) {
      fetch(`/api/${ent.name}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data: EntityRecord[] | null) => {
          if (Array.isArray(data) && data.length > 0) {
            setRecordsByEntity((prev) => ({ ...prev, [ent.name]: data }));
          }
        })
        .catch(() => {
          // Offline mode uses in-memory state
        });
    }
  }, []);

  const openCreateModal = (): void => {
    const defaults: Record<string, string | number | boolean> = {};
    for (const fld of activeEntity.fields) {
      if (fld.field_type === 'boolean') {
        defaults[fld.name] = Boolean(fld.default_value ?? false);
      } else if (NUMERIC_TYPES.has(fld.field_type)) {
        defaults[fld.name] = Number(fld.default_value ?? 0);
      } else if (fld.field_type === 'enum' && fld.enum_values && fld.enum_values.length > 0) {
        defaults[fld.name] = fld.enum_values[0];
      } else {
        defaults[fld.name] = String(fld.default_value ?? '');
      }
    }
    setFormState(defaults);
    setIsModalOpen(true);
  };

  const handleCreateRecord = (): void => {
    const newRecord: EntityRecord = {
      id: `${activeEntity.name}-${Date.now()}`,
      ...formState,
    };
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: [newRecord, ...(prev[activeEntity.name] || [])],
    }));
    fetch(`/api/${activeEntity.name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formState),
    }).catch(() => undefined);
    setIsModalOpen(false);
    setToastMsg(`Saved ${activeEntity.singular_label}`);
  };

  const handleLoadSampleSeedData = (): void => {
    setRecordsByEntity(SAMPLE_SEED_DATA);
    fetch('/api/seed', { method: 'POST' }).catch(() => undefined);
    setToastMsg('Loaded domain sample records');
  };

  const handleDeleteRecord = (recordId: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).filter((r) => String(r.id) !== recordId),
    }));
    fetch(`/api/${activeEntity.name}/${recordId}`, {
      method: 'DELETE',
    }).catch(() => undefined);
    setToastMsg(`Removed ${activeEntity.singular_label}`);
  };

  const handleToggleBoolean = (recordId: string, fieldName: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).map((r) =>
        String(r.id) === recordId ? { ...r, [fieldName]: !r[fieldName] } : r
      ),
    }));
  };

  return (
    <div className="min-h-screen bg-surface text-text font-body">
      <AdaptiveAppShell
        pattern={BLUEPRINT.navigation.pattern}
        appName={BLUEPRINT.app_name}
        tagline={BLUEPRINT.product_tagline}
        brandMark={
          <span
            className="inline-flex items-center"
            dangerouslySetInnerHTML={{ __html: BRAND_SVG_MARKUP }}
          />
        }
        navItems={BLUEPRINT.navigation.items.map((item) => ({
          page_id: item.page_id,
          label: item.label,
          icon: item.icon,
        }))}
        activePageId={activePage.id}
        onSelectPage={setActivePageId}
        primaryAction={
          <div className="flex items-center gap-2">
            {activeRecords.length === 0 && (
              <Button variant="secondary" onClick={handleLoadSampleSeedData}>
                Load Sample Data
              </Button>
            )}
            <Button variant="primary" onClick={openCreateModal}>
              + {activePage.primary_actions[0] || `New ${activeEntity.singular_label}`}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {toastMsg && (
            <div className="flex justify-between items-center">
              <Toast message={toastMsg} tone="success" />
              <Button variant="ghost" onClick={() => setToastMsg(null)}>Dismiss</Button>
            </div>
          )}
          <AdaptiveLayoutRenderer
            page={activePage}
            entity={activeEntity}
            records={activeRecords}
            onOpenCreate={openCreateModal}
            onDeleteRecord={handleDeleteRecord}
            onToggleBoolean={handleToggleBoolean}
          />
        </div>
      </AdaptiveAppShell>

      <Modal
        open={isModalOpen}
        title={`Add ${activeEntity.singular_label}`}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-3">
          {activeEntity.fields.map((fld) => (
            <FormField key={fld.name} label={fld.label} required={fld.required}>
              {fld.field_type === 'enum' && fld.enum_values ? (
                <Select
                  value={String(formState[fld.name] ?? fld.enum_values[0] ?? '')}
                  options={fld.enum_values.map((v) => ({ value: v, label: v }))}
                  onChange={(val) => setFormState((prev) => ({ ...prev, [fld.name]: val }))}
                />
              ) : (
                <Input
                  type={
                    NUMERIC_TYPES.has(fld.field_type)
                      ? 'number'
                      : fld.field_type === 'date'
                        ? 'date'
                        : 'text'
                  }
                  value={String(formState[fld.name] ?? '')}
                  placeholder={`Enter ${fld.label}`}
                  onChange={(val) =>
                    setFormState((prev) => ({
                      ...prev,
                      [fld.name]: NUMERIC_TYPES.has(fld.field_type) ? Number(val) : val,
                    }))
                  }
                />
              )}
            </FormField>
          ))}
          <div className="flex justify-end gap-2 pt-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCreateRecord}>
              Save {activeEntity.singular_label}
            </Button>
          </div>
        </div>
      </Modal>
      
    </div>
  );
}
