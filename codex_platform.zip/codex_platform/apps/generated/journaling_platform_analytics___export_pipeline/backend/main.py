"""FastAPI backend for Journaling Platform Analytics & Export Pipeline — Unhurried daily habit check-ins, streak heatmaps, and mindful reflection."""

import json
from typing import Any, Optional
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import HabitRitualModel, ReflectionNoteModel
from seed import seed_database

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='Journaling Platform Analytics & Export Pipeline',
    description='Unhurried daily habit check-ins, streak heatmaps, and mindful reflection',
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class HabitRitualCreate(BaseModel):
    ritual_name: str = ''
    time_of_day: str = 'Morning'
    current_streak: int = 1
    completed_today: bool = False
    cue_prompt: str = ''

class HabitRitualUpdate(BaseModel):
    ritual_name: Optional[str] = None
    time_of_day: Optional[str] = None
    current_streak: Optional[int] = None
    completed_today: Optional[bool] = None
    cue_prompt: Optional[str] = None

def _serialize_habit_ritual(item: HabitRitualModel) -> dict[str, Any]:
    return {"id": item.id, "ritual_name": getattr(item, "ritual_name"), "time_of_day": getattr(item, "time_of_day"), "current_streak": getattr(item, "current_streak"), "completed_today": getattr(item, "completed_today"), "cue_prompt": getattr(item, "cue_prompt")}

@app.get("/api/habit_ritual")
def list_habit_ritual(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(HabitRitualModel).order_by(HabitRitualModel.created_at.desc()).all()
    return [_serialize_habit_ritual(r) for r in rows]

@app.post("/api/habit_ritual", status_code=201)
def create_habit_ritual(
    payload: HabitRitualCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = HabitRitualModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_habit_ritual(record)

@app.put("/api/habit_ritual/{item_id}")
def update_habit_ritual(
    item_id: str, payload: HabitRitualUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(HabitRitualModel).filter(HabitRitualModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Habit Ritual not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_habit_ritual(record)

@app.delete("/api/habit_ritual/{item_id}")
def delete_habit_ritual(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(HabitRitualModel).filter(HabitRitualModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Habit Ritual not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class ReflectionNoteCreate(BaseModel):
    entry_date: str = ''
    energy_level: str = 'Rested'
    gratitude_takeaway: str = ''

class ReflectionNoteUpdate(BaseModel):
    entry_date: Optional[str] = None
    energy_level: Optional[str] = None
    gratitude_takeaway: Optional[str] = None

def _serialize_reflection_note(item: ReflectionNoteModel) -> dict[str, Any]:
    return {"id": item.id, "entry_date": getattr(item, "entry_date"), "energy_level": getattr(item, "energy_level"), "gratitude_takeaway": getattr(item, "gratitude_takeaway")}

@app.get("/api/reflection_note")
def list_reflection_note(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(ReflectionNoteModel).order_by(ReflectionNoteModel.created_at.desc()).all()
    return [_serialize_reflection_note(r) for r in rows]

@app.post("/api/reflection_note", status_code=201)
def create_reflection_note(
    payload: ReflectionNoteCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = ReflectionNoteModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_reflection_note(record)

@app.put("/api/reflection_note/{item_id}")
def update_reflection_note(
    item_id: str, payload: ReflectionNoteUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(ReflectionNoteModel).filter(ReflectionNoteModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Reflection Note not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_reflection_note(record)

@app.delete("/api/reflection_note/{item_id}")
def delete_reflection_note(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(ReflectionNoteModel).filter(ReflectionNoteModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Reflection Note not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

@app.post("/api/seed")
def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:
    inserted = seed_database(db)
    return {"status": "seeded", "inserted": inserted}

@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {
        "status": "healthy",
        "app": 'Journaling Platform Analytics & Export Pipeline',
        "archetype": 'habit_or_goal_tracker',
    }
