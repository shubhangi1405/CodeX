# VitalsPath Clinic

> Outpatient visit timeline, exam-room triage, and guided patient intake

## Product & Domain Summary
- **Product Kind**: Outpatient Medical Clinic Patient Intake & Appointment Flow
- **Archetype**: `health_log`
- **Primary Object**: `patient_visit`
- **Target Audience**: Clinic care coordinators, triage nurses, and attending physicians (Bright clinical nursing station and exam-room tablet check-in)
- **Navigation Pattern**: `sidebar`
- **Home Page**: `patient-flow-timeline` (`timeline`)

## Design Direction (`clinical_clean`)
- **Color Mode**: `light` | **Primary**: `#86198F` | **Surface**: `#F9FBFC`
- **Typography**: Heading `Public Sans` · Body `Public Sans` · Mono `IBM Plex Mono`
- **Shape & Density**: Radius `soft` · Density `comfortable`
- **Rationale**: High-legibility Public Sans typography, cool hygienic surfaces, and calm plum-orchid clinical badges give triage nurses instant clarity across exam rooms.

## Domain Entities
- **Patient Visits** (`patient_visit`): `patient_full_name` (string), `appointment_slot` (string), `attending_clinician` (enum), `visit_stage` (enum), `chief_complaint` (string)
- **Exam Rooms** (`exam_room`): `room_code` (string), `wing_floor` (enum), `sanitation_state` (enum)

## Application Screens
- **Live Patient Flow Timeline** (`/patient-flow-timeline`) — Layout: `timeline`
- **Patient Intake Registration** (`/intake-wizard`) — Layout: `form_wizard`
- **Exam Room Readiness** (`/exam-room-status`) — Layout: `card_grid`

## API Endpoints
- `GET /api/patient_visit`
- `POST /api/patient_visit`
- `PUT /api/patient_visit/{item_id}`
- `DELETE /api/patient_visit/{item_id}`
- `GET /api/exam_room`
- `POST /api/exam_room`
- `PUT /api/exam_room/{item_id}`
- `DELETE /api/exam_room/{item_id}`
- `POST /api/seed`
- `GET /api/health`

## SQLAlchemy Models
- `PatientVisitModel`
- `ExamRoomModel`

## Local Execution

### 1. Instant Standalone UI
Open `standalone_app.html` directly in any browser (zero external CDN dependencies).

### 2. Backend API (`FastAPI` + `SQLite`)
```bash
cd backend
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### 3. React + Vite Frontend
```bash
cd frontend
npm install
npm run dev
```
