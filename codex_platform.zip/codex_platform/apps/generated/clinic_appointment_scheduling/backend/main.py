"""FastAPI backend for VitalsPath Clinic — Outpatient visit timeline, exam-room triage, and guided patient intake."""

import json
from typing import Any, Optional
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import PatientVisitModel, ExamRoomModel
from seed import seed_database

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='VitalsPath Clinic',
    description='Outpatient visit timeline, exam-room triage, and guided patient intake',
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class PatientVisitCreate(BaseModel):
    patient_full_name: str = ''
    appointment_slot: str = ''
    attending_clinician: str = 'Dr. Amara Okafor (Internal Med)'
    visit_stage: str = 'Checked In - Waiting'
    chief_complaint: str = ''

class PatientVisitUpdate(BaseModel):
    patient_full_name: Optional[str] = None
    appointment_slot: Optional[str] = None
    attending_clinician: Optional[str] = None
    visit_stage: Optional[str] = None
    chief_complaint: Optional[str] = None

def _serialize_patient_visit(item: PatientVisitModel) -> dict[str, Any]:
    return {"id": item.id, "patient_full_name": getattr(item, "patient_full_name"), "appointment_slot": getattr(item, "appointment_slot"), "attending_clinician": getattr(item, "attending_clinician"), "visit_stage": getattr(item, "visit_stage"), "chief_complaint": getattr(item, "chief_complaint")}

@app.get("/api/patient_visit")
def list_patient_visit(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(PatientVisitModel).order_by(PatientVisitModel.created_at.desc()).all()
    return [_serialize_patient_visit(r) for r in rows]

@app.post("/api/patient_visit", status_code=201)
def create_patient_visit(
    payload: PatientVisitCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = PatientVisitModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_patient_visit(record)

@app.put("/api/patient_visit/{item_id}")
def update_patient_visit(
    item_id: str, payload: PatientVisitUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(PatientVisitModel).filter(PatientVisitModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Patient Visit not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_patient_visit(record)

@app.delete("/api/patient_visit/{item_id}")
def delete_patient_visit(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(PatientVisitModel).filter(PatientVisitModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Patient Visit not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class ExamRoomCreate(BaseModel):
    room_code: str = ''
    wing_floor: str = 'North Primary Wing'
    sanitation_state: str = 'Ready for Patient'

class ExamRoomUpdate(BaseModel):
    room_code: Optional[str] = None
    wing_floor: Optional[str] = None
    sanitation_state: Optional[str] = None

def _serialize_exam_room(item: ExamRoomModel) -> dict[str, Any]:
    return {"id": item.id, "room_code": getattr(item, "room_code"), "wing_floor": getattr(item, "wing_floor"), "sanitation_state": getattr(item, "sanitation_state")}

@app.get("/api/exam_room")
def list_exam_room(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(ExamRoomModel).order_by(ExamRoomModel.created_at.desc()).all()
    return [_serialize_exam_room(r) for r in rows]

@app.post("/api/exam_room", status_code=201)
def create_exam_room(
    payload: ExamRoomCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = ExamRoomModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_exam_room(record)

@app.put("/api/exam_room/{item_id}")
def update_exam_room(
    item_id: str, payload: ExamRoomUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(ExamRoomModel).filter(ExamRoomModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Exam Room not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_exam_room(record)

@app.delete("/api/exam_room/{item_id}")
def delete_exam_room(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(ExamRoomModel).filter(ExamRoomModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Exam Room not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

@app.post("/api/seed")
def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:
    inserted = seed_database(db)
    return {"status": "seeded", "inserted": inserted}

@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {
        "status": "healthy",
        "app": 'VitalsPath Clinic',
        "archetype": 'health_log',
    }
