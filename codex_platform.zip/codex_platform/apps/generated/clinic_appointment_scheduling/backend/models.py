"""Domain SQLAlchemy ORM models for VitalsPath Clinic."""

from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from database import Base

class PatientVisitModel(Base):
    __tablename__ = "patient_visits"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    patient_full_name = Column(String, nullable=False, default='')
    appointment_slot = Column(String, nullable=False, default='')
    attending_clinician = Column(String, nullable=False, default='Dr. Amara Okafor (Internal Med)')
    visit_stage = Column(String, nullable=False, default='Checked In - Waiting')
    chief_complaint = Column(String, nullable=False, default='')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class ExamRoomModel(Base):
    __tablename__ = "exam_rooms"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    room_code = Column(String, nullable=False, default='')
    wing_floor = Column(String, nullable=False, default='North Primary Wing')
    sanitation_state = Column(String, nullable=False, default='Ready for Patient')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
