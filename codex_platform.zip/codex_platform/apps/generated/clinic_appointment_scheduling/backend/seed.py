"""Optional sample seed data loader for VitalsPath Clinic."""

import json
from sqlalchemy.orm import Session
from database import Base, SessionLocal, engine
from models import PatientVisitModel, ExamRoomModel

SAMPLE_SEED_DATA = json.loads(r'''{
  "patient_visit": [
    {
      "id": "vis-101",
      "patient_full_name": "Arthur Pendelton",
      "appointment_slot": "09:15 AM",
      "attending_clinician": "Dr. Henrik Lindqvist (Cardiology)",
      "visit_stage": "With Physician",
      "chief_complaint": "Quarterly hypertension follow-up & ECG review"
    },
    {
      "id": "vis-102",
      "patient_full_name": "Nadia Al-Mansoor",
      "appointment_slot": "09:30 AM",
      "attending_clinician": "Dr. Amara Okafor (Internal Med)",
      "visit_stage": "Vitals & Triage (Room B)",
      "chief_complaint": "Persistent seasonal cough and spirometry check"
    },
    {
      "id": "vis-103",
      "patient_full_name": "Lucas Meyer",
      "appointment_slot": "09:45 AM",
      "attending_clinician": "NP Sofia Reyes (Primary Care)",
      "visit_stage": "Checked In - Waiting",
      "chief_complaint": "Annual preventive wellness lab review"
    }
  ],
  "exam_room": [
    {
      "id": "rm-1",
      "room_code": "Exam Suite N-204",
      "wing_floor": "Cardio Diagnostics",
      "sanitation_state": "Occupied"
    },
    {
      "id": "rm-2",
      "room_code": "Exam Suite N-108",
      "wing_floor": "North Primary Wing",
      "sanitation_state": "Ready for Patient"
    }
  ]
}''')


def seed_database(db: Session) -> dict[str, int]:
    """Inserts domain sample records if tables are currently empty."""
    inserted: dict[str, int] = {}
    records_patient_visit = SAMPLE_SEED_DATA.get("patient_visit", [])
    existing_patient_visit = db.query(PatientVisitModel).count()
    count_patient_visit = 0
    if existing_patient_visit == 0:
        for row in records_patient_visit:
            allowed = ['patient_full_name', 'appointment_slot', 'attending_clinician', 'visit_stage', 'chief_complaint']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(PatientVisitModel(**payload))
            count_patient_visit += 1
    inserted["patient_visit"] = count_patient_visit
    records_exam_room = SAMPLE_SEED_DATA.get("exam_room", [])
    existing_exam_room = db.query(ExamRoomModel).count()
    count_exam_room = 0
    if existing_exam_room == 0:
        for row in records_exam_room:
            allowed = ['room_code', 'wing_floor', 'sanitation_state']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            db.add(ExamRoomModel(**payload))
            count_exam_room += 1
    inserted["exam_room"] = count_exam_room
    db.commit()
    return inserted


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as session:
        result = seed_database(session)
        print("Seeded sample records:", result)
