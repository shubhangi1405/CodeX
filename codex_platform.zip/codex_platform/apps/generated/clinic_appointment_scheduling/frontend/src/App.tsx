import React, { useEffect, useState } from 'react';
import {
  AdaptiveAppShell,
  AdaptiveLayoutRenderer,
  Button,
  FormField,
  Input,
  Modal,
  Select,
  Toast,
  EntityRecord,
  EntitySpecData,
  PageSpecData,
} from './ui_kit';

const BLUEPRINT = {
  "app_name": "VitalsPath Clinic",
  "product_tagline": "Outpatient visit timeline, exam-room triage, and guided patient intake",
  "domain": {
    "product_kind": "Outpatient Medical Clinic Patient Intake & Appointment Flow",
    "archetype": "health_log",
    "audience": {
      "who": "Clinic care coordinators, triage nurses, and attending physicians",
      "context_of_use": "Bright clinical nursing station and exam-room tablet check-in",
      "device_likely_used": "desktop",
      "tech_comfort": "medium"
    },
    "core_jobs": [
      "Track patient arrival, vitals triage, and exam room flow on a live timeline",
      "Register new patient visit intake with chief complaint and clinician assignment",
      "Coordinate weekly physician consultation slots across exam rooms"
    ],
    "primary_object": "patient_visit",
    "tone": "clinical",
    "data_shape": "calendar",
    "needs_automation": false,
    "rationale": "Care coordinators managing exam rooms need a calm, high-legibility patient flow timeline and guided intake wizard with zero visual clutter."
  },
  "entities": [
    {
      "name": "patient_visit",
      "singular_label": "Patient Visit",
      "plural_label": "Patient Visits",
      "fields": [
        {
          "name": "patient_full_name",
          "label": "Patient Name",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "appointment_slot",
          "label": "Scheduled Time",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "attending_clinician",
          "label": "Attending Clinician",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Dr. Amara Okafor (Internal Med)",
            "Dr. Henrik Lindqvist (Cardiology)",
            "NP Sofia Reyes (Primary Care)"
          ],
          "default_value": null
        },
        {
          "name": "visit_stage",
          "label": "Exam Room Stage",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Checked In - Waiting",
            "Vitals & Triage (Room B)",
            "With Physician",
            "Discharge Complete"
          ],
          "default_value": null
        },
        {
          "name": "chief_complaint",
          "label": "Chief Clinical Reason",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        }
      ],
      "relationships": []
    },
    {
      "name": "exam_room",
      "singular_label": "Exam Room",
      "plural_label": "Exam Rooms",
      "fields": [
        {
          "name": "room_code",
          "label": "Room Identifier",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "wing_floor",
          "label": "Clinic Wing",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "North Primary Wing",
            "Cardio Diagnostics",
            "Pediatric Suite"
          ],
          "default_value": null
        },
        {
          "name": "sanitation_state",
          "label": "Room Readiness",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Ready for Patient",
            "Occupied",
            "Sanitizing"
          ],
          "default_value": null
        }
      ],
      "relationships": []
    }
  ],
  "pages": [
    {
      "id": "patient-flow-timeline",
      "title": "Live Patient Flow Timeline",
      "route": "/patient-flow-timeline",
      "layout": "timeline",
      "entities_used": [
        "patient_visit"
      ],
      "primary_actions": [
        "Check In Patient",
        "Advance Room Stage"
      ],
      "empty_state": {
        "headline": "No Patients Checked In for Current Clinic Session",
        "body": "Register the first arriving patient to start tracking vitals triage and exam room assignment.",
        "cta_label": "Register Patient Visit",
        "cta_action_id": "create_patient_visit"
      }
    },
    {
      "id": "intake-wizard",
      "title": "Patient Intake Registration",
      "route": "/intake-wizard",
      "layout": "form_wizard",
      "entities_used": [
        "patient_visit"
      ],
      "primary_actions": [
        "Complete Intake Step"
      ],
      "empty_state": {
        "headline": "Guided Patient Check-In Ready",
        "body": "Walk through demographics, attending clinician, and chief complaint.",
        "cta_label": "Start Patient Intake",
        "cta_action_id": "create_patient_visit"
      }
    },
    {
      "id": "exam-room-status",
      "title": "Exam Room Readiness",
      "route": "/exam-room-status",
      "layout": "card_grid",
      "entities_used": [
        "exam_room"
      ],
      "primary_actions": [
        "Update Room Readiness"
      ],
      "empty_state": {
        "headline": "No Exam Rooms Configured",
        "body": "Add your clinic's exam rooms to coordinate sanitation and rooming.",
        "cta_label": "Add Exam Room",
        "cta_action_id": "create_exam_room"
      }
    }
  ],
  "navigation": {
    "pattern": "sidebar",
    "items": [
      {
        "page_id": "patient-flow-timeline",
        "label": "Patient Timeline",
        "icon": "stethoscope"
      },
      {
        "page_id": "intake-wizard",
        "label": "Intake Wizard",
        "icon": "check-circle"
      },
      {
        "page_id": "exam-room-status",
        "label": "Exam Rooms",
        "icon": "heart"
      }
    ]
  },
  "home_page_id": "patient-flow-timeline",
  "automations": []
} as const;
const DESIGN_DIRECTION = {
  "direction_id": "clinical_clean",
  "palette": {
    "primary": "#86198F",
    "primary_foreground": "#FFFFFF",
    "accent": "#0B7266",
    "neutral_ramp": [
      "#F9FBFC",
      "#F0F5F9",
      "#E1EBF2",
      "#C5D7E5",
      "#94B2C9",
      "#62829C",
      "#405B73",
      "#243B53",
      "#102A43"
    ],
    "surface": "#F9FBFC",
    "surface_elevated": "#FFFFFF",
    "border": "#5A768E",
    "text": "#102A43",
    "text_muted": "#334E68",
    "focus_ring": "#86198F",
    "success": "#146C43",
    "warning": "#8A5000",
    "danger": "#A61B1B"
  },
  "color_mode": "light",
  "typography": {
    "heading_font": "Public Sans",
    "body_font": "Public Sans",
    "mono_font": "IBM Plex Mono",
    "scale_ratio": 1.22
  },
  "shape": {
    "radius_class": "soft",
    "border_style": "hairline",
    "shadow_style": "flat"
  },
  "density": "comfortable",
  "motion": "subtle",
  "iconography": "outline",
  "brand_mark": {
    "kind": "geometric_glyph",
    "glyph_primitive": "pulse_wave",
    "monogram_letters": "VP"
  },
  "copy_voice": "Calm, reassuring, unambiguous clinical and scheduling terminology.",
  "rationale": "High-legibility Public Sans typography, cool hygienic surfaces, and calm plum-orchid clinical badges give triage nurses instant clarity across exam rooms."
} as const;
const SAMPLE_SEED_DATA: Record<string, EntityRecord[]> = {
  "patient_visit": [
    {
      "id": "vis-101",
      "patient_full_name": "Arthur Pendelton",
      "appointment_slot": "09:15 AM",
      "attending_clinician": "Dr. Henrik Lindqvist (Cardiology)",
      "visit_stage": "With Physician",
      "chief_complaint": "Quarterly hypertension follow-up & ECG review"
    },
    {
      "id": "vis-102",
      "patient_full_name": "Nadia Al-Mansoor",
      "appointment_slot": "09:30 AM",
      "attending_clinician": "Dr. Amara Okafor (Internal Med)",
      "visit_stage": "Vitals & Triage (Room B)",
      "chief_complaint": "Persistent seasonal cough and spirometry check"
    },
    {
      "id": "vis-103",
      "patient_full_name": "Lucas Meyer",
      "appointment_slot": "09:45 AM",
      "attending_clinician": "NP Sofia Reyes (Primary Care)",
      "visit_stage": "Checked In - Waiting",
      "chief_complaint": "Annual preventive wellness lab review"
    }
  ],
  "exam_room": [
    {
      "id": "rm-1",
      "room_code": "Exam Suite N-204",
      "wing_floor": "Cardio Diagnostics",
      "sanitation_state": "Occupied"
    },
    {
      "id": "rm-2",
      "room_code": "Exam Suite N-108",
      "wing_floor": "North Primary Wing",
      "sanitation_state": "Ready for Patient"
    }
  ]
};
const BRAND_SVG_MARKUP = "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M3 12H7L9.5 6L14.5 18L17 12H21\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" fill=\"none\"/></svg>";
const NUMERIC_TYPES = new Set(['integer', 'float', 'currency']);

export default function App(): React.ReactElement {
  const [activePageId, setActivePageId] = useState<string>(BLUEPRINT.home_page_id);
  const [recordsByEntity, setRecordsByEntity] = useState<Record<string, EntityRecord[]>>(() => {
    const initial: Record<string, EntityRecord[]> = {};
    for (const ent of BLUEPRINT.entities) {
      initial[ent.name] = [];
    }
    return initial;
  });
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formState, setFormState] = useState<Record<string, string | number | boolean>>({});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const pages = BLUEPRINT.pages as unknown as PageSpecData[];
  const entities = BLUEPRINT.entities as unknown as EntitySpecData[];
  const activePage = pages.find((p) => p.id === activePageId) || pages[0];
  const primaryEntityName = activePage.entities_used[0] || entities[0].name;
  const activeEntity = entities.find((e) => e.name === primaryEntityName) || entities[0];
  const activeRecords = recordsByEntity[activeEntity.name] || [];

  useEffect(() => {
    for (const ent of entities) {
      fetch(`/api/${ent.name}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data: EntityRecord[] | null) => {
          if (Array.isArray(data) && data.length > 0) {
            setRecordsByEntity((prev) => ({ ...prev, [ent.name]: data }));
          }
        })
        .catch(() => {
          // Offline mode uses in-memory state
        });
    }
  }, []);

  const openCreateModal = (): void => {
    const defaults: Record<string, string | number | boolean> = {};
    for (const fld of activeEntity.fields) {
      if (fld.field_type === 'boolean') {
        defaults[fld.name] = Boolean(fld.default_value ?? false);
      } else if (NUMERIC_TYPES.has(fld.field_type)) {
        defaults[fld.name] = Number(fld.default_value ?? 0);
      } else if (fld.field_type === 'enum' && fld.enum_values && fld.enum_values.length > 0) {
        defaults[fld.name] = fld.enum_values[0];
      } else {
        defaults[fld.name] = String(fld.default_value ?? '');
      }
    }
    setFormState(defaults);
    setIsModalOpen(true);
  };

  const handleCreateRecord = (): void => {
    const newRecord: EntityRecord = {
      id: `${activeEntity.name}-${Date.now()}`,
      ...formState,
    };
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: [newRecord, ...(prev[activeEntity.name] || [])],
    }));
    fetch(`/api/${activeEntity.name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formState),
    }).catch(() => undefined);
    setIsModalOpen(false);
    setToastMsg(`Saved ${activeEntity.singular_label}`);
  };

  const handleLoadSampleSeedData = (): void => {
    setRecordsByEntity(SAMPLE_SEED_DATA);
    fetch('/api/seed', { method: 'POST' }).catch(() => undefined);
    setToastMsg('Loaded domain sample records');
  };

  const handleDeleteRecord = (recordId: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).filter((r) => String(r.id) !== recordId),
    }));
    fetch(`/api/${activeEntity.name}/${recordId}`, {
      method: 'DELETE',
    }).catch(() => undefined);
    setToastMsg(`Removed ${activeEntity.singular_label}`);
  };

  const handleToggleBoolean = (recordId: string, fieldName: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).map((r) =>
        String(r.id) === recordId ? { ...r, [fieldName]: !r[fieldName] } : r
      ),
    }));
  };

  return (
    <div className="min-h-screen bg-surface text-text font-body">
      <AdaptiveAppShell
        pattern={BLUEPRINT.navigation.pattern}
        appName={BLUEPRINT.app_name}
        tagline={BLUEPRINT.product_tagline}
        brandMark={
          <span
            className="inline-flex items-center"
            dangerouslySetInnerHTML={{ __html: BRAND_SVG_MARKUP }}
          />
        }
        navItems={BLUEPRINT.navigation.items.map((item) => ({
          page_id: item.page_id,
          label: item.label,
          icon: item.icon,
        }))}
        activePageId={activePage.id}
        onSelectPage={setActivePageId}
        primaryAction={
          <div className="flex items-center gap-2">
            {activeRecords.length === 0 && (
              <Button variant="secondary" onClick={handleLoadSampleSeedData}>
                Load Sample Data
              </Button>
            )}
            <Button variant="primary" onClick={openCreateModal}>
              + {activePage.primary_actions[0] || `New ${activeEntity.singular_label}`}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {toastMsg && (
            <div className="flex justify-between items-center">
              <Toast message={toastMsg} tone="success" />
              <Button variant="ghost" onClick={() => setToastMsg(null)}>Dismiss</Button>
            </div>
          )}
          <AdaptiveLayoutRenderer
            page={activePage}
            entity={activeEntity}
            records={activeRecords}
            onOpenCreate={openCreateModal}
            onDeleteRecord={handleDeleteRecord}
            onToggleBoolean={handleToggleBoolean}
          />
        </div>
      </AdaptiveAppShell>

      <Modal
        open={isModalOpen}
        title={`Add ${activeEntity.singular_label}`}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-3">
          {activeEntity.fields.map((fld) => (
            <FormField key={fld.name} label={fld.label} required={fld.required}>
              {fld.field_type === 'enum' && fld.enum_values ? (
                <Select
                  value={String(formState[fld.name] ?? fld.enum_values[0] ?? '')}
                  options={fld.enum_values.map((v) => ({ value: v, label: v }))}
                  onChange={(val) => setFormState((prev) => ({ ...prev, [fld.name]: val }))}
                />
              ) : (
                <Input
                  type={
                    NUMERIC_TYPES.has(fld.field_type)
                      ? 'number'
                      : fld.field_type === 'date'
                        ? 'date'
                        : 'text'
                  }
                  value={String(formState[fld.name] ?? '')}
                  placeholder={`Enter ${fld.label}`}
                  onChange={(val) =>
                    setFormState((prev) => ({
                      ...prev,
                      [fld.name]: NUMERIC_TYPES.has(fld.field_type) ? Number(val) : val,
                    }))
                  }
                />
              )}
            </FormField>
          ))}
          <div className="flex justify-end gap-2 pt-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCreateRecord}>
              Save {activeEntity.singular_label}
            </Button>
          </div>
        </div>
      </Modal>
      
    </div>
  );
}
