"""Domain SQLAlchemy ORM models for Personal Expense Tracker Pipeline."""

from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from database import Base

class ExpenseTransactionModel(Base):
    __tablename__ = "expense_transactions"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    owner_id = Column(String, nullable=True)
    title = Column(String, nullable=False, default='')
    amount = Column(Float, nullable=False, default=0.0)
    transaction_date = Column(String, nullable=False, default='')
    category = Column(String, nullable=False, default='Groceries')
    transaction_type = Column(String, nullable=False, default='Expense')
    payment_method = Column(String, nullable=False, default='Credit Card')
    notes = Column(String, nullable=True, default='')
    budget_category_id = Column(String, nullable=True, default='')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class BudgetCategoryModel(Base):
    __tablename__ = "budget_categorys"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    owner_id = Column(String, nullable=True)
    category_name = Column(String, nullable=False, default='')
    monthly_limit = Column(Float, nullable=False, default=0.0)
    current_spend = Column(Float, nullable=False, default=0.0)
    period_month = Column(String, nullable=False, default='2026-10')
    alert_threshold = Column(Integer, nullable=False, default=85)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class UserModel(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    display_name = Column(String, nullable=False, default='')
    role = Column(String, nullable=False, default='member')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class SessionTokenModel(Base):
    __tablename__ = "session_tokens"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    token = Column(String, unique=True, nullable=False)
    user_id = Column(String, nullable=False)
    revoked = Column(Boolean, default=False, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
