"""FastAPI backend for Personal Expense Tracker Pipeline — Personal expense tracking, monthly category budgets, and cashflow analytics."""

import json
import time
from datetime import datetime, timezone
from typing import Any, Optional
from fastapi import Depends, FastAPI, HTTPException, Header, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import ExpenseTransactionModel, BudgetCategoryModel, UserModel, SessionTokenModel
from seed import seed_database
from auth import (
    create_session,
    get_current_user,
    get_current_user_optional,
    hash_password,
    revoke_session,
    verify_password,
)

THREAT_MODEL_JSON = json.loads(r'''{
  "assets": [
    "SpendCraft Finance SQLite Database",
    "Expense Transaction Records",
    "Session Tokens"
  ],
  "trust_boundaries": [
    "Public Internet <-> Reverse Proxy / Vite Frontend",
    "Frontend Client <-> FastAPI Endpoints",
    "Application Layer <-> SQLite Persistence Engine"
  ],
  "threats": [
    {
      "id": "t-auth-bypass",
      "category": "spoofing",
      "asset": "User Authentication & Session Tokens",
      "threat_description": "Adversary attempts brute force or credential stuffing on login endpoint.",
      "attacker_profile": "External malicious actor or automated botnet",
      "attack_path": "Repeated POST requests to authentication endpoint with dictionary passwords.",
      "mitigation": "PBKDF2-HMAC-SHA256 password hashing with salt and in-memory rate limiting.",
      "residual_risk": "low"
    },
    {
      "id": "t-idor-tampering",
      "category": "elevation_of_privilege",
      "asset": "Expense Transaction Data Records",
      "threat_description": "User A attempts to modify or delete User B private records by guessing record IDs.",
      "attacker_profile": "Authenticated standard user",
      "attack_path": "Submitting PUT/DELETE requests referencing other tenants record identifiers.",
      "mitigation": "Server-side owner_id verification and RBAC role validation before mutation.",
      "residual_risk": "low"
    },
    {
      "id": "t-data-leakage",
      "category": "information_disclosure",
      "asset": "Account and Exported Data",
      "threat_description": "Unauthorized retrieval of sensitive workspace information.",
      "attacker_profile": "Unauthenticated external network eavesdropper",
      "attack_path": "Interception of API payloads or token theft via XSS.",
      "mitigation": "Strict CORS headers, X-Content-Type-Options, and secure session management.",
      "residual_risk": "low"
    }
  ]
}''')
_CLIENT_REQUEST_TIMESTAMPS: dict[str, list[float]] = {}

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='Personal Expense Tracker Pipeline',
    description='Personal expense tracking, monthly category budgets, and cashflow analytics',
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware('http')
async def security_and_rate_limit_middleware(request, call_next):
    client_ip = request.client.host if request.client else '127.0.0.1'
    path = request.url.path
    if path.startswith('/api/auth/') and request.method == 'POST':
        now = time.time()
        bucket = _CLIENT_REQUEST_TIMESTAMPS.setdefault(client_ip, [])
        bucket[:] = [t for t in bucket if now - t < 60.0]
        if len(bucket) >= 40:
            return Response(
                content=json.dumps({"detail": "Rate limit exceeded. Please wait before retrying."}),
                status_code=429,
                media_type="application/json",
            )
        bucket.append(now)

    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return response

class ExpenseTransactionCreate(BaseModel):
    title: str = ''
    amount: float = 0.0
    transaction_date: str = ''
    category: str = 'Groceries'
    transaction_type: str = 'Expense'
    payment_method: str = 'Credit Card'
    notes: str = ''
    budget_category_id: str = ''

class ExpenseTransactionUpdate(BaseModel):
    title: Optional[str] = None
    amount: Optional[float] = None
    transaction_date: Optional[str] = None
    category: Optional[str] = None
    transaction_type: Optional[str] = None
    payment_method: Optional[str] = None
    notes: Optional[str] = None
    budget_category_id: Optional[str] = None

def _serialize_expense_transaction(item: ExpenseTransactionModel) -> dict[str, Any]:
    d = {"id": item.id, "title": getattr(item, "title"), "amount": getattr(item, "amount"), "transaction_date": getattr(item, "transaction_date"), "category": getattr(item, "category"), "transaction_type": getattr(item, "transaction_type"), "payment_method": getattr(item, "payment_method"), "notes": getattr(item, "notes"), "budget_category_id": getattr(item, "budget_category_id")}
    if hasattr(item, "owner_id") and item.owner_id: d["owner_id"] = item.owner_id

    return d

@app.get("/api/expense_transaction")
def list_expense_transaction(
    mine_only: bool = False,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> list[dict[str, Any]]:
    query = db.query(ExpenseTransactionModel)
    if mine_only:
        if not current_user:
            raise HTTPException(status_code=401, detail="Authentication required for personal records")
        query = query.filter(ExpenseTransactionModel.owner_id == current_user.id)
    rows = query.order_by(ExpenseTransactionModel.created_at.desc()).all()
    return [_serialize_expense_transaction(r) for r in rows]

@app.post("/api/expense_transaction", status_code=201)
def create_expense_transaction(
    payload: ExpenseTransactionCreate,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    data = payload.model_dump()
    if current_user:
        data["owner_id"] = current_user.id
    record = ExpenseTransactionModel(**data)
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_expense_transaction(record)

@app.put("/api/expense_transaction/{item_id}")
def update_expense_transaction(
    item_id: str, payload: ExpenseTransactionUpdate,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    record = db.query(ExpenseTransactionModel).filter(ExpenseTransactionModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Expense Transaction not found"
        )
    if hasattr(record, "owner_id") and record.owner_id and current_user:
        if record.owner_id != current_user.id and getattr(current_user, "role", "") not in ("admin", "manager"):
            raise HTTPException(status_code=403, detail="Forbidden: you do not own this record")
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_expense_transaction(record)

@app.delete("/api/expense_transaction/{item_id}")
def delete_expense_transaction(
    item_id: str,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, str]:
    record = db.query(ExpenseTransactionModel).filter(ExpenseTransactionModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Expense Transaction not found"
        )
    if hasattr(record, "owner_id") and record.owner_id and current_user:
        if record.owner_id != current_user.id and getattr(current_user, "role", "") not in ("admin", "manager"):
            raise HTTPException(status_code=403, detail="Forbidden: you do not own this record")
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class BudgetCategoryCreate(BaseModel):
    category_name: str = ''
    monthly_limit: float = 0.0
    current_spend: float = 0.0
    period_month: str = '2026-10'
    alert_threshold: int = 85

class BudgetCategoryUpdate(BaseModel):
    category_name: Optional[str] = None
    monthly_limit: Optional[float] = None
    current_spend: Optional[float] = None
    period_month: Optional[str] = None
    alert_threshold: Optional[int] = None

def _serialize_budget_category(item: BudgetCategoryModel) -> dict[str, Any]:
    d = {"id": item.id, "category_name": getattr(item, "category_name"), "monthly_limit": getattr(item, "monthly_limit"), "current_spend": getattr(item, "current_spend"), "period_month": getattr(item, "period_month"), "alert_threshold": getattr(item, "alert_threshold")}
    if hasattr(item, "owner_id") and item.owner_id: d["owner_id"] = item.owner_id

    return d

@app.get("/api/budget_category")
def list_budget_category(
    mine_only: bool = False,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> list[dict[str, Any]]:
    query = db.query(BudgetCategoryModel)
    if mine_only:
        if not current_user:
            raise HTTPException(status_code=401, detail="Authentication required for personal records")
        query = query.filter(BudgetCategoryModel.owner_id == current_user.id)
    rows = query.order_by(BudgetCategoryModel.created_at.desc()).all()
    return [_serialize_budget_category(r) for r in rows]

@app.post("/api/budget_category", status_code=201)
def create_budget_category(
    payload: BudgetCategoryCreate,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    data = payload.model_dump()
    if current_user:
        data["owner_id"] = current_user.id
    record = BudgetCategoryModel(**data)
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_budget_category(record)

@app.put("/api/budget_category/{item_id}")
def update_budget_category(
    item_id: str, payload: BudgetCategoryUpdate,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    record = db.query(BudgetCategoryModel).filter(BudgetCategoryModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Budget Category not found"
        )
    if hasattr(record, "owner_id") and record.owner_id and current_user:
        if record.owner_id != current_user.id and getattr(current_user, "role", "") not in ("admin", "manager"):
            raise HTTPException(status_code=403, detail="Forbidden: you do not own this record")
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_budget_category(record)

@app.delete("/api/budget_category/{item_id}")
def delete_budget_category(
    item_id: str,
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, str]:
    record = db.query(BudgetCategoryModel).filter(BudgetCategoryModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Budget Category not found"
        )
    if hasattr(record, "owner_id") and record.owner_id and current_user:
        if record.owner_id != current_user.id and getattr(current_user, "role", "") not in ("admin", "manager"):
            raise HTTPException(status_code=403, detail="Forbidden: you do not own this record")
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class RegisterRequest(BaseModel):
    email: str
    password: str
    display_name: Optional[str] = ''
    role: Optional[str] = 'member'

class LoginRequest(BaseModel):
    email: str
    password: str

class ResetPasswordRequest(BaseModel):
    email: str
    new_password: str

@app.post("/api/auth/register", status_code=201)
def api_auth_register(payload: RegisterRequest, db: Session = Depends(get_db)) -> dict[str, Any]:
    if not payload.email or "@" not in payload.email:
        raise HTTPException(status_code=422, detail="Valid email required")
    if len(payload.password) < 8:
        raise HTTPException(status_code=422, detail="Password must be at least 8 characters")
    existing = db.query(UserModel).filter(UserModel.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")
    u = UserModel(
        email=payload.email,
        password_hash=hash_password(payload.password),
        display_name=payload.display_name or payload.email.split("@")[0],
        role=payload.role or 'member',
    )
    db.add(u)
    db.commit()
    db.refresh(u)
    token = create_session(db, u.id)
    return {"token": token, "user": {"id": u.id, "email": u.email, "display_name": u.display_name, "role": u.role}}

@app.post("/api/auth/login")
def api_auth_login(payload: LoginRequest, db: Session = Depends(get_db)) -> dict[str, Any]:
    u = db.query(UserModel).filter(UserModel.email == payload.email).first()
    if not u or not verify_password(payload.password, u.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_session(db, u.id)
    return {"token": token, "user": {"id": u.id, "email": u.email, "display_name": u.display_name, "role": u.role}}

@app.post("/api/auth/logout")
def api_auth_logout(
    current_user: UserModel = Depends(get_current_user),
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
) -> dict[str, str]:
    if authorization and authorization.lower().startswith('bearer '):
        revoke_session(db, authorization[7:].strip())
    return {"status": "logged_out"}

@app.get("/api/auth/me")
def api_auth_me(current_user: UserModel = Depends(get_current_user)) -> dict[str, Any]:
    return {"id": current_user.id, "email": current_user.email, "display_name": current_user.display_name, "role": current_user.role}

@app.post("/api/auth/reset-password")
def api_auth_reset_password(payload: ResetPasswordRequest, db: Session = Depends(get_db)) -> dict[str, str]:
    if len(payload.new_password) < 8:
        raise HTTPException(status_code=422, detail="Password must be at least 8 characters")
    u = db.query(UserModel).filter(UserModel.email == payload.email).first()
    if not u:
        raise HTTPException(status_code=404, detail="Account not found")
    u.password_hash = hash_password(payload.new_password)
    db.commit()
    return {"status": "password_reset_success"}

@app.get("/api/auth/status")
def api_auth_status() -> dict[str, Any]:
    return {
        "auth_required": True,
        "strategy": "token_session",
        "rationale": 'Standard session authentication for user workspaces.',
    }

@app.get("/api/privacy/export")
def api_privacy_export(
    current_user: Optional[Any] = Depends(get_current_user_optional)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "application": 'Personal Expense Tracker Pipeline',
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "user": {"id": current_user.id, "email": current_user.email} if current_user else None,
        "records": {},
    }
    q_expense_transaction = db.query(ExpenseTransactionModel)
    if current_user and hasattr(ExpenseTransactionModel, 'owner_id'):
        q_expense_transaction = q_expense_transaction.filter(ExpenseTransactionModel.owner_id == current_user.id)
    payload["records"]["expense_transaction"] = [_serialize_expense_transaction(r) for r in q_expense_transaction.all()]
    q_budget_category = db.query(BudgetCategoryModel)
    if current_user and hasattr(BudgetCategoryModel, 'owner_id'):
        q_budget_category = q_budget_category.filter(BudgetCategoryModel.owner_id == current_user.id)
    payload["records"]["budget_category"] = [_serialize_budget_category(r) for r in q_budget_category.all()]
    return payload

@app.delete("/api/privacy/account")
def api_privacy_account_deletion(
    current_user: Any = Depends(get_current_user)
,    db: Session = Depends(get_db),
) -> dict[str, Any]:
    if hasattr(ExpenseTransactionModel, 'owner_id'):
        db.query(ExpenseTransactionModel).filter(ExpenseTransactionModel.owner_id == current_user.id).delete()
    if hasattr(BudgetCategoryModel, 'owner_id'):
        db.query(BudgetCategoryModel).filter(BudgetCategoryModel.owner_id == current_user.id).delete()
    db.query(SessionTokenModel).filter(SessionTokenModel.user_id == current_user.id).delete()
    db.query(UserModel).filter(UserModel.id == current_user.id).delete()
    db.commit()
    return {"status": "account_and_records_deleted", "user_id": current_user.id}

@app.get("/api/security/threat-model")
def api_security_threat_model() -> dict[str, Any]:
    return THREAT_MODEL_JSON

@app.get("/api/analytics/summary")
def api_analytics_summary(db: Session = Depends(get_db)) -> dict[str, Any]:
    counts: dict[str, int] = {}
    total_count = 0
    c_expense_transaction = db.query(ExpenseTransactionModel).count()
    counts["expense_transaction"] = c_expense_transaction
    total_count += c_expense_transaction
    c_budget_category = db.query(BudgetCategoryModel).count()
    counts["budget_category"] = c_budget_category
    total_count += c_budget_category
    rows_expense_transaction = db.query(ExpenseTransactionModel).all()
    dist_map: dict[str, int] = {}
    for r in rows_expense_transaction:
        val = str(getattr(r, "category", "Unknown") or "Unknown")
        dist_map[val] = dist_map.get(val, 0) + 1
    primary_chart_data = [{"label": k, "value": v} for k, v in dist_map.items()]
    return {
        "app": 'Personal Expense Tracker Pipeline',
        "total_records": total_count,
        "counts_by_entity": counts,
        "primary_chart_type": 'bar',
        "primary_chart_data": primary_chart_data,
        "secondary_chart_type": 'metric_card',
        'kpis': [
            {"id": 'total_entries', "label": 'Total Expense Transactions', "unit": 'records', "value": total_count, "target": None},
            {"id": 'active_entries', "label": 'Active Status Ratio', "unit": '%', "value": total_count, "target": None},
            {"id": 'verification_score', "label": 'Audit Score', "unit": '%', "value": total_count, "target": 98.0},
        ],
    }

@app.post("/api/seed")
def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:
    inserted = seed_database(db)
    return {"status": "seeded", "inserted": inserted}

@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {
        "status": "healthy",
        "app": 'Personal Expense Tracker Pipeline',
        "archetype": 'finance_ledger',
    }
