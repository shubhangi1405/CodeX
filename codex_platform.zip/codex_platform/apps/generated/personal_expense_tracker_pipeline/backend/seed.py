"""Optional sample seed data loader for Personal Expense Tracker Pipeline."""

import json
from sqlalchemy.orm import Session
from database import Base, SessionLocal, engine
from models import ExpenseTransactionModel, BudgetCategoryModel, UserModel
from auth import hash_password

SAMPLE_SEED_DATA = json.loads(r'''{
  "expense_transaction": [
    {
      "id": "tx-101",
      "title": "Fresh Market Organic Groceries",
      "amount": 128.45,
      "transaction_date": "2026-10-10",
      "category": "Groceries",
      "transaction_type": "Expense",
      "payment_method": "Credit Card",
      "notes": "Weekly produce, dairy, and household essentials",
      "budget_category_id": "cat-01"
    },
    {
      "id": "tx-102",
      "title": "Monthly High-Speed Fiber Internet",
      "amount": 79.99,
      "transaction_date": "2026-10-08",
      "category": "Utilities",
      "transaction_type": "Expense",
      "payment_method": "Debit Card",
      "notes": "Home office fiber connection utility bill",
      "budget_category_id": "cat-02"
    },
    {
      "id": "tx-103",
      "title": "Artisan Bistro Dinner with Team",
      "amount": 64.5,
      "transaction_date": "2026-10-11",
      "category": "Dining Out",
      "transaction_type": "Expense",
      "payment_method": "Credit Card",
      "notes": "Dinner celebration with project collaborators",
      "budget_category_id": "cat-03"
    },
    {
      "id": "tx-104",
      "title": "Monthly Direct Deposit Salary",
      "amount": 4250.0,
      "transaction_date": "2026-10-01",
      "category": "Salary & Income",
      "transaction_type": "Income",
      "payment_method": "Bank Transfer",
      "notes": "Primary software engineering payroll deposit",
      "budget_category_id": "cat-04"
    }
  ],
  "budget_category": [
    {
      "id": "cat-01",
      "category_name": "Groceries",
      "monthly_limit": 600.0,
      "current_spend": 384.2,
      "period_month": "2026-10",
      "alert_threshold": 80
    },
    {
      "id": "cat-02",
      "category_name": "Utilities",
      "monthly_limit": 250.0,
      "current_spend": 195.4,
      "period_month": "2026-10",
      "alert_threshold": 90
    },
    {
      "id": "cat-03",
      "category_name": "Dining Out",
      "monthly_limit": 300.0,
      "current_spend": 210.5,
      "period_month": "2026-10",
      "alert_threshold": 85
    },
    {
      "id": "cat-04",
      "category_name": "Transportation",
      "monthly_limit": 200.0,
      "current_spend": 85.0,
      "period_month": "2026-10",
      "alert_threshold": 75
    }
  ]
}''')


def seed_database(db: Session) -> dict[str, int]:
    """Inserts domain sample records if tables are currently empty."""
    inserted: dict[str, int] = {}
    if db.query(UserModel).count() == 0:
        admin_u = UserModel(
            id="usr-admin",
            email="admin@workspace.example",
            password_hash=hash_password("Password123!"),
            display_name="Admin Director",
            role="admin",
        )
        member_u = UserModel(
            id="usr-member",
            email="member@workspace.example",
            password_hash=hash_password("Password123!"),
            display_name="Active Member",
            role="member",
        )
        db.add_all([admin_u, member_u])
        db.commit()
        inserted["users"] = 2

    records_expense_transaction = SAMPLE_SEED_DATA.get("expense_transaction", [])
    existing_expense_transaction = db.query(ExpenseTransactionModel).count()
    count_expense_transaction = 0
    if existing_expense_transaction == 0:
        for row in records_expense_transaction:
            allowed = ['title', 'amount', 'transaction_date', 'category', 'transaction_type', 'payment_method', 'notes', 'budget_category_id']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            if 'owner_id' not in payload:
                payload['owner_id'] = 'usr-member'
            db.add(ExpenseTransactionModel(**payload))
            count_expense_transaction += 1
    inserted["expense_transaction"] = count_expense_transaction
    records_budget_category = SAMPLE_SEED_DATA.get("budget_category", [])
    existing_budget_category = db.query(BudgetCategoryModel).count()
    count_budget_category = 0
    if existing_budget_category == 0:
        for row in records_budget_category:
            allowed = ['category_name', 'monthly_limit', 'current_spend', 'period_month', 'alert_threshold']
            payload = {k: v for k, v in row.items() if k in allowed or k == 'id'}
            if 'owner_id' not in payload:
                payload['owner_id'] = 'usr-member'
            db.add(BudgetCategoryModel(**payload))
            count_budget_category += 1
    inserted["budget_category"] = count_budget_category
    db.commit()
    return inserted


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as session:
        result = seed_database(session)
        print("Seeded sample records:", result)
