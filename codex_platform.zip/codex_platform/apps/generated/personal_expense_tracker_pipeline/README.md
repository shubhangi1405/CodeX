# Personal Expense Tracker Pipeline

> Personal expense tracking, monthly category budgets, and cashflow analytics

## Product & Domain Summary
- **Product Kind**: Personal Expense, Budget & Cashflow Tracker
- **Archetype**: `finance_ledger`
- **Primary Object**: `expense_transaction`
- **Target Audience**: Individuals, households, and professionals managing personal finances and monthly budgets (Daily expense entry, budget threshold monitoring, and spending analytics)
- **Navigation Pattern**: `sidebar`
- **Home Page**: `expense-dashboard` (`stat_tiles_with_charts`)

## Design Direction (`ledger_precision`)
- **Color Mode**: `light` | **Primary**: `#047857` | **Surface**: `#F8FAFC`
- **Typography**: Heading `IBM Plex Sans` · Body `IBM Plex Sans` · Mono `IBM Plex Mono`
- **Shape & Density**: Radius `soft` · Density `compact`
- **Rationale**: Meticulous financial ledger aesthetic with emerald accents, high data density, and clean numerical alignment for personal budgeting.

## Domain Entities
- **Expense Transactions** (`expense_transaction`): `title` (string), `amount` (currency), `transaction_date` (date), `category` (enum), `transaction_type` (enum), `payment_method` (enum), `notes` (string), `budget_category_id` (string)
- **Budget Categories** (`budget_category`): `category_name` (string), `monthly_limit` (currency), `current_spend` (currency), `period_month` (string), `alert_threshold` (integer)

## Application Screens
- **Expense & Cashflow Dashboard** (`/expense-dashboard`) — Layout: `stat_tiles_with_charts`
- **Transaction Ledger & Spending History** (`/transaction-ledger`) — Layout: `data_table_with_filters`
- **Monthly Budget Limits & Caps** (`/budget-limits`) — Layout: `card_grid`

## API Endpoints
- `GET /api/expense_transaction`
- `POST /api/expense_transaction`
- `PUT /api/expense_transaction/{item_id}`
- `DELETE /api/expense_transaction/{item_id}`
- `GET /api/budget_category`
- `POST /api/budget_category`
- `PUT /api/budget_category/{item_id}`
- `DELETE /api/budget_category/{item_id}`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `POST /api/auth/reset-password`
- `GET /api/auth/status`
- `GET /api/privacy/export`
- `DELETE /api/privacy/account`
- `GET /api/security/threat-model`
- `GET /api/analytics/summary`
- `POST /api/seed`
- `GET /api/health`

## SQLAlchemy Models
- `ExpenseTransactionModel`
- `BudgetCategoryModel`

## Local Execution

### 1. Instant Standalone UI
Open `standalone_app.html` directly in any browser (zero external CDN dependencies).

### 2. Backend API (`FastAPI` + `SQLite`)
```bash
cd backend
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### 3. React + Vite Frontend
```bash
cd frontend
npm install
npm run dev
```
