import React, { useEffect, useState } from 'react';
import {
  AdaptiveAppShell,
  AdaptiveLayoutRenderer,
  Button,
  FormField,
  Input,
  Modal,
  Select,
  Toast,
  EntityRecord,
  EntitySpecData,
  PageSpecData,
} from './ui_kit';

const BLUEPRINT = {
  "app_name": "Personal Expense Tracker Pipeline",
  "product_tagline": "Personal expense tracking, monthly category budgets, and cashflow analytics",
  "domain": {
    "product_kind": "Personal Expense, Budget & Cashflow Tracker",
    "archetype": "finance_ledger",
    "audience": {
      "who": "Individuals, households, and professionals managing personal finances and monthly budgets",
      "context_of_use": "Daily expense entry, budget threshold monitoring, and spending analytics",
      "device_likely_used": "hybrid",
      "tech_comfort": "medium"
    },
    "core_jobs": [
      "Record daily income and expense transactions with category and payment method tags",
      "Monitor monthly budget limits, current category spending, and threshold alerts",
      "Inspect spending distribution charts and monthly cashflow summaries"
    ],
    "primary_object": "expense_transaction",
    "tone": "reassuring, meticulous, clear",
    "data_shape": "time-series",
    "needs_automation": false,
    "rationale": "Personal money management requires an instant ledger of expenses and income, visual monthly budget utilization gauges, and category breakdown analytics."
  },
  "entities": [
    {
      "name": "expense_transaction",
      "singular_label": "Expense Transaction",
      "plural_label": "Expense Transactions",
      "fields": [
        {
          "name": "title",
          "label": "Transaction Description",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "amount",
          "label": "Transaction Amount",
          "field_type": "currency",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "transaction_date",
          "label": "Transaction Date",
          "field_type": "date",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "category",
          "label": "Spending Category",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Groceries",
            "Utilities",
            "Dining Out",
            "Transportation",
            "Entertainment",
            "Healthcare",
            "Salary & Income",
            "General"
          ],
          "default_value": null
        },
        {
          "name": "transaction_type",
          "label": "Type",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Expense",
            "Income"
          ],
          "default_value": null
        },
        {
          "name": "payment_method",
          "label": "Payment Method",
          "field_type": "enum",
          "required": true,
          "unique": false,
          "enum_values": [
            "Credit Card",
            "Debit Card",
            "Bank Transfer",
            "Cash",
            "Mobile Payment"
          ],
          "default_value": null
        },
        {
          "name": "notes",
          "label": "Notes & Tags",
          "field_type": "string",
          "required": false,
          "unique": false,
          "enum_values": [],
          "default_value": ""
        },
        {
          "name": "budget_category_id",
          "label": "Linked Budget Category",
          "field_type": "string",
          "required": false,
          "unique": false,
          "enum_values": [],
          "default_value": ""
        }
      ],
      "relationships": [
        {
          "target_entity": "budget_category",
          "kind": "many_to_one",
          "foreign_key": "budget_category_id"
        }
      ]
    },
    {
      "name": "budget_category",
      "singular_label": "Budget Category",
      "plural_label": "Budget Categories",
      "fields": [
        {
          "name": "category_name",
          "label": "Category Name",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "monthly_limit",
          "label": "Monthly Spending Limit",
          "field_type": "currency",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": null
        },
        {
          "name": "current_spend",
          "label": "Current Month Spending",
          "field_type": "currency",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": 0.0
        },
        {
          "name": "period_month",
          "label": "Budget Period (YYYY-MM)",
          "field_type": "string",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": "2026-10"
        },
        {
          "name": "alert_threshold",
          "label": "Alert Threshold (%)",
          "field_type": "integer",
          "required": true,
          "unique": false,
          "enum_values": [],
          "default_value": 85
        }
      ],
      "relationships": []
    }
  ],
  "pages": [
    {
      "id": "expense-dashboard",
      "title": "Expense & Cashflow Dashboard",
      "route": "/expense-dashboard",
      "layout": "stat_tiles_with_charts",
      "entities_used": [
        "expense_transaction",
        "budget_category"
      ],
      "primary_actions": [
        "Log Expense",
        "Add Income"
      ],
      "empty_state": {
        "headline": "No Financial Activity Logged",
        "body": "Start by recording your first expense transaction or monthly budget limit.",
        "cta_label": "Log Transaction",
        "cta_action_id": "create_expense_transaction"
      }
    },
    {
      "id": "transaction-ledger",
      "title": "Transaction Ledger & Spending History",
      "route": "/transaction-ledger",
      "layout": "data_table_with_filters",
      "entities_used": [
        "expense_transaction"
      ],
      "primary_actions": [
        "New Transaction",
        "Export Transactions"
      ],
      "empty_state": {
        "headline": "Transaction Ledger Is Clean",
        "body": "Your recorded income and expense transactions will appear here with multi-column filtering.",
        "cta_label": "Add Transaction",
        "cta_action_id": "create_expense_transaction"
      }
    },
    {
      "id": "budget-limits",
      "title": "Monthly Budget Limits & Caps",
      "route": "/budget-limits",
      "layout": "card_grid",
      "entities_used": [
        "budget_category"
      ],
      "primary_actions": [
        "Set Budget Cap",
        "Adjust Limits"
      ],
      "empty_state": {
        "headline": "No Budget Categories Defined",
        "body": "Set monthly spending limits for categories like Groceries, Utilities, and Dining.",
        "cta_label": "Create Budget Limit",
        "cta_action_id": "create_budget_category"
      }
    }
  ],
  "navigation": {
    "pattern": "sidebar",
    "items": [
      {
        "page_id": "expense-dashboard",
        "label": "Cashflow Overview",
        "icon": "bar-chart-2"
      },
      {
        "page_id": "transaction-ledger",
        "label": "Transaction Ledger",
        "icon": "credit-card"
      },
      {
        "page_id": "budget-limits",
        "label": "Budget Caps",
        "icon": "check-square"
      }
    ]
  },
  "home_page_id": "expense-dashboard",
  "automations": [],
  "auth": {
    "required": true,
    "strategy": "token_session",
    "roles": [
      {
        "name": "admin",
        "label": "System Administrator",
        "permissions": [
          "read",
          "write",
          "delete",
          "export",
          "manage_users"
        ],
        "description": "Full administrative control over all SpendCraft Finance data."
      },
      {
        "name": "member",
        "label": "Active Member",
        "permissions": [
          "read",
          "write",
          "export"
        ],
        "description": "Can create and manage personal Expense Transaction entries."
      },
      {
        "name": "viewer",
        "label": "Auditor / Read-Only",
        "permissions": [
          "read"
        ],
        "description": "Can view dashboards and reports without modifying data."
      }
    ],
    "protected_entities": [
      "expense_transaction"
    ],
    "password_min_length": 8,
    "session_timeout_minutes": 1440,
    "rationale": "Standard session authentication for user workspaces."
  },
  "security": {
    "data_sensitivity": "confidential",
    "rate_limit_rpm": 120,
    "pii_fields": [
      "budget_category.category_name"
    ],
    "export_enabled": true,
    "deletion_enabled": true,
    "audit_logging": true,
    "encryption_in_transit": true
  },
  "threat_model": {
    "assets": [
      "SpendCraft Finance SQLite Database",
      "Expense Transaction Records",
      "Session Tokens"
    ],
    "trust_boundaries": [
      "Public Internet <-> Reverse Proxy / Vite Frontend",
      "Frontend Client <-> FastAPI Endpoints",
      "Application Layer <-> SQLite Persistence Engine"
    ],
    "threats": [
      {
        "id": "t-auth-bypass",
        "category": "spoofing",
        "asset": "User Authentication & Session Tokens",
        "threat_description": "Adversary attempts brute force or credential stuffing on login endpoint.",
        "attacker_profile": "External malicious actor or automated botnet",
        "attack_path": "Repeated POST requests to authentication endpoint with dictionary passwords.",
        "mitigation": "PBKDF2-HMAC-SHA256 password hashing with salt and in-memory rate limiting.",
        "residual_risk": "low"
      },
      {
        "id": "t-idor-tampering",
        "category": "elevation_of_privilege",
        "asset": "Expense Transaction Data Records",
        "threat_description": "User A attempts to modify or delete User B private records by guessing record IDs.",
        "attacker_profile": "Authenticated standard user",
        "attack_path": "Submitting PUT/DELETE requests referencing other tenants record identifiers.",
        "mitigation": "Server-side owner_id verification and RBAC role validation before mutation.",
        "residual_risk": "low"
      },
      {
        "id": "t-data-leakage",
        "category": "information_disclosure",
        "asset": "Account and Exported Data",
        "threat_description": "Unauthorized retrieval of sensitive workspace information.",
        "attacker_profile": "Unauthenticated external network eavesdropper",
        "attack_path": "Interception of API payloads or token theft via XSS.",
        "mitigation": "Strict CORS headers, X-Content-Type-Options, and secure session management.",
        "residual_risk": "low"
      }
    ]
  },
  "analytics": {
    "primary_chart": "bar",
    "secondary_chart": "metric_card",
    "kpis": [
      {
        "id": "total_entries",
        "label": "Total Expense Transactions",
        "unit": "records",
        "calculation": "count(all)",
        "target": null
      },
      {
        "id": "active_entries",
        "label": "Active Status Ratio",
        "unit": "%",
        "calculation": "active / total * 100",
        "target": null
      },
      {
        "id": "verification_score",
        "label": "Audit Score",
        "unit": "%",
        "calculation": "valid / total * 100",
        "target": 98.0
      }
    ],
    "date_filtering": true,
    "export_format": "json"
  },
  "feature_checklist": [
    {
      "id": "feat-core-crud",
      "name": "Expense Transaction Lifecycle Management",
      "description": "Create, inspect, update, and remove Expense Transaction domain records with persistence.",
      "tier": "essential",
      "status": "Verified",
      "acceptance_criteria": [
        "User can create a new Expense Transaction with required fields.",
        "Database validates input types and persists changes.",
        "Deleted Expense Transaction records are safely pruned from the system."
      ],
      "verified_by_test": "test_create_and_query_expense_transaction"
    },
    {
      "id": "feat-domain-analytics",
      "name": "Domain KPI & Analytical Visualizations",
      "description": "Real-time visual summaries and KPI computation derived from Expense Transaction state.",
      "tier": "essential",
      "status": "Verified",
      "acceptance_criteria": [
        "Metrics recalculate dynamically from SQLite records.",
        "Chart distributions render without external CDN dependencies."
      ],
      "verified_by_test": "test_analytics_summary_kpi_computation"
    },
    {
      "id": "feat-auth-security",
      "name": "Authentication, Roles & Data Custody",
      "description": "Cryptographic password security, session token management, and per-user privacy.",
      "tier": "recommended",
      "status": "Verified",
      "acceptance_criteria": [
        "Passwords hashed with PBKDF2-HMAC-SHA256 and unique salt.",
        "Data export and account deletion endpoints honor privacy rights."
      ],
      "verified_by_test": "test_authentication_and_data_isolation"
    },
    {
      "id": "feat-data-export-portability",
      "name": "Data Portability & Tabular Export",
      "description": "Export workspace records for offline analysis, archiving, or auditing.",
      "tier": "optional",
      "status": "Verified",
      "acceptance_criteria": [
        "Complete JSON / data export is generated upon request.",
        "User can download their complete record history."
      ],
      "verified_by_test": "test_privacy_data_export"
    }
  ],
  "user_journeys": [
    {
      "id": "uj-onboarding",
      "persona": "Individuals, households, and professionals managing personal finances and monthly budgets",
      "goal": "Initialize workspace and record the first Expense Transaction",
      "trigger": "User opens SpendCraft Finance for the first time",
      "steps": [
        {
          "step_number": 1,
          "action": "Navigate to Expense & Cashflow Dashboard",
          "expected_result": "Dashboard loads with empty state guidance or sample seed data."
        },
        {
          "step_number": 2,
          "action": "Click '+ Log Expense'",
          "expected_result": "Input modal opens with validated form controls."
        },
        {
          "step_number": 3,
          "action": "Fill required values and click Save",
          "expected_result": "Record appears instantly in the layout and updates KPI totals."
        }
      ],
      "outcome": "User has an active, verified Expense Transaction in their workspace."
    },
    {
      "id": "uj-review-analytics",
      "persona": "Individuals, households, and professionals managing personal finances and monthly budgets",
      "goal": "Review performance trends, filter by date, and audit status",
      "trigger": "Periodic review routine or operational check-in",
      "steps": [
        {
          "step_number": 1,
          "action": "View Expense & Cashflow Dashboard charts and KPI cards",
          "expected_result": "Visual charts display real distributions calculated from active records."
        },
        {
          "step_number": 2,
          "action": "Apply status filter or search keyword",
          "expected_result": "Table and metrics narrow immediately to matching entries."
        }
      ],
      "outcome": "User gains actionable domain insight from their data."
    }
  ],
  "business_rules": [
    "Every Expense Transaction must have a unique identifier and required core attributes.",
    "Numeric metrics (amounts, streaks, scores) must not be negative.",
    "Users may only update or delete records they own unless granted administrative role.",
    "Exported data sets must reflect currently committed database state accurately."
  ]
} as const;
const DESIGN_DIRECTION = {
  "direction_id": "ledger_precision",
  "palette": {
    "primary": "#047857",
    "primary_foreground": "#FFFFFF",
    "accent": "#0B6E66",
    "neutral_ramp": [
      "#F8FAFC",
      "#F1F5F9",
      "#E2E8F0",
      "#CBD5E1",
      "#94A3B8",
      "#64748B",
      "#475569",
      "#1E293B",
      "#0F172A"
    ],
    "surface": "#F8FAFC",
    "surface_elevated": "#FFFFFF",
    "border": "#52637A",
    "text": "#0F172A",
    "text_muted": "#334155",
    "focus_ring": "#047857",
    "success": "#156D3B",
    "warning": "#854D0E",
    "danger": "#991B1B"
  },
  "color_mode": "light",
  "typography": {
    "heading_font": "IBM Plex Sans",
    "body_font": "IBM Plex Sans",
    "mono_font": "IBM Plex Mono",
    "scale_ratio": 1.2
  },
  "shape": {
    "radius_class": "soft",
    "border_style": "crisp",
    "shadow_style": "flat"
  },
  "density": "compact",
  "motion": "none",
  "iconography": "outline",
  "brand_mark": {
    "kind": "geometric_glyph",
    "glyph_primitive": "bars_ascending",
    "monogram_letters": "SC"
  },
  "copy_voice": "Exact, accounting-grade, noun-first labels with zero marketing fluff.",
  "rationale": "Meticulous financial ledger aesthetic with emerald accents, high data density, and clean numerical alignment for personal budgeting."
} as const;
const SAMPLE_SEED_DATA: Record<string, EntityRecord[]> = {
  "expense_transaction": [
    {
      "id": "tx-101",
      "title": "Fresh Market Organic Groceries",
      "amount": 128.45,
      "transaction_date": "2026-10-10",
      "category": "Groceries",
      "transaction_type": "Expense",
      "payment_method": "Credit Card",
      "notes": "Weekly produce, dairy, and household essentials",
      "budget_category_id": "cat-01"
    },
    {
      "id": "tx-102",
      "title": "Monthly High-Speed Fiber Internet",
      "amount": 79.99,
      "transaction_date": "2026-10-08",
      "category": "Utilities",
      "transaction_type": "Expense",
      "payment_method": "Debit Card",
      "notes": "Home office fiber connection utility bill",
      "budget_category_id": "cat-02"
    },
    {
      "id": "tx-103",
      "title": "Artisan Bistro Dinner with Team",
      "amount": 64.5,
      "transaction_date": "2026-10-11",
      "category": "Dining Out",
      "transaction_type": "Expense",
      "payment_method": "Credit Card",
      "notes": "Dinner celebration with project collaborators",
      "budget_category_id": "cat-03"
    },
    {
      "id": "tx-104",
      "title": "Monthly Direct Deposit Salary",
      "amount": 4250.0,
      "transaction_date": "2026-10-01",
      "category": "Salary & Income",
      "transaction_type": "Income",
      "payment_method": "Bank Transfer",
      "notes": "Primary software engineering payroll deposit",
      "budget_category_id": "cat-04"
    }
  ],
  "budget_category": [
    {
      "id": "cat-01",
      "category_name": "Groceries",
      "monthly_limit": 600.0,
      "current_spend": 384.2,
      "period_month": "2026-10",
      "alert_threshold": 80
    },
    {
      "id": "cat-02",
      "category_name": "Utilities",
      "monthly_limit": 250.0,
      "current_spend": 195.4,
      "period_month": "2026-10",
      "alert_threshold": 90
    },
    {
      "id": "cat-03",
      "category_name": "Dining Out",
      "monthly_limit": 300.0,
      "current_spend": 210.5,
      "period_month": "2026-10",
      "alert_threshold": 85
    },
    {
      "id": "cat-04",
      "category_name": "Transportation",
      "monthly_limit": 200.0,
      "current_spend": 85.0,
      "period_month": "2026-10",
      "alert_threshold": 75
    }
  ]
};
const BRAND_SVG_MARKUP = "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"5\" y=\"13\" width=\"3\" height=\"6\" rx=\"1\" fill=\"currentColor\"/><rect x=\"10.5\" y=\"9\" width=\"3\" height=\"10\" rx=\"1\" fill=\"currentColor\"/><rect x=\"16\" y=\"5\" width=\"3\" height=\"14\" rx=\"1\" fill=\"currentColor\"/></svg>";
const NUMERIC_TYPES = new Set(['integer', 'float', 'currency']);

export default function App(): React.ReactElement {
  const [activePageId, setActivePageId] = useState<string>(BLUEPRINT.home_page_id);
  const [recordsByEntity, setRecordsByEntity] = useState<Record<string, EntityRecord[]>>(() => {
    const initial: Record<string, EntityRecord[]> = {};
    for (const ent of BLUEPRINT.entities) {
      initial[ent.name] = [];
    }
    return initial;
  });
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formState, setFormState] = useState<Record<string, string | number | boolean>>({});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const pages = BLUEPRINT.pages as unknown as PageSpecData[];
  const entities = BLUEPRINT.entities as unknown as EntitySpecData[];
  const activePage = pages.find((p) => p.id === activePageId) || pages[0];
  const primaryEntityName = activePage.entities_used[0] || entities[0].name;
  const activeEntity = entities.find((e) => e.name === primaryEntityName) || entities[0];
  const activeRecords = recordsByEntity[activeEntity.name] || [];

  useEffect(() => {
    for (const ent of entities) {
      fetch(`/api/${ent.name}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data: EntityRecord[] | null) => {
          if (Array.isArray(data) && data.length > 0) {
            setRecordsByEntity((prev) => ({ ...prev, [ent.name]: data }));
          }
        })
        .catch(() => {
          // Offline mode uses in-memory state
        });
    }
  }, []);

  const openCreateModal = (): void => {
    const defaults: Record<string, string | number | boolean> = {};
    for (const fld of activeEntity.fields) {
      if (fld.field_type === 'boolean') {
        defaults[fld.name] = Boolean(fld.default_value ?? false);
      } else if (NUMERIC_TYPES.has(fld.field_type)) {
        defaults[fld.name] = Number(fld.default_value ?? 0);
      } else if (fld.field_type === 'enum' && fld.enum_values && fld.enum_values.length > 0) {
        defaults[fld.name] = fld.enum_values[0];
      } else {
        defaults[fld.name] = String(fld.default_value ?? '');
      }
    }
    setFormState(defaults);
    setIsModalOpen(true);
  };

  const handleCreateRecord = (): void => {
    const newRecord: EntityRecord = {
      id: `${activeEntity.name}-${Date.now()}`,
      ...formState,
    };
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: [newRecord, ...(prev[activeEntity.name] || [])],
    }));
    fetch(`/api/${activeEntity.name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formState),
    }).catch(() => undefined);
    setIsModalOpen(false);
    setToastMsg(`Saved ${activeEntity.singular_label}`);
  };

  const handleLoadSampleSeedData = (): void => {
    setRecordsByEntity(SAMPLE_SEED_DATA);
    fetch('/api/seed', { method: 'POST' }).catch(() => undefined);
    setToastMsg('Loaded domain sample records');
  };

  const handleDeleteRecord = (recordId: string): void => {
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).filter((r) => String(r.id) !== recordId),
    }));
    fetch(`/api/${activeEntity.name}/${recordId}`, {
      method: 'DELETE',
    }).catch(() => undefined);
    setToastMsg(`Removed ${activeEntity.singular_label}`);
  };

  const [isLiveTouched, setIsLiveTouched] = useState<boolean>(false);

  const handleExportJsonData = (): void => {
    const jsonStr = JSON.stringify(recordsByEntity, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${BLUEPRINT.app_name.toLowerCase().replace(/[^a-z0-9]/g, '_')}_export.json`;
    a.click();
    URL.revokeObjectURL(url);
    setToastMsg('Workspace records exported');
  };

  const handleToggleBoolean = (recordId: string, fieldName: string): void => {
    setIsLiveTouched(true);
    setRecordsByEntity((prev) => ({
      ...prev,
      [activeEntity.name]: (prev[activeEntity.name] || []).map((r) =>
        String(r.id) === recordId ? { ...r, [fieldName]: !r[fieldName] } : r
      ),
    }));
  };

  return (
    <div className="min-h-screen bg-surface text-text font-body">
      <AdaptiveAppShell
        pattern={BLUEPRINT.navigation.pattern}
        appName={BLUEPRINT.app_name}
        tagline={BLUEPRINT.product_tagline}
        brandMark={
          <span
            className="inline-flex items-center"
            dangerouslySetInnerHTML={{ __html: BRAND_SVG_MARKUP }}
          />
        }
        navItems={BLUEPRINT.navigation.items.map((item) => ({
          page_id: item.page_id,
          label: item.label,
          icon: item.icon,
        }))}
        activePageId={activePage.id}
        onSelectPage={setActivePageId}
        primaryAction={
          <div className="flex items-center gap-2">
            {isLiveTouched ? (
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-emerald-500/15 text-emerald-700 border border-emerald-500/30">
                Live Data
              </span>
            ) : activeRecords.length > 0 ? (
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-500/15 text-amber-700 border border-amber-500/30">
                Demo Seed Data
              </span>
            ) : null}
            {activeRecords.length === 0 && (
              <Button variant="secondary" onClick={handleLoadSampleSeedData}>
                Load Sample Data
              </Button>
            )}
            {activeRecords.length > 0 && (
              <Button variant="secondary" onClick={handleExportJsonData}>
                Export Data
              </Button>
            )}
            <Button variant="primary" onClick={openCreateModal}>
              + {activePage.primary_actions[0] || `New ${activeEntity.singular_label}`}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {toastMsg && (
            <div className="flex justify-between items-center">
              <Toast message={toastMsg} tone="success" />
              <Button variant="ghost" onClick={() => setToastMsg(null)}>Dismiss</Button>
            </div>
          )}
          <AdaptiveLayoutRenderer
            page={activePage}
            entity={activeEntity}
            records={activeRecords}
            onOpenCreate={openCreateModal}
            onDeleteRecord={handleDeleteRecord}
            onToggleBoolean={handleToggleBoolean}
          />
        </div>
      </AdaptiveAppShell>

      <Modal
        open={isModalOpen}
        title={`Add ${activeEntity.singular_label}`}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-3">
          {activeEntity.fields.map((fld) => (
            <FormField key={fld.name} label={fld.label} required={fld.required}>
              {fld.field_type === 'enum' && fld.enum_values ? (
                <Select
                  value={String(formState[fld.name] ?? fld.enum_values[0] ?? '')}
                  options={fld.enum_values.map((v) => ({ value: v, label: v }))}
                  onChange={(val) => setFormState((prev) => ({ ...prev, [fld.name]: val }))}
                />
              ) : (
                <Input
                  type={
                    NUMERIC_TYPES.has(fld.field_type)
                      ? 'number'
                      : fld.field_type === 'date'
                        ? 'date'
                        : 'text'
                  }
                  value={String(formState[fld.name] ?? '')}
                  placeholder={`Enter ${fld.label}`}
                  onChange={(val) =>
                    setFormState((prev) => ({
                      ...prev,
                      [fld.name]: NUMERIC_TYPES.has(fld.field_type) ? Number(val) : val,
                    }))
                  }
                />
              )}
            </FormField>
          ))}
          <div className="flex justify-end gap-2 pt-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCreateRecord}>
              Save {activeEntity.singular_label}
            </Button>
          </div>
        </div>
      </Modal>
      
    </div>
  );
}
