"""FastAPI backend for LedgerFlow Monthly Totals — Deterministic CSV batch ingestion, validation, and monthly revenue aggregation."""

import json
from typing import Any, Optional
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import TransactionBatchModel, RejectedRecordModel, AutomationExecutionModel
from seed import seed_database
from engine import execute_automation_pipeline

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='LedgerFlow Monthly Totals',
    description='Deterministic CSV batch ingestion, validation, and monthly revenue aggregation',
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class TransactionBatchCreate(BaseModel):
    batch_code: str = ''
    reporting_month: str = ''
    source_csv_file: str = ''
    total_amount: float = 0.0
    valid_rows: int = 0
    status: str = 'Verified'

class TransactionBatchUpdate(BaseModel):
    batch_code: Optional[str] = None
    reporting_month: Optional[str] = None
    source_csv_file: Optional[str] = None
    total_amount: Optional[float] = None
    valid_rows: Optional[int] = None
    status: Optional[str] = None

def _serialize_transaction_batch(item: TransactionBatchModel) -> dict[str, Any]:
    return {"id": item.id, "batch_code": getattr(item, "batch_code"), "reporting_month": getattr(item, "reporting_month"), "source_csv_file": getattr(item, "source_csv_file"), "total_amount": getattr(item, "total_amount"), "valid_rows": getattr(item, "valid_rows"), "status": getattr(item, "status")}

@app.get("/api/transaction_batch")
def list_transaction_batch(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(TransactionBatchModel).order_by(TransactionBatchModel.created_at.desc()).all()
    return [_serialize_transaction_batch(r) for r in rows]

@app.post("/api/transaction_batch", status_code=201)
def create_transaction_batch(
    payload: TransactionBatchCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = TransactionBatchModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_transaction_batch(record)

@app.put("/api/transaction_batch/{item_id}")
def update_transaction_batch(
    item_id: str, payload: TransactionBatchUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(TransactionBatchModel).filter(TransactionBatchModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Transaction Batch not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_transaction_batch(record)

@app.delete("/api/transaction_batch/{item_id}")
def delete_transaction_batch(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(TransactionBatchModel).filter(TransactionBatchModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Transaction Batch not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

class RejectedRecordCreate(BaseModel):
    row_number: int = 0
    rejection_reason: str = ''
    raw_payload: str = ''
    batch_id: str = ''

class RejectedRecordUpdate(BaseModel):
    row_number: Optional[int] = None
    rejection_reason: Optional[str] = None
    raw_payload: Optional[str] = None
    batch_id: Optional[str] = None

def _serialize_rejected_record(item: RejectedRecordModel) -> dict[str, Any]:
    return {"id": item.id, "row_number": getattr(item, "row_number"), "rejection_reason": getattr(item, "rejection_reason"), "raw_payload": getattr(item, "raw_payload"), "batch_id": getattr(item, "batch_id")}

@app.get("/api/rejected_record")
def list_rejected_record(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.query(RejectedRecordModel).order_by(RejectedRecordModel.created_at.desc()).all()
    return [_serialize_rejected_record(r) for r in rows]

@app.post("/api/rejected_record", status_code=201)
def create_rejected_record(
    payload: RejectedRecordCreate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = RejectedRecordModel(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize_rejected_record(record)

@app.put("/api/rejected_record/{item_id}")
def update_rejected_record(
    item_id: str, payload: RejectedRecordUpdate, db: Session = Depends(get_db)
) -> dict[str, Any]:
    record = db.query(RejectedRecordModel).filter(RejectedRecordModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Rejected Record not found"
        )
    for k, v in payload.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return _serialize_rejected_record(record)

@app.delete("/api/rejected_record/{item_id}")
def delete_rejected_record(
    item_id: str, db: Session = Depends(get_db)
) -> dict[str, str]:
    record = db.query(RejectedRecordModel).filter(RejectedRecordModel.id == item_id).first()
    if not record:
        raise HTTPException(
            status_code=404, detail="Rejected Record not found"
        )
    db.delete(record)
    db.commit()
    return {"status": "deleted", "id": item_id}

@app.post("/api/seed")
def api_seed_sample_data(db: Session = Depends(get_db)) -> dict[str, Any]:
    inserted = seed_database(db)
    return {"status": "seeded", "inserted": inserted}

@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {
        "status": "healthy",
        "app": 'LedgerFlow Monthly Totals',
        "archetype": 'analytics_dashboard',
    }

@app.post("/api/automations/run")
def run_domain_automation(db: Session = Depends(get_db)) -> dict[str, Any]:
    rows = db.query(TransactionBatchModel).all()
    serialized = [_serialize_transaction_batch(r) for r in rows]
    summary = execute_automation_pipeline(serialized)
    rec = AutomationExecutionModel(
        automation_id='auto-monthly-csv',
        status="completed",
        summary_json=json.dumps(summary),
    )
    db.add(rec)
    db.commit()
    return summary
