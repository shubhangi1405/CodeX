# LedgerFlow Monthly Totals

> Deterministic CSV batch ingestion, validation, and monthly revenue aggregation

## Product & Domain Summary
- **Product Kind**: Tabular File Ingestion & Monthly Revenue Reconciliation
- **Archetype**: `analytics_dashboard`
- **Primary Object**: `transaction_batch`
- **Target Audience**: Finance analysts and revenue operations controllers (Desktop reconciliation workstation during monthly close)
- **Navigation Pattern**: `top_tabs`
- **Home Page**: `monthly-kpis` (`stat_tiles_with_charts`)

## Design Direction (`ledger_precision`)
- **Color Mode**: `light` | **Primary**: `#0F3D5E` | **Surface**: `#F8FAFC`
- **Typography**: Heading `IBM Plex Sans` · Body `IBM Plex Sans` · Mono `IBM Plex Mono`
- **Shape & Density**: Radius `sharp` · Density `compact`
- **Rationale**: Finance analysts reconciling monthly CSV exports work in bright spreadsheets and need IBM Plex Sans tabular numerals, compact tables, and deep navy contrast.

## Domain Entities
- **Transaction Batches** (`transaction_batch`): `batch_code` (string), `reporting_month` (string), `source_csv_file` (file_ingest), `total_amount` (currency), `valid_rows` (integer), `status` (enum)
- **Rejected Records** (`rejected_record`): `row_number` (integer), `rejection_reason` (string), `raw_payload` (text), `batch_id` (string)

## Application Screens
- **Monthly Revenue KPIs** (`/monthly-kpis`) — Layout: `stat_tiles_with_charts`
- **Batch Ledger Table** (`/batch-ledger`) — Layout: `data_table_with_filters`
- **Rejected Row Quarantine** (`/rejected-quarantine`) — Layout: `data_table_with_filters`

## API Endpoints
- `GET /api/transaction_batch`
- `POST /api/transaction_batch`
- `PUT /api/transaction_batch/{item_id}`
- `DELETE /api/transaction_batch/{item_id}`
- `GET /api/rejected_record`
- `POST /api/rejected_record`
- `PUT /api/rejected_record/{item_id}`
- `DELETE /api/rejected_record/{item_id}`
- `POST /api/seed`
- `GET /api/health`
- `POST /api/automations/run`

## SQLAlchemy Models
- `TransactionBatchModel`
- `RejectedRecordModel`
- `AutomationExecutionModel`

## Local Execution

### 1. Instant Standalone UI
Open `standalone_app.html` directly in any browser (zero external CDN dependencies).

### 2. Backend API (`FastAPI` + `SQLite`)
```bash
cd backend
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### 3. React + Vite Frontend
```bash
cd frontend
npm install
npm run dev
```
