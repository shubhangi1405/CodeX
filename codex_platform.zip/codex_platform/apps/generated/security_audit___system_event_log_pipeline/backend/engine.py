import csv
import hashlib
import io
import json
from typing import Any

WORKFLOW_SPEC = {
  "id": "wf-canonical-csv",
  "name": "Security Audit & System Event Log Pipeline",
  "version": 1,
  "description": "Validates system event logs, verifies timestamp formatting, and creates monthly audit summaries.",
  "trigger": {
    "id": "trig-upload",
    "type": "manual_upload",
    "config": {
      "accepted_extensions": [
        ".csv"
      ]
    }
  },
  "inputs": [
    {
      "name": "file_in",
      "data_type": "file",
      "table_schema": null
    }
  ],
  "nodes": [
    {
      "id": "node-read",
      "type": "ingest.read_csv",
      "label": "Read CSV File",
      "category": "ingest",
      "config": {
        "delimiter": ",",
        "has_header": true,
        "encoding": "utf-8"
      },
      "input_ports": [
        {
          "name": "file_in",
          "data_type": "file",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "table_out",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-req",
      "type": "validate.required_fields",
      "label": "Validate Required Fields",
      "category": "validate",
      "config": {
        "required_columns": [
          "date",
          "amount"
        ],
        "rejection_strategy": "drop"
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "valid_out",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "rejected_out",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-types",
      "type": "validate.type_check",
      "label": "Coerce & Check Types",
      "category": "validate",
      "config": {
        "column_types": {
          "amount": "number",
          "date": "string"
        },
        "coerce": true
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "valid_out",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "rejected_out",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-filter",
      "type": "transform.filter",
      "label": "Filter Positive Amounts",
      "category": "transform",
      "config": {
        "expression": "amount > 0"
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "matched_out",
          "data_type": "table",
          "table_schema": null
        },
        {
          "name": "unmatched_out",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-monthly",
      "type": "aggregate.monthly_totals",
      "label": "Calculate Monthly Totals",
      "category": "aggregate",
      "config": {
        "date_column": "date",
        "amount_column": "amount"
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "table_out",
          "data_type": "table",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-assert",
      "type": "quality.assert",
      "label": "Assert Rows Exist",
      "category": "quality",
      "config": {
        "rule": "row_count > 0"
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "passed_out",
          "data_type": "boolean",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-report",
      "type": "output.report",
      "label": "Generate Monthly Report",
      "category": "output",
      "config": {
        "title": "Monthly Revenue Report",
        "chart_type": "bar"
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "report_out",
          "data_type": "report",
          "table_schema": null
        }
      ]
    },
    {
      "id": "node-export",
      "type": "output.export_csv",
      "label": "Export Totals CSV",
      "category": "output",
      "config": {
        "filename_template": "monthly_totals.csv"
      },
      "input_ports": [
        {
          "name": "table_in",
          "data_type": "table",
          "table_schema": null
        }
      ],
      "output_ports": [
        {
          "name": "file_out",
          "data_type": "file",
          "table_schema": null
        }
      ]
    }
  ],
  "edges": [
    {
      "id": "e1",
      "from_node": "node-read",
      "from_port": "table_out",
      "to_node": "node-req",
      "to_port": "table_in"
    },
    {
      "id": "e2",
      "from_node": "node-req",
      "from_port": "valid_out",
      "to_node": "node-types",
      "to_port": "table_in"
    },
    {
      "id": "e3",
      "from_node": "node-types",
      "from_port": "valid_out",
      "to_node": "node-filter",
      "to_port": "table_in"
    },
    {
      "id": "e4",
      "from_node": "node-filter",
      "from_port": "matched_out",
      "to_node": "node-monthly",
      "to_port": "table_in"
    },
    {
      "id": "e5",
      "from_node": "node-monthly",
      "from_port": "table_out",
      "to_node": "node-assert",
      "to_port": "table_in"
    },
    {
      "id": "e6",
      "from_node": "node-monthly",
      "from_port": "table_out",
      "to_node": "node-report",
      "to_port": "table_in"
    },
    {
      "id": "e7",
      "from_node": "node-monthly",
      "from_port": "table_out",
      "to_node": "node-export",
      "to_port": "table_in"
    }
  ],
  "outputs": [
    {
      "name": "report",
      "data_type": "report",
      "table_schema": null
    },
    {
      "name": "csv_file",
      "data_type": "file",
      "table_schema": null
    }
  ],
  "tests": []
}


class EmbeddedWorkflowEngine:
    @staticmethod
    def execute(csv_data: str) -> dict[str, Any]:
        reader = csv.DictReader(io.StringIO(csv_data))
        raw_rows = list(reader)
        valid_rows = []
        rejected_rows = []

        for idx, row in enumerate(raw_rows):
            date = row.get("date", "").strip()
            amt_str = row.get("amount", "").strip()
            cat = row.get("category", "").strip()
            if not date or not amt_str:
                rejected_rows.append({
                    "row_index": idx + 1,
                    "reason": "Missing required date or amount",
                    "data": row,
                })
                continue
            try:
                amt = float(amt_str.replace("$", "").replace(",", ""))
                if amt <= 0:
                    rejected_rows.append({
                        "row_index": idx + 1,
                        "reason": "Amount must be strictly positive (> 0)",
                        "data": row,
                    })
                    continue
                valid_rows.append({"date": date, "amount": amt, "category": cat})
            except ValueError:
                rejected_rows.append({
                    "row_index": idx + 1,
                    "reason": f"Invalid numeric amount format: {amt_str}",
                    "data": row,
                })

        monthly = {}
        for r in valid_rows:
            month = r["date"][:7]
            if month not in monthly:
                monthly[month] = {"month": month, "total_amount": 0.0, "record_count": 0}
            monthly[month]["total_amount"] += r["amount"]
            monthly[month]["record_count"] += 1

        monthly_list = sorted(monthly.values(), key=lambda x: x["month"])
        for m in monthly_list:
            m["total_amount"] = round(m["total_amount"], 2)

        total_revenue = round(sum(m["total_amount"] for m in monthly_list), 2)
        out_bytes = json.dumps(monthly_list, sort_keys=True).encode("utf-8")
        out_hash = hashlib.sha256(out_bytes).hexdigest()

        return {
            "status": "success",
            "total_rows_in": len(raw_rows),
            "valid_count": len(valid_rows),
            "rejected_count": len(rejected_rows),
            "total_revenue": total_revenue,
            "monthly_breakdown": monthly_list,
            "rejected_rows": rejected_rows,
            "output_hash": out_hash,
        }
