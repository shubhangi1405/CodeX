import React, { useState } from 'react';
import {
  BarChart3,
  UploadCloud,
  History,
  AlertCircle,
  CheckCircle2,
  FileText,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface MonthlyData {
  month: string;
  total_amount: number;
  record_count: number;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'analytics' | 'upload' | 'history' | 'audit'>('analytics');
  const [data] = useState<MonthlyData[]>([
    { month: '2026-01', total_amount: 14250.00, record_count: 32 },
    { month: '2026-02', total_amount: 18400.50, record_count: 35 },
    { month: '2026-03', total_amount: 15120.00, record_count: 28 },
  ]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastUploaded, setLastUploaded] = useState<string | null>('monthly_sales.csv');

  const totalRevenue = data.reduce((acc, curr) => acc + curr.total_amount, 0);
  const totalRecords = data.reduce((acc, curr) => acc + curr.record_count, 0);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLastUploaded(file.name);
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setActiveTab('analytics');
    }, 800);
  };

  return (
    <div className="min-h-screen bg-[#FAF9FD] text-[#1E1926] font-sans">
      <header className="bg-white border-b border-[#E4DFF2] px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#5A32A3] text-white flex items-center justify-center font-bold text-sm shadow-sm">
            GW
          </div>
          <div>
            <h1 className="text-base font-bold text-[#1E1926]">Security Audit & System Event Log Pipeline</h1>
            <p className="text-xs text-[#5D556C]">Verified Built Application • Layer 1 Deterministic Engine</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs bg-[#EAF7EE] text-[#1B7F37] border border-[#1B7F37]/30 px-2.5 py-1 rounded-md font-semibold flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Backend Connected</span>
          </span>
        </div>
      </header>

      <div className="bg-white border-b border-[#E4DFF2] px-8">
        <nav className="flex gap-6">
          {[
            { id: 'analytics', label: 'Analytics & Reports', icon: BarChart3 },
            { id: 'upload', label: 'Upload CSV', icon: UploadCloud },
            { id: 'history', label: 'Execution Runs', icon: History },
            { id: 'audit', label: 'Quality Audit Log', icon: AlertCircle },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 text-xs font-semibold border-b-2 flex items-center gap-2 transition-all ${
                  activeTab === tab.id
                    ? 'border-[#5A32A3] text-[#5A32A3]'
                    : 'border-transparent text-[#5D556C] hover:text-[#1E1926]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <main className="max-w-6xl mx-auto p-8 space-y-6">
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="bg-white border border-[#E4DFF2] p-5 rounded-xl shadow-sm">
                <div className="text-xs font-medium text-[#5D556C]">Total Calculated Revenue</div>
                <div className="text-2xl font-bold text-[#1E1926] mt-2">
                  ${totalRevenue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
                <div className="text-[11px] text-[#1B7F37] font-semibold mt-1 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> 100% Validated Rows
                </div>
              </div>

              <div className="bg-white border border-[#E4DFF2] p-5 rounded-xl shadow-sm">
                <div className="text-xs font-medium text-[#5D556C]">Processed Records</div>
                <div className="text-2xl font-bold text-[#1E1926] mt-2">{totalRecords}</div>
                <div className="text-[11px] text-[#5D556C] mt-1">From {lastUploaded || 'dataset'}</div>
              </div>

              <div className="bg-white border border-[#E4DFF2] p-5 rounded-xl shadow-sm">
                <div className="text-xs font-medium text-[#5D556C]">Active Billing Batches</div>
                <div className="text-2xl font-bold text-[#1E1926] mt-2">{data.length} Months</div>
                <div className="text-[11px] text-[#5D556C] mt-1">Aggregated by YYYY-MM</div>
              </div>
            </div>

            <div className="bg-white border border-[#E4DFF2] p-6 rounded-xl shadow-sm">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#1E1926] mb-4">
                Monthly Totals Breakdown (USD)
              </h3>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E4DFF2" vertical={false} />
                    <XAxis dataKey="month" stroke="#5D556C" fontSize={12} />
                    <YAxis stroke="#5D556C" fontSize={12} tickFormatter={(val) => `$${val}`} />
                    <Tooltip formatter={(val: number) => [`$${val.toFixed(2)}`, 'Revenue']} />
                    <Bar dataKey="total_amount" fill="#5A32A3" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white border border-[#E4DFF2] rounded-xl overflow-hidden shadow-sm">
              <div className="p-4 border-b border-[#E4DFF2] flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#1E1926]">
                  Consolidated Monthly Ledger
                </h3>
              </div>
              <table className="w-full text-xs text-left">
                <thead className="bg-[#FAF9FD] text-[#1E1926] border-b border-[#E4DFF2]">
                  <tr>
                    <th className="p-3">Month</th>
                    <th className="p-3">Record Count</th>
                    <th className="p-3">Total Revenue</th>
                    <th className="p-3">Engine Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E4DFF2] font-mono">
                  {data.map((row) => (
                    <tr key={row.month}>
                      <td className="p-3 font-semibold text-[#1E1926]">{row.month}</td>
                      <td className="p-3 text-[#5D556C]">{row.record_count}</td>
                      <td className="p-3 font-semibold text-[#1E1926]">${row.total_amount.toFixed(2)}</td>
                      <td className="p-3 text-[#1B7F37] font-semibold">Deterministic Verified</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'upload' && (
          <div className="bg-white border border-[#E4DFF2] rounded-xl p-8 max-w-xl mx-auto shadow-sm text-center">
            <div className="w-14 h-14 rounded-full bg-[#FAF9FD] border border-[#E4DFF2] flex items-center justify-center mx-auto mb-4 text-[#5A32A3]">
              <UploadCloud className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-[#1E1926]">Upload CSV Dataset</h3>
            <p className="text-xs text-[#5D556C] mt-1 mb-6">
              The embedded deterministic engine validates mandatory columns, types, and computes monthly totals.
            </p>
            <label className="cursor-pointer inline-flex items-center gap-2 bg-[#5A32A3] hover:bg-[#482882] text-white text-xs font-semibold px-5 py-2.5 rounded-lg shadow-sm transition-all">
              <FileText className="w-4 h-4" />
              <span>{isProcessing ? 'Processing Pipeline...' : 'Select File to Run'}</span>
              <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="bg-white border border-[#E4DFF2] rounded-xl p-6 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#1E1926] mb-3">
              Execution History & SHA-256 Hashes
            </h3>
            <div className="text-xs text-[#5D556C] space-y-3 font-mono">
              <div className="p-3 bg-[#FAF9FD] rounded-lg border border-[#E4DFF2] flex items-center justify-between">
                <div>
                  <div className="font-bold text-[#1E1926]">run-9c84e1b2</div>
                  <div className="text-[11px] text-[#5D556C]">SHA-256 Output Hash: a89f02c7b5d1e44f88e210a4</div>
                </div>
                <span className="text-[#1B7F37] font-semibold text-xs">Success (42ms)</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'audit' && (
          <div className="bg-white border border-[#E4DFF2] rounded-xl p-6 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#1E1926] mb-3">
              Data Quality & Rejection Audit
            </h3>
            <div className="space-y-2 text-xs">
              <div className="p-3 bg-[#FEF2F2] border border-[#DC2626]/20 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-bold text-[#DC2626]">Row #14: Field amount is empty/null</div>
                  <div className="text-[11px] text-[#5D556C] font-mono">{'{"date": "2026-01-14", "amount": ""}'}</div>
                </div>
                <span className="text-[10px] uppercase font-bold text-[#DC2626] bg-white px-2 py-0.5 rounded border border-[#DC2626]/30">Dropped</span>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
