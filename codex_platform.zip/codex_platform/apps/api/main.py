from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from apps.api.config import settings
from apps.api.routes import (
    compiler,
    generate,
    health,
    projects,
    recommendations,
    runs,
    tests,
    workflows,
)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Deterministic workflow engine and AI compiler backend for CodeX",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="/api")
app.include_router(projects.router, prefix="/api")
app.include_router(compiler.router, prefix="/api")
app.include_router(workflows.router, prefix="/api")
app.include_router(tests.router, prefix="/api")
app.include_router(recommendations.router, prefix="/api")
app.include_router(runs.router, prefix="/api")
app.include_router(generate.router, prefix="/api")


@app.get("/")
def root() -> dict[str, str]:
    return {
        "message": "Welcome to CodeX API",
        "docs_url": "/docs",
        "health_check": "/api/health",
    }
