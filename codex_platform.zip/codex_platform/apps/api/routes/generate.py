import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

from apps.api.database import SessionLocal
from apps.api.models import AdaptiveGenerationRecord
from engine.spec import WorkflowSpec
from generators.app_generator import AppGenerator
from generators.blueprint.archetypes import resolve_benchmark_bundle
from generators.blueprint.compiler import apply_natural_language_restyle
from generators.blueprint.schemas import AppBlueprint
from generators.design.directions import (
    CURATED_DIRECTION_PROFILES,
    list_curated_directions,
)
from generators.design.fingerprint import compute_fingerprint, fingerprint_distance
from generators.design.schemas import DesignDirection
from generators.schemas import GeneratedAppManifest

router = APIRouter(prefix="/generate", tags=["generate"])


class GenerateAppRequest(BaseModel):
    workflow: WorkflowSpec
    direction_id: Optional[str] = None
    output_base_dir: str = "apps/generated"
    blueprint: Optional[AppBlueprint] = None
    project_id: Optional[str] = None


class RestyleAppRequest(BaseModel):
    project_id: str
    instruction: Optional[str] = None
    direction_id: Optional[str] = None
    output_base_dir: str = "apps/generated"


class RegenerateLookRequest(BaseModel):
    project_id: str
    output_base_dir: str = "apps/generated"


class RevertLookRequest(BaseModel):
    project_id: str
    output_base_dir: str = "apps/generated"


class PersistedAdaptiveStateResponse(BaseModel):
    project_id: str
    app_name: str
    version: int
    domain_analysis_json: str
    app_blueprint_json: str
    design_direction_json: str
    design_proposals_json: str
    design_history_json: str
    look_fingerprint_json: str
    updated_at: str


def _save_adaptive_record(
    manifest: GeneratedAppManifest,
    workflow: Optional[WorkflowSpec],
    history: list[dict[str, object]],
) -> None:
    if manifest.blueprint is None or manifest.design_direction is None:
        return
    fp = compute_fingerprint(
        manifest.blueprint.domain,
        manifest.blueprint,
        manifest.design_direction,
    )
    db = SessionLocal()
    try:
        rec = (
            db.query(AdaptiveGenerationRecord)
            .filter(AdaptiveGenerationRecord.project_id == manifest.project_id)
            .first()
        )
        now_iso = datetime.now(timezone.utc).isoformat()
        wf_json = json.dumps(workflow.model_dump()) if workflow else "{}"
        domain_json = json.dumps(manifest.blueprint.domain.model_dump())
        bp_json = json.dumps(manifest.blueprint.model_dump())
        dir_json = json.dumps(manifest.design_direction.model_dump())
        prop_json = json.dumps([d.model_dump() for d in manifest.direction_proposals])
        hist_json = json.dumps(history)
        fp_json = json.dumps(fp.model_dump())

        if rec is None:
            rec = AdaptiveGenerationRecord(
                project_id=manifest.project_id,
                app_name=manifest.name,
                version=manifest.version,
                workflow_json=wf_json,
                domain_analysis_json=domain_json,
                app_blueprint_json=bp_json,
                design_direction_json=dir_json,
                design_proposals_json=prop_json,
                design_history_json=hist_json,
                look_fingerprint_json=fp_json,
                updated_at=now_iso,
            )
            db.add(rec)
        else:
            rec.app_name = manifest.name
            rec.version = manifest.version
            if workflow is not None:
                rec.workflow_json = wf_json
            rec.domain_analysis_json = domain_json
            rec.app_blueprint_json = bp_json
            rec.design_direction_json = dir_json
            rec.design_proposals_json = prop_json
            rec.design_history_json = hist_json
            rec.look_fingerprint_json = fp_json
            rec.updated_at = now_iso
        db.commit()
    finally:
        db.close()


def _load_adaptive_record(project_id: str) -> AdaptiveGenerationRecord:
    db = SessionLocal()
    try:
        rec = (
            db.query(AdaptiveGenerationRecord)
            .filter(AdaptiveGenerationRecord.project_id == project_id)
            .first()
        )
        if rec is None:
            raise HTTPException(
                status_code=404,
                detail=f"Adaptive generation state for '{project_id}' not found.",
            )
        db.expunge(rec)
        return rec
    finally:
        db.close()


@router.post("", response_model=GeneratedAppManifest)
def api_generate_app(req: GenerateAppRequest) -> GeneratedAppManifest:
    try:
        search_hint = f"{req.workflow.name} {req.workflow.description}"
        if req.blueprint is not None:
            active_bp = req.blueprint
            bundle = resolve_benchmark_bundle(
                f"{active_bp.app_name} {active_bp.domain.product_kind} {active_bp.domain.primary_object} {search_hint}"
            )
        else:
            bundle = resolve_benchmark_bundle(search_hint)
            active_bp = bundle.blueprint

        chosen_dir: Optional[DesignDirection] = None
        if req.direction_id:
            for prop in bundle.direction_proposals:
                if prop.direction_id == req.direction_id:
                    chosen_dir = prop
                    break
            if chosen_dir is None and req.direction_id in CURATED_DIRECTION_PROFILES:
                chosen_dir = CURATED_DIRECTION_PROFILES[req.direction_id].direction.model_copy(
                    deep=True
                )

        manifest = AppGenerator.generate(
            req.workflow,
            output_base_dir=req.output_base_dir,
            blueprint=active_bp,
            direction=chosen_dir or bundle.primary_direction,
        )
        _save_adaptive_record(manifest=manifest, workflow=req.workflow, history=[])
        return manifest
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Code generation failed: {str(e)}") from e


@router.post("/restyle", response_model=GeneratedAppManifest)
def api_restyle_app(req: RestyleAppRequest) -> GeneratedAppManifest:
    rec = _load_adaptive_record(req.project_id)
    blueprint = AppBlueprint.model_validate(json.loads(rec.app_blueprint_json))
    current_dir = DesignDirection.model_validate(json.loads(rec.design_direction_json))
    proposals = [
        DesignDirection.model_validate(d) for d in json.loads(rec.design_proposals_json or "[]")
    ]
    history: list[dict[str, object]] = json.loads(rec.design_history_json or "[]")
    wf_raw = json.loads(rec.workflow_json or "{}")
    workflow = WorkflowSpec.model_validate(wf_raw) if wf_raw else None

    next_dir: Optional[DesignDirection] = None
    if req.direction_id:
        for p in proposals:
            if p.direction_id == req.direction_id:
                next_dir = p.model_copy(deep=True)
                break
        if next_dir is None and req.direction_id in CURATED_DIRECTION_PROFILES:
            next_dir = CURATED_DIRECTION_PROFILES[req.direction_id].direction.model_copy(deep=True)
        if next_dir is None:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown direction_id '{req.direction_id}'.",
            )
    elif req.instruction and req.instruction.strip():
        next_dir, _ = apply_natural_language_restyle(
            current_direction=current_dir,
            instruction=req.instruction.strip(),
            blueprint=blueprint,
        )
    else:
        raise HTTPException(
            status_code=400,
            detail="Either 'instruction' or 'direction_id' must be provided for restyling.",
        )

    history.append(current_dir.model_dump())
    manifest = AppGenerator.generate_from_blueprint(
        blueprint=blueprint,
        direction=next_dir,
        output_base_dir=req.output_base_dir,
        project_id_override=req.project_id,
        name_override=rec.app_name,
        version=rec.version,
        workflow=workflow,
        direction_proposals=proposals,
        previous_direction=current_dir,
        design_history_count=len(history),
        restyle_only=True,
    )
    _save_adaptive_record(manifest=manifest, workflow=workflow, history=history)
    return manifest


@router.post("/regenerate-look", response_model=GeneratedAppManifest)
def api_regenerate_look(req: RegenerateLookRequest) -> GeneratedAppManifest:
    rec = _load_adaptive_record(req.project_id)
    blueprint = AppBlueprint.model_validate(json.loads(rec.app_blueprint_json))
    current_dir = DesignDirection.model_validate(json.loads(rec.design_direction_json))
    proposals = [
        DesignDirection.model_validate(d) for d in json.loads(rec.design_proposals_json or "[]")
    ]
    history: list[dict[str, object]] = json.loads(rec.design_history_json or "[]")
    wf_raw = json.loads(rec.workflow_json or "{}")
    workflow = WorkflowSpec.model_validate(wf_raw) if wf_raw else None

    curr_fp = compute_fingerprint(blueprint.domain, blueprint, current_dir)
    candidates = [*proposals, *list_curated_directions()]
    next_dir = current_dir
    best_dist = -1
    for cand in candidates:
        if cand.direction_id == current_dir.direction_id:
            continue
        cand_fp = compute_fingerprint(blueprint.domain, blueprint, cand)
        dist = fingerprint_distance(curr_fp, cand_fp)
        if dist > best_dist:
            best_dist = dist
            next_dir = cand.model_copy(deep=True)
            if dist >= 3:
                break

    history.append(current_dir.model_dump())
    manifest = AppGenerator.generate_from_blueprint(
        blueprint=blueprint,
        direction=next_dir,
        output_base_dir=req.output_base_dir,
        project_id_override=req.project_id,
        name_override=rec.app_name,
        version=rec.version,
        workflow=workflow,
        direction_proposals=proposals,
        previous_direction=current_dir,
        design_history_count=len(history),
        restyle_only=True,
    )
    _save_adaptive_record(manifest=manifest, workflow=workflow, history=history)
    return manifest


@router.post("/revert-look", response_model=GeneratedAppManifest)
def api_revert_look(req: RevertLookRequest) -> GeneratedAppManifest:
    rec = _load_adaptive_record(req.project_id)
    blueprint = AppBlueprint.model_validate(json.loads(rec.app_blueprint_json))
    current_dir = DesignDirection.model_validate(json.loads(rec.design_direction_json))
    proposals = [
        DesignDirection.model_validate(d) for d in json.loads(rec.design_proposals_json or "[]")
    ]
    history: list[dict[str, object]] = json.loads(rec.design_history_json or "[]")
    if not history:
        raise HTTPException(
            status_code=400,
            detail="No previous design direction in history to revert to.",
        )

    restored_raw = history.pop()
    restored_dir = DesignDirection.model_validate(restored_raw)
    wf_raw = json.loads(rec.workflow_json or "{}")
    workflow = WorkflowSpec.model_validate(wf_raw) if wf_raw else None

    manifest = AppGenerator.generate_from_blueprint(
        blueprint=blueprint,
        direction=restored_dir,
        output_base_dir=req.output_base_dir,
        project_id_override=req.project_id,
        name_override=rec.app_name,
        version=rec.version,
        workflow=workflow,
        direction_proposals=proposals,
        previous_direction=current_dir,
        design_history_count=len(history),
        restyle_only=True,
    )
    _save_adaptive_record(manifest=manifest, workflow=workflow, history=history)
    return manifest


@router.get("/state/{project_id}", response_model=PersistedAdaptiveStateResponse)
def api_get_adaptive_state(project_id: str) -> PersistedAdaptiveStateResponse:
    rec = _load_adaptive_record(project_id)
    return PersistedAdaptiveStateResponse(
        project_id=rec.project_id,
        app_name=rec.app_name,
        version=rec.version,
        domain_analysis_json=rec.domain_analysis_json,
        app_blueprint_json=rec.app_blueprint_json,
        design_direction_json=rec.design_direction_json,
        design_proposals_json=rec.design_proposals_json,
        design_history_json=rec.design_history_json,
        look_fingerprint_json=rec.look_fingerprint_json,
        updated_at=rec.updated_at,
    )


@router.get("/export/{project_id}")
def api_export_app_zip(project_id: str) -> FileResponse:
    zip_path = Path("apps/generated") / f"{project_id}.zip"
    if not zip_path.exists():
        raise HTTPException(status_code=404, detail=f"Export for '{project_id}' not found.")

    return FileResponse(
        path=str(zip_path),
        filename=f"{project_id}.zip",
        media_type="application/zip",
    )


@router.get("/preview/{project_id}")
def api_preview_standalone_html(project_id: str) -> FileResponse:
    html_path = Path("apps/generated") / project_id / "standalone_app.html"
    if not html_path.exists():
        raise HTTPException(
            status_code=404, detail=f"Standalone HTML for '{project_id}' not found."
        )

    return FileResponse(
        path=str(html_path),
        media_type="text/html",
    )
