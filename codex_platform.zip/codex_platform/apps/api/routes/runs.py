from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from engine.executor import WorkflowExecutor
from engine.runs.storage import RunStorage
from engine.spec import WorkflowSpec
from engine.types import NodeResult, RunRecord
from engine.versioning.diff import WorkflowDiff, WorkflowVersionManager

router = APIRouter(prefix="/runs", tags=["runs"])
storage = RunStorage()


class ReplayRequest(BaseModel):
    new_inputs: Optional[dict[str, Any]] = None


class ReplayResponse(BaseModel):
    replayed_record: RunRecord
    bit_for_bit_identical: bool


class ExecuteNodeRequest(BaseModel):
    node_type: str
    node_id: str
    label: str
    config: dict[str, Any]
    inputs: dict[str, Any]


class WorkflowDiffRequest(BaseModel):
    old_workflow: WorkflowSpec
    new_workflow: WorkflowSpec


@router.get("", response_model=list[RunRecord])
def api_list_runs(workflow_id: Optional[str] = None) -> list[RunRecord]:
    return storage.list_runs(workflow_id)


@router.get("/{run_id}", response_model=RunRecord)
def api_get_run(run_id: str) -> RunRecord:
    item = storage.get_run(run_id)
    if not item:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found.")
    record, _ = item
    return record


@router.post("/{run_id}/replay", response_model=ReplayResponse)
def api_replay_run(run_id: str, req: Optional[ReplayRequest] = None) -> ReplayResponse:
    new_inputs = req.new_inputs if req else None
    try:
        replayed, identical = storage.replay_run(run_id, new_inputs)
        return ReplayResponse(
            replayed_record=replayed,
            bit_for_bit_identical=identical,
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e


@router.post("/execute-node", response_model=NodeResult)
def api_execute_node(req: ExecuteNodeRequest) -> NodeResult:
    executor = WorkflowExecutor()
    try:
        return executor.execute_single_node(
            node_type=req.node_type,
            node_id=req.node_id,
            label=req.label,
            config=req.config,
            inputs=req.inputs,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Node execution failed: {str(e)}") from e


@router.post("/diff", response_model=WorkflowDiff)
def api_diff_workflows(req: WorkflowDiffRequest) -> WorkflowDiff:
    return WorkflowVersionManager.compute_diff(req.old_workflow, req.new_workflow)
