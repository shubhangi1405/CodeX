from typing import Optional

from fastapi import APIRouter
from pydantic import BaseModel

from engine.spec import WorkflowSpec
from engine.testing.generator import TestCaseGenerator
from engine.testing.runner import WorkflowTestRunner
from engine.testing.schemas import TestCase, TestSuiteResult

router = APIRouter(prefix="/tests", tags=["tests"])


class GenerateTestsRequest(BaseModel):
    workflow: WorkflowSpec
    sample_csv: Optional[str] = None


class RunTestsRequest(BaseModel):
    workflow: WorkflowSpec
    tests: Optional[list[TestCase]] = None
    sample_csv: Optional[str] = None


@router.post("/generate", response_model=list[TestCase])
def api_generate_tests(req: GenerateTestsRequest) -> list[TestCase]:
    return TestCaseGenerator.generate_suite(req.workflow, req.sample_csv)


@router.post("/run", response_model=TestSuiteResult)
def api_run_tests(req: RunTestsRequest) -> TestSuiteResult:
    tests = req.tests
    if not tests:
        tests = TestCaseGenerator.generate_suite(req.workflow, req.sample_csv)

    runner = WorkflowTestRunner()
    return runner.run_suite(req.workflow, tests)
