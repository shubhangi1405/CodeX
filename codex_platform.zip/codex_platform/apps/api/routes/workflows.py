from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from engine.compiler.validator import WorkflowValidator
from engine.executor import WorkflowExecutor
from engine.spec import WorkflowSpec
from engine.types import RunRecord

router = APIRouter(prefix="/workflows", tags=["workflows"])


class ValidateWorkflowResponse(BaseModel):
    valid: bool
    errors: list[str]


class RunWorkflowRequest(BaseModel):
    workflow: WorkflowSpec
    initial_inputs: Optional[dict[str, Any]] = None


@router.post("/validate", response_model=ValidateWorkflowResponse)
def api_validate(spec_data: dict[str, Any]) -> ValidateWorkflowResponse:
    errors = WorkflowValidator.validate(spec_data)
    return ValidateWorkflowResponse(valid=len(errors) == 0, errors=errors)


@router.post("/run", response_model=RunRecord)
def api_run_workflow(req: RunWorkflowRequest) -> RunRecord:
    executor = WorkflowExecutor()
    inputs = req.initial_inputs or {}

    # If no file is provided, synthesize domain-appropriate CSV or load canonical monthly_sales.csv
    has_csv = any(n.type == "ingest.read_csv" for n in req.workflow.nodes)
    if "file" not in inputs and "file_in" not in inputs and has_csv:
        from engine.testing.generator import TestCaseGenerator

        wf_text = f"{req.workflow.id} {req.workflow.name}".lower()
        sample_path = Path("samples/monthly_sales.csv")
        if (
            req.workflow.id == "wf-csv-monthly-totals-v1" or "sales" in wf_text
        ) and sample_path.exists():
            sample_data = sample_path.read_text(encoding="utf-8")
        else:
            sample_data = TestCaseGenerator.build_domain_csv(req.workflow)
        inputs["file"] = sample_data
        inputs["file_in"] = sample_data

    try:
        record = executor.execute(req.workflow, inputs)
        from apps.api.routes.runs import storage

        storage.save_run(record, req.workflow)
        return record
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Execution failed: {str(e)}") from e


class WorkflowDiffRequest(BaseModel):
    old_workflow: WorkflowSpec
    new_workflow: WorkflowSpec


@router.post("/diff", response_model=Any)
def api_diff_workflows(req: WorkflowDiffRequest) -> Any:
    from engine.versioning.diff import WorkflowVersionManager

    return WorkflowVersionManager.compute_diff(req.old_workflow, req.new_workflow)
