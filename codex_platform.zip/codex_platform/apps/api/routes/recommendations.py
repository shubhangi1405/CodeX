from typing import Optional

from fastapi import APIRouter
from pydantic import BaseModel

from apps.api.routes.compiler import _get_provider
from engine.compiler.schemas import ProductUnderstanding
from engine.recommender.engine import FeatureRecommender
from engine.recommender.schemas import FeatureRecommendation
from engine.spec import WorkflowSpec

router = APIRouter(prefix="/recommendations", tags=["recommendations"])


class GenerateRecommendationsRequest(BaseModel):
    understanding: ProductUnderstanding
    workflow: Optional[WorkflowSpec] = None
    provider: str = "mock"


class ApplyRecommendationsRequest(BaseModel):
    workflow: WorkflowSpec
    recommendations: list[FeatureRecommendation]


class ApplyRecommendationsResponse(BaseModel):
    workflow: WorkflowSpec
    applied_count: int


@router.post("/generate", response_model=list[FeatureRecommendation])
def api_generate_recommendations(
    req: GenerateRecommendationsRequest,
) -> list[FeatureRecommendation]:
    provider = _get_provider(req.provider)
    return FeatureRecommender.recommend_for_prompt(
        req.understanding, req.workflow, provider=provider
    )


@router.post("/apply", response_model=ApplyRecommendationsResponse)
def api_apply_recommendations(
    req: ApplyRecommendationsRequest,
) -> ApplyRecommendationsResponse:
    updated = FeatureRecommender.apply_decisions(req.workflow, req.recommendations)
    accepted = [r for r in req.recommendations if r.decision == "accepted"]
    return ApplyRecommendationsResponse(
        workflow=updated,
        applied_count=len(accepted),
    )
