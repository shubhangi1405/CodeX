import uuid
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from apps.api.database import SessionLocal
from apps.api.models import AdaptiveGenerationRecord

router = APIRouter(prefix="/projects", tags=["Projects"])


class ProjectCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=120)
    prompt: str = Field(..., min_length=1)


class ProjectResponse(BaseModel):
    id: str
    name: str
    prompt: str
    created_at: str
    status: str = "draft"
    current_step: int = 1
    domain_analysis_json: Optional[str] = None
    app_blueprint_json: Optional[str] = None
    design_direction_json: Optional[str] = None
    design_history_json: Optional[str] = None
    look_fingerprint_json: Optional[str] = None


# In-memory store for fast M0 bootstrap; enriched with adaptive DB records
_PROJECTS: dict[str, ProjectResponse] = {
    "default-sample": ProjectResponse(
        id="default-sample",
        name="CSV Monthly Totals Pipeline",
        prompt=(
            "Whenever a new CSV arrives, validate the records, identify missing fields, "
            "calculate monthly totals and create a report."
        ),
        created_at=datetime.now(timezone.utc).isoformat(),
        status="draft",
        current_step=1,
    ),
    "habit-tracker": ProjectResponse(
        id="habit-tracker",
        name="Habit Tracker & Streak Analytics",
        prompt=(
            "Build a daily habit tracker that logs habit check-ins, validates completion "
            "dates and streak points, filters missed days, calculates monthly streak "
            "consistency totals, and creates a habit progress report."
        ),
        created_at=datetime.now(timezone.utc).isoformat(),
        status="draft",
        current_step=1,
    ),
}


def _enrich_project_with_adaptive_state(proj: ProjectResponse) -> ProjectResponse:
    clean_slug = "".join(c if c.isalnum() else "_" for c in proj.name.lower()).strip("_")
    db = SessionLocal()
    try:
        rec = (
            db.query(AdaptiveGenerationRecord)
            .filter(AdaptiveGenerationRecord.project_id.in_([proj.id, clean_slug]))
            .first()
        )
        if rec:
            return proj.model_copy(
                update={
                    "domain_analysis_json": str(rec.domain_analysis_json),
                    "app_blueprint_json": str(rec.app_blueprint_json),
                    "design_direction_json": str(rec.design_direction_json),
                    "design_history_json": str(rec.design_history_json),
                    "look_fingerprint_json": str(rec.look_fingerprint_json),
                }
            )
    finally:
        db.close()
    return proj


@router.get("", response_model=List[ProjectResponse])
def list_projects() -> List[ProjectResponse]:
    return [_enrich_project_with_adaptive_state(p) for p in _PROJECTS.values()]


@router.post("", response_model=ProjectResponse, status_code=201)
def create_project(data: ProjectCreate) -> ProjectResponse:
    project_id = str(uuid.uuid4())
    proj = ProjectResponse(
        id=project_id,
        name=data.name,
        prompt=data.prompt,
        created_at=datetime.now(timezone.utc).isoformat(),
        status="draft",
        current_step=1,
    )
    _PROJECTS[project_id] = proj
    return proj


@router.get("/{project_id}", response_model=ProjectResponse)
def get_project(project_id: str) -> ProjectResponse:
    if project_id not in _PROJECTS:
        raise HTTPException(status_code=404, detail="Project not found")
    return _enrich_project_with_adaptive_state(_PROJECTS[project_id])
