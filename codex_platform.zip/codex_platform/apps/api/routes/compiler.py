import os
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from apps.api.config import settings
from engine.compiler.evolver import WorkflowEvolver
from engine.compiler.pipeline import clarify, compile_prompt_to_workflow, interpret
from engine.compiler.providers import (
    GeminiProvider,
    MockProvider,
    ModelProvider,
    OpenAICompatibleProvider,
)
from engine.compiler.schemas import CompilationResult, ProductUnderstanding
from engine.spec import WorkflowSpec
from engine.versioning.diff import WorkflowDiff


def _get_provider(provider_name: str) -> ModelProvider:
    name = provider_name.lower().strip()
    if name == "gemini":
        api_key = settings.GEMINI_API_KEY or os.environ.get("GEMINI_API_KEY", "")
        return GeminiProvider(api_key=api_key)
    elif name in ("openai", "ollama", "vllm"):
        api_key = settings.OPENAI_API_KEY or os.environ.get("OPENAI_API_KEY", "")
        base_url = settings.OPENAI_BASE_URL or os.environ.get(
            "OPENAI_BASE_URL", "https://api.openai.com/v1"
        )
        return OpenAICompatibleProvider(api_key=api_key, base_url=base_url)
    elif name == "mock":
        return MockProvider()
    else:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown provider '{provider_name}'. Supported: 'mock', 'gemini', 'openai'.",
        )


router = APIRouter(prefix="/compiler", tags=["compiler"])


class InterpretRequest(BaseModel):
    prompt: str = Field(..., min_length=3)
    provider: str = "mock"


class ClarifyRequest(BaseModel):
    understanding: ProductUnderstanding
    answers: dict[str, str]


class CompileRequest(BaseModel):
    prompt: str = Field(..., min_length=3)
    answers: Optional[dict[str, str]] = None
    understanding: Optional[ProductUnderstanding] = None
    provider: str = "mock"
    max_repairs: int = 3


class EvolveRequest(BaseModel):
    workflow: WorkflowSpec
    instruction: str = Field(..., min_length=2)
    provider: str = "mock"


class EvolveResponse(BaseModel):
    evolved_workflow: WorkflowSpec
    diff: WorkflowDiff
    validation_errors: list[str]


@router.post("/interpret", response_model=ProductUnderstanding)
def api_interpret(req: InterpretRequest) -> ProductUnderstanding:
    try:
        provider = _get_provider(req.provider)
        return interpret(req.prompt, provider)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/clarify", response_model=ProductUnderstanding)
def api_clarify(req: ClarifyRequest) -> ProductUnderstanding:
    try:
        return clarify(req.understanding, req.answers)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/compile", response_model=CompilationResult)
def api_compile(req: CompileRequest) -> CompilationResult:
    try:
        provider = _get_provider(req.provider)
        return compile_prompt_to_workflow(
            prompt=req.prompt,
            answers=req.answers,
            provider=provider,
            max_repairs=req.max_repairs,
            understanding=req.understanding,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/evolve", response_model=EvolveResponse)
def api_evolve(req: EvolveRequest) -> EvolveResponse:
    try:
        provider = _get_provider(req.provider)
        evolved_wf, diff, errors = WorkflowEvolver.evolve(
            current_wf=req.workflow,
            instruction=req.instruction,
            provider=provider,
        )
        return EvolveResponse(
            evolved_workflow=evolved_wf,
            diff=diff,
            validation_errors=errors,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e
