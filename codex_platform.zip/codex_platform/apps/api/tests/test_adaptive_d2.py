"""Unit tests for Milestone D2: Curated Design Direction Library & Token Writer."""

from generators.design.contrast import validate_and_adjust_palette
from generators.design.directions import (
    CURATED_DIRECTION_PROFILES,
    apply_bounded_adjustments,
    get_curated_direction,
    list_curated_directions,
)
from generators.design.schemas import ColorMode, DensityClass, RadiusClass
from generators.design.token_writer import (
    generate_design_tokens_css,
    generate_tailwind_config,
    render_brand_mark_svg,
    render_direction_token_sheet_html,
)


def test_at_least_10_curated_directions_defined_and_distinct() -> None:
    directions = list_curated_directions()
    assert len(directions) >= 10
    direction_ids = {d.direction_id for d in directions}
    assert len(direction_ids) >= 10

    voices = {d.copy_voice for d in directions}
    assert len(voices) == len(directions)


def test_every_curated_direction_renders_token_sheet_passing_wcag_contrast() -> None:
    for dir_id, profile in CURATED_DIRECTION_PROFILES.items():
        direction = profile.direction
        _, adjustments, pair_results = validate_and_adjust_palette(direction.palette)
        assert all(p.passed for p in pair_results), (
            f"Direction '{dir_id}' failed contrast checks: "
            f"{[p for p in pair_results if not p.passed]}"
        )
        assert len(adjustments) == 0

        css = generate_design_tokens_css(direction)
        assert f"--app-primary: {direction.palette.primary};" in css
        assert "--app-font-heading:" in css
        assert "prefers-reduced-motion: reduce" in css

        tw = generate_tailwind_config(direction)
        assert "var(--app-primary)" in tw
        assert "var(--app-radius-card)" in tw

        svg = render_brand_mark_svg(direction)
        assert svg.startswith("<svg")

        sheet_html = render_direction_token_sheet_html(direction)
        assert f"Token Sheet — {dir_id}" in sheet_html
        assert "FAIL" not in sheet_html
        assert "PASS" in sheet_html


def test_bounded_adjustments_preserve_wcag_aa_contrast() -> None:
    base = get_curated_direction("editorial_calm")
    adjusted = apply_bounded_adjustments(
        base,
        hue_shift_deg=45.0,
        radius_override=RadiusClass.ROUND,
        density_override=DensityClass.COMPACT,
        color_mode_override=ColorMode.DARK,
        monogram_override="HB",
    )
    assert adjusted.shape.radius_class == RadiusClass.ROUND
    assert adjusted.density == DensityClass.COMPACT
    assert adjusted.color_mode == ColorMode.DARK
    assert adjusted.brand_mark.monogram_letters == "HB"

    _, _, pair_results = validate_and_adjust_palette(adjusted.palette)
    assert all(p.passed for p in pair_results)
