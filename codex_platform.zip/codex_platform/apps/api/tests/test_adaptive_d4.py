"""Milestone D4 Tests: Blueprint compilation (Stages A-D), 8-idea diversity, and restyling."""

import json

from engine.compiler.providers import MockProvider
from generators.blueprint.archetypes import BENCHMARK_BUNDLES
from generators.blueprint.compiler import (
    apply_natural_language_restyle,
    compile_adaptive_app,
    load_design_system_prompt,
)
from generators.design.fingerprint import fingerprint_distance
from generators.design.schemas import ColorMode, DensityClass, LookFingerprint


def test_design_prompt_file_loaded_and_complete() -> None:
    prompt_text = load_design_system_prompt()
    assert "You are CodeX's Product Designer and Application Architect." in prompt_text
    assert "Start from the user's primary object and top 3 daily jobs." in prompt_text
    assert (
        "Only include a CSV upload screen if the user's product is explicitly about" in prompt_text
    )
    assert "WCAG AA contrast" in prompt_text


def test_all_eight_benchmark_ideas_compile_and_differ_by_at_least_four() -> None:
    eight_prompts = [
        "CSV ingestion with monthly totals",
        "daily habit tracker",
        "security event log viewer",
        "sports court booking",
        "hackathon team finder for students",
        "restaurant inventory",
        "clinic appointment scheduling",
        "freelance invoice tracker",
    ]

    provider = MockProvider()
    accumulated_fingerprints: list[LookFingerprint] = []
    bundles = []

    for prompt in eight_prompts:
        bundle = compile_adaptive_app(
            prompt=prompt,
            provider=provider,
            existing_fingerprints=accumulated_fingerprints,
        )
        assert bundle.validation_report.valid is True
        assert bundle.validation_report.diversity_passed is True
        assert len(bundle.direction_proposals) == 3
        # Proposals must represent 3 distinct directions
        prop_ids = {p.direction_id for p in bundle.direction_proposals}
        assert len(prop_ids) == 3

        # Only CSV prompt should have needs_automation or CSV copy
        if "csv" in prompt.lower():
            assert bundle.domain_analysis.needs_automation is True
            assert bundle.blueprint.has_file_ingest_entity() is True
            assert len(bundle.blueprint.automations) == 1
        else:
            assert bundle.domain_analysis.needs_automation is False
            assert bundle.blueprint.has_file_ingest_entity() is False
            assert len(bundle.blueprint.automations) == 0
            serialized_bp = json.dumps(bundle.blueprint.model_dump()).lower()
            assert "csv" not in serialized_bp

        accumulated_fingerprints.append(bundle.validation_report.fingerprint)
        bundles.append(bundle)

    # Assert pairwise distance >= 4 across all 28 pairs
    for i in range(len(accumulated_fingerprints)):
        for j in range(i + 1, len(accumulated_fingerprints)):
            dist = fingerprint_distance(accumulated_fingerprints[i], accumulated_fingerprints[j])
            assert dist >= 4, (
                f"Pair ({eight_prompts[i]}, {eight_prompts[j]}) had distance {dist} < 4: "
                f"{accumulated_fingerprints[i]} vs {accumulated_fingerprints[j]}"
            )


def test_diversity_collision_triggers_bounded_repair() -> None:
    provider = MockProvider()
    first = compile_adaptive_app(prompt="daily habit tracker", provider=provider)
    # Compile a second habit tracker against the first fingerprint: Stage D must shift look
    second = compile_adaptive_app(
        prompt="daily habit tracker",
        provider=provider,
        existing_fingerprints=[first.validation_report.fingerprint],
    )
    dist = fingerprint_distance(
        first.validation_report.fingerprint,
        second.validation_report.fingerprint,
    )
    assert dist >= 4
    assert second.validation_report.diversity_passed is True
    assert len(second.repair_log) >= 1


def test_natural_language_restyle_preserves_wcag_and_updates_tokens() -> None:
    bundle = BENCHMARK_BUNDLES["daily_habit_tracker"]
    bp = bundle.blueprint
    initial_dir = bundle.primary_direction

    # 1. "make it darker"
    dark_dir, dark_report = apply_natural_language_restyle(
        current_direction=initial_dir,
        instruction="make it darker with a night theme",
        blueprint=bp,
    )
    assert dark_dir.color_mode == ColorMode.DARK
    assert dark_report.valid is True
    assert all(p.passed for p in dark_report.contrast_pairs)

    # 2. "more playful"
    playful_dir, playful_report = apply_natural_language_restyle(
        current_direction=dark_dir,
        instruction="make it more playful and energetic",
        blueprint=bp,
    )
    assert playful_dir.direction_id == "playful_momentum"
    assert playful_report.valid is True

    # 3. "denser tables and use green"
    dense_green_dir, dense_report = apply_natural_language_restyle(
        current_direction=playful_dir,
        instruction="denser tables and use green",
        blueprint=bp,
    )
    assert dense_green_dir.density == DensityClass.COMPACT
    assert dense_report.valid is True
    assert all(p.passed for p in dense_report.contrast_pairs)
