from fastapi.testclient import TestClient

from apps.api.main import app
from engine.compiler.pipeline import draft_workflow
from engine.compiler.providers import MockProvider
from engine.compiler.schemas import ProductUnderstanding

client = TestClient(app)


def test_api_generate_tests_endpoint() -> None:
    understanding = ProductUnderstanding(
        goal="Validate CSV and generate report",
        summary="A pipeline for monthly sales.",
        target_users=["Auditor"],
        inputs=[],
        outputs=[],
        business_rules=[],
        assumptions=[],
        clarifications=[],
    )
    workflow = draft_workflow(understanding, provider=MockProvider())

    res = client.post(
        "/api/tests/generate",
        json={"workflow": workflow.model_dump(mode="json")},
    )
    assert res.status_code == 200
    data = res.json()
    assert isinstance(data, list)
    assert len(data) >= 7
    test_ids = [t["id"] for t in data]
    assert "test-happy-path" in test_ids
    assert "test-edge-empty-file" in test_ids


def test_api_run_tests_endpoint() -> None:
    understanding = ProductUnderstanding(
        goal="Validate CSV and generate report",
        summary="A pipeline for monthly sales.",
        target_users=["Auditor"],
        inputs=[],
        outputs=[],
        business_rules=[],
        assumptions=[],
        clarifications=[],
    )
    workflow = draft_workflow(understanding, provider=MockProvider())

    res = client.post(
        "/api/tests/run",
        json={"workflow": workflow.model_dump(mode="json")},
    )
    assert res.status_code == 200
    data = res.json()
    assert data["workflow_id"] == workflow.id
    assert data["total_tests"] >= 7
    assert data["passed_tests"] > 0
    assert data["all_passed"] is True
    assert len(data["results"]) == data["total_tests"]
