"""Milestone D3 tests: UI kit zero-hardcoded-color enforcement and full layout/shell coverage."""

import re
from pathlib import Path

from generators.design.allowlists import ALLOWED_LAYOUTS, ALLOWED_NAV_PATTERNS

UI_KIT_DIR = Path(__file__).resolve().parents[3] / "generators" / "ui_kit"

HEX_LITERAL_RE = re.compile(r"#[0-9A-Fa-f]{3,8}\b")
TAILWIND_COLOR_CLASS_RE = re.compile(
    r"\b(?:bg|text|border|ring)-(?:slate|gray|zinc|neutral|stone|red|orange|amber|yellow|"
    r"lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose)-\d{2,3}\b"
)


def test_ui_kit_contains_no_hardcoded_hex_or_tailwind_palette_colors() -> None:
    files = list(UI_KIT_DIR.rglob("*.ts")) + list(UI_KIT_DIR.rglob("*.tsx"))
    assert len(files) >= 4

    for file_path in files:
        content = file_path.read_text(encoding="utf-8")
        hex_hits = HEX_LITERAL_RE.findall(content)
        assert not hex_hits, f"{file_path.name} contains hardcoded hex colors: {hex_hits}"

        tw_hits = TAILWIND_COLOR_CLASS_RE.findall(content)
        assert not tw_hits, f"{file_path.name} contains hardcoded Tailwind colors: {tw_hits}"


def test_ui_kit_implements_every_allowed_layout_and_nav_shell() -> None:
    layouts_content = (UI_KIT_DIR / "layouts.tsx").read_text(encoding="utf-8")
    for layout_id in ALLOWED_LAYOUTS:
        assert f'data-layout="{layout_id}"' in layouts_content, (
            f"Missing data-layout='{layout_id}' in generators/ui_kit/layouts.tsx"
        )
        assert f"case '{layout_id}':" in layouts_content, (
            f"Missing switch case for '{layout_id}' in AdaptiveLayoutRenderer"
        )

    shells_content = (UI_KIT_DIR / "shells.tsx").read_text(encoding="utf-8")
    for nav_id in ALLOWED_NAV_PATTERNS:
        assert f'data-shell="{nav_id}"' in shells_content, (
            f"Missing data-shell='{nav_id}' in generators/ui_kit/shells.tsx"
        )
        assert f"case '{nav_id}':" in shells_content, (
            f"Missing switch case for '{nav_id}' in NavigationShell"
        )
