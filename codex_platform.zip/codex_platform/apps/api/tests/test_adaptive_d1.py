"""Unit tests for Milestone D1: Adaptive UI Schemas, Contrast Adjuster, Fingerprint & Guards."""

import pytest
from pydantic import ValidationError

from generators.blueprint.schemas import (
    AppBlueprint,
    AudienceProfile,
    DataShape,
    DomainAnalysis,
    EmptyStateSpec,
    EntitySpec,
    FieldSpec,
    FieldType,
    LayoutArchetype,
    NavigationSpec,
    NavItemSpec,
    NavPattern,
    PageSpec,
    ProductArchetype,
)
from generators.design.contrast import (
    contrast_ratio,
    primary_hue_bucket,
    relative_luminance,
    validate_and_adjust_palette,
)
from generators.design.fingerprint import (
    check_diversity_guard,
    compute_fingerprint,
    fingerprint_distance,
    resolve_diversity_with_retries,
    scan_generated_source_for_leakage,
)
from generators.design.schemas import (
    BorderStyle,
    BrandMarkSpec,
    ColorMode,
    DensityClass,
    DesignDirection,
    IconStyle,
    MotionLevel,
    PaletteTokens,
    RadiusClass,
    ShadowStyle,
    ShapeTokens,
    TypographyTokens,
)


def _sample_domain(
    archetype: ProductArchetype = ProductArchetype.HABIT_OR_GOAL_TRACKER,
    needs_automation: bool = False,
) -> DomainAnalysis:
    return DomainAnalysis(
        product_kind="Daily Habit & Streak Tracker",
        archetype=archetype,
        audience=AudienceProfile(
            who="Individual learners and remote professionals",
            context_of_use="Morning and evening daily routine check-ins",
            device_likely_used="hybrid",
            tech_comfort="medium",
        ),
        core_jobs=[
            "Check off today's scheduled habits in one tap",
            "Inspect active multi-day streaks and consistency heatmaps",
            "Add or adjust recurring habit targets",
        ],
        primary_object="habit",
        tone="calm, encouraging, reflective",
        data_shape=DataShape.TIME_SERIES,
        needs_automation=needs_automation,
        rationale=(
            "Users open a habit tracker daily to mark completions quickly and see "
            "their streak momentum without administrative clutter."
        ),
    )


def _sample_blueprint(domain: DomainAnalysis | None = None) -> AppBlueprint:
    dom = domain or _sample_domain()
    return AppBlueprint(
        app_name="Cadence",
        product_tagline="Mindful daily rituals and streak consistency",
        domain=dom,
        entities=[
            EntitySpec(
                name="habit",
                singular_label="Habit",
                plural_label="Habits",
                fields=[
                    FieldSpec(name="title", label="Habit Name", field_type=FieldType.STRING),
                    FieldSpec(
                        name="frequency",
                        label="Frequency",
                        field_type=FieldType.ENUM,
                        enum_values=["daily", "weekdays", "weekly"],
                    ),
                    FieldSpec(
                        name="streak_days",
                        label="Current Streak",
                        field_type=FieldType.INTEGER,
                    ),
                ],
            ),
            EntitySpec(
                name="checkin",
                singular_label="Check-In",
                plural_label="Check-Ins",
                fields=[
                    FieldSpec(name="completed_on", label="Date", field_type=FieldType.DATE),
                    FieldSpec(name="completed", label="Completed", field_type=FieldType.BOOLEAN),
                ],
            ),
        ],
        pages=[
            PageSpec(
                id="today",
                title="Today's Rituals",
                route="/",
                layout=LayoutArchetype.CHECKLIST_TODAY,
                entities_used=["habit", "checkin"],
                primary_actions=["Complete Habit", "Add Ritual"],
                empty_state=EmptyStateSpec(
                    headline="Your daily ritual board is clear",
                    body="Start with one small daily habit you want to anchor into your routine.",
                    cta_label="Create First Habit",
                    cta_action_id="create_habit",
                ),
            ),
            PageSpec(
                id="streaks",
                title="Streak Heatmap",
                route="/streaks",
                layout=LayoutArchetype.HEATMAP_STREAKS,
                entities_used=["habit", "checkin"],
                primary_actions=["Filter Period"],
                empty_state=EmptyStateSpec(
                    headline="No streak history recorded yet",
                    body="Check off your first habit today to light up your consistency calendar.",
                    cta_label="Log Today's Check-In",
                    cta_action_id="log_checkin",
                ),
            ),
        ],
        navigation=NavigationSpec(
            pattern=NavPattern.SIDEBAR,
            items=[
                NavItemSpec(page_id="today", label="Today's Rituals", icon="check-circle"),
                NavItemSpec(page_id="streaks", label="Streak Heatmap", icon="flame"),
            ],
        ),
        home_page_id="today",
        automations=[],
    )


def _sample_direction(
    direction_id: str = "editorial_calm",
    primary: str = "#2D5A3D",
    heading_font: str = "Fraunces",
    radius: RadiusClass = RadiusClass.SOFT,
    density: DensityClass = DensityClass.SPACIOUS,
    color_mode: ColorMode = ColorMode.LIGHT,
) -> DesignDirection:
    is_dark = color_mode == ColorMode.DARK
    return DesignDirection(
        direction_id=direction_id,
        palette=PaletteTokens(
            primary=primary,
            primary_foreground="#FFFFFF" if not is_dark else "#0B0F17",
            accent="#A35C37",
            neutral_ramp=[
                "#FBF9F5",
                "#F3EFE6",
                "#E5DEC9",
                "#C9BFA3",
                "#9C9178",
                "#6E6552",
                "#4B4537",
                "#2D2920",
                "#1C241E",
            ],
            surface="#0B0F17" if is_dark else "#FBF9F5",
            surface_elevated="#161F2E" if is_dark else "#FFFFFF",
            border="#475569" if is_dark else "#6E6552",
            text="#F1F5F9" if is_dark else "#1C241E",
            text_muted="#94A3B8" if is_dark else "#4B4537",
            focus_ring="#38BDF8" if is_dark else "#2D5A3D",
            success="#34D399" if is_dark else "#1B7F37",
            warning="#FBBF24" if is_dark else "#9A5B00",
            danger="#F87171" if is_dark else "#B91C1C",
        ),
        color_mode=color_mode,
        typography=TypographyTokens(
            heading_font=heading_font,
            body_font="Source Sans 3",
            mono_font="JetBrains Mono",
            scale_ratio=1.25,
        ),
        shape=ShapeTokens(
            radius_class=radius,
            border_style=BorderStyle.HAIRLINE,
            shadow_style=ShadowStyle.SOFT,
        ),
        density=density,
        motion=MotionLevel.SUBTLE,
        iconography=IconStyle.OUTLINE,
        brand_mark=BrandMarkSpec(
            kind="geometric_glyph",
            glyph_primitive="leaf_arch",
            monogram_letters="CD",
        ),
        copy_voice="Encouraging, unhurried, reflective sentences.",
        rationale=(
            "Editorial serif headings paired with warm off-white and forest tones "
            "foster a calm daily habit ritual."
        ),
    )


def test_stage_a_rejects_generic_crud_when_specialized_archetype_fits() -> None:
    with pytest.raises(ValidationError, match="generic_crud is forbidden"):
        _sample_domain(archetype=ProductArchetype.GENERIC_CRUD)


def test_stage_b_rejects_unknown_icon_and_invalid_automation() -> None:
    bp = _sample_blueprint()
    assert bp.has_file_ingest_entity() is False

    # Reject unknown icon
    with pytest.raises(ValidationError, match="ALLOWED_ICONS"):
        NavItemSpec(page_id="today", label="Home", icon="nonexistent-rocket-icon")

    # Reject automations when needs_automation=False
    with pytest.raises(ValidationError, match="automations must be empty"):
        bp_data = bp.model_dump()
        bp_data["automations"] = [
            {
                "id": "auto-1",
                "name": "Daily Sync",
                "workflow_id": "wf-1",
                "trigger_entity": "habit",
            }
        ]
        AppBlueprint.model_validate(bp_data)


def test_stage_c_rejects_gw_brand_leak_and_unknown_font() -> None:
    # Reject GW and CX platform monograms
    for forbidden_monogram in ("GW", "CX"):
        with pytest.raises(ValidationError, match="reserved for CodeX / Ghostwriter"):
            BrandMarkSpec(
                kind="wordmark",
                glyph_primitive="circle_ring",
                monogram_letters=forbidden_monogram,
            )

    # Reject CodeX / Ghostwriter brand purple #5A32A3
    with pytest.raises(ValidationError, match="reserved for CodeX / Ghostwriter's workspace brand"):
        _sample_direction(primary="#5A32A3")

    # Reject unbundled font
    with pytest.raises(ValidationError, match="Unknown heading_font"):
        _sample_direction(heading_font="Papyrus")


def test_wcag_contrast_adjuster_repairs_failing_palette() -> None:
    assert relative_luminance("#FFFFFF") == pytest.approx(1.0, rel=1e-3)
    assert relative_luminance("#000000") == pytest.approx(0.0, abs=1e-5)
    assert contrast_ratio("#FFFFFF", "#000000") == pytest.approx(21.0, abs=0.05)

    # Construct a direction with intentionally failing low-contrast tokens on a light surface
    bad_dir = _sample_direction()
    bad_palette = bad_dir.palette.model_copy(
        update={
            "surface": "#FBF9F5",
            "text": "#C5C2BA",  # Fails 4.5:1 on #FBF9F5
            "text_muted": "#D0CEC7",  # Fails 4.5:1 on #FBF9F5
            "border": "#EFECE6",  # Fails 3.0:1 on #FBF9F5
            "primary": "#A8E6CF",
            "primary_foreground": "#FFFFFF",  # Fails 4.5:1 on #A8E6CF
        }
    )
    repaired_palette, adjustments, pair_results = validate_and_adjust_palette(bad_palette)

    assert len(adjustments) >= 4
    assert all(p.passed for p in pair_results)
    assert contrast_ratio(repaired_palette.text, repaired_palette.surface) >= 4.5
    assert contrast_ratio(repaired_palette.text_muted, repaired_palette.surface) >= 4.5
    assert contrast_ratio(repaired_palette.border, repaired_palette.surface) >= 3.0
    assert contrast_ratio(repaired_palette.primary_foreground, repaired_palette.primary) >= 4.5


def test_fingerprint_and_collision_retry_guard() -> None:
    dom_habit = _sample_domain()
    bp_habit = _sample_blueprint(dom_habit)
    dir_calm = _sample_direction()

    fp_habit = compute_fingerprint(dom_habit, bp_habit, dir_calm)
    assert fp_habit.primary_hue_bucket == primary_hue_bucket("#2D5A3D")
    assert fingerprint_distance(fp_habit, fp_habit) == 0

    # Create a colliding direction (differs in only 1 attribute: density)
    colliding_dir = _sample_direction(density=DensityClass.COMFORTABLE)
    fp_colliding = compute_fingerprint(dom_habit, bp_habit, colliding_dir)
    assert fingerprint_distance(fp_habit, fp_colliding) == 1

    passed, min_dist, diag = check_diversity_guard(
        fp_colliding, [("Cadence", fp_habit)], min_distance=4
    )
    assert passed is False
    assert min_dist == 1
    assert len(diag) == 1
    assert "Cadence" in diag[0]

    # Create a contrasting direction & blueprint that differs in >= 4 attributes
    dir_console = _sample_direction(
        direction_id="console_dark",
        primary="#06B6D4",
        heading_font="Space Grotesk",
        radius=RadiusClass.SHARP,
        density=DensityClass.COMPACT,
        color_mode=ColorMode.DARK,
    )

    # Test resolve_diversity_with_retries: retry 1 returns identical collision, retry 2 succeeds
    call_count = 0

    def _mock_retry(collisions: list[str], attempt: int) -> DesignDirection:
        nonlocal call_count
        call_count += 1
        assert len(collisions) >= 1
        if attempt == 1:
            return colliding_dir  # Identical to initial attempt -> rejected
        return dir_console  # Differs in 5 attributes (hue, font, radius, density, color_mode)

    resolved_dir, report, retries = resolve_diversity_with_retries(
        domain=dom_habit,
        blueprint=bp_habit,
        initial_direction=colliding_dir,
        existing_fingerprints=[("Cadence", fp_habit)],
        fallback_directions=[dir_console],
        retry_fn=_mock_retry,
        max_retries=3,
        min_distance=4,
    )
    assert retries == 2
    assert call_count == 2
    assert report.diversity_passed is True
    assert report.min_fingerprint_distance >= 4
    assert resolved_dir.direction_id == "console_dark"


def test_collision_retry_falls_back_to_curated_direction_when_retries_exhausted() -> None:
    dom = _sample_domain()
    bp = _sample_blueprint(dom)
    dir_calm = _sample_direction()
    fp_existing = compute_fingerprint(dom, bp, dir_calm)

    colliding_dir = _sample_direction(density=DensityClass.COMFORTABLE)
    dir_fallback = _sample_direction(
        direction_id="console_dark",
        primary="#06B6D4",
        heading_font="Space Grotesk",
        radius=RadiusClass.SHARP,
        density=DensityClass.COMPACT,
        color_mode=ColorMode.DARK,
    )

    # retry_fn always returns a colliding direction
    resolved_dir, report, retries = resolve_diversity_with_retries(
        domain=dom,
        blueprint=bp,
        initial_direction=colliding_dir,
        existing_fingerprints=[("ExistingApp", fp_existing)],
        fallback_directions=[dir_fallback],
        retry_fn=lambda _diag, _att: colliding_dir,
        max_retries=3,
        min_distance=4,
    )
    assert retries == 3
    assert report.diversity_passed is True
    assert resolved_dir.direction_id == "console_dark"


def test_source_leakage_scanner_catches_all_forbidden_patterns() -> None:
    bad_files = {
        "frontend/src/App.tsx": (
            "<div><span>GW</span><span>CX</span><p>Production Verified</p>"
            "<p>Upload CSV file monthly_sales.csv with 14250.00</p></div>"
        ),
        "standalone_app.html": (
            '<script src="https://cdn.tailwindcss.com"></script>'
            "<title>Habit App - Powered by CodeX & Ghostwriter</title>"
        ),
    }
    violations = scan_generated_source_for_leakage(
        files=bad_files,
        has_file_ingest_entity=False,
        allow_opt_in_footer=False,
    )
    assert any("GW logo" in v for v in violations)
    assert any("CX logo" in v for v in violations)
    assert any("Production Verified" in v for v in violations)
    assert any("14250.00" in v for v in violations)
    assert any("CSV" in v for v in violations)
    assert any("Tailwind CDN" in v for v in violations)
    assert any("CodeX" in v for v in violations)
    assert any("Ghostwriter" in v for v in violations)

    clean_files = {
        "frontend/src/App.tsx": "<div><h1>Cadence Rituals</h1><p>Check off today's habits</p></div>"
    }
    assert (
        scan_generated_source_for_leakage(
            files=clean_files,
            has_file_ingest_entity=False,
            allow_opt_in_footer=False,
        )
        == []
    )
