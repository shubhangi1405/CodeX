from fastapi.testclient import TestClient

from apps.api.main import app
from engine.compiler.pipeline import draft_workflow
from engine.compiler.providers import MockProvider
from engine.compiler.schemas import ProductUnderstanding

client = TestClient(app)


def test_api_runs_and_replay_endpoints() -> None:
    understanding = ProductUnderstanding(
        goal="Process monthly CSV",
        summary="A pipeline.",
        target_users=["Auditor"],
        inputs=[],
        outputs=[],
        business_rules=[],
        assumptions=[],
        clarifications=[],
    )
    workflow = draft_workflow(understanding, provider=MockProvider())

    # 1. Run workflow via API
    run_res = client.post(
        "/api/workflows/run",
        json={"workflow": workflow.model_dump(mode="json")},
    )
    assert run_res.status_code == 200
    run_record = run_res.json()
    run_id = run_record["run_id"]
    assert run_id is not None

    # 2. List runs
    list_res = client.get("/api/runs")
    assert list_res.status_code == 200
    runs = list_res.json()
    assert any(r["run_id"] == run_id for r in runs)

    # 3. Get specific run
    get_res = client.get(f"/api/runs/{run_id}")
    assert get_res.status_code == 200
    assert get_res.json()["run_id"] == run_id

    # 4. Replay past run
    replay_res = client.post(f"/api/runs/{run_id}/replay", json={})
    assert replay_res.status_code == 200
    replay_data = replay_res.json()
    assert replay_data["bit_for_bit_identical"] is True
    assert replay_data["replayed_record"]["output_hash"] == run_record["output_hash"]

    # 5. Execute single node endpoint
    node_res = client.post(
        "/api/runs/execute-node",
        json={
            "node_type": "aggregate.monthly_totals",
            "node_id": "node-test-agg",
            "label": "Monthly Totals Test",
            "config": {"date_column": "date", "amount_column": "amount"},
            "inputs": {
                "table": [
                    {"date": "2026-01-15", "amount": 100.0},
                    {"date": "2026-01-20", "amount": 250.0},
                ]
            },
        },
    )
    assert node_res.status_code == 200
    node_data = node_res.json()
    assert node_data["status"] == "success"
    assert node_data["row_count_out"] == 1
    assert node_data["outputs"]["table"][0]["total_amount"] == 350.0
