"""Comprehensive Acceptance Test Suite for CodeX Complete Software Generation Upgrade.

Covers all 6 required benchmark and extended domain applications:
1. Daily Habit Tracker (daily_habit_tracker)
2. Clinic Appointment Scheduling (clinic_appointment_scheduling)
3. Restaurant Inventory (restaurant_inventory)
4. CRM Sales Pipeline (crm_sales_pipeline)
5. Online Learning Platform (online_learning_platform)
6. Community Event Directory (community_event_directory)

Verifies:
- Domain Blueprint Resolution & Structural Differentiation (pairwise distance >= 4)
- WCAG 2.1 AA Contrast Compliance across all 9 pairs
- Zero Leakage across all generated files
- Cryptographic Authentication & PBKDF2 Password Security
- Tenant Ownership, Data Isolation & IDOR Protection (403 Forbidden)
- Data Portability & GDPR Right to Erasure (Account Deletion)
- Domain Analytics & STRIDE Threat Modeling
"""

import contextlib
import importlib.util
import os
import sys
from pathlib import Path
from typing import Any, Generator

from fastapi.testclient import TestClient

from generators.app_generator import AppGenerator
from generators.blueprint.archetypes import (
    EXTENDED_DOMAIN_BUNDLES,
    resolve_benchmark_bundle,
)
from generators.design.fingerprint import compute_fingerprint, fingerprint_distance
from generators.design.schemas import LookFingerprint
from generators.schemas import GeneratedAppManifest

ACCEPTANCE_PRODUCTS: list[tuple[str, str]] = [
    ("daily_habit_tracker", "daily habit tracker and ritual streak log"),
    ("clinic_appointment_scheduling", "clinic patient triage and appointment scheduling"),
    ("restaurant_inventory", "restaurant pantry inventory stock alert"),
    ("crm_sales_pipeline", "b2b crm sales pipeline deals leads"),
    ("online_learning_platform", "online learning platform courses lessons curriculum"),
    ("community_event_directory", "neighborhood community event directory bulletin meetup"),
]


@contextlib.contextmanager
def boot_generated_backend(backend_dir: Path) -> Generator[tuple[TestClient, Any], None, None]:
    """Temporarily imports and boots a generated FastAPI application with SQLite in its folder."""
    sys.path.insert(0, str(backend_dir))
    orig_cwd = Path.cwd()
    os.chdir(backend_dir)
    for mod_name in ("database", "models", "seed", "main", "auth"):
        sys.modules.pop(mod_name, None)
    try:
        spec = importlib.util.spec_from_file_location("main", backend_dir / "main.py")
        assert spec is not None and spec.loader is not None
        main_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(main_mod)
        client = TestClient(main_mod.app)
        yield client, main_mod
    finally:
        os.chdir(orig_cwd)
        if str(backend_dir) in sys.path:
            sys.path.remove(str(backend_dir))
        for mod_name in ("database", "models", "seed", "main", "auth"):
            sys.modules.pop(mod_name, None)


def test_six_acceptance_products_blueprint_resolution_and_diversity(tmp_path: Path) -> None:
    """Verifies that all 6 products resolve distinctly and produce pairwise distance >= 4."""
    manifests: dict[str, GeneratedAppManifest] = {}
    fingerprints: list[tuple[str, LookFingerprint]] = []

    for slug, prompt in ACCEPTANCE_PRODUCTS:
        bundle = resolve_benchmark_bundle(prompt)
        assert bundle.benchmark_key == slug, (
            f"Prompt '{prompt}' resolved to {bundle.benchmark_key} instead of {slug}"
        )

        manifest = AppGenerator.generate_from_blueprint(
            blueprint=bundle.blueprint,
            direction=bundle.primary_direction,
            output_base_dir=str(tmp_path),
            project_id_override=slug,
            sample_seed_data=bundle.sample_seed_data,
            direction_proposals=bundle.direction_proposals,
            existing_fingerprints=fingerprints,
            allow_opt_in_footer=False,
        )

        assert manifest.blueprint is not None
        assert manifest.design_direction is not None
        assert manifest.validation_report is not None
        assert manifest.validation_report.valid is True
        assert manifest.validation_report.leakage_violations == []

        # WCAG 2.1 AA contrast validation on all 9 color pairs
        assert len(manifest.validation_report.contrast_pairs) == 9
        for pair in manifest.validation_report.contrast_pairs:
            assert pair.passed is True, (
                f"{slug} failed WCAG AA on {pair.pair_name}: "
                f"{pair.contrast_ratio}:1 < {pair.required_ratio}:1"
            )

        # Zero leakage check across every file in every generated app
        for gf in manifest.files:
            lower = gf.content.lower()
            assert "csv" not in lower, f"Leaked 'csv' in {slug}/{gf.path}"
            assert "upload csv" not in lower, f"Leaked 'upload csv' in {slug}/{gf.path}"
            assert "14250" not in lower, f"Leaked demo figure in {slug}/{gf.path}"
            assert "production verified" not in lower
            assert "bit-for-bit" not in lower
            assert "ghostwriter" not in lower
            assert "codex" not in lower

        fp = compute_fingerprint(
            manifest.blueprint.domain,
            manifest.blueprint,
            manifest.design_direction,
        )
        manifests[slug] = manifest
        fingerprints.append((slug, fp))

    # All 15 pairs among the 6 apps must have fingerprint distance >= 4
    pair_count = 0
    for i in range(len(fingerprints)):
        slug_a, fp_a = fingerprints[i]
        for j in range(i + 1, len(fingerprints)):
            slug_b, fp_b = fingerprints[j]
            dist = fingerprint_distance(fp_a, fp_b)
            pair_count += 1
            assert dist >= 4, (
                f"Fingerprint collision between {slug_a} and {slug_b}: "
                f"distance={dist} (< 4). fp_a={fp_a.as_tuple()}, fp_b={fp_b.as_tuple()}"
            )
    assert pair_count == 15

    # Diversity checks across structural dimensions
    home_layouts = {fp.home_layout for _, fp in fingerprints}
    nav_patterns = {fp.nav_pattern for _, fp in fingerprints}
    heading_fonts = {fp.heading_font for _, fp in fingerprints}

    assert len(home_layouts) >= 5, f"Expected >= 5 distinct home layouts, got {len(home_layouts)}"
    assert len(nav_patterns) >= 3, f"Expected >= 3 distinct nav patterns, got {len(nav_patterns)}"
    assert len(heading_fonts) >= 4, f"Expected >= 4 distinct heading fonts, got {len(heading_fonts)}"


def test_crm_sales_pipeline_cryptographic_auth_and_session(tmp_path: Path) -> None:
    """Verifies live cryptographic registration, PBKDF2 hashing, login, and session revocation."""
    bundle = EXTENDED_DOMAIN_BUNDLES["crm_sales_pipeline"]
    manifest = AppGenerator.generate_from_blueprint(
        blueprint=bundle.blueprint,
        direction=bundle.primary_direction,
        output_base_dir=str(tmp_path),
        project_id_override="crm_auth_test",
        sample_seed_data=bundle.sample_seed_data,
    )

    backend_dir = Path(manifest.output_dir) / "backend"
    with boot_generated_backend(backend_dir) as (client, main_mod):
        # 1. Health check
        health = client.get("/api/health")
        assert health.status_code == 200
        assert health.json()["archetype"] == "crm_pipeline"

        # 2. Register new user
        reg_resp = client.post(
            "/api/auth/register",
            json={
                "email": "sarah.lead@salescorp.example",
                "password": "SecurePassword999!",
                "display_name": "Sarah Sales Leader",
                "role": "manager",
            },
        )
        assert reg_resp.status_code == 201
        reg_data = reg_resp.json()
        assert "token" in reg_data and len(reg_data["token"]) > 20
        user = reg_data["user"]
        assert user["email"] == "sarah.lead@salescorp.example"

        # 3. Verify SQLite stored password hash is cryptographic PBKDF2, NOT plain text
        from database import SessionLocal
        from models import UserModel

        db = SessionLocal()
        try:
            db_user = db.query(UserModel).filter(UserModel.id == user["id"]).first()
            assert db_user is not None
            assert db_user.password_hash != "SecurePassword999!"
            # Hash format is salt:derived_hex (16 bytes salt hex + 32 bytes derived hex)
            parts = db_user.password_hash.split(":")
            assert len(parts) == 2
            assert len(parts[0]) == 32  # 16 bytes salt
            assert len(parts[1]) == 64  # sha256 hex
        finally:
            db.close()

        # 4. Valid login
        login_resp = client.post(
            "/api/auth/login",
            json={
                "email": "sarah.lead@salescorp.example",
                "password": "SecurePassword999!",
            },
        )
        assert login_resp.status_code == 200
        login_data = login_resp.json()
        assert "token" in login_data
        active_token = login_data["token"]

        # 5. Invalid login fails with 401
        bad_login = client.post(
            "/api/auth/login",
            json={
                "email": "sarah.lead@salescorp.example",
                "password": "WrongPassword!",
            },
        )
        assert bad_login.status_code == 401

        # 6. Authenticated /api/auth/me
        me_resp = client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {active_token}"},
        )
        assert me_resp.status_code == 200
        assert me_resp.json()["email"] == "sarah.lead@salescorp.example"

        # 7. Unauthenticated /api/auth/me fails with 401
        unauth_resp = client.get("/api/auth/me")
        assert unauth_resp.status_code == 401

        # 8. Password Reset
        reset_resp = client.post(
            "/api/auth/reset-password",
            json={
                "email": "sarah.lead@salescorp.example",
                "new_password": "NewSecretPassword888!",
            },
        )
        assert reset_resp.status_code == 200
        assert reset_resp.json()["status"] == "password_reset_success"

        # Login with old password now fails
        assert client.post(
            "/api/auth/login",
            json={"email": "sarah.lead@salescorp.example", "password": "SecurePassword999!"},
        ).status_code == 401

        # Login with new password succeeds
        new_login = client.post(
            "/api/auth/login",
            json={"email": "sarah.lead@salescorp.example", "password": "NewSecretPassword888!"},
        )
        assert new_login.status_code == 200
        fresh_token = new_login.json()["token"]

        # 9. Logout revokes token
        logout_resp = client.post(
            "/api/auth/logout",
            headers={"Authorization": f"Bearer {fresh_token}"},
        )
        assert logout_resp.status_code == 200
        # Subsequent call with revoked token returns 401
        assert client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {fresh_token}"},
        ).status_code == 401


def test_online_learning_platform_tenant_isolation_and_idor_protection(tmp_path: Path) -> None:
    """Verifies that User B cannot modify or delete User A's records (IDOR protection with 403)."""
    bundle = EXTENDED_DOMAIN_BUNDLES["online_learning_platform"]
    manifest = AppGenerator.generate_from_blueprint(
        blueprint=bundle.blueprint,
        direction=bundle.primary_direction,
        output_base_dir=str(tmp_path),
        project_id_override="edu_auth_test",
        sample_seed_data=bundle.sample_seed_data,
    )

    backend_dir = Path(manifest.output_dir) / "backend"
    with boot_generated_backend(backend_dir) as (client, main_mod):
        # Register User A (Instructor)
        reg_a = client.post(
            "/api/auth/register",
            json={"email": "instructor.a@academy.example", "password": "Password123!", "role": "member"},
        )
        assert reg_a.status_code == 201
        token_a = reg_a.json()["token"]
        user_a_id = reg_a.json()["user"]["id"]

        # Register User B (Student)
        reg_b = client.post(
            "/api/auth/register",
            json={"email": "student.b@academy.example", "password": "Password123!", "role": "member"},
        )
        assert reg_b.status_code == 201
        token_b = reg_b.json()["token"]

        # User A creates a course
        create_resp = client.post(
            "/api/learning_course",
            headers={"Authorization": f"Bearer {token_a}"},
            json={
                "course_title": "Advanced Algorithmic Thinking",
                "category": "Computer Science",
                "difficulty_level": "Advanced",
                "estimated_hours": 36,
                "instructor_name": "Prof. Turing",
            },
        )
        assert create_resp.status_code == 201
        course_data = create_resp.json()
        course_id = course_data["id"]
        assert course_data["owner_id"] == user_a_id

        # User B attempts to edit User A's course -> 403 Forbidden!
        bad_edit = client.put(
            f"/api/learning_course/{course_id}",
            headers={"Authorization": f"Bearer {token_b}"},
            json={"course_title": "Malicious Title Overwrite"},
        )
        assert bad_edit.status_code == 403
        assert "Forbidden" in bad_edit.json()["detail"]

        # User B attempts to delete User A's course -> 403 Forbidden!
        bad_del = client.delete(
            f"/api/learning_course/{course_id}",
            headers={"Authorization": f"Bearer {token_b}"},
        )
        assert bad_del.status_code == 403

        # User A edits their own course -> 200 OK
        ok_edit = client.put(
            f"/api/learning_course/{course_id}",
            headers={"Authorization": f"Bearer {token_a}"},
            json={"course_title": "Advanced Algorithmic Thinking (Updated)"},
        )
        assert ok_edit.status_code == 200
        assert ok_edit.json()["course_title"] == "Advanced Algorithmic Thinking (Updated)"


def test_privacy_export_and_gdpr_account_deletion(tmp_path: Path) -> None:
    """Verifies that GET /api/privacy/export extracts tenant data and DELETE /api/privacy/account purges it."""
    bundle = EXTENDED_DOMAIN_BUNDLES["crm_sales_pipeline"]
    manifest = AppGenerator.generate_from_blueprint(
        blueprint=bundle.blueprint,
        direction=bundle.primary_direction,
        output_base_dir=str(tmp_path),
        project_id_override="privacy_test",
        sample_seed_data=bundle.sample_seed_data,
    )

    backend_dir = Path(manifest.output_dir) / "backend"
    with boot_generated_backend(backend_dir) as (client, main_mod):
        # Register user
        reg = client.post(
            "/api/auth/register",
            json={"email": "gdpr.user@example.org", "password": "Password123!", "role": "member"},
        )
        token = reg.json()["token"]
        user_id = reg.json()["user"]["id"]

        # Create records owned by this user
        deal_resp = client.post(
            "/api/sales_deal",
            headers={"Authorization": f"Bearer {token}"},
            json={
                "deal_name": "Cloud Migration Contract",
                "company_name": "Tech Corp",
                "deal_value": 75000.0,
                "pipeline_stage": "Proposal",
                "contact_email": "cto@techcorp.example",
            },
        )
        assert deal_resp.status_code == 201
        deal_id = deal_resp.json()["id"]

        # 1. Privacy Data Export
        export_resp = client.get(
            "/api/privacy/export",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert export_resp.status_code == 200
        export_data = export_resp.json()
        assert export_data["user"]["id"] == user_id
        assert "sales_deal" in export_data["records"]
        assert any(d["id"] == deal_id for d in export_data["records"]["sales_deal"])

        # 2. Account Deletion (GDPR Right to Erasure)
        del_resp = client.delete(
            "/api/privacy/account",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert del_resp.status_code == 200
        assert del_resp.json()["status"] == "account_and_records_deleted"

        # Verify deal was deleted from database
        all_deals = client.get("/api/sales_deal").json()
        assert not any(d["id"] == deal_id for d in all_deals)

        # Verify directly in SQLite that records and user are erased
        from database import SessionLocal
        from models import SalesDealModel, UserModel

        db = SessionLocal()
        try:
            assert db.query(SalesDealModel).filter(SalesDealModel.id == deal_id).first() is None
            assert db.query(UserModel).filter(UserModel.id == user_id).first() is None
        finally:
            db.close()

        # Verify user account was deleted from database
        login_again = client.post(
            "/api/auth/login",
            json={"email": "gdpr.user@example.org", "password": "Password123!"},
        )
        assert login_again.status_code == 401


def test_community_event_directory_analytics_and_threat_model(tmp_path: Path) -> None:
    """Verifies that seed data populates, analytics summary computes real metrics, and threat model returns."""
    bundle = EXTENDED_DOMAIN_BUNDLES["community_event_directory"]
    manifest = AppGenerator.generate_from_blueprint(
        blueprint=bundle.blueprint,
        direction=bundle.primary_direction,
        output_base_dir=str(tmp_path),
        project_id_override="community_test",
        sample_seed_data=bundle.sample_seed_data,
    )

    backend_dir = Path(manifest.output_dir) / "backend"
    with boot_generated_backend(backend_dir) as (client, main_mod):
        # 1. Verify threat model
        threat_resp = client.get("/api/security/threat-model")
        assert threat_resp.status_code == 200
        threat_data = threat_resp.json()
        assert "threats" in threat_data
        assert len(threat_data["threats"]) >= 3
        # Ensure STRIDE categories are present
        categories = {t["category"] for t in threat_data["threats"]}
        assert any(cat in categories for cat in ("spoofing", "tampering", "information_disclosure", "elevation_of_privilege"))

        # 2. Seed database
        seed_resp = client.post("/api/seed")
        assert seed_resp.status_code == 200
        assert seed_resp.json()["inserted"]["community_event"] >= 3

        # 3. Analytics Summary computed from live database
        analytics_resp = client.get("/api/analytics/summary")
        assert analytics_resp.status_code == 200
        summary = analytics_resp.json()
        assert summary["total_records"] >= 3
        assert summary["counts_by_entity"]["community_event"] >= 3
        assert len(summary["primary_chart_data"]) >= 2
        assert len(summary["kpis"]) >= 2
        for kpi in summary["kpis"]:
            assert "label" in kpi
            assert "value" in kpi
            assert kpi["value"] >= 3
