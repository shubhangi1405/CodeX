from fastapi.testclient import TestClient

from apps.api.main import app

client = TestClient(app)


def test_health_check_returns_ok() -> None:
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "version" in data
    assert "timestamp" in data


def test_list_projects() -> None:
    response = client.get("/api/projects")
    assert response.status_code == 200
    projects = response.json()
    assert isinstance(projects, list)
    assert len(projects) >= 1
    assert projects[0]["name"] == "CSV Monthly Totals Pipeline"


def test_create_and_get_project() -> None:
    payload = {
        "name": "E-Commerce Order Reconciliation",
        "prompt": (
            "Parse daily orders JSON, reconcile against payment gateway, alert on discrepancies."
        ),
    }
    create_res = client.post("/api/projects", json=payload)
    assert create_res.status_code == 201
    created = create_res.json()
    assert created["name"] == payload["name"]
    project_id = created["id"]

    get_res = client.get(f"/api/projects/{project_id}")
    assert get_res.status_code == 200
    retrieved = get_res.json()
    assert retrieved["id"] == project_id
    assert retrieved["prompt"] == payload["prompt"]
