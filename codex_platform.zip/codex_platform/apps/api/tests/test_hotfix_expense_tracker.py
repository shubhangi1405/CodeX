"""Regression and acceptance tests for CODEX HOTFIX:

Verifies:
1. Personal Expense Tracker Pipeline generates authentic finance ledger (expense_transaction + budget_category),
   with ZERO sales deal or CRM entities/terms.
2. Habit Tracker, Sports Court Booking, and Security Event Log Viewer resolve accurately without CRM pollution.
3. In-workspace specification changes properly switch domains without stale blueprint reuse.
4. Rebuild determinism across multiple runs.
5. FastAPI /api/generate endpoint respects blueprint and project_id parameters.
"""

import contextlib
import importlib.util
import os
import sys
from pathlib import Path
from typing import Any, Generator

from fastapi.testclient import TestClient

from apps.api.main import app as main_codex_app
from engine.spec import NodeSpec, TriggerSpec, WorkflowSpec
from generators.app_generator import AppGenerator
from generators.blueprint.archetypes import EXTENDED_DOMAIN_BUNDLES


@contextlib.contextmanager
def boot_generated_backend(backend_dir: Path) -> Generator[tuple[TestClient, Any], None, None]:
    """Temporarily imports and boots a generated FastAPI application with SQLite in its folder."""
    sys.path.insert(0, str(backend_dir))
    orig_cwd = Path.cwd()
    os.chdir(backend_dir)
    for mod_name in ("database", "models", "seed", "main", "auth"):
        sys.modules.pop(mod_name, None)
    try:
        spec = importlib.util.spec_from_file_location("main", backend_dir / "main.py")
        assert spec is not None and spec.loader is not None
        main_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(main_mod)
        client = TestClient(main_mod.app)
        yield client, main_mod
    finally:
        os.chdir(orig_cwd)
        if str(backend_dir) in sys.path:
            sys.path.remove(str(backend_dir))
        for mod_name in ("database", "models", "seed", "main", "auth"):
            sys.modules.pop(mod_name, None)


def _make_dummy_workflow(name: str, desc: str) -> WorkflowSpec:
    return WorkflowSpec(
        id=f"wf-{abs(hash(name)) % 100000}",
        name=name,
        description=desc,
        version=1,
        trigger=TriggerSpec(id="t1", type="manual_upload", config={}),
        nodes=[
            NodeSpec(
                id="n1",
                type="ingest.read_csv",
                label=f"Ingest {name} Records",
                category="ingest",
                config={},
                input_ports=[],
                output_ports=[],
            )
        ],
        edges=[],
    )


def test_expense_tracker_pipeline_resolves_and_generates_authentically(tmp_path: Path) -> None:
    """Test A: 'Personal Expense Tracker Pipeline' generates authentic expense & budget software, not CRM."""
    wf = _make_dummy_workflow(
        name="Personal Expense Tracker Pipeline",
        desc="Personal expense tracker and monthly budget limit pipeline",
    )
    manifest = AppGenerator.generate(wf, output_base_dir=str(tmp_path))

    # 1. Blueprint entities must be expense_transaction and budget_category
    assert manifest.blueprint is not None
    entity_names = [e.name for e in manifest.blueprint.entities]
    assert "expense_transaction" in entity_names
    assert "budget_category" in entity_names
    assert "sales_deal" not in entity_names
    assert "deal_activity" not in entity_names

    # 2. Check routes and models
    assert any("expense_transaction" in r for r in manifest.routes)
    assert any("budget_category" in r for r in manifest.routes)
    assert not any("sales_deal" in r for r in manifest.routes)

    # 3. Check generated file contents for zero CRM leakage
    file_map = {f.path: f.content for f in manifest.files}
    main_py = file_map["backend/main.py"]
    assert "expense_transaction" in main_py
    assert "budget_category" in main_py
    assert "sales_deal" not in main_py
    assert "PipelineOps CRM" not in file_map["standalone_app.html"]
    assert "Deal Pipeline" not in file_map["standalone_app.html"]

    # 4. Boot backend and test endpoints
    backend_dir = tmp_path / manifest.project_id / "backend"
    with boot_generated_backend(backend_dir) as (client, main_mod):
        # Seed database
        res_seed = client.post("/api/seed")
        assert res_seed.status_code == 200
        seed_data = res_seed.json()
        assert seed_data["status"] == "seeded"
        assert "expense_transaction" in seed_data["inserted"]
        assert "budget_category" in seed_data["inserted"]

        # Register a new user
        res_reg = client.post(
            "/api/auth/register",
            json={"email": "saver@example.com", "password": "StrongPassword123!", "role": "member"},
        )
        assert res_reg.status_code == 201
        token = res_reg.json()["token"]
        headers = {"Authorization": f"Bearer {token}"}

        # Create a new expense transaction
        res_tx = client.post(
            "/api/expense_transaction",
            headers=headers,
            json={
                "title": "Local Farmers Market Vegetables",
                "amount": 45.50,
                "transaction_date": "2026-10-12",
                "category": "Groceries",
                "transaction_type": "Expense",
                "payment_method": "Debit Card",
                "notes": "Fresh organic celery, carrots, and apples",
            },
        )
        assert res_tx.status_code == 201
        created_tx = res_tx.json()
        assert created_tx["title"] == "Local Farmers Market Vegetables"
        assert created_tx["amount"] == 45.50

        # Query analytics summary
        res_an = client.get("/api/analytics/summary", headers=headers)
        assert res_an.status_code == 200
        analytics = res_an.json()
        assert "counts_by_entity" in analytics
        assert "expense_transaction" in analytics["counts_by_entity"]


def test_habit_tracker_regression(tmp_path: Path) -> None:
    """Test B: 'Habit Tracker Pipeline' resolves to habit tracker with zero CRM/expense leakage."""
    wf = _make_dummy_workflow(
        name="Daily Habit Tracker Pipeline",
        desc="Daily habit tracking and morning ritual checkins",
    )
    manifest = AppGenerator.generate(wf, output_base_dir=str(tmp_path))
    assert manifest.blueprint is not None
    entity_names = [e.name for e in manifest.blueprint.entities]
    assert "habit_ritual" in entity_names
    assert "sales_deal" not in entity_names
    assert "expense_transaction" not in entity_names


def test_sports_court_booking_regression(tmp_path: Path) -> None:
    """Test C: 'Sports Court Booking Pipeline' resolves to court booking."""
    wf = _make_dummy_workflow(
        name="Sports Court Booking Pipeline",
        desc="Tennis court reservation and facility booking schedule",
    )
    manifest = AppGenerator.generate(wf, output_base_dir=str(tmp_path))
    assert manifest.blueprint is not None
    entity_names = [e.name for e in manifest.blueprint.entities]
    assert "court_reservation" in entity_names
    assert "court_venue" in entity_names
    assert "sales_deal" not in entity_names


def test_security_event_log_viewer_regression(tmp_path: Path) -> None:
    """Test D: 'Security Event Log Viewer Pipeline' resolves to security events."""
    wf = _make_dummy_workflow(
        name="Security Event Log Viewer Pipeline",
        desc="SIEM security audit and telemetry event triage",
    )
    manifest = AppGenerator.generate(wf, output_base_dir=str(tmp_path))
    assert manifest.blueprint is not None
    entity_names = [e.name for e in manifest.blueprint.entities]
    assert "security_event" in entity_names
    assert "detection_rule" in entity_names
    assert "sales_deal" not in entity_names


def test_specification_change_in_same_workspace(tmp_path: Path) -> None:
    """Test E: Changing specification from CRM to Expense Tracker completely updates generated code."""
    # First generate CRM app
    wf_crm = _make_dummy_workflow(
        name="B2B CRM Sales Pipeline",
        desc="Sales leads and opportunity deal stages",
    )
    manifest_1 = AppGenerator.generate(wf_crm, output_base_dir=str(tmp_path))
    assert manifest_1.blueprint is not None
    assert "sales_deal" in [e.name for e in manifest_1.blueprint.entities]

    # Now generate Expense Tracker in same output directory
    wf_exp = _make_dummy_workflow(
        name="Personal Expense Tracker Pipeline",
        desc="Personal finances and budget limits",
    )
    manifest_2 = AppGenerator.generate(wf_exp, output_base_dir=str(tmp_path))
    assert manifest_2.blueprint is not None
    assert "expense_transaction" in [e.name for e in manifest_2.blueprint.entities]
    assert "sales_deal" not in [e.name for e in manifest_2.blueprint.entities]


def test_rebuild_determinism(tmp_path: Path) -> None:
    """Test F: Rebuilding same specification produces deterministic entities, routes, and layouts."""
    wf = _make_dummy_workflow(
        name="Personal Expense Tracker Pipeline",
        desc="Personal expense tracker and monthly budget limit pipeline",
    )
    manifest_1 = AppGenerator.generate(wf, output_base_dir=str(tmp_path / "run1"))
    manifest_2 = AppGenerator.generate(wf, output_base_dir=str(tmp_path / "run2"))
    assert manifest_1.blueprint is not None
    assert manifest_2.blueprint is not None
    assert [e.name for e in manifest_1.blueprint.entities] == [e.name for e in manifest_2.blueprint.entities]
    assert manifest_1.routes == manifest_2.routes
    assert [p.layout for p in manifest_1.blueprint.pages] == [p.layout for p in manifest_2.blueprint.pages]


def test_api_generate_endpoint_with_explicit_blueprint(tmp_path: Path) -> None:
    """Test G: /api/generate endpoint prioritizes provided blueprint."""
    bundle = EXTENDED_DOMAIN_BUNDLES["personal_expense_tracker"]
    wf = _make_dummy_workflow(
        name="Custom Pipeline With Explicit Blueprint",
        desc="A workflow with explicit blueprint override",
    )
    client = TestClient(main_codex_app)
    req_payload = {
        "workflow": wf.model_dump(),
        "blueprint": bundle.blueprint.model_dump(),
        "output_base_dir": str(tmp_path),
    }
    res = client.post("/api/generate", json=req_payload)
    assert res.status_code == 200
    data = res.json()
    assert "expense_transaction" in [e["name"] for e in data["blueprint"]["entities"]]
    assert "sales_deal" not in [e["name"] for e in data["blueprint"]["entities"]]
