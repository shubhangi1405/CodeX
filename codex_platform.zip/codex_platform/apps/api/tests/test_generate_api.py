from fastapi.testclient import TestClient

from apps.api.main import app

client = TestClient(app)


def test_api_generate_app_and_export_zip() -> None:
    compile_resp = client.post(
        "/api/compiler/compile",
        json={"prompt": "Validate CSV and group by month", "provider": "mock"},
    )
    workflow_dict = compile_resp.json()["workflow"]

    # Test code generation
    gen_resp = client.post("/api/generate", json={"workflow": workflow_dict})
    assert gen_resp.status_code == 200
    manifest = gen_resp.json()

    assert manifest["name"] == workflow_dict["name"]
    assert len(manifest["files"]) >= 8
    file_paths = [f["path"] for f in manifest["files"]]
    assert "backend/main.py" in file_paths
    assert "backend/models.py" in file_paths
    assert "backend/engine.py" in file_paths
    assert "frontend/src/App.tsx" in file_paths
    assert "README.md" in file_paths

    # Test zip export
    project_id = manifest["project_id"]
    export_resp = client.get(f"/api/generate/export/{project_id}")
    assert export_resp.status_code == 200
    assert export_resp.headers["content-type"] == "application/zip"
    assert len(export_resp.content) > 0

    # Test standalone HTML preview
    preview_resp = client.get(f"/api/generate/preview/{project_id}")
    assert preview_resp.status_code == 200
    assert "text/html" in preview_resp.headers["content-type"]
    assert manifest["name"] in preview_resp.text
    assert "Production Verified" not in preview_resp.text
