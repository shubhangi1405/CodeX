from fastapi.testclient import TestClient

from apps.api.main import app

client = TestClient(app)


def test_api_interpret_endpoint() -> None:
    payload = {
        "prompt": (
            "Whenever a new CSV arrives, validate records, "
            "calculate monthly totals and create a report."
        ),
        "provider": "mock",
    }
    response = client.post("/api/compiler/interpret", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "goal" in data
    assert len(data["inputs"]) >= 1
    assert len(data["clarifications"]) <= 3


def test_api_compile_endpoint() -> None:
    payload = {
        "prompt": (
            "Whenever a new CSV arrives, validate records, "
            "calculate monthly totals and create a report."
        ),
        "provider": "mock",
        "max_repairs": 3,
    }
    response = client.post("/api/compiler/compile", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["workflow"] is not None
    assert len(data["workflow"]["nodes"]) >= 6


def test_api_validate_workflow_endpoint() -> None:
    # Get a valid workflow from compile
    compile_resp = client.post(
        "/api/compiler/compile",
        json={"prompt": "Validate CSV and group by month", "provider": "mock"},
    )
    workflow_dict = compile_resp.json()["workflow"]

    # Validate valid workflow
    val_resp = client.post("/api/workflows/validate", json=workflow_dict)
    assert val_resp.status_code == 200
    assert val_resp.json()["valid"] is True
    assert len(val_resp.json()["errors"]) == 0

    # Introduce invalid node type
    broken = dict(workflow_dict)
    broken["nodes"][0]["type"] = "unregistered.fake_node"
    val_broken = client.post("/api/workflows/validate", json=broken)
    assert val_broken.status_code == 200
    assert val_broken.json()["valid"] is False
    assert len(val_broken.json()["errors"]) > 0


def test_api_run_workflow_endpoint() -> None:
    compile_resp = client.post(
        "/api/compiler/compile",
        json={"prompt": "Validate CSV and group by month", "provider": "mock"},
    )
    workflow_dict = compile_resp.json()["workflow"]

    run_resp = client.post("/api/workflows/run", json={"workflow": workflow_dict})
    assert run_resp.status_code == 200
    data = run_resp.json()
    assert data["status"] == "success"
    assert "node_results" in data
    assert data["node_results"]["node-read"]["status"] == "success"
    assert data["node_results"]["node-monthly"]["status"] == "success"


def test_api_evolve_endpoint() -> None:
    compile_resp = client.post(
        "/api/compiler/compile",
        json={"prompt": "Validate CSV and group by month", "provider": "mock"},
    )
    workflow_dict = compile_resp.json()["workflow"]

    evolve_payload = {
        "workflow": workflow_dict,
        "instruction": "filter out amounts below $100",
        "provider": "mock",
    }
    evolve_resp = client.post("/api/compiler/evolve", json=evolve_payload)
    assert evolve_resp.status_code == 200
    data = evolve_resp.json()
    assert "evolved_workflow" in data
    assert data["evolved_workflow"]["version"] == workflow_dict["version"] + 1
    assert "diff" in data
    assert len(data["validation_errors"]) == 0
