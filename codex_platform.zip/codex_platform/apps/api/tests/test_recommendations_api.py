from fastapi.testclient import TestClient

from apps.api.main import app
from engine.compiler.pipeline import draft_workflow
from engine.compiler.providers import MockProvider
from engine.compiler.schemas import ProductUnderstanding

client = TestClient(app)


def test_api_recommendations_endpoints() -> None:
    understanding = ProductUnderstanding(
        goal="Process monthly CSV",
        summary="A pipeline.",
        target_users=["Auditor"],
        inputs=[],
        outputs=[],
        business_rules=[],
        assumptions=[],
        clarifications=[],
    )
    workflow = draft_workflow(understanding, provider=MockProvider())

    # Generate recommendations
    res = client.post(
        "/api/recommendations/generate",
        json={
            "understanding": understanding.model_dump(mode="json"),
            "workflow": workflow.model_dump(mode="json"),
        },
    )
    assert res.status_code == 200
    recs = res.json()
    assert isinstance(recs, list)
    assert len(recs) >= 4

    # Apply recommendations
    for r in recs:
        if r["id"] == "feat-trend-viz":
            r["decision"] = "accepted"

    apply_res = client.post(
        "/api/recommendations/apply",
        json={
            "workflow": workflow.model_dump(mode="json"),
            "recommendations": recs,
        },
    )
    assert apply_res.status_code == 200
    data = apply_res.json()
    assert data["applied_count"] >= 1
    updated_nodes = data["workflow"]["nodes"]
    report_node = next(n for n in updated_nodes if n["type"] == "output.report")
    assert report_node["config"].get("chart_type") == "bar"
