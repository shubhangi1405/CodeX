"""Milestone D6 Tests: Persisted adaptive state, restyle, regenerate-look, revert, and DB safety."""

import importlib.util
import json
import os
import sys
from pathlib import Path
from typing import Any

from fastapi.testclient import TestClient

from apps.api.main import app

client = TestClient(app)


def _compile_habit_workflow() -> dict[str, Any]:
    resp = client.post(
        "/api/compiler/compile",
        json={
            "prompt": "Build a daily habit tracker for morning rituals and streak consistency",
            "provider": "mock",
        },
    )
    assert resp.status_code == 200
    wf: dict[str, Any] = resp.json()["workflow"]
    wf["name"] = "Daily Habit Tracker"
    wf["description"] = "Track daily habits, morning rituals, streaks, and consistency."
    return wf


def test_d6_restyle_regenerate_and_revert_preserve_backend_routes_and_sqlite_data(
    tmp_path: Path,
) -> None:
    wf_dict = _compile_habit_workflow()

    # 1. Generate initial app via POST /api/generate
    gen_resp = client.post(
        "/api/generate",
        json={"workflow": wf_dict, "output_base_dir": str(tmp_path)},
    )
    assert gen_resp.status_code == 200
    initial_manifest = gen_resp.json()
    project_id = initial_manifest["project_id"]
    initial_routes = initial_manifest["routes"]
    initial_models = initial_manifest["models"]
    initial_dir = initial_manifest["design_direction"]
    assert initial_dir["direction_id"] == "editorial_calm"
    assert initial_dir["color_mode"] == "light"
    assert len(initial_manifest["direction_proposals"]) == 3

    # 2. Verify persisted adaptive state via GET /api/generate/state/{project_id}
    state_resp = client.get(f"/api/generate/state/{project_id}")
    assert state_resp.status_code == 200
    state_data = state_resp.json()
    assert json.loads(state_data["domain_analysis_json"])["archetype"] == "habit_or_goal_tracker"
    assert json.loads(state_data["app_blueprint_json"])["home_page_id"] == "today-rituals"
    assert json.loads(state_data["look_fingerprint_json"])["heading_font"] == "Fraunces"

    # 3. Boot generated backend and insert a real habit record into SQLite
    backend_dir = Path(initial_manifest["output_dir"]) / "backend"
    orig_cwd = Path.cwd()
    sys.path.insert(0, str(backend_dir))
    try:
        os.chdir(backend_dir)
        for mod_name in ("database", "models", "seed", "main"):
            sys.modules.pop(mod_name, None)

        spec = importlib.util.spec_from_file_location("main", backend_dir / "main.py")
        assert spec is not None and spec.loader is not None
        main_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(main_mod)
        gen_client = TestClient(main_mod.app)

        post_rec = gen_client.post(
            "/api/habit_ritual",
            json={
                "ritual_name": "Evening Reading 30m",
                "cadence": "Daily",
                "target_minutes": 30,
                "current_streak": 12,
                "completed_today": True,
            },
        )
        assert post_rec.status_code == 201
        saved_id = post_rec.json()["id"]
    finally:
        os.chdir(orig_cwd)
        if str(backend_dir) in sys.path:
            sys.path.remove(str(backend_dir))
        for mod_name in ("database", "models", "seed", "main"):
            sys.modules.pop(mod_name, None)

    # 4. Apply natural-language restyle ("make it darker, denser tables, and use green")
    restyle_resp = client.post(
        "/api/generate/restyle",
        json={
            "project_id": project_id,
            "instruction": "make it darker, denser tables, and use green",
            "output_base_dir": str(tmp_path),
        },
    )
    assert restyle_resp.status_code == 200
    restyled_manifest = restyle_resp.json()
    restyled_dir = restyled_manifest["design_direction"]
    assert restyled_dir["color_mode"] == "dark"
    assert restyled_dir["density"] == "compact"
    assert restyled_manifest["previous_design_direction"]["direction_id"] == "editorial_calm"
    assert restyled_manifest["design_history_count"] == 1
    assert restyled_manifest["validation_report"]["valid"] is True
    assert restyled_manifest["routes"] == initial_routes
    assert restyled_manifest["models"] == initial_models

    # 5. Regenerate look (switches to next distinct direction)
    regen_resp = client.post(
        "/api/generate/regenerate-look",
        json={"project_id": project_id, "output_base_dir": str(tmp_path)},
    )
    assert regen_resp.status_code == 200
    regen_manifest = regen_resp.json()
    assert regen_manifest["design_direction"]["direction_id"] != restyled_dir["direction_id"]
    assert regen_manifest["design_history_count"] == 2
    assert regen_manifest["routes"] == initial_routes

    # 6. Revert look twice back to original editorial_calm
    rev1 = client.post(
        "/api/generate/revert-look",
        json={"project_id": project_id, "output_base_dir": str(tmp_path)},
    )
    assert rev1.status_code == 200
    assert rev1.json()["design_direction"]["color_mode"] == "dark"

    rev2 = client.post(
        "/api/generate/revert-look",
        json={"project_id": project_id, "output_base_dir": str(tmp_path)},
    )
    assert rev2.status_code == 200
    rev2_manifest = rev2.json()
    assert rev2_manifest["design_direction"]["direction_id"] == "editorial_calm"
    assert rev2_manifest["design_direction"]["color_mode"] == "light"
    assert rev2_manifest["design_history_count"] == 0

    # 7. Verify the SQLite database record inserted in step 3 is STILL intact!
    sys.path.insert(0, str(backend_dir))
    try:
        os.chdir(backend_dir)
        for mod_name in ("database", "models", "seed", "main"):
            sys.modules.pop(mod_name, None)

        spec = importlib.util.spec_from_file_location("main", backend_dir / "main.py")
        assert spec is not None and spec.loader is not None
        main_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(main_mod)
        gen_client_after = TestClient(main_mod.app)

        rows = gen_client_after.get("/api/habit_ritual").json()
        assert len(rows) == 1
        assert rows[0]["id"] == saved_id
        assert rows[0]["ritual_name"] == "Evening Reading 30m"
    finally:
        os.chdir(orig_cwd)
        if str(backend_dir) in sys.path:
            sys.path.remove(str(backend_dir))
        for mod_name in ("database", "models", "seed", "main"):
            sys.modules.pop(mod_name, None)
