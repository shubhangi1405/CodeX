"""Milestone D5 Tests: Stage E Blueprint-driven AppGenerator, backend CRUD, and zero-leakage."""

import importlib.util
import sys
from pathlib import Path

from fastapi.testclient import TestClient

from generators.app_generator import AppGenerator
from generators.blueprint.archetypes import BENCHMARK_BUNDLES
from generators.frontend_composer import validate_custom_tsx_component


def test_deterministic_generation_same_blueprint_and_direction(tmp_path: Path) -> None:
    bundle = BENCHMARK_BUNDLES["daily_habit_tracker"]
    out1 = tmp_path / "run1"
    out2 = tmp_path / "run2"

    m1 = AppGenerator.generate_from_blueprint(
        blueprint=bundle.blueprint,
        direction=bundle.primary_direction,
        output_base_dir=str(out1),
        sample_seed_data=bundle.sample_seed_data,
    )
    m2 = AppGenerator.generate_from_blueprint(
        blueprint=bundle.blueprint,
        direction=bundle.primary_direction,
        output_base_dir=str(out2),
        sample_seed_data=bundle.sample_seed_data,
    )

    map1 = {f.path: f.content for f in m1.files}
    map2 = {f.path: f.content for f in m2.files}
    assert set(map1.keys()) == set(map2.keys())
    for rel_path, content1 in map1.items():
        assert content1 == map2[rel_path], f"Non-deterministic output in {rel_path}"


def test_two_different_blueprints_produce_visibly_different_code_and_zero_leakage(
    tmp_path: Path,
) -> None:
    habit_bundle = BENCHMARK_BUNDLES["daily_habit_tracker"]
    sec_bundle = BENCHMARK_BUNDLES["security_event_log_viewer"]

    habit_manifest = AppGenerator.generate_from_blueprint(
        blueprint=habit_bundle.blueprint,
        direction=habit_bundle.primary_direction,
        output_base_dir=str(tmp_path),
        sample_seed_data=habit_bundle.sample_seed_data,
    )
    sec_manifest = AppGenerator.generate_from_blueprint(
        blueprint=sec_bundle.blueprint,
        direction=sec_bundle.primary_direction,
        output_base_dir=str(tmp_path),
        sample_seed_data=sec_bundle.sample_seed_data,
    )

    assert habit_manifest.models == ["HabitRitualModel", "ReflectionNoteModel"]
    assert sec_manifest.models == ["SecurityEventModel", "DetectionRuleModel"]
    assert "GET /api/habit_ritual" in habit_manifest.routes
    assert "GET /api/security_event" in sec_manifest.routes
    assert set(habit_manifest.models).isdisjoint(set(sec_manifest.models))

    habit_files = {f.path: f.content for f in habit_manifest.files}
    sec_files = {f.path: f.content for f in sec_manifest.files}

    # Neither has needs_automation, so backend/engine.py must NOT be emitted
    assert "backend/engine.py" not in habit_files
    assert "backend/engine.py" not in sec_files

    # Tokens and standalone HTML must differ in palette, fonts, shell, and layout
    assert (
        habit_files["frontend/src/design-tokens.css"] != sec_files["frontend/src/design-tokens.css"]
    )
    assert "Fraunces" in habit_files["frontend/src/design-tokens.css"]
    assert "Space Grotesk" in sec_files["frontend/src/design-tokens.css"]
    assert 'data-direction="editorial_calm"' in habit_files["standalone_app.html"]
    assert 'data-direction="console_dark"' in sec_files["standalone_app.html"]

    # Zero leakage assertions across every generated file of both non-CSV apps
    for manifest in (habit_manifest, sec_manifest):
        assert manifest.validation_report is not None
        assert manifest.validation_report.valid is True
        assert manifest.validation_report.leakage_violations == []
        for gf in manifest.files:
            lower = gf.content.lower()
            assert "csv" not in lower, f"Leaked 'csv' in {manifest.project_id}/{gf.path}"
            assert "production verified" not in lower
            assert "bit-for-bit" not in lower
            assert "14250.00" not in lower
            assert "ghostwriter" not in lower
            assert "codex" not in lower


def test_generated_backend_executes_real_entity_crud_and_seed(
    tmp_path: Path, monkeypatch: object
) -> None:
    court_bundle = BENCHMARK_BUNDLES["sports_court_booking"]
    manifest = AppGenerator.generate_from_blueprint(
        blueprint=court_bundle.blueprint,
        direction=court_bundle.primary_direction,
        output_base_dir=str(tmp_path),
        project_id_override="court_test_app",
        sample_seed_data=court_bundle.sample_seed_data,
    )

    backend_dir = Path(manifest.output_dir) / "backend"
    sys.path.insert(0, str(backend_dir))
    orig_cwd = Path.cwd()
    try:
        import os

        os.chdir(backend_dir)
        for mod_name in ("database", "models", "seed", "main"):
            sys.modules.pop(mod_name, None)

        spec = importlib.util.spec_from_file_location("main", backend_dir / "main.py")
        assert spec is not None and spec.loader is not None
        main_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(main_mod)

        test_client = TestClient(main_mod.app)

        # 1. Health check
        health = test_client.get("/api/health")
        assert health.status_code == 200
        assert health.json()["archetype"] == "booking_scheduler"

        # 2. Initially empty (no hardcoded demo records)
        initial_list = test_client.get("/api/court_reservation")
        assert initial_list.status_code == 200
        assert initial_list.json() == []

        # 3. Create a court reservation
        create_resp = test_client.post(
            "/api/court_reservation",
            json={
                "court_name": "Court 1 - Championship Clay",
                "booking_date": "2026-10-20",
                "time_slot": "09:00 - 10:30",
                "player_captain": "Serena Test",
                "court_fee": 45.0,
            },
        )
        assert create_resp.status_code == 201
        created = create_resp.json()
        assert created["player_captain"] == "Serena Test"
        rec_id = created["id"]

        # 4. Update reservation
        upd_resp = test_client.put(
            f"/api/court_reservation/{rec_id}",
            json={"player_captain": "Serena Updated"},
        )
        assert upd_resp.status_code == 200
        assert upd_resp.json()["player_captain"] == "Serena Updated"

        # 5. Delete reservation
        del_resp = test_client.delete(f"/api/court_reservation/{rec_id}")
        assert del_resp.status_code == 200

        # 6. Seed sample data via /api/seed
        seed_resp = test_client.post("/api/seed")
        assert seed_resp.status_code == 200
        after_seed = test_client.get("/api/court_reservation").json()
        assert len(after_seed) >= 2
    finally:
        import os

        os.chdir(orig_cwd)
        if str(backend_dir) in sys.path:
            sys.path.remove(str(backend_dir))
        for mod_name in ("database", "models", "seed", "main"):
            sys.modules.pop(mod_name, None)


def test_custom_widget_validator_enforces_rules() -> None:
    valid_code = """import React from 'react';
import { Card, Badge } from '../ui_kit';

export function StreakPill(): React.ReactElement {
  return (
    <Card>
      <Badge tone="primary">7 Day Streak</Badge>
    </Card>
  );
}
"""
    assert validate_custom_tsx_component("StreakPill.tsx", valid_code) == []

    invalid_code = """import React from 'react';
import axios from 'axios';

export function BadWidget(): React.ReactElement {
  fetch('/api/hack');
  return <div style={{ color: '#FF00AA' }}>Bad</div>;
}
"""
    errs = validate_custom_tsx_component("BadWidget.tsx", invalid_code)
    assert len(errs) == 4
