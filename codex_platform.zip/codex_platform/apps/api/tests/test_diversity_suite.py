"""Milestone D7 Diversity Suite: 8 benchmark apps, 28-pair distance >= 4, WCAG AA, zero leakage."""

from pathlib import Path

from generators.app_generator import AppGenerator
from generators.blueprint.archetypes import BENCHMARK_BUNDLES, resolve_benchmark_bundle
from generators.design.fingerprint import compute_fingerprint, fingerprint_distance
from generators.design.schemas import LookFingerprint
from generators.schemas import GeneratedAppManifest

BENCHMARK_PROMPTS: list[tuple[str, str]] = [
    ("csv_ingestion_monthly_totals", "CSV ingestion with monthly totals"),
    ("daily_habit_tracker", "daily habit tracker"),
    ("security_event_log_viewer", "security event log viewer"),
    ("sports_court_booking", "sports court booking"),
    ("hackathon_team_finder", "hackathon team finder for students"),
    ("restaurant_inventory", "restaurant inventory"),
    ("clinic_appointment_scheduling", "clinic appointment scheduling"),
    ("freelance_invoice_tracker", "freelance invoice tracker"),
]


def test_eight_benchmark_apps_diversity_contrast_and_zero_leakage(tmp_path: Path) -> None:
    assert len(BENCHMARK_PROMPTS) == 8
    assert len(BENCHMARK_BUNDLES) == 8

    manifests: dict[str, GeneratedAppManifest] = {}
    fingerprints: list[tuple[str, LookFingerprint]] = []

    for slug, prompt in BENCHMARK_PROMPTS:
        bundle = resolve_benchmark_bundle(prompt)
        assert bundle.benchmark_key == slug, (
            f"Prompt '{prompt}' resolved to {bundle.benchmark_key} instead of {slug}"
        )

        manifest = AppGenerator.generate_from_blueprint(
            blueprint=bundle.blueprint,
            direction=bundle.primary_direction,
            output_base_dir=str(tmp_path),
            project_id_override=slug,
            sample_seed_data=bundle.sample_seed_data,
            direction_proposals=bundle.direction_proposals,
            existing_fingerprints=fingerprints,
            allow_opt_in_footer=False,
        )
        assert manifest.blueprint is not None
        assert manifest.design_direction is not None
        assert manifest.validation_report is not None
        assert manifest.validation_report.valid is True
        assert manifest.validation_report.leakage_violations == []

        # Verify all 9 WCAG 2.1 AA contrast pairs pass
        assert len(manifest.validation_report.contrast_pairs) == 9
        for pair in manifest.validation_report.contrast_pairs:
            assert pair.passed is True, (
                f"{slug} failed WCAG AA on {pair.pair_name}: "
                f"{pair.contrast_ratio}:1 < {pair.required_ratio}:1"
            )

        fp = compute_fingerprint(
            manifest.blueprint.domain,
            manifest.blueprint,
            manifest.design_direction,
        )
        manifests[slug] = manifest
        fingerprints.append((slug, fp))

        # Check non-CSV apps have zero CSV or brand leakage across all files
        if slug != "csv_ingestion_monthly_totals":
            for gf in manifest.files:
                lower = gf.content.lower()
                assert "csv" not in lower, f"Leaked 'csv' in {slug}/{gf.path}"
                assert "upload csv" not in lower, f"Leaked 'upload csv' in {slug}/{gf.path}"
                assert "14250" not in lower, f"Leaked demo number in {slug}/{gf.path}"
                assert "production verified" not in lower
                assert "bit-for-bit" not in lower
                assert "ghostwriter" not in lower
                assert "codex" not in lower

    # 1. All 28 pairs must have fingerprint distance >= 4 of 8 attributes
    pair_count = 0
    for i in range(len(fingerprints)):
        slug_a, fp_a = fingerprints[i]
        for j in range(i + 1, len(fingerprints)):
            slug_b, fp_b = fingerprints[j]
            dist = fingerprint_distance(fp_a, fp_b)
            pair_count += 1
            assert dist >= 4, (
                f"Fingerprint collision between {slug_a} and {slug_b}: "
                f"distance={dist} (< 4). fp_a={fp_a.as_tuple()}, fp_b={fp_b.as_tuple()}"
            )
    assert pair_count == 28

    # 2. Aggregate diversity assertions across the 8 benchmark apps
    home_layouts = {fp.home_layout for _, fp in fingerprints}
    nav_patterns = {fp.nav_pattern for _, fp in fingerprints}
    color_modes = {fp.color_mode for _, fp in fingerprints}
    heading_fonts = {fp.heading_font for _, fp in fingerprints}

    assert len(home_layouts) >= 6, f"Expected >= 6 distinct home layouts, got {len(home_layouts)}"
    assert len(nav_patterns) >= 4, f"Expected >= 4 distinct nav patterns, got {len(nav_patterns)}"
    assert "light" in color_modes
    assert "dark" in color_modes
    assert len(heading_fonts) >= 4, f"Expected >= 4 heading fonts, got {len(heading_fonts)}"
