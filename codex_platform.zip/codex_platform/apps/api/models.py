"""SQLAlchemy models for persisting adaptive blueprints, directions, history, and fingerprints."""

from datetime import datetime, timezone

from sqlalchemy import Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from apps.api.database import Base, engine


class AdaptiveGenerationRecord(Base):
    """Persists Stage A-D adaptive state per generated project."""

    __tablename__ = "adaptive_generations"

    project_id: Mapped[str] = mapped_column(String, primary_key=True, index=True)
    app_name: Mapped[str] = mapped_column(String, nullable=False)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    workflow_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    domain_analysis_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    app_blueprint_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    design_direction_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    design_proposals_json: Mapped[str] = mapped_column(Text, default="[]", nullable=False)
    design_history_json: Mapped[str] = mapped_column(Text, default="[]", nullable=False)
    look_fingerprint_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    updated_at: Mapped[str] = mapped_column(
        String,
        default=lambda: datetime.now(timezone.utc).isoformat(),
        nullable=False,
    )


Base.metadata.create_all(bind=engine)
