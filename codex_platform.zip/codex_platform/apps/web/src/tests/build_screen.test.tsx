import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { BuildScreen } from '../components/screens/BuildScreen';

const mockManifest = {
  project_id: 'daily_habit_tracker',
  name: 'Daily Habit Tracker',
  version: 1,
  output_dir: 'apps/generated/daily_habit_tracker',
  files: [
    {
      path: 'standalone_app.html',
      content: '<!DOCTYPE html><html><body>Habit Rituals</body></html>',
      category: 'frontend',
      description: 'Standalone HTML',
      size_bytes: 55,
    },
  ],
  routes: ['GET /api/habit_ritual', 'POST /api/habit_ritual'],
  models: ['HabitRitualModel'],
  run_command_backend: 'uvicorn main:app --reload --port 8000',
  run_command_frontend: 'npm run dev',
  generated_at: '2026-10-13T11:00:00Z',
  blueprint: {
    app_name: 'Daily Habit Tracker',
    product_tagline: 'Quiet daily ritual tracking',
    domain: {
      product_kind: 'Habit & Ritual Companion',
      archetype: 'habit_or_goal_tracker',
      primary_object: 'habit_ritual',
      tone: 'calm',
      data_shape: 'time-series',
      needs_automation: false,
    },
    entities: [
      {
        name: 'habit_ritual',
        singular_label: 'Habit Ritual',
        plural_label: 'Habit Rituals',
        fields: [{ name: 'ritual_title', label: 'Ritual Title', field_type: 'string' }],
      },
    ],
    pages: [
      {
        id: 'today_rituals',
        title: 'Today Rituals',
        route: '/',
        layout: 'checklist_today',
        entities_used: ['habit_ritual'],
        primary_actions: ['Log Ritual'],
      },
    ],
    navigation: {
      pattern: 'sidebar',
      items: [{ page_id: 'today_rituals', label: 'Today Rituals', icon: 'check_circle' }],
    },
    home_page_id: 'today_rituals',
  },
  design_direction: {
    direction_id: 'editorial_calm',
    palette: {
      primary: '#2F5233',
      primary_foreground: '#FFFFFF',
      accent: '#B5651D',
      surface: '#FAF7F2',
      surface_elevated: '#FFFFFF',
      border: '#5C574F',
      text: '#1E1D1A',
      text_muted: '#4A4740',
      focus_ring: '#2F5233',
      success: '#2E6F40',
      warning: '#9A5B13',
      danger: '#A62626',
    },
    color_mode: 'light',
    typography: {
      heading_font: 'Fraunces',
      body_font: 'Source Sans 3',
      mono_font: 'IBM Plex Mono',
      scale_ratio: 1.25,
    },
    shape: {
      radius_class: 'soft',
      border_style: 'subtle',
      shadow_style: 'soft',
    },
    density: 'spacious',
    motion: 'subtle',
    iconography: 'outline',
    brand_mark: {
      kind: 'glyph_and_wordmark',
      glyph_primitive: 'leaf_arch',
      monogram_letters: 'DHT',
    },
    copy_voice: 'Encouraging, unhurried sentences.',
    rationale: 'Warm off-white and Fraunces serif create a calm ritual journal.',
  },
  previous_design_direction: {
    direction_id: 'playful_momentum',
    palette: {
      primary: '#C83E2B',
      primary_foreground: '#FFFFFF',
      accent: '#D97706',
      surface: '#FFFDF9',
      surface_elevated: '#FFFFFF',
      border: '#64748B',
      text: '#1E1B18',
      text_muted: '#57534E',
      focus_ring: '#C83E2B',
      success: '#15803D',
      warning: '#B45309',
      danger: '#B91C1C',
    },
    color_mode: 'light',
    typography: {
      heading_font: 'Outfit',
      body_font: 'Plus Jakarta Sans',
      mono_font: 'JetBrains Mono',
      scale_ratio: 1.25,
    },
    shape: {
      radius_class: 'round',
      border_style: 'crisp',
      shadow_style: 'layered',
    },
    density: 'comfortable',
    motion: 'lively',
    iconography: 'solid',
    brand_mark: {
      kind: 'monogram_badge',
      glyph_primitive: 'spark_diamond',
      monogram_letters: 'DHT',
    },
    copy_voice: 'Energetic microcopy.',
    rationale: 'Energetic coral and rounded cards.',
  },
  direction_proposals: [
    {
      direction_id: 'editorial_calm',
      palette: {
        primary: '#2F5233',
        primary_foreground: '#FFFFFF',
        accent: '#B5651D',
        surface: '#FAF7F2',
        surface_elevated: '#FFFFFF',
        border: '#5C574F',
        text: '#1E1D1A',
        text_muted: '#4A4740',
        focus_ring: '#2F5233',
        success: '#2E6F40',
        warning: '#9A5B13',
        danger: '#A62626',
      },
      color_mode: 'light',
      typography: {
        heading_font: 'Fraunces',
        body_font: 'Source Sans 3',
        mono_font: 'IBM Plex Mono',
        scale_ratio: 1.25,
      },
      shape: {
        radius_class: 'soft',
        border_style: 'subtle',
        shadow_style: 'soft',
      },
      density: 'spacious',
      motion: 'subtle',
      iconography: 'outline',
      brand_mark: {
        kind: 'glyph_and_wordmark',
        glyph_primitive: 'leaf_arch',
        monogram_letters: 'DHT',
      },
      copy_voice: 'Encouraging, unhurried sentences.',
      rationale: 'Warm off-white and Fraunces serif create a calm ritual journal.',
    },
  ],
  design_history_count: 1,
  validation_report: {
    valid: true,
    fingerprint: {
      archetype: 'habit_or_goal_tracker',
      nav_pattern: 'sidebar',
      home_layout: 'checklist_today',
      primary_hue_bucket: 120,
      heading_font: 'Fraunces',
      radius_class: 'soft',
      density: 'spacious',
      color_mode: 'light',
    },
    contrast_pairs: [
      {
        pair_name: 'Body text on surface',
        foreground_hex: '#1E1D1A',
        background_hex: '#FAF7F2',
        contrast_ratio: 15.1,
        required_ratio: 4.5,
        passed: true,
      },
    ],
    leakage_violations: [],
  },
};

describe('BuildScreen Milestone D6 Adaptive Controls', () => {
  beforeEach(() => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        json: async () => mockManifest,
      })
    );
  });

  it('renders Blueprint Summary, 3-Direction Chooser, Natural-Language Restyle, Before/After Token Diff, and Revert button', async () => {
    render(<BuildScreen />);

    await waitFor(() => {
      expect(screen.getByTestId('blueprint-summary-card')).toBeDefined();
    });

    expect(screen.getByText('habit_or_goal_tracker')).toBeDefined();
    expect(screen.getByTestId('direction-chooser-card')).toBeDefined();
    expect(screen.getByTestId('natural-language-restyle-card')).toBeDefined();
    expect(screen.getByTestId('before-after-token-diff')).toBeDefined();
    expect(screen.getByTestId('revert-look-btn')).toBeDefined();
    expect(screen.getByTestId('regenerate-look-btn')).toBeDefined();
  });
});
