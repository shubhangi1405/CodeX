import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import {
  AdaptiveLayoutRenderer,
  NavigationShell,
  EntityDef,
  EmptyStateDef,
  RecordItem,
} from '../../../../generators/ui_kit';

const ALL_17_LAYOUTS = [
  'stat_tiles_with_charts',
  'data_table_with_filters',
  'card_grid',
  'kanban_board',
  'calendar_month',
  'calendar_week_agenda',
  'timeline',
  'feed',
  'master_detail',
  'form_wizard',
  'single_form',
  'checklist_today',
  'heatmap_streaks',
  'leaderboard',
  'map_or_location_list',
  'report_document',
  'log_stream',
] as const;

const THREE_DIRECTIONS: Record<string, Record<string, string>> = {
  editorial_calm: {
    '--app-primary': '#245436',
    '--app-primary-fg': '#FFFFFF',
    '--app-surface': '#FBF9F5',
    '--app-surface-elevated': '#FFFFFF',
    '--app-border': '#6B6250',
    '--app-text': '#1C241E',
    '--app-text-muted': '#4B4537',
    '--app-radius-card': '8px',
    '--app-radius-control': '6px',
  },
  console_dark: {
    '--app-primary': '#22D3EE',
    '--app-primary-fg': '#081018',
    '--app-surface': '#0B0F17',
    '--app-surface-elevated': '#141C2B',
    '--app-border': '#64748B',
    '--app-text': '#F1F5F9',
    '--app-text-muted': '#94A3B8',
    '--app-radius-card': '2px',
    '--app-radius-control': '2px',
  },
  playful_momentum: {
    '--app-primary': '#C2381E',
    '--app-primary-fg': '#FFFFFF',
    '--app-surface': '#FFFDF9',
    '--app-surface-elevated': '#FFFFFF',
    '--app-border': '#7A654F',
    '--app-text': '#231815',
    '--app-text-muted': '#524132',
    '--app-radius-card': '20px',
    '--app-radius-control': '9999px',
  },
};

const SAMPLE_ENTITY: EntityDef = {
  name: 'habit',
  singularLabel: 'Habit',
  pluralLabel: 'Habits',
  fields: [
    { name: 'title', label: 'Habit Name', fieldType: 'string' },
    {
      name: 'status',
      label: 'Status',
      fieldType: 'enum',
      enumValues: ['Queued', 'Active', 'Completed'],
    },
    { name: 'streak_days', label: 'Streak Days', fieldType: 'integer' },
  ],
};

const SAMPLE_EMPTY: EmptyStateDef = {
  headline: 'No habits scheduled yet',
  body: 'Create your first daily ritual to start tracking streaks.',
  ctaLabel: 'Add First Habit',
  ctaActionId: 'create_habit',
};

const SAMPLE_RECORDS: RecordItem[] = [
  { id: '1', title: 'Morning Mobility', status: 'Active', streak_days: 12, completed: true },
  { id: '2', title: 'Deep Reading', status: 'Queued', streak_days: 7, completed: false },
];

describe('Milestone D3: Themeable UI Kit (17 layouts x 3 directions + 5 nav shells)', () => {
  it('renders all 17 layouts across 3 contrasting design directions without hardcoded colors', () => {
    for (const [dirId, tokens] of Object.entries(THREE_DIRECTIONS)) {
      for (const layout of ALL_17_LAYOUTS) {
        const { container, unmount } = render(
          <div style={tokens as React.CSSProperties} data-direction={dirId}>
            <AdaptiveLayoutRenderer
              layout={layout}
              pageTitle={`${layout} (${dirId})`}
              entity={SAMPLE_ENTITY}
              records={SAMPLE_RECORDS}
              primaryActions={['Create Habit']}
              emptyState={SAMPLE_EMPTY}
              onCreateRecord={vi.fn()}
              onRequestCreateModal={vi.fn()}
            />
          </div>
        );

        const layoutNode = container.querySelector(`[data-layout="${layout}"]`);
        expect(layoutNode).not.toBeNull();
        unmount();
      }
    }
  });

  it('renders domain-specific empty states when records are empty', () => {
    render(
      <AdaptiveLayoutRenderer
        layout="checklist_today"
        pageTitle="Today's Rituals"
        entity={SAMPLE_ENTITY}
        records={[]}
        primaryActions={['Create Habit']}
        emptyState={SAMPLE_EMPTY}
        onCreateRecord={vi.fn()}
        onRequestCreateModal={vi.fn()}
      />
    );
    expect(screen.getByText('No habits scheduled yet')).toBeDefined();
    expect(screen.getByText('Add First Habit')).toBeDefined();
  });

  it('renders all 5 navigation shells cleanly', () => {
    const patterns = [
      'sidebar',
      'top_tabs',
      'bottom_tabs',
      'command_palette_plus_minimal_top',
      'split_master_detail',
    ] as const;

    for (const pattern of patterns) {
      const { container, unmount } = render(
        <NavigationShell
          pattern={pattern}
          brand={{
            appName: 'Cadence',
            tagline: 'Daily Rituals',
            glyphPrimitive: 'leaf_arch',
            monogram: 'CD',
          }}
          items={[
            { pageId: 'today', label: 'Today', icon: 'check-circle' },
            { pageId: 'streaks', label: 'Streaks', icon: 'flame' },
          ]}
          activePageId="today"
          onNavigate={vi.fn()}
        >
          <div>Page Content</div>
        </NavigationShell>
      );
      expect(container.querySelector(`[data-shell="${pattern}"]`)).not.toBeNull();
      unmount();
    }
  });
});
