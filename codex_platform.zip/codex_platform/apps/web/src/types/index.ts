export type StepId =
  | 'projects'
  | 'describe'
  | 'understanding'
  | 'recommendations'
  | 'specification'
  | 'workflow'
  | 'tests'
  | 'build';

export interface StepItem {
  id: StepId;
  label: string;
  number: number;
  unlocked: boolean;
  completed: boolean;
}

export interface Project {
  id: string;
  name: string;
  prompt: string;
  created_at: string;
  status: 'draft' | 'running' | 'completed' | 'failed';
  current_step: number;
}

export interface FeatureRecommendation {
  id: string;
  title: string;
  description: string;
  rationale?: string;
  tier: 'essential' | 'recommended' | 'optional' | 'future';
  complexity: 'S' | 'M' | 'L';
  dependencies: string[];
  risks: string[];
  decision: 'pending' | 'accepted' | 'rejected' | 'deferred';
}

export interface NodePort {
  name: string;
  dataType: string;
}

export interface WorkflowNodeData {
  id: string;
  type: string;
  label: string;
  category: 'trigger' | 'ingest' | 'validate' | 'transform' | 'aggregate' | 'branch' | 'output' | 'quality';
  config: Record<string, unknown>;
  inputPorts: NodePort[];
  outputPorts: NodePort[];
  status?: 'idle' | 'running' | 'success' | 'failed' | 'skipped';
  durationMs?: number;
  rowCountIn?: number;
  rowCountOut?: number;
  rejectedCount?: number;
  errorMessage?: string;
}

export interface RunRecord {
  id: string;
  workflowVersion: number;
  status: 'running' | 'success' | 'failed';
  startedAt: string;
  durationMs: number;
  inputHash: string;
  nodeResults: Record<string, {
    status: 'success' | 'failed' | 'skipped';
    durationMs: number;
    rowCountIn: number;
    rowCountOut: number;
    rejectedCount: number;
    errors?: string[];
  }>;
}

export type ItemAttribution = 'user_stated' | 'assumption' | 'ai_recommendation';

export interface UnderstandingItem {
  id: string;
  title: string;
  description: string;
  attribution: ItemAttribution;
  editable: boolean;
}

export interface ClarificationQuestion {
  id: string;
  question: string;
  context: string;
  options: string[];
  default_choice: string;
  selected_choice?: string;
}

export interface ProductUnderstanding {
  goal: string;
  summary: string;
  target_users: string[];
  inputs: UnderstandingItem[];
  outputs: UnderstandingItem[];
  business_rules: UnderstandingItem[];
  assumptions: UnderstandingItem[];
  clarifications: ClarificationQuestion[];
}

export interface RepairAttempt {
  attempt: number;
  errors_encountered: string[];
  repair_summary: string;
  success: boolean;
}

export interface CompilationResult {
  success: boolean;
  understanding: ProductUnderstanding;
  workflow?: Record<string, unknown>;
  validation_errors: string[];
  repair_history: RepairAttempt[];
  diagnostics: string;
}

export interface TestCaseModel {
  id: string;
  name: string;
  description: string;
  category: 'happy_path' | 'edge_case' | 'stress';
  edge_case_type?: string;
  input_data: Record<string, unknown>;
  expected_output: Record<string, unknown>;
  expect_failure: boolean;
  expected_failure_node?: string;
  remediation_hint?: string;
}

export interface TestResultModel {
  test_case_id: string;
  name: string;
  category: 'happy_path' | 'edge_case' | 'stress';
  passed: boolean;
  duration_ms: number;
  expected_output: Record<string, unknown>;
  actual_output: Record<string, unknown>;
  failing_node?: string;
  explanation?: string;
  remediation?: string;
  run_record?: Record<string, unknown>;
}

export interface TestSuiteResultModel {
  workflow_id: string;
  total_tests: number;
  passed_tests: number;
  failed_tests: number;
  all_passed: boolean;
  results: TestResultModel[];
}

