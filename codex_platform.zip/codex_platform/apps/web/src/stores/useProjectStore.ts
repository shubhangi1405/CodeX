import { create } from 'zustand';
import {
  Project,
  StepId,
  ProductUnderstanding,
  CompilationResult,
  RepairAttempt,
  TestCaseModel,
  TestResultModel,
  TestSuiteResultModel,
} from '../types';
import { API_BASE } from '../api/config';


interface ProjectState {
  currentProject: Project | null;
  activeStep: StepId;
  completedSteps: Set<StepId>;
  unlockedSteps: Set<StepId>;
  promptInput: string;
  sampleFileName: string | null;
  selectedProvider: 'mock' | 'gemini' | 'openai';

  // Compiler state
  isCompiling: boolean;
  compilationError: string | null;
  productUnderstanding: ProductUnderstanding | null;
  clarificationAnswers: Record<string, string>;
  compiledWorkflow: Record<string, unknown> | null;
  repairHistory: RepairAttempt[];
  validationErrors: string[];
  compileDiagnostics: string;

  // Test suite state
  generatedTests: TestCaseModel[];
  testResults: TestResultModel[];
  isTesting: boolean;
  testSuiteSummary: TestSuiteResultModel | null;

  setCurrentProject: (project: Project) => void;
  setActiveStep: (step: StepId) => void;
  completeStep: (step: StepId) => void;
  unlockStep: (step: StepId) => void;
  setPromptInput: (prompt: string) => void;
  setSampleFileName: (name: string | null) => void;
  setSelectedProvider: (provider: 'mock' | 'gemini' | 'openai') => void;
  setClarificationAnswer: (questionId: string, answer: string) => void;
  setProductUnderstanding: (understanding: ProductUnderstanding) => void;
  setCompiledWorkflow: (workflow: Record<string, unknown> | null) => void;

  interpretPrompt: () => Promise<void>;
  compileWorkflow: () => Promise<boolean>;
  fetchOrGenerateTests: () => Promise<void>;
  executeTestSuite: () => Promise<boolean>;
}


const DEFAULT_PROJECT: Project = {
  id: 'default-sample',
  name: 'CSV Monthly Totals Pipeline',
  prompt:
    'Whenever a new CSV arrives, validate the records, identify missing fields, calculate monthly totals and create a report.',
  created_at: new Date().toISOString(),
  status: 'draft',
  current_step: 1,
};

function deriveProjectMeta(prompt: string, goal?: string): {
  name: string;
  sampleFile: string;
} {
  const combined = `${prompt} ${goal || ''}`.toLowerCase();
  if (
    combined.includes('calendar') ||
    combined.includes('claendar') ||
    combined.includes('calender') ||
    combined.includes('reminder') ||
    combined.includes('remind') ||
    combined.includes('agenda') ||
    combined.includes('schedule')
  ) {
    return {
      name: 'TimeFlow Calendar & Reminders',
      sampleFile: 'events_and_reminders.json',
    };
  }
  if (
    combined.includes('habit') ||
    combined.includes('streak') ||
    combined.includes('routine')
  ) {
    return {
      name: 'Habit Tracker & Streak Analytics',
      sampleFile: 'habit_checkins.csv',
    };
  }
  if (combined.includes('fitness') || combined.includes('workout')) {
    return {
      name: 'Fitness & Workout Tracker',
      sampleFile: 'workout_logs.csv',
    };
  }
  if (
    combined.includes('task') ||
    combined.includes('todo') ||
    combined.includes('sprint')
  ) {
    return {
      name: 'Task & Sprint Velocity Tracker',
      sampleFile: 'sprint_tasks.csv',
    };
  }
  if (
    combined.includes('expense') ||
    combined.includes('budget') ||
    combined.includes('spending') ||
    combined.includes('receipt') ||
    combined.includes('finance')
  ) {
    return {
      name: 'Personal Expense & Budget Tracker',
      sampleFile: 'expenses.json',
    };
  }
  if (combined.includes('order') || combined.includes('ecommerce')) {
    return {
      name: 'Customer Order Fulfillment Pipeline',
      sampleFile: 'customer_orders.csv',
    };
  }
  if (
    combined.includes('shift') ||
    combined.includes('payroll') ||
    combined.includes('attendance')
  ) {
    return {
      name: 'Shift & Timesheet Analytics',
      sampleFile: 'shift_timesheets.csv',
    };
  }
  if (combined.includes('inventory') || combined.includes('warehouse')) {
    return {
      name: 'Warehouse Inventory Control',
      sampleFile: 'inventory_ledger.csv',
    };
  }
  if (combined.includes('court') || combined.includes('booking') || combined.includes('reservation')) {
    return {
      name: 'Sports Court Booking & Conflict Engine',
      sampleFile: 'court_reservations.csv',
    };
  }
  if (combined.includes('security') || combined.includes('siem') || combined.includes('threat') || combined.includes('audit log')) {
    return {
      name: 'Security Event Triage & Threat Stream',
      sampleFile: 'security_events.csv',
    };
  }
  if (combined.includes('hackathon') || combined.includes('team finder') || combined.includes('teammate')) {
    return {
      name: 'Hackathon Team & Skill Matchmaker',
      sampleFile: 'hackathon_applicants.csv',
    };
  }
  if (combined.includes('clinic') || combined.includes('patient') || combined.includes('appointment')) {
    return {
      name: 'Clinical Appointment & Triage Queue',
      sampleFile: 'clinical_appointments.csv',
    };
  }
  if (combined.includes('invoice') || combined.includes('freelance') || combined.includes('retainer')) {
    return {
      name: 'Client Invoice & Receivables Ledger',
      sampleFile: 'client_invoices.csv',
    };
  }
  if (combined.includes('sales') || combined.includes('monthly totals')) {
    return {
      name: 'CSV Monthly Totals Pipeline',
      sampleFile: 'monthly_sales.csv',
    };
  }

  const rawTitle = (goal || prompt || 'Custom Software Pipeline')
    .replace(/^(build|create|make|design|develop|whenever)\s+(a|an|the)?\s*/i, '')
    .split(/[.,;!?]/)[0]
    .trim();
  const cleanName =
    rawTitle.length > 3
      ? rawTitle.charAt(0).toUpperCase() + rawTitle.slice(1, 46)
      : 'Custom Software Pipeline';
  const slug =
    cleanName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_|_$/g, '')
      .slice(0, 24) || 'project';
  return {
    name: cleanName,
    sampleFile: `${slug}_data.csv`,
  };
}

export const useProjectStore = create<ProjectState>((set, get) => ({
  currentProject: DEFAULT_PROJECT,
  activeStep: 'describe',
  completedSteps: new Set<StepId>([]),
  unlockedSteps: new Set<StepId>([
    'projects',
    'describe',
    'understanding',
    'recommendations',
    'specification',
    'workflow',
    'tests',
    'build',
  ]),
  promptInput: DEFAULT_PROJECT.prompt,
  sampleFileName: 'monthly_sales.csv',
  selectedProvider: 'gemini',

  isCompiling: false,
  compilationError: null,
  productUnderstanding: null,
  clarificationAnswers: {},
  compiledWorkflow: null,
  repairHistory: [],
  validationErrors: [],
  compileDiagnostics: '',

  generatedTests: [],
  testResults: [],
  isTesting: false,
  testSuiteSummary: null,

  setCurrentProject: (project) => {
    const meta = deriveProjectMeta(project.prompt, project.name);
    set({
      currentProject: project,
      promptInput: project.prompt,
      sampleFileName: meta.sampleFile,
      productUnderstanding: null,
      compiledWorkflow: null,
      generatedTests: [],
      testResults: [],
      testSuiteSummary: null,
    });
  },
  setActiveStep: (step) => set({ activeStep: step }),
  completeStep: (step) =>
    set((state) => {
      const nextCompleted = new Set(state.completedSteps);
      nextCompleted.add(step);
      return { completedSteps: nextCompleted };
    }),
  unlockStep: (step) =>
    set((state) => {
      const nextUnlocked = new Set(state.unlockedSteps);
      nextUnlocked.add(step);
      return { unlockedSteps: nextUnlocked };
    }),
  setPromptInput: (prompt) => set({ promptInput: prompt }),
  setSampleFileName: (name) => set({ sampleFileName: name }),
  setSelectedProvider: (provider) => set({ selectedProvider: provider }),
  setClarificationAnswer: (questionId, answer) =>
    set((state) => ({
      clarificationAnswers: {
        ...state.clarificationAnswers,
        [questionId]: answer,
      },
    })),
  setProductUnderstanding: (understanding) =>
    set({ productUnderstanding: understanding }),
  setCompiledWorkflow: (workflow) => set({ compiledWorkflow: workflow }),

  interpretPrompt: async () => {
    const { promptInput, selectedProvider, currentProject } = get();
    set({
      isCompiling: true,
      compilationError: null,
      compiledWorkflow: null,
      generatedTests: [],
      testResults: [],
      testSuiteSummary: null,
    });

    try {
      const res = await fetch(`${API_BASE}/api/compiler/interpret`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptInput,
          provider: selectedProvider,
        }),
      });

      if (!res.ok) {
        throw new Error(`API returned error: ${res.statusText}`);
      }

      const data: ProductUnderstanding = await res.json();
      const defaultAnswers: Record<string, string> = {};
      data.clarifications.forEach((q) => {
        defaultAnswers[q.id] = q.selected_choice || q.default_choice;
      });

      const meta = deriveProjectMeta(promptInput, data.goal);
      const updatedProject: Project = currentProject
        ? {
            ...currentProject,
            name: meta.name,
            prompt: promptInput,
          }
        : {
            id: `proj-${Date.now()}`,
            name: meta.name,
            prompt: promptInput,
            created_at: new Date().toISOString(),
            status: 'draft',
            current_step: 2,
          };

      set({
        currentProject: updatedProject,
        sampleFileName: meta.sampleFile,
        productUnderstanding: data,
        clarificationAnswers: defaultAnswers,
        isCompiling: false,
      });
    } catch {
      const meta = deriveProjectMeta(promptInput);
      const isCal = promptInput.toLowerCase().includes('calendar') ||
                    promptInput.toLowerCase().includes('claendar') ||
                    promptInput.toLowerCase().includes('reminder');
      const fallbackUnderstanding: ProductUnderstanding = {
        goal: isCal
          ? 'Manage calendar events, appointments, and priority reminders with schedule agenda and task checklist views.'
          : `Automate operational workflows, tracking, and interactive dashboards for ${meta.name}.`,
        summary: isCal
          ? 'A personal and team calendar scheduling and reminder workspace with week agenda, priority reminders, and upcoming timelines.'
          : `A deterministic application workspace for ${meta.name} that manages core records and generates an interactive dashboard.`,
        target_users: ['Primary User', 'Operations Lead', 'Team Manager'],
        inputs: [
          {
            id: 'inp-file',
            title: `${meta.name} Data Source`,
            description: `Incoming records for ${meta.name}.`,
            attribution: 'user_stated',
            editable: true,
          },
          {
            id: 'inp-encoding',
            title: 'UTF-8 Text Encoding',
            description:
              'Standard text encoding for robust cross-platform parsing.',
            attribution: 'assumption',
            editable: true,
          },
        ],
        outputs: [
          {
            id: 'out-report',
            title: `${meta.name} Executive Report`,
            description:
              'Formatted report with monthly breakdown and KPI metrics.',
            attribution: 'user_stated',
            editable: true,
          },
          {
            id: 'out-audit',
            title: 'Rejected Entries Audit Log',
            description:
              'Detailed log of any entry excluded due to missing fields or bad formats.',
            attribution: 'ai_recommendation',
            editable: true,
          },
        ],
        business_rules: [
          {
            id: 'rule-validate',
            title: 'Entry Schema Validation',
            description:
              'Verify that required fields exist and conform to expected schema.',
            attribution: 'user_stated',
            editable: true,
          },
          {
            id: 'rule-monthly',
            title: 'Monthly Progress & Score Aggregation',
            description:
              'Group valid entries by calendar month (YYYY-MM) and sum metrics.',
            attribution: 'user_stated',
            editable: true,
          },
        ],
        assumptions: [
          {
            id: 'asm-date',
            title: 'Date Column Identifier',
            description: "The entry timestamp column is labeled 'date'.",
            attribution: 'assumption',
            editable: true,
          },
        ],
        clarifications: [
          {
            id: 'cq-error-strategy',
            question: 'How should corrupt or incomplete entries be handled?',
            context: 'If records miss required fields, should the pipeline stop?',
            options: [
              'Drop invalid rows to rejected log and continue',
              'Halt entire workflow on first error',
            ],
            default_choice: 'Drop invalid rows to rejected log and continue',
            selected_choice: 'Drop invalid rows to rejected log and continue',
          },
        ],
      };

      set({
        sampleFileName: meta.sampleFile,
        productUnderstanding: fallbackUnderstanding,
        clarificationAnswers: {
          'cq-error-strategy':
            'Drop invalid rows to rejected log and continue',
        },
        isCompiling: false,
      });
    }
  },

  compileWorkflow: async () => {
    const {
      promptInput,
      clarificationAnswers,
      selectedProvider,
      productUnderstanding,
      currentProject,
    } = get();
    set({ isCompiling: true, compilationError: null });

    try {
      const res = await fetch(`${API_BASE}/api/compiler/compile`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptInput,
          answers: clarificationAnswers,
          provider: selectedProvider,
          max_repairs: 3,
          understanding: productUnderstanding || undefined,
        }),
      });

      if (!res.ok) {
        throw new Error(`Compile failed: ${res.statusText}`);
      }

      const result: CompilationResult = await res.json();
      const wfObj = result.workflow || null;
      const wfName =
        wfObj && typeof wfObj.name === 'string' && wfObj.name.trim()
          ? wfObj.name
          : currentProject?.name || 'Custom Software Pipeline';

      set({
        compiledWorkflow: wfObj,
        currentProject: currentProject
          ? { ...currentProject, name: wfName, prompt: promptInput }
          : null,
        validationErrors: result.validation_errors,
        repairHistory: result.repair_history,
        compileDiagnostics: result.diagnostics,
        isCompiling: false,
      });

      return result.success;
    } catch (e: unknown) {
      set({
        isCompiling: false,
        compilationError:
          e instanceof Error ? e.message : 'Unknown compilation error',
      });
      return false;
    }
  },

  fetchOrGenerateTests: async () => {
    let { compiledWorkflow } = get();
    if (!compiledWorkflow) {
      await get().compileWorkflow();
      compiledWorkflow = get().compiledWorkflow;
    }
    const { currentProject } = get();
    const fallbackName = currentProject?.name || 'Custom Software Pipeline';
    const payloadWorkflow = compiledWorkflow || {
      id: 'wf-custom-pipeline-v1',
      name: fallbackName,
      description: currentProject?.prompt || fallbackName,
      version: 1,
      trigger: { id: 't1', type: 'manual_upload', config: {} },
      nodes: [
        {
          id: 'node-read',
          type: 'ingest.read_csv',
          label: `Ingest ${fallbackName} Records`,
          config: { delimiter: ',', encoding: 'utf-8', has_header: true },
          input_ports: [{ name: 'file', data_type: 'file' }],
          output_ports: [{ name: 'table', data_type: 'table' }],
        },
        {
          id: 'node-req',
          type: 'validate.required_fields',
          label: 'Validate Required Fields',
          config: { required_columns: ['date', 'amount'], rejection_strategy: 'drop' },
          input_ports: [{ name: 'table', data_type: 'table' }],
          output_ports: [{ name: 'table', data_type: 'table' }],
        },
        {
          id: 'node-type',
          type: 'validate.type_check',
          label: 'Type & Range Check',
          config: { column_types: { date: 'date', amount: 'number' }, coerce: true },
          input_ports: [{ name: 'table', data_type: 'table' }],
          output_ports: [{ name: 'table', data_type: 'table' }],
        },
        {
          id: 'node-filter',
          type: 'transform.filter',
          label: 'Filter Active Entries',
          config: { expression: 'amount > 0' },
          input_ports: [{ name: 'table', data_type: 'table' }],
          output_ports: [{ name: 'table', data_type: 'table' }],
        },
        {
          id: 'node-monthly',
          type: 'aggregate.monthly_totals',
          label: 'Monthly Progress & Score Totals',
          config: { date_column: 'date', amount_column: 'amount' },
          input_ports: [{ name: 'table', data_type: 'table' }],
          output_ports: [{ name: 'table', data_type: 'table' }],
        },
        {
          id: 'node-report',
          type: 'output.report',
          label: `Generate ${fallbackName} Report`,
          config: { title: `${fallbackName} Dashboard`, chart_type: 'bar' },
          input_ports: [{ name: 'table', data_type: 'table' }],
          output_ports: [{ name: 'report', data_type: 'report' }],
        },
      ],
      edges: [
        { from_node: 'node-read', from_port: 'table', to_node: 'node-req', to_port: 'table' },
        { from_node: 'node-req', from_port: 'table', to_node: 'node-type', to_port: 'table' },
        { from_node: 'node-type', from_port: 'table', to_node: 'node-filter', to_port: 'table' },
        { from_node: 'node-filter', from_port: 'table', to_node: 'node-monthly', to_port: 'table' },
        { from_node: 'node-monthly', from_port: 'table', to_node: 'node-report', to_port: 'table' },
      ],
    };

    try {
      const res = await fetch(`${API_BASE}/api/tests/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workflow: payloadWorkflow }),
      });
      if (res.ok) {
        const tests: TestCaseModel[] = await res.json();
        set({ generatedTests: tests });
      }
    } catch {
      // Offline fallback
    }
  },

  executeTestSuite: async () => {
    let { compiledWorkflow } = get();
    if (!compiledWorkflow) {
      await get().compileWorkflow();
      compiledWorkflow = get().compiledWorkflow;
    }
    const { generatedTests, currentProject } = get();
    set({ isTesting: true });

    const fallbackName = currentProject?.name || 'Custom Software Pipeline';
    const payloadWorkflow = compiledWorkflow || {
      id: 'wf-custom-pipeline-v1',
      name: fallbackName,
      description: currentProject?.prompt || fallbackName,
      version: 1,
      trigger: { id: 't1', type: 'manual_upload', config: {} },
      nodes: [
        {
          id: 'node-read',
          type: 'ingest.read_csv',
          label: `Ingest ${fallbackName} Records`,
          config: { delimiter: ',', encoding: 'utf-8', has_header: true },
          input_ports: [{ name: 'file', data_type: 'file' }],
          output_ports: [{ name: 'table', data_type: 'table' }],
        },
        {
          id: 'node-req',
          type: 'validate.required_fields',
          label: 'Validate Required Fields',
          config: { required_columns: ['date', 'amount'], rejection_strategy: 'drop' },
          input_ports: [{ name: 'table', data_type: 'table' }],
          output_ports: [{ name: 'table', data_type: 'table' }],
        },
        {
          id: 'node-type',
          type: 'validate.type_check',
          label: 'Type & Range Check',
          config: { column_types: { date: 'date', amount: 'number' }, coerce: true },
          input_ports: [{ name: 'table', data_type: 'table' }],
          output_ports: [{ name: 'table', data_type: 'table' }],
        },
        {
          id: 'node-filter',
          type: 'transform.filter',
          label: 'Filter Active Entries',
          config: { expression: 'amount > 0' },
          input_ports: [{ name: 'table', data_type: 'table' }],
          output_ports: [{ name: 'table', data_type: 'table' }],
        },
        {
          id: 'node-monthly',
          type: 'aggregate.monthly_totals',
          label: 'Monthly Progress & Score Totals',
          config: { date_column: 'date', amount_column: 'amount' },
          input_ports: [{ name: 'table', data_type: 'table' }],
          output_ports: [{ name: 'table', data_type: 'table' }],
        },
        {
          id: 'node-report',
          type: 'output.report',
          label: `Generate ${fallbackName} Report`,
          config: { title: `${fallbackName} Dashboard`, chart_type: 'bar' },
          input_ports: [{ name: 'table', data_type: 'table' }],
          output_ports: [{ name: 'report', data_type: 'report' }],
        },
      ],
      edges: [
        { from_node: 'node-read', from_port: 'table', to_node: 'node-req', to_port: 'table' },
        { from_node: 'node-req', from_port: 'table', to_node: 'node-type', to_port: 'table' },
        { from_node: 'node-type', from_port: 'table', to_node: 'node-filter', to_port: 'table' },
        { from_node: 'node-filter', from_port: 'table', to_node: 'node-monthly', to_port: 'table' },
        { from_node: 'node-monthly', from_port: 'table', to_node: 'node-report', to_port: 'table' },
      ],
    };

    try {
      const res = await fetch(`${API_BASE}/api/tests/run`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workflow: payloadWorkflow,
          tests: generatedTests.length > 0 ? generatedTests : undefined,
        }),
      });

      if (res.ok) {
        const suite: TestSuiteResultModel = await res.json();
        set({
          testSuiteSummary: suite,
          testResults: suite.results,
          isTesting: false,
        });
        return suite.all_passed;
      }
    } catch {
      // Offline fallback
    }

    set({ isTesting: false });
    return false;
  },
}));
