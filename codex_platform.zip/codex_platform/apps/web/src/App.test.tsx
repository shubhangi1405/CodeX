import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import App from './App';

describe('CodeX App Shell', () => {
  it('renders the CodeX brand title, logo, and navigation stepper without legacy Ghostwriter text', () => {
    render(<App />);
    expect(screen.getAllByText('CodeX').length).toBeGreaterThan(0);
    expect(screen.getByLabelText('CodeX Logo')).toBeDefined();
    expect(screen.queryByText(/Ghostwriter/i)).toBeNull();
    expect(screen.getByText('1. Describe')).toBeDefined();
    expect(screen.getByText('5. Workflow')).toBeDefined();
    expect(screen.getByText('Engine: Ready')).toBeDefined();
  });
});
