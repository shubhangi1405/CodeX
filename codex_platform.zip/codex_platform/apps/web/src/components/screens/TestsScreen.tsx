import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  XCircle,
  Play,
  ArrowRight,
  ShieldAlert,
  Loader2,
  ChevronDown,
  ChevronUp,
  FileCode,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { useProjectStore } from '../../stores/useProjectStore';
import { TestCaseModel, TestResultModel } from '../../types';

export const TestsScreen: React.FC = () => {
  const {
    generatedTests,
    testResults,
    isTesting,
    testSuiteSummary,
    fetchOrGenerateTests,
    executeTestSuite,
    setActiveStep,
    unlockStep,
    completeStep,
  } = useProjectStore();

  const [activeFilter, setActiveFilter] = useState<'all' | 'happy_path' | 'edge_case'>('all');
  const [expandedTestId, setExpandedTestId] = useState<string | null>(null);

  useEffect(() => {
    if (generatedTests.length === 0) {
      fetchOrGenerateTests();
    }
  }, [generatedTests.length, fetchOrGenerateTests]);

  const handleRunAll = async () => {
    const passed = await executeTestSuite();
    if (passed) {
      completeStep('tests');
      unlockStep('build');
    }
  };

  const handleNext = () => {
    completeStep('tests');
    unlockStep('build');
    setActiveStep('build');
  };

  const resultMap = new Map<string, TestResultModel>();
  testResults.forEach((r) => resultMap.set(r.test_case_id, r));

  const filteredTests = generatedTests.filter((t) => {
    if (activeFilter === 'all') return true;
    return t.category === activeFilter;
  });

  const totalCount = generatedTests.length;
  const passedCount = testResults.filter((r) => r.passed).length;
  const failedCount = testResults.filter((r) => !r.passed).length;
  const hasRun = testResults.length > 0;

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-border flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-text">6. Automated Test Suites & Edge Cases</h2>
          <p className="text-sm text-text-muted mt-1">
            Generated edge-case matrix evaluated against independent reference oracles (zero circular verification).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRunAll}
            disabled={isTesting}
            className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 text-white px-5 py-2.5 rounded-md text-xs font-semibold transition-all shadow-subtle"
          >
            {isTesting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Executing Suite...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                <span>Run All Tests</span>
              </>
            )}
          </button>

          {hasRun && failedCount === 0 && (
            <button
              onClick={handleNext}
              className="flex items-center gap-2 bg-success hover:bg-green-700 text-white px-5 py-2.5 rounded-md text-xs font-semibold transition-all shadow-subtle"
            >
              <span>Proceed to Built App</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Metrics Banner */}
      <div className="grid grid-cols-4 gap-4">
        <div className="p-4 bg-surface border border-border rounded-lg">
          <div className="text-[10px] text-text-muted uppercase font-semibold">Total Test Cases</div>
          <div className="text-2xl font-bold text-text mt-1">{totalCount || 8}</div>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg">
          <div className="text-[10px] text-text-muted uppercase font-semibold">Passed Checks</div>
          <div className="text-2xl font-bold text-success mt-1">{passedCount}</div>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg">
          <div className="text-[10px] text-text-muted uppercase font-semibold">Edge Anomaly Catches</div>
          <div className="text-2xl font-bold text-primary-700 mt-1">
            {hasRun ? totalCount - 1 : 0}
          </div>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg">
          <div className="text-[10px] text-text-muted uppercase font-semibold">Verification Oracle</div>
          <div className="text-xs font-semibold text-text mt-2 flex items-center gap-1.5">
            <Check className="w-4 h-4 text-success" />
            <span>Independent Python/Pandas</span>
          </div>
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center bg-surface border border-border rounded-md p-0.5 text-xs">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1 rounded font-medium transition-all ${
              activeFilter === 'all'
                ? 'bg-white text-primary-700 shadow-subtle border border-border/50'
                : 'text-text-muted hover:text-text'
            }`}
          >
            All Tests ({generatedTests.length})
          </button>
          <button
            onClick={() => setActiveFilter('happy_path')}
            className={`px-3 py-1 rounded font-medium transition-all ${
              activeFilter === 'happy_path'
                ? 'bg-white text-primary-700 shadow-subtle border border-border/50'
                : 'text-text-muted hover:text-text'
            }`}
          >
            Happy Path (1)
          </button>
          <button
            onClick={() => setActiveFilter('edge_case')}
            className={`px-3 py-1 rounded font-medium transition-all ${
              activeFilter === 'edge_case'
                ? 'bg-white text-primary-700 shadow-subtle border border-border/50'
                : 'text-text-muted hover:text-text'
            }`}
          >
            Edge Cases ({generatedTests.length > 1 ? generatedTests.length - 1 : 7})
          </button>
        </div>

        <div className="text-xs text-text-muted">
          {hasRun && testSuiteSummary && (
            <span>Execution Duration: {testSuiteSummary.results.reduce((acc, r) => acc + r.duration_ms, 0).toFixed(1)} ms</span>
          )}
        </div>
      </div>

      {/* Test Cases List */}
      <div className="space-y-3">
        {filteredTests.map((tc: TestCaseModel) => {
          const res = resultMap.get(tc.id);
          const isExpanded = expandedTestId === tc.id;
          const status = res ? (res.passed ? 'passed' : 'failed') : 'pending';

          return (
            <div
              key={tc.id}
              className={`border rounded-lg bg-white transition-all ${
                status === 'failed'
                  ? 'border-danger/40 bg-red-50/20'
                  : status === 'passed'
                  ? 'border-border hover:border-primary-400'
                  : 'border-border'
              }`}
            >
              <div
                onClick={() => setExpandedTestId(isExpanded ? null : tc.id)}
                className="p-4 flex items-center justify-between cursor-pointer select-none"
              >
                <div className="flex items-center gap-3">
                  {status === 'passed' ? (
                    <CheckCircle2 className="w-5 h-5 text-success shrink-0" />
                  ) : status === 'failed' ? (
                    <XCircle className="w-5 h-5 text-danger shrink-0" />
                  ) : (
                    <div className="w-5 h-5 rounded-full border border-border bg-surface shrink-0 flex items-center justify-center text-[10px] text-text-muted font-bold">
                      •
                    </div>
                  )}

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-text">{tc.name}</span>
                      <span
                        className={`text-[10px] uppercase px-1.5 py-0.5 rounded font-mono font-medium ${
                          tc.category === 'happy_path'
                            ? 'bg-primary-100 text-primary-900 border border-primary-200'
                            : 'bg-surface-2 text-text-muted border border-border'
                        }`}
                      >
                        {tc.category.replace('_', ' ')}
                      </span>
                    </div>
                    <p className="text-[11px] text-text-muted mt-0.5">{tc.description}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {res && (
                    <span className="text-[11px] font-mono text-text-muted">
                      {res.duration_ms} ms
                    </span>
                  )}
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-text-muted" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-text-muted" />
                  )}
                </div>
              </div>

              {/* Expanded Inspection Accordion */}
              {isExpanded && (
                <div className="px-4 pb-4 pt-2 border-t border-border/60 bg-surface/50 space-y-3 text-xs">
                  {/* Failure Diagnostic if failed */}
                  {res && !res.passed && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-md space-y-1.5 text-danger">
                      <div className="flex items-center gap-1.5 font-semibold">
                        <ShieldAlert className="w-4 h-4 text-danger" />
                        <span>Deterministic Failure Explanation</span>
                      </div>
                      <div className="text-[11px] text-red-900 leading-relaxed">
                        <strong>Explanation:</strong> {res.explanation}
                      </div>
                      {res.failing_node && (
                        <div className="text-[11px] text-red-900">
                          <strong>Failing Node:</strong>{' '}
                          <code className="bg-red-100 px-1 py-0.5 rounded">{res.failing_node}</code>
                        </div>
                      )}
                      {res.remediation && (
                        <div className="text-[11px] text-red-900">
                          <strong>Remediation:</strong> {res.remediation}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Input Snapshot */}
                  <div>
                    <div className="font-semibold text-text text-[11px] mb-1 flex items-center gap-1">
                      <FileCode className="w-3.5 h-3.5 text-primary-600" />
                      <span>Input Snapshot (Synthetic CSV)</span>
                    </div>
                    <pre className="p-2.5 bg-white border border-border rounded font-mono text-[11px] text-text overflow-x-auto max-h-36">
                      {String(tc.input_data.file || tc.input_data.file_in || '<Empty string>')}
                    </pre>
                  </div>

                  {/* Expected Criteria */}
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div className="p-2 bg-white border border-border rounded">
                      <div className="text-[10px] text-text-muted font-semibold uppercase">Expected Criteria</div>
                      <div className="font-mono text-[11px] mt-1 text-text">
                        {tc.expect_failure ? (
                          <span className="text-warning flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" />
                            <span>Expects Graceful Rejection at {tc.expected_failure_node || 'Validation'}</span>
                          </span>
                        ) : (
                          <span>Revenue: ${Number(tc.expected_output.total_revenue || 0).toLocaleString()} (Valid rows: {String(tc.expected_output.valid_rows_count || 'all')})</span>
                        )}
                      </div>
                    </div>

                    <div className="p-2 bg-white border border-border rounded">
                      <div className="text-[10px] text-text-muted font-semibold uppercase">Actual Verification</div>
                      <div className="font-mono text-[11px] mt-1 text-text">
                        {res ? (
                          <span className={res.passed ? 'text-success font-semibold' : 'text-danger font-semibold'}>
                            {res.passed ? 'Passed (Criteria met)' : 'Failed'}
                          </span>
                        ) : (
                          <span className="text-text-muted">Not run yet</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
