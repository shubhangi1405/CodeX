import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  Terminal,
  FolderTree,
  Download,
  BarChart3,
  Copy,
  Check,
  FileCode,
  Layers,
  Database,
  RefreshCw,
  ExternalLink,
  Palette,
  Sparkles,
  RotateCcw,
  ShieldCheck,
} from 'lucide-react';
import { useProjectStore } from '../../stores/useProjectStore';
import { API_BASE } from '../../api/config';

interface GeneratedFileModel {
  path: string;
  content: string;
  category: string;
  description: string;
  size_bytes: number;
}

interface PaletteTokensModel {
  primary: string;
  primary_foreground: string;
  accent: string;
  surface: string;
  surface_elevated: string;
  border: string;
  text: string;
  text_muted: string;
  focus_ring: string;
  success: string;
  warning: string;
  danger: string;
}

interface DesignDirectionModel {
  direction_id: string;
  palette: PaletteTokensModel;
  color_mode: string;
  typography: {
    heading_font: string;
    body_font: string;
    mono_font: string;
    scale_ratio: number;
  };
  shape: {
    radius_class: string;
    border_style: string;
    shadow_style: string;
  };
  density: string;
  motion: string;
  iconography: string;
  brand_mark: {
    kind: string;
    glyph_primitive: string;
    monogram_letters: string;
  };
  copy_voice: string;
  rationale: string;
}

interface EntityFieldModel {
  name: string;
  label: string;
  field_type: string;
}

interface EntitySpecModel {
  name: string;
  singular_label: string;
  plural_label: string;
  fields: EntityFieldModel[];
}

interface PageSpecModel {
  id: string;
  title: string;
  route: string;
  layout: string;
  entities_used: string[];
  primary_actions: string[];
}

interface AppBlueprintModel {
  app_name: string;
  product_tagline: string;
  domain: {
    product_kind: string;
    archetype: string;
    primary_object: string;
    tone: string;
    data_shape: string;
    needs_automation: boolean;
  };
  entities: EntitySpecModel[];
  pages: PageSpecModel[];
  navigation: {
    pattern: string;
    items: Array<{ page_id: string; label: string; icon: string }>;
  };
  home_page_id: string;
}

interface ContrastPairModel {
  pair_name: string;
  foreground_hex: string;
  background_hex: string;
  contrast_ratio: number;
  required_ratio: number;
  passed: boolean;
}

interface ValidationReportModel {
  valid: boolean;
  fingerprint: {
    archetype: string;
    nav_pattern: string;
    home_layout: string;
    primary_hue_bucket: number;
    heading_font: string;
    radius_class: string;
    density: string;
    color_mode: string;
  };
  contrast_pairs: ContrastPairModel[];
  leakage_violations: string[];
}

interface GeneratedManifestModel {
  project_id: string;
  name: string;
  version: number;
  output_dir: string;
  files: GeneratedFileModel[];
  routes: string[];
  models: string[];
  run_command_backend: string;
  run_command_frontend: string;
  generated_at: string;
  zip_path?: string;
  blueprint?: AppBlueprintModel;
  design_direction?: DesignDirectionModel;
  previous_design_direction?: DesignDirectionModel | null;
  direction_proposals?: DesignDirectionModel[];
  design_history_count?: number;
  validation_report?: ValidationReportModel;
}

const RESTYLE_SUGGESTIONS = [
  'make it darker',
  'more playful',
  'denser tables',
  'use green',
];

export const BuildScreen: React.FC = () => {
  const {
    currentProject,
    compiledWorkflow,
    compileWorkflow,
  } = useProjectStore();
  const [activeTab, setActiveTab] = useState<'preview' | 'files' | 'logs'>('preview');
  const [manifest, setManifest] = useState<GeneratedManifestModel | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isRestyling, setIsRestyling] = useState(false);
  const [restyleInstruction, setRestyleInstruction] = useState('');
  const [selectedFilePath, setSelectedFilePath] = useState<string>('backend/main.py');
  const [copied, setCopied] = useState(false);

  const buildPayloadWorkflow = async () => {
    let activeWf = useProjectStore.getState().compiledWorkflow;
    if (!activeWf) {
      await compileWorkflow();
      activeWf = useProjectStore.getState().compiledWorkflow;
    }

    const fallbackName = currentProject?.name || 'Custom Software Pipeline';
    return (
      activeWf || {
        id: 'wf-custom-pipeline-v1',
        name: fallbackName,
        description: currentProject?.prompt || fallbackName,
        version: 1,
        trigger: { id: 't1', type: 'manual_upload', config: {} },
        nodes: [
          {
            id: 'node-read',
            type: 'ingest.read_csv',
            label: `Ingest ${fallbackName} Records`,
            category: 'ingest',
            config: { delimiter: ',', encoding: 'utf-8', has_header: true },
            input_ports: [{ name: 'file', data_type: 'file' }],
            output_ports: [{ name: 'table', data_type: 'table' }],
          },
          {
            id: 'node-req',
            type: 'validate.required_fields',
            label: 'Validate Required Fields',
            category: 'validate',
            config: { required_columns: ['date', 'amount'], rejection_strategy: 'drop' },
            input_ports: [{ name: 'table', data_type: 'table' }],
            output_ports: [{ name: 'table', data_type: 'table' }],
          },
          {
            id: 'node-agg',
            type: 'aggregate.monthly_totals',
            label: 'Monthly Progress & Totals',
            category: 'aggregate',
            config: { date_column: 'date', amount_column: 'amount' },
            input_ports: [{ name: 'table', data_type: 'table' }],
            output_ports: [{ name: 'table', data_type: 'table' }],
          },
          {
            id: 'node-rep',
            type: 'output.report',
            label: `Generate ${fallbackName} Report`,
            category: 'output',
            config: { title: `${fallbackName} Dashboard` },
            input_ports: [{ name: 'table', data_type: 'table' }],
            output_ports: [{ name: 'report', data_type: 'report' }],
          },
        ],
        edges: [
          { id: 'e1', from_node: 'node-read', from_port: 'table', to_node: 'node-req', to_port: 'table' },
          { id: 'e2', from_node: 'node-req', from_port: 'table', to_node: 'node-agg', to_port: 'table' },
          { id: 'e3', from_node: 'node-agg', from_port: 'table', to_node: 'node-rep', to_port: 'table' },
        ],
      }
    );
  };

  const generateSoftware = async () => {
    setIsGenerating(true);
    try {
      const payloadWorkflow = await buildPayloadWorkflow();
      const res = await fetch(`${API_BASE}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workflow: payloadWorkflow,
          project_id: currentProject?.id,
        }),
      });

      if (res.ok) {
        const data: GeneratedManifestModel = await res.json();
        setManifest(data);
        if (data.files.length > 0 && !data.files.some((f) => f.path === selectedFilePath)) {
          setSelectedFilePath(data.files[0].path);
        }
      }
    } catch {
      // Offline fallback handled by UI state
    } finally {
      setIsGenerating(false);
    }
  };

  useEffect(() => {
    generateSoftware();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [compiledWorkflow]);

  const handleSelectDirection = async (directionId: string) => {
    if (!manifest) return;
    setIsRestyling(true);
    try {
      const res = await fetch(`${API_BASE}/api/generate/restyle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          project_id: manifest.project_id,
          direction_id: directionId,
        }),
      });
      if (res.ok) {
        const updated: GeneratedManifestModel = await res.json();
        setManifest(updated);
      }
    } catch {
      // Ignore network errors
    } finally {
      setIsRestyling(false);
    }
  };

  const handleApplyRestyle = async (overrideText?: string) => {
    const instruction = (overrideText ?? restyleInstruction).trim();
    if (!manifest || !instruction) return;
    setIsRestyling(true);
    try {
      const res = await fetch(`${API_BASE}/api/generate/restyle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          project_id: manifest.project_id,
          instruction,
        }),
      });
      if (res.ok) {
        const updated: GeneratedManifestModel = await res.json();
        setManifest(updated);
        if (!overrideText) {
          setRestyleInstruction('');
        }
      }
    } catch {
      // Ignore network errors
    } finally {
      setIsRestyling(false);
    }
  };

  const handleRegenerateLook = async () => {
    if (!manifest) return;
    setIsRestyling(true);
    try {
      const res = await fetch(`${API_BASE}/api/generate/regenerate-look`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ project_id: manifest.project_id }),
      });
      if (res.ok) {
        const updated: GeneratedManifestModel = await res.json();
        setManifest(updated);
      }
    } catch {
      // Ignore network errors
    } finally {
      setIsRestyling(false);
    }
  };

  const handleRevertLook = async () => {
    if (!manifest) return;
    setIsRestyling(true);
    try {
      const res = await fetch(`${API_BASE}/api/generate/revert-look`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ project_id: manifest.project_id }),
      });
      if (res.ok) {
        const updated: GeneratedManifestModel = await res.json();
        setManifest(updated);
      }
    } catch {
      // Ignore network errors
    } finally {
      setIsRestyling(false);
    }
  };

  const selectedFile =
    manifest?.files.find((f) => f.path === selectedFilePath) || manifest?.files[0];
  const standaloneFile = manifest?.files.find((f) => f.path === 'standalone_app.html');
  const bp = manifest?.blueprint;
  const dir = manifest?.design_direction;
  const prevDir = manifest?.previous_design_direction;
  const proposals = manifest?.direction_proposals || [];

  const handleCopyCode = () => {
    if (selectedFile) {
      navigator.clipboard.writeText(selectedFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }
  };

  const handleExportZip = () => {
    if (manifest) {
      window.open(`${API_BASE}/api/generate/export/${manifest.project_id}`, '_blank');
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="pb-4 border-b border-border flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-text flex items-center gap-2">
            <Layers className="w-5 h-5 text-primary-600" />
            <span>7. Adaptive Software Generation & Design Studio</span>
          </h2>
          <p className="text-xs text-text-muted mt-1">
            Blueprint-driven domain application with curated design directions, WCAG 2.1 AA contrast verification, and zero-leakage UI kit composition.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={generateSoftware}
            disabled={isGenerating}
            data-testid="regenerate-app-btn"
            className="flex items-center gap-1.5 bg-white border border-border hover:border-primary-400 text-text px-3 py-2 rounded-md text-xs font-semibold transition-all shadow-subtle"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>Rebuild Full Application</span>
          </button>

          <button
            onClick={handleRegenerateLook}
            disabled={!manifest || isRestyling}
            data-testid="regenerate-look-btn"
            className="flex items-center gap-1.5 bg-white border border-border hover:border-primary-400 text-primary-700 px-3 py-2 rounded-md text-xs font-semibold transition-all shadow-subtle"
          >
            <Palette className={`w-3.5 h-3.5 ${isRestyling ? 'animate-spin' : ''}`} />
            <span>Regenerate Look</span>
          </button>

          <button
            onClick={() => {
              if (manifest) {
                window.open(`${API_BASE}/api/generate/preview/${manifest.project_id}`, '_blank');
              }
            }}
            disabled={!manifest}
            className="flex items-center gap-1.5 bg-[#15803D] hover:bg-[#166534] disabled:opacity-50 text-white px-3.5 py-2 rounded-md text-xs font-semibold transition-all shadow-subtle"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Open Standalone HTML UI</span>
          </button>

          <button
            onClick={handleExportZip}
            disabled={!manifest}
            className="flex items-center gap-1.5 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 text-white px-4 py-2 rounded-md text-xs font-semibold transition-all shadow-subtle"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Standalone ZIP</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-border">
        <button
          onClick={() => setActiveTab('preview')}
          className={`px-4 py-2 text-xs font-semibold border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'preview'
              ? 'border-primary-600 text-primary-700'
              : 'border-transparent text-text-muted hover:text-text'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Design & Layout Studio + Live Preview</span>
        </button>
        <button
          onClick={() => setActiveTab('files')}
          className={`px-4 py-2 text-xs font-semibold border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'files'
              ? 'border-primary-600 text-primary-700'
              : 'border-transparent text-text-muted hover:text-text'
          }`}
        >
          <FolderTree className="w-4 h-4" />
          <span>File Manifest & Code Viewer ({manifest?.files.length || 0} Files)</span>
        </button>
        <button
          onClick={() => setActiveTab('logs')}
          className={`px-4 py-2 text-xs font-semibold border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'logs'
              ? 'border-primary-600 text-primary-700'
              : 'border-transparent text-text-muted hover:text-text'
          }`}
        >
          <Terminal className="w-4 h-4" />
          <span>Stage D Contrast & Architecture Spec</span>
        </button>
      </div>

      {activeTab === 'preview' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Design & Layout Controls (5 cols) */}
          <div className="lg:col-span-5 space-y-5" data-testid="design-and-layout-panel">
            {/* 1. Blueprint Summary */}
            <div
              className="p-4 border border-border rounded-xl bg-white shadow-subtle space-y-3"
              data-testid="blueprint-summary-card"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-text flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-primary-600" />
                  <span>Blueprint Summary</span>
                </h3>
                {bp && (
                  <span className="px-2 py-0.5 rounded bg-primary-50 text-primary-700 font-mono text-[11px] font-semibold">
                    {bp.domain.archetype}
                  </span>
                )}
              </div>

              {bp ? (
                <div className="space-y-2.5 text-xs">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 rounded bg-surface border border-border">
                      <div className="text-[10px] text-text-muted uppercase">Primary Object</div>
                      <div className="font-semibold text-text mt-0.5">{bp.domain.primary_object}</div>
                    </div>
                    <div className="p-2 rounded bg-surface border border-border">
                      <div className="text-[10px] text-text-muted uppercase">Navigation Shell</div>
                      <div className="font-mono font-semibold text-text mt-0.5">
                        {bp.navigation.pattern}
                      </div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded bg-surface border border-border space-y-1.5">
                    <div className="text-[10px] text-text-muted uppercase font-semibold">
                      Domain Entities ({bp.entities.length})
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {bp.entities.map((ent) => (
                        <span
                          key={ent.name}
                          className="px-2 py-0.5 rounded bg-white border border-border font-mono text-[11px] text-text"
                        >
                          {ent.plural_label} ({ent.fields.length} fields)
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="p-2.5 rounded bg-surface border border-border space-y-1.5">
                    <div className="text-[10px] text-text-muted uppercase font-semibold">
                      Pages & Layout Archetypes ({bp.pages.length})
                    </div>
                    <div className="space-y-1">
                      {bp.pages.map((pg) => (
                        <div
                          key={pg.id}
                          className="flex items-center justify-between text-[11px] bg-white px-2 py-1 rounded border border-border"
                        >
                          <span className="font-semibold text-text">
                            {pg.title}{' '}
                            {pg.id === bp.home_page_id && (
                              <span className="text-[10px] text-primary-600 font-bold">(Home)</span>
                            )}
                          </span>
                          <span className="font-mono text-text-muted">{pg.layout}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-text-muted py-3">
                  Compiling domain analysis and application blueprint...
                </div>
              )}
            </div>

            {/* 2. 3-Direction Chooser */}
            <div
              className="p-4 border border-border rounded-xl bg-white shadow-subtle space-y-3"
              data-testid="direction-chooser-card"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-text flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 text-primary-600" />
                  <span>3 Proposed Design Directions</span>
                </h3>
                {dir && (
                  <span className="text-[11px] font-mono text-text-muted">
                    Active: <strong>{dir.direction_id}</strong>
                  </span>
                )}
              </div>

              <div className="space-y-2.5">
                {proposals.map((prop) => {
                  const isSelected = dir?.direction_id === prop.direction_id;
                  return (
                    <button
                      key={prop.direction_id}
                      type="button"
                      data-testid={`direction-option-${prop.direction_id}`}
                      onClick={() => handleSelectDirection(prop.direction_id)}
                      disabled={isRestyling}
                      className={`w-full text-left p-3 rounded-lg border transition-all ${
                        isSelected
                          ? 'border-primary-600 bg-primary-50/40 ring-1 ring-primary-500'
                          : 'border-border hover:border-primary-400 bg-surface'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-text">
                            {prop.direction_id}
                          </span>
                          <span className="text-[10px] uppercase px-1.5 py-0.5 rounded bg-white border border-border text-text-muted">
                            {prop.color_mode} · {prop.density} · {prop.shape.radius_class}
                          </span>
                        </div>
                        {/* Swatches */}
                        <div className="flex items-center gap-1">
                          {[
                            prop.palette.surface,
                            prop.palette.primary,
                            prop.palette.accent,
                            prop.palette.text,
                          ].map((hex, i) => (
                            <span
                              key={`${prop.direction_id}-swatch-${i}`}
                              title={hex}
                              className="w-4 h-4 rounded-full border border-border inline-block"
                              style={{ backgroundColor: hex }}
                            />
                          ))}
                        </div>
                      </div>
                      <div className="mt-1.5 text-[11px] text-text-muted flex items-center gap-2">
                        <span>
                          Font: <strong>{prop.typography.heading_font}</strong> /{' '}
                          {prop.typography.body_font}
                        </span>
                      </div>
                      <p className="mt-1 text-[11px] text-text-muted line-clamp-2">
                        {prop.rationale}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Natural-Language Restyle Box */}
            <div
              className="p-4 border border-border rounded-xl bg-white shadow-subtle space-y-3"
              data-testid="natural-language-restyle-card"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-text flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-primary-600" />
                  <span>Natural-Language Restyle</span>
                </h3>
                {(manifest?.design_history_count || 0) > 0 && (
                  <button
                    type="button"
                    onClick={handleRevertLook}
                    disabled={isRestyling}
                    data-testid="revert-look-btn"
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-primary-700 hover:text-primary-800 px-2 py-1 rounded bg-primary-50 border border-primary-200"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Revert ({manifest?.design_history_count})</span>
                  </button>
                )}
              </div>

              <p className="text-[11px] text-text-muted">
                Update palette, color mode, density, or shape without modifying backend routes or losing SQLite records.
              </p>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={restyleInstruction}
                  onChange={(e) => setRestyleInstruction(e.target.value)}
                  placeholder="e.g., make it darker, more playful, denser tables, use green..."
                  data-testid="restyle-input"
                  className="flex-1 px-3 py-1.5 text-xs rounded-md border border-border bg-surface text-text focus:outline-none focus:border-primary-500"
                />
                <button
                  type="button"
                  onClick={() => handleApplyRestyle()}
                  disabled={isRestyling || !restyleInstruction.trim()}
                  data-testid="apply-restyle-btn"
                  className="bg-primary-600 hover:bg-primary-700 disabled:opacity-50 text-white px-3 py-1.5 rounded-md text-xs font-semibold transition-all"
                >
                  Apply
                </button>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {RESTYLE_SUGGESTIONS.map((chip) => (
                  <button
                    key={chip}
                    type="button"
                    onClick={() => handleApplyRestyle(chip)}
                    disabled={isRestyling}
                    className="text-[11px] px-2 py-0.5 rounded-full bg-surface hover:bg-primary-50 text-text-muted hover:text-primary-700 border border-border transition-all"
                  >
                    {chip}
                  </button>
                ))}
              </div>

              {/* 4. Before / After Token Diff */}
              {prevDir && dir && (
                <div
                  className="mt-3 pt-3 border-t border-border space-y-2"
                  data-testid="before-after-token-diff"
                >
                  <div className="text-[11px] font-bold uppercase tracking-wider text-text">
                    Before / After Token Diff
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-[11px] font-mono border border-border rounded">
                      <thead className="bg-surface text-text-muted border-b border-border">
                        <tr>
                          <th className="p-1.5 text-left">Token</th>
                          <th className="p-1.5 text-left">Before</th>
                          <th className="p-1.5 text-left">After</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        <tr>
                          <td className="p-1.5 font-semibold">direction_id</td>
                          <td className="p-1.5 text-text-muted">{prevDir.direction_id}</td>
                          <td className="p-1.5 font-bold text-primary-700">{dir.direction_id}</td>
                        </tr>
                        <tr>
                          <td className="p-1.5 font-semibold">color_mode</td>
                          <td className="p-1.5 text-text-muted">{prevDir.color_mode}</td>
                          <td className="p-1.5 font-bold text-primary-700">{dir.color_mode}</td>
                        </tr>
                        <tr>
                          <td className="p-1.5 font-semibold">primary</td>
                          <td className="p-1.5 text-text-muted">{prevDir.palette.primary}</td>
                          <td className="p-1.5 font-bold text-primary-700">
                            {dir.palette.primary}
                          </td>
                        </tr>
                        <tr>
                          <td className="p-1.5 font-semibold">surface</td>
                          <td className="p-1.5 text-text-muted">{prevDir.palette.surface}</td>
                          <td className="p-1.5 font-bold text-primary-700">
                            {dir.palette.surface}
                          </td>
                        </tr>
                        <tr>
                          <td className="p-1.5 font-semibold">heading_font</td>
                          <td className="p-1.5 text-text-muted">
                            {prevDir.typography.heading_font}
                          </td>
                          <td className="p-1.5 font-bold text-primary-700">
                            {dir.typography.heading_font}
                          </td>
                        </tr>
                        <tr>
                          <td className="p-1.5 font-semibold">radius / density</td>
                          <td className="p-1.5 text-text-muted">
                            {prevDir.shape.radius_class} / {prevDir.density}
                          </td>
                          <td className="p-1.5 font-bold text-primary-700">
                            {dir.shape.radius_class} / {dir.density}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Live Standalone App Preview (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="border border-border rounded-xl bg-white overflow-hidden shadow-subtle flex flex-col h-[720px]">
              <div className="px-4 py-2.5 bg-surface border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-text">
                    {bp?.app_name || manifest?.name || 'Adaptive Application Preview'}
                  </span>
                  {dir && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white border border-border text-text-muted">
                      {dir.direction_id} · {dir.color_mode}
                    </span>
                  )}
                </div>
                {manifest?.validation_report?.valid && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-success">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>WCAG AA Verified</span>
                  </span>
                )}
              </div>

              {standaloneFile ? (
                <iframe
                  title="Adaptive Standalone Application Preview"
                  srcDoc={standaloneFile.content}
                  data-testid="standalone-preview-iframe"
                  className="w-full flex-1 border-0"
                />
              ) : (
                <div className="flex-1 flex items-center justify-center text-xs text-text-muted p-8">
                  Generating domain-specific application preview...
                </div>
              )}
            </div>
          </div>
        </div>
      ) : activeTab === 'files' ? (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 border border-border rounded-xl bg-white overflow-hidden shadow-subtle min-h-[500px]">
          {/* File Tree Sidebar */}
          <div className="border-r border-border p-4 bg-surface space-y-4">
            <div className="text-xs font-bold uppercase tracking-wider text-text flex items-center gap-1.5">
              <FolderTree className="w-3.5 h-3.5 text-primary-600" />
              <span>Project Structure</span>
            </div>

            <div className="space-y-1">
              {manifest?.files.map((file) => (
                <button
                  key={file.path}
                  onClick={() => setSelectedFilePath(file.path)}
                  className={`w-full text-left px-2.5 py-1.5 rounded text-xs font-mono flex items-center justify-between transition-all ${
                    selectedFilePath === file.path
                      ? 'bg-primary-50 text-primary-700 font-semibold border border-primary-200'
                      : 'text-text-muted hover:text-text hover:bg-white'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileCode className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{file.path}</span>
                  </div>
                  <span className="text-[9px] uppercase font-sans text-text-muted px-1 rounded bg-white/60">
                    {file.category}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Code Viewer Panel */}
          <div className="col-span-3 flex flex-col h-full">
            {selectedFile ? (
              <>
                <div className="p-3 border-b border-border bg-surface flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-text">
                      {selectedFile.path}
                    </span>
                    <span className="text-[10px] text-text-muted">
                      ({selectedFile.size_bytes} bytes)
                    </span>
                    <span className="text-[10px] text-text-muted italic">
                      {selectedFile.description}
                    </span>
                  </div>
                  <button
                    onClick={handleCopyCode}
                    className="flex items-center gap-1 text-xs text-text-muted hover:text-text px-2 py-1 rounded hover:bg-white border border-transparent hover:border-border transition-all"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-success" />
                        <span className="text-success font-semibold">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Code</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="flex-1 p-4 bg-white overflow-auto max-h-[500px]">
                  <pre className="font-mono text-xs text-text leading-relaxed whitespace-pre">
                    {selectedFile.content}
                  </pre>
                </div>
              </>
            ) : (
              <div className="p-8 text-center text-xs text-text-muted">
                Select a file to inspect source code.
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Stage D WCAG Contrast & Fingerprint Verification */}
          {manifest?.validation_report && (
            <div className="p-5 border border-border rounded-xl bg-white space-y-4 shadow-subtle">
              <h3 className="text-xs font-bold uppercase tracking-wider text-text flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-success" />
                <span>Stage D Validation & WCAG 2.1 AA Contrast Pairs</span>
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs font-mono">
                {manifest.validation_report.contrast_pairs.map((pair) => (
                  <div
                    key={pair.pair_name}
                    className="p-2.5 rounded bg-surface border border-border flex items-center justify-between"
                  >
                    <div>
                      <div className="font-sans font-semibold text-text text-[11px]">
                        {pair.pair_name}
                      </div>
                      <div className="text-[10px] text-text-muted">
                        {pair.foreground_hex} on {pair.background_hex}
                      </div>
                    </div>
                    <span className="text-success font-bold">{pair.contrast_ratio}:1</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Architecture & Run Spec */}
          <div className="p-5 border border-border rounded-xl bg-white space-y-4 shadow-subtle">
            <h3 className="text-xs font-bold uppercase tracking-wider text-text flex items-center gap-1.5">
              <Database className="w-4 h-4 text-primary-600" />
              <span>Registered FastAPI Backend Endpoints</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 font-mono text-xs">
              {manifest?.routes.map((route) => (
                <div
                  key={route}
                  className="p-2.5 rounded bg-surface border border-border flex items-center justify-between"
                >
                  <span className="text-text font-semibold">{route}</span>
                  <span className="text-[10px] text-success font-bold">200 OK</span>
                </div>
              ))}
            </div>
          </div>

          <div className="p-5 border border-border rounded-xl bg-white space-y-4 shadow-subtle">
            <h3 className="text-xs font-bold uppercase tracking-wider text-text flex items-center gap-1.5">
              <ExternalLink className="w-4 h-4 text-primary-600" />
              <span>Local Execution Commands</span>
            </h3>
            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 bg-surface rounded-lg border border-border">
                <div className="text-[10px] text-text-muted uppercase font-sans font-semibold mb-1">
                  Backend Command:
                </div>
                <div className="text-primary-700 font-bold">
                  {manifest?.run_command_backend || 'uvicorn main:app --reload --port 8000'}
                </div>
              </div>
              <div className="p-3 bg-surface rounded-lg border border-border">
                <div className="text-[10px] text-text-muted uppercase font-sans font-semibold mb-1">
                  Frontend Command:
                </div>
                <div className="text-primary-700 font-bold">
                  {manifest?.run_command_frontend || 'npm run dev'}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
