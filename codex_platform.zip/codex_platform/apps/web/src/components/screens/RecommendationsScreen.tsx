import React, { useState, useEffect } from 'react';
import {
  ArrowRight,
  Check,
  X,
  Clock,
  AlertTriangle,
  Lightbulb,
  Edit2,
  CheckCircle2,
  Loader2,
} from 'lucide-react';
import { useProjectStore } from '../../stores/useProjectStore';
import { FeatureRecommendation } from '../../types';
import { API_BASE } from '../../api/config';

function buildFallbackRecommendations(goalText: string): FeatureRecommendation[] {
  const lower = goalText.toLowerCase();
  const isHabit =
    lower.includes('habit') ||
    lower.includes('streak') ||
    lower.includes('routine') ||
    lower.includes('fitness');

  if (isHabit) {
    return [
      {
        id: 'feat-streak-validation',
        title: 'Missed Check-In & Invalid Log Audit',
        description:
          'Capture incomplete or out-of-range habit check-in entries with exact dates and reasons into an audit log.',
        rationale:
          'Recommended for Habit Trackers so missed or malformed daily check-ins are logged transparently without breaking streak calculations.',
        tier: 'essential',
        complexity: 'S',
        dependencies: ['validate.required_fields'],
        risks: [],
        decision: 'accepted',
      },
      {
        id: 'feat-habit-consistency-chart',
        title: 'Monthly Habit Consistency & Streak KPI Charting',
        description:
          'Generate interactive bar and trend charts of monthly habit completions, streak points, and consistency rates.',
        rationale:
          'Recommended because visual streak momentum and monthly completion charts reinforce daily habit adherence.',
        tier: 'recommended',
        complexity: 'M',
        dependencies: ['aggregate.monthly_totals', 'output.report'],
        risks: ['Requires valid date parse on all check-in logs.'],
        decision: 'accepted',
      },
      {
        id: 'feat-duplicate-checkin-guard',
        title: 'Same-Day Duplicate Check-In Guard',
        description:
          'Detect and deduplicate multiple accidental check-ins for the same habit on the same calendar date.',
        rationale:
          'Recommended because double-tapping a habit check-in button should not artificially inflate streak counts.',
        tier: 'recommended',
        complexity: 'S',
        dependencies: ['transform.filter'],
        risks: [],
        decision: 'pending',
      },
      {
        id: 'feat-streak-freeze-grace',
        title: 'Streak Freeze & Minimum Score Thresholds',
        description:
          'Enforce quality assertions on daily habit score bounds (> 0) and support configurable streak targets.',
        rationale:
          'Recommended to keep habit scoring fair and prevent negative or corrupted point values from skewing progress.',
        tier: 'optional',
        complexity: 'S',
        dependencies: ['validate.type_check'],
        risks: [],
        decision: 'pending',
      },
      {
        id: 'feat-habit-reminder-webhook',
        title: 'Automated Daily Reminder & Check-In Webhook',
        description:
          'Trigger habit log syncs via mobile/wearable webhook payload and send daily streak reminder notifications.',
        rationale:
          'Recommended for future expansion to connect the habit tracker with mobile shortcuts or calendar reminders.',
        tier: 'future',
        complexity: 'L',
        dependencies: ['trigger.webhook'],
        risks: ['Requires notification channel configuration.'],
        decision: 'deferred',
      },
    ];
  }

  const label = goalText.slice(0, 50) || 'Project Pipeline';
  return [
    {
      id: 'feat-rejected-audit',
      title: `Invalid Entry Audit Log (${label})`,
      description:
        'Capture invalid or incomplete records with exact line numbers and structured failure reasons into an audit report.',
      rationale: `Recommended for "${label}" so malformed inputs never cause silent data corruption or crashes.`,
      tier: 'essential',
      complexity: 'S',
      dependencies: ['validate.required_fields'],
      risks: [],
      decision: 'accepted',
    },
    {
      id: 'feat-trend-viz',
      title: 'Interactive Monthly Progress & KPI Charting',
      description:
        'Generate responsive bar and trend charts alongside tabular summaries in the final dashboard report.',
      rationale: `Recommended so users of "${label}" can visually track monthly trends and completion metrics at a glance.`,
      tier: 'recommended',
      complexity: 'M',
      dependencies: ['aggregate.monthly_totals', 'output.report'],
      risks: ['Requires valid date parse on all grouped records.'],
      decision: 'accepted',
    },
    {
      id: 'feat-duplicate-detection',
      title: 'Automatic Duplicate Entry Detection',
      description:
        'Flag or filter duplicated entries based on composite date and category keys.',
      rationale: `Recommended because repeated submissions in "${label}" can double-count metrics if not deduplicated.`,
      tier: 'recommended',
      complexity: 'M',
      dependencies: ['transform.filter'],
      risks: [],
      decision: 'pending',
    },
    {
      id: 'feat-input-normalization',
      title: 'Smart Field Coercion & Range Sanitization',
      description:
        'Automatically coerce numeric strings, strip whitespace, and validate positive score/amount ranges.',
      rationale:
        'Recommended because user-entered records frequently contain formatting variations.',
      tier: 'optional',
      complexity: 'S',
      dependencies: ['validate.type_check'],
      risks: [],
      decision: 'pending',
    },
    {
      id: 'feat-webhook-trigger',
      title: 'Automated Webhook Sync & Notifications',
      description:
        'Trigger workflow via authenticated webhook payload and dispatch alerts on threshold breaches.',
      rationale:
        'Recommended to enable automated system-to-system sync without manual uploads.',
      tier: 'future',
      complexity: 'L',
      dependencies: ['trigger.webhook'],
      risks: ['Requires API key management and endpoint authentication.'],
      decision: 'deferred',
    },
  ];
}

export const RecommendationsScreen: React.FC = () => {
  const {
    productUnderstanding,
    compiledWorkflow,
    selectedProvider,
    promptInput,
    compileWorkflow,
    setCompiledWorkflow,
    setActiveStep,
    unlockStep,
    completeStep,
  } = useProjectStore();

  const goalContext = productUnderstanding?.goal || promptInput || '';
  const [features, setFeatures] = useState<FeatureRecommendation[]>(() =>
    buildFallbackRecommendations(goalContext)
  );
  const [isLoadingRecs, setIsLoadingRecs] = useState<boolean>(false);
  const [isApplying, setIsApplying] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDesc, setEditDesc] = useState('');

  // Fetch recommendations from API tailored to productUnderstanding and selectedProvider
  useEffect(() => {
    setFeatures(buildFallbackRecommendations(goalContext));
    if (!productUnderstanding) return;
    let cancelled = false;
    const fetchRecs = async () => {
      setIsLoadingRecs(true);
      try {
        const res = await fetch(`${API_BASE}/api/recommendations/generate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            understanding: productUnderstanding,
            workflow: compiledWorkflow || undefined,
            provider: selectedProvider,
          }),
        });
        if (res.ok && !cancelled) {
          const data: FeatureRecommendation[] = await res.json();
          if (data && data.length > 0) {
            setFeatures(data);
          }
        }
      } catch {
        // Keep domain-aware fallback recommendations
      } finally {
        if (!cancelled) {
          setIsLoadingRecs(false);
        }
      }
    };
    fetchRecs();
    return () => {
      cancelled = true;
    };
  }, [productUnderstanding, compiledWorkflow, selectedProvider, goalContext]);

  const handleDecision = (id: string, decision: 'accepted' | 'rejected' | 'deferred') => {
    setFeatures((prev) =>
      prev.map((f) => (f.id === id ? { ...f, decision } : f))
    );
  };

  const handleStartEdit = (f: FeatureRecommendation) => {
    setEditingId(f.id);
    setEditTitle(f.title);
    setEditDesc(f.description);
  };

  const handleSaveEdit = (id: string) => {
    setFeatures((prev) =>
      prev.map((f) =>
        f.id === id ? { ...f, title: editTitle, description: editDesc } : f
      )
    );
    setEditingId(null);
  };

  const handleNext = async () => {
    setIsApplying(true);
    try {
      let activeWf = useProjectStore.getState().compiledWorkflow;
      if (!activeWf) {
        await compileWorkflow();
        activeWf = useProjectStore.getState().compiledWorkflow;
      }

      if (activeWf) {
        try {
          const res = await fetch(`${API_BASE}/api/recommendations/apply`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              workflow: activeWf,
              recommendations: features,
            }),
          });
          if (res.ok) {
            const data = await res.json();
            const updatedWf = data.workflow || data;
            if (updatedWf && updatedWf.nodes) {
              setCompiledWorkflow(updatedWf);
            }
          }
        } catch {
          // Handled gracefully
        }
      }
    } finally {
      setIsApplying(false);
    }

    completeStep('recommendations');
    unlockStep('specification');
    setActiveStep('specification');
  };

  const tiers: Array<{ key: FeatureRecommendation['tier']; label: string; badge: string }> = [
    {
      key: 'essential',
      label: 'Essential (Core Pipeline)',
      badge: 'bg-primary-100 text-primary-900 border-primary-200',
    },
    {
      key: 'recommended',
      label: 'High-Value Recommended',
      badge: 'bg-surface-2 text-text border-border',
    },
    {
      key: 'optional',
      label: 'Optional Enhancements',
      badge: 'bg-surface text-text-muted border-border',
    },
    {
      key: 'future',
      label: 'Future Iterations',
      badge: 'bg-surface text-text-muted/60 border-border',
    },
  ];

  const acceptedCount = features.filter((f) => f.decision === 'accepted').length;

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-6">
      <div className="pb-4 border-b border-border flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-text">3. Feature Recommendations</h2>
          <p className="text-sm text-text-muted mt-1">
            CodeX identified recommended features beyond your literal sentence. Accept, reject, or defer to shape your specification.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {isLoadingRecs && (
            <span className="flex items-center gap-1.5 text-xs text-primary-700 font-medium">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Tailoring to your project...</span>
            </span>
          )}
          <span className="text-xs text-text-muted font-medium">
            {acceptedCount} of {features.length} Features Accepted
          </span>

          <button
            onClick={handleNext}
            disabled={isApplying}
            className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 text-white px-5 py-2.5 rounded-md text-xs font-semibold transition-all shadow-subtle"
          >
            {isApplying ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Compiling & Applying...</span>
              </>
            ) : (
              <>
                <span>Apply to Specification</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>

      <div className="space-y-6">
        {tiers.map((tier) => {
          const tierFeatures = features.filter((f) => f.tier === tier.key);
          if (tierFeatures.length === 0) return null;

          return (
            <div key={tier.key} className="space-y-3">
              <div className="flex items-center gap-2">
                <span
                  className={`text-[11px] font-semibold uppercase px-2 py-0.5 rounded border ${tier.badge}`}
                >
                  {tier.label}
                </span>
              </div>

              <div className="grid grid-cols-1 gap-3">
                {tierFeatures.map((feat) => {
                  const isEditing = editingId === feat.id;

                  return (
                    <div
                      key={feat.id}
                      className={`p-4 border rounded-lg bg-white transition-all space-y-3 ${
                        feat.decision === 'accepted'
                          ? 'border-primary-400 ring-1 ring-primary-400/20'
                          : 'border-border'
                      }`}
                    >
                      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                        <div className="space-y-1.5 flex-1">
                          <div className="flex items-center gap-2">
                            {isEditing ? (
                              <input
                                type="text"
                                value={editTitle}
                                onChange={(e) => setEditTitle(e.target.value)}
                                className="border border-border rounded px-2 py-0.5 text-xs font-semibold text-text"
                              />
                            ) : (
                              <h4 className="text-sm font-semibold text-text">{feat.title}</h4>
                            )}

                            <span className="text-[10px] bg-surface-2 border border-border px-1.5 py-0.5 rounded text-text-muted font-mono">
                              Complexity: {feat.complexity}
                            </span>

                            {feat.decision === 'accepted' && (
                              <span className="text-[10px] bg-success-bg text-success border border-success/30 px-1.5 py-0.5 rounded font-medium flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Accepted</span>
                              </span>
                            )}
                            {feat.decision === 'rejected' && (
                              <span className="text-[10px] bg-danger-bg text-danger border border-danger/30 px-1.5 py-0.5 rounded font-medium">
                                Rejected
                              </span>
                            )}
                            {feat.decision === 'deferred' && (
                              <span className="text-[10px] bg-surface-2 text-text-muted border border-border px-1.5 py-0.5 rounded font-medium">
                                Deferred
                              </span>
                            )}
                          </div>

                          {isEditing ? (
                            <textarea
                              rows={2}
                              value={editDesc}
                              onChange={(e) => setEditDesc(e.target.value)}
                              className="w-full border border-border rounded p-2 text-xs text-text mt-1"
                            />
                          ) : (
                            <p className="text-xs text-text-muted leading-relaxed">
                              {feat.description}
                            </p>
                          )}

                          {/* Rationale explanation */}
                          {feat.rationale && (
                            <div className="p-2 bg-primary-50/50 border border-primary-100 rounded text-[11px] text-primary-900 flex items-start gap-1.5 mt-2">
                              <Lightbulb className="w-3.5 h-3.5 text-primary-600 shrink-0 mt-0.5" />
                              <div className="leading-relaxed">
                                <strong className="font-semibold text-primary-900">Why recommended: </strong>
                                {feat.rationale}
                              </div>
                            </div>
                          )}

                          {feat.risks && feat.risks.length > 0 && (
                            <div className="flex items-center gap-1 text-[11px] text-warning mt-1">
                              <AlertTriangle className="w-3 h-3" />
                              <span>{feat.risks.join('; ')}</span>
                            </div>
                          )}
                        </div>

                        {/* Decision actions */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          {isEditing ? (
                            <button
                              onClick={() => handleSaveEdit(feat.id)}
                              className="px-2.5 py-1.5 rounded text-xs font-medium bg-primary-600 text-white"
                            >
                              Save
                            </button>
                          ) : (
                            <button
                              onClick={() => handleStartEdit(feat)}
                              className="p-1.5 rounded text-xs text-text-muted hover:text-text border border-border"
                              title="Edit feature"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          <button
                            onClick={() => handleDecision(feat.id, 'accepted')}
                            className={`px-2.5 py-1.5 rounded text-xs font-medium border transition-all flex items-center gap-1 ${
                              feat.decision === 'accepted'
                                ? 'bg-primary-600 text-white border-primary-600 shadow-subtle'
                                : 'bg-white text-text hover:bg-surface-2 border-border'
                            }`}
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Accept</span>
                          </button>

                          <button
                            onClick={() => handleDecision(feat.id, 'rejected')}
                            className={`px-2.5 py-1.5 rounded text-xs font-medium border transition-all flex items-center gap-1 ${
                              feat.decision === 'rejected'
                                ? 'bg-danger text-white border-danger shadow-subtle'
                                : 'bg-white text-text hover:bg-surface-2 border-border'
                            }`}
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>

                          <button
                            onClick={() => handleDecision(feat.id, 'deferred')}
                            className={`px-2.5 py-1.5 rounded text-xs font-medium border transition-all flex items-center gap-1 ${
                              feat.decision === 'deferred'
                                ? 'bg-text-muted text-white border-text-muted shadow-subtle'
                                : 'bg-white text-text hover:bg-surface-2 border-border'
                            }`}
                          >
                            <Clock className="w-3.5 h-3.5" />
                            <span>Defer</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
