import React, { useEffect } from 'react';
import { ArrowRight, HelpCircle, Layers, CheckCircle, Loader2, AlertCircle } from 'lucide-react';
import { useProjectStore } from '../../stores/useProjectStore';
import { ItemAttribution } from '../../types';

export const UnderstandingScreen: React.FC = () => {
  const {
    productUnderstanding,
    clarificationAnswers,
    setClarificationAnswer,
    compileWorkflow,
    isCompiling,
    compilationError,
    interpretPrompt,
    promptInput,
    setActiveStep,
    unlockStep,
    completeStep,
  } = useProjectStore();

  useEffect(() => {
    if (!productUnderstanding && promptInput) {
      interpretPrompt();
    }
  }, [productUnderstanding, promptInput, interpretPrompt]);

  const renderBadge = (attr: ItemAttribution) => {
    switch (attr) {
      case 'user_stated':
        return (
          <span className="text-[10px] bg-primary-100 text-primary-900 border border-primary-200 px-2 py-0.5 rounded font-medium">
            User-stated
          </span>
        );
      case 'ai_recommendation':
        return (
          <span className="text-[10px] bg-purple-100 text-purple-800 border border-purple-200 px-2 py-0.5 rounded font-medium">
            AI Recommendation
          </span>
        );
      case 'assumption':
      default:
        return (
          <span className="text-[10px] bg-surface-2 text-text-muted border border-border px-2 py-0.5 rounded font-mono">
            Assumption
          </span>
        );
    }
  };

  const handleNext = () => {
    completeStep('understanding');
    unlockStep('recommendations');
    setActiveStep('recommendations');
  };

  const handleCompileDirectly = async () => {
    const success = await compileWorkflow();
    if (success) {
      completeStep('understanding');
      unlockStep('specification');
      unlockStep('workflow');
      setActiveStep('specification');
    }
  };

  if (!productUnderstanding && isCompiling) {
    return (
      <div className="p-16 flex flex-col items-center justify-center text-center">
        <Loader2 className="w-8 h-8 text-primary-600 animate-spin mb-3" />
        <h3 className="text-sm font-semibold text-text">Deconstructing Instruction...</h3>
        <p className="text-xs text-text-muted mt-1 max-w-sm">
          Extracting goals, inputs, outputs, rules, and identifying clarifying questions.
        </p>
      </div>
    );
  }

  const u = productUnderstanding;

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <div className="pb-4 border-b border-border flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-text">2. Product Understanding & Assumptions</h2>
          <p className="text-sm text-text-muted mt-1">
            CodeX parsed your request into verified goals, inputs, outputs, rules, and assumptions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCompileDirectly}
            disabled={isCompiling}
            className="flex items-center gap-2 bg-white border border-primary-600 text-primary-700 hover:bg-primary-50 px-4 py-2 rounded-md text-xs font-semibold transition-all shadow-subtle disabled:opacity-50"
          >
            {isCompiling ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Layers className="w-3.5 h-3.5" />
            )}
            <span>Compile Workflow Spec</span>
          </button>

          <button
            onClick={handleNext}
            className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md text-xs font-semibold transition-all shadow-subtle"
          >
            <span>Feature Recommendations</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {compilationError && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2.5 text-xs text-red-800">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
          <div>
            <div className="font-semibold">Compilation Notice</div>
            <div className="text-[11px] mt-0.5">{compilationError}</div>
          </div>
        </div>
      )}

      {/* Goal & Target Users */}
      <div className="p-5 border border-border rounded-lg bg-surface space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-text">System Goal</span>
          <span className="text-[10px] bg-primary-100 text-primary-900 border border-primary-200 px-2 py-0.5 rounded font-medium">
            User-stated
          </span>
        </div>
        <p className="text-sm text-text font-medium leading-relaxed">
          {u?.goal || 'Automate CSV ingestion, validate records, detect missing fields, calculate monthly aggregates, and output a structured report.'}
        </p>
        {u?.summary && (
          <p className="text-xs text-text-muted leading-relaxed">
            {u.summary}
          </p>
        )}
        {u?.target_users && u.target_users.length > 0 && (
          <div className="pt-2 flex items-center gap-2 flex-wrap">
            <span className="text-[11px] text-text-muted font-medium">Target Users:</span>
            {u.target_users.map((user, i) => (
              <span
                key={i}
                className="text-[11px] bg-white border border-border text-text px-2.5 py-0.5 rounded-full font-medium"
              >
                {user}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* 4 Quadrants: Inputs, Outputs, Rules, Assumptions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Inputs */}
        <div className="border border-border rounded-lg p-4 bg-white space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-border/60">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-text">Inputs & Sources</h3>
            <span className="text-[11px] text-text-muted">{u?.inputs?.length || 0} items</span>
          </div>
          <div className="space-y-2.5">
            {u?.inputs?.map((item) => (
              <div key={item.id} className="p-2.5 bg-surface rounded border border-border/50 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-text">{item.title}</span>
                  {renderBadge(item.attribution)}
                </div>
                <p className="text-[11px] text-text-muted mt-1 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Outputs */}
        <div className="border border-border rounded-lg p-4 bg-white space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-border/60">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-text">Expected Outputs</h3>
            <span className="text-[11px] text-text-muted">{u?.outputs?.length || 0} items</span>
          </div>
          <div className="space-y-2.5">
            {u?.outputs?.map((item) => (
              <div key={item.id} className="p-2.5 bg-surface rounded border border-border/50 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-text">{item.title}</span>
                  {renderBadge(item.attribution)}
                </div>
                <p className="text-[11px] text-text-muted mt-1 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Business Rules */}
        <div className="border border-border rounded-lg p-4 bg-white space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-border/60">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-text">Validation & Business Rules</h3>
            <span className="text-[11px] text-text-muted">{u?.business_rules?.length || 0} items</span>
          </div>
          <div className="space-y-2.5">
            {u?.business_rules?.map((item) => (
              <div key={item.id} className="p-2.5 bg-surface rounded border border-border/50 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-text">{item.title}</span>
                  {renderBadge(item.attribution)}
                </div>
                <p className="text-[11px] text-text-muted mt-1 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Working Assumptions */}
        <div className="border border-border rounded-lg p-4 bg-white space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-border/60">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-text">Working Assumptions</h3>
            <span className="text-[11px] text-text-muted">{u?.assumptions?.length || 0} items</span>
          </div>
          <div className="space-y-2.5">
            {u?.assumptions?.map((item) => (
              <div key={item.id} className="p-2.5 bg-surface rounded border border-border/50 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-text">{item.title}</span>
                  {renderBadge(item.attribution)}
                </div>
                <p className="text-[11px] text-text-muted mt-1 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Clarification Questions (Max 3) */}
      {u?.clarifications && u.clarifications.length > 0 && (
        <div className="p-5 border border-primary-200 bg-primary-50/40 rounded-lg space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-primary-900 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-primary-600" />
              <span>Design Clarifications ({u.clarifications.length} Pending)</span>
            </h3>
            <span className="text-[11px] text-primary-700">
              Select your preference before compiling workflow
            </span>
          </div>

          <div className="space-y-3">
            {u.clarifications.map((cq) => {
              const currentVal = clarificationAnswers[cq.id] || cq.selected_choice || cq.default_choice;
              return (
                <div key={cq.id} className="p-3.5 bg-white border border-border rounded-md text-xs space-y-2">
                  <div className="font-semibold text-text">{cq.question}</div>
                  {cq.context && <p className="text-[11px] text-text-muted">{cq.context}</p>}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {cq.options.map((option, optIdx) => {
                      const isSelected = currentVal === option;
                      return (
                        <button
                          key={optIdx}
                          type="button"
                          onClick={() => setClarificationAnswer(cq.id, option)}
                          className={`p-2.5 rounded border text-left flex items-start gap-2 transition-all ${
                            isSelected
                              ? 'bg-primary-50 border-primary-600 text-primary-900 font-medium ring-1 ring-primary-600'
                              : 'bg-surface border-border text-text-muted hover:border-text-muted hover:text-text'
                          }`}
                        >
                          <CheckCircle
                            className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${
                              isSelected ? 'text-primary-600' : 'text-text-muted/30'
                            }`}
                          />
                          <span className="text-[11px]">{option}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
