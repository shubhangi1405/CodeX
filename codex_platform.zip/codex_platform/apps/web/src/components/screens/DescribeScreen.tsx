import React from 'react';
import {
  UploadCloud,
  ArrowRight,
  Sparkles,
  FileText,
  Cpu,
  AlertCircle,
  Loader2,
  X,
  Keyboard,
  ShieldCheck,
  CheckCircle,
} from 'lucide-react';
import { useProjectStore } from '../../stores/useProjectStore';

const EXAMPLE_PROMPTS = [
  {
    title: 'Daily Habit & Streak Tracker',
    tag: 'Productivity',
    prompt:
      'Build a daily habit tracker that logs habit check-ins, validates completion dates and streak points, filters missed days, calculates monthly streak consistency totals, and creates a habit progress report.',
  },
  {
    title: 'CSV Monthly Totals Pipeline',
    tag: 'Finance',
    prompt: 'Whenever a new CSV arrives, validate the records, identify missing fields, calculate monthly totals and create a report.',
  },
  {
    title: 'Customer Order Reconciliation',
    tag: 'E-Commerce',
    prompt: 'Read daily orders CSV, filter cancelled orders, compute revenue by product category, and alert on any negative totals.',
  },
  {
    title: 'Employee Expense Validation & Approvals',
    tag: 'Corporate',
    prompt: 'Validate employee expense receipts CSV, verify required receipt IDs, alert on expenses over 500, and group monthly spending.',
  },
  {
    title: 'Employee Attendance & Shift Hours',
    tag: 'Operations',
    prompt: 'Ingest shift log CSV, check required employee IDs and timestamps, flag duplicate shifts, and calculate total hours worked.',
  },
  {
    title: 'Inventory Stock & Reorder Alert',
    tag: 'Supply Chain',
    prompt: 'Check SKU inventory records, validate stock levels and unit values, filter discontinued items, and summarize total inventory valuation.',
  },
];

export const DescribeScreen: React.FC = () => {
  const {
    promptInput,
    setPromptInput,
    sampleFileName,
    setSampleFileName,
    selectedProvider,
    setSelectedProvider,
    isCompiling,
    compilationError,
    interpretPrompt,
    setActiveStep,
    unlockStep,
    completeStep,
  } = useProjectStore();

  const handleAnalyze = async () => {
    if (!promptInput.trim() || isCompiling) return;
    await interpretPrompt();
    completeStep('describe');
    unlockStep('understanding');
    setActiveStep('understanding');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleAnalyze();
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-6">
      {/* Hero Header */}
      <div className="bg-white border border-[#E6E0F5] rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider bg-[#F5F0FF] text-[#6D28D9] border border-[#D8D2EB] px-2 py-0.5 rounded-full">
              Step 1 of 7
            </span>
            <span className="text-xs text-[#6B6585]">• Natural Language Compiler</span>
          </div>
          <h2 className="text-xl font-bold text-[#1A1528] mt-1 tracking-tight">
            Describe Your Software in Plain English
          </h2>
          <p className="text-xs text-[#6B6585] mt-1 max-w-2xl leading-relaxed">
            CodeX translates your business instructions into a strongly typed DAG workflow, generates automated test suites, verifies deterministic replay, and scaffolds a complete production application.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1.5 text-xs bg-[#FAF9FD] border border-[#E6E0F5] px-3 py-1.5 rounded-xl text-[#6B6585]">
            <ShieldCheck className="w-4 h-4 text-[#15803D]" />
            <span>Deterministic Sandbox Active</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 columns: Text area & sample upload */}
        <div className="lg:col-span-2 space-y-6">
          {/* Model Provider Selector */}
          <div className="bg-white border border-[#E6E0F5] rounded-xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs font-bold uppercase tracking-wider text-[#1A1528] flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-[#6D28D9]" />
                <span>Compiler AI Engine</span>
              </label>
              <span className="text-[11px] text-[#6B6585]">
                Layer 2 drafts specs; Layer 1 strictly verifies
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setSelectedProvider('mock')}
                className={`p-3 rounded-xl text-xs text-left border transition-all ${
                  selectedProvider === 'mock'
                    ? 'bg-[#F5F0FF] border-[#6D28D9] text-[#4C1D95] shadow-sm ring-1 ring-[#6D28D9]'
                    : 'bg-white border-[#E6E0F5] text-[#6B6585] hover:border-[#D8D2EB]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#1A1528]">Deterministic Mock</span>
                  {selectedProvider === 'mock' && <CheckCircle className="w-3.5 h-3.5 text-[#6D28D9]" />}
                </div>
                <div className="text-[10px] text-[#6B6585] mt-1">100% offline, zero tokens, reproducible</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedProvider('gemini')}
                className={`p-3 rounded-xl text-xs text-left border transition-all ${
                  selectedProvider === 'gemini'
                    ? 'bg-[#F5F0FF] border-[#6D28D9] text-[#4C1D95] shadow-sm ring-1 ring-[#6D28D9]'
                    : 'bg-white border-[#E6E0F5] text-[#6B6585] hover:border-[#D8D2EB]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#1A1528]">Google Gemini</span>
                  {selectedProvider === 'gemini' && <CheckCircle className="w-3.5 h-3.5 text-[#6D28D9]" />}
                </div>
                <div className="text-[10px] text-[#6B6585] mt-1">Uses GEMINI_API_KEY environment variable</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedProvider('openai')}
                className={`p-3 rounded-xl text-xs text-left border transition-all ${
                  selectedProvider === 'openai'
                    ? 'bg-[#F5F0FF] border-[#6D28D9] text-[#4C1D95] shadow-sm ring-1 ring-[#6D28D9]'
                    : 'bg-white border-[#E6E0F5] text-[#6B6585] hover:border-[#D8D2EB]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#1A1528]">OpenAI / Ollama</span>
                  {selectedProvider === 'openai' && <CheckCircle className="w-3.5 h-3.5 text-[#6D28D9]" />}
                </div>
                <div className="text-[10px] text-[#6B6585] mt-1">Local vLLM / Ollama or OpenAI compat</div>
              </button>
            </div>
          </div>

          {/* Prompt Textarea */}
          <div className="bg-white border border-[#E6E0F5] rounded-xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-[#1A1528]">
                Instruction Prompt
              </label>
              {promptInput.length > 0 && (
                <button
                  onClick={() => setPromptInput('')}
                  className="text-[11px] text-[#6B6585] hover:text-[#1A1528] flex items-center gap-1"
                >
                  <X className="w-3 h-3" />
                  <span>Clear</span>
                </button>
              )}
            </div>

            <textarea
              rows={6}
              value={promptInput}
              onChange={(e) => setPromptInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="e.g. Whenever a new CSV arrives, validate the records, identify missing fields, calculate monthly totals and create a report."
              className="w-full p-4 border border-[#D8D2EB] rounded-xl bg-[#FAF9FD] text-sm text-[#1A1528] focus:bg-white focus:border-[#6D28D9] focus:ring-2 focus:ring-[#6D28D9]/20 transition-all font-mono resize-none leading-relaxed outline-none"
            />

            <div className="flex items-center justify-between text-xs text-[#6B6585] pt-1">
              <span className="font-mono text-[11px]">
                {promptInput.length} characters
              </span>
              <span className="flex items-center gap-1 text-[11px]">
                <Keyboard className="w-3.5 h-3.5 text-[#9B95B3]" />
                <span>Press <kbd className="bg-[#FAF9FD] border border-[#D8D2EB] px-1 py-0.5 rounded text-[10px] font-mono">Ctrl+Enter</kbd> to compile</span>
              </span>
            </div>
          </div>

          {/* Sample Dataset Attachment */}
          <div className="border-2 border-dashed border-[#D8D2EB] hover:border-[#6D28D9] rounded-xl p-5 bg-white text-center transition-all">
            <div className="flex flex-col items-center justify-center">
              <UploadCloud className="w-7 h-7 text-[#6D28D9] mb-1.5" />
              <div className="text-xs font-semibold text-[#1A1528]">
                {sampleFileName ? (
                  <span className="flex items-center gap-1.5 text-[#15803D] font-bold">
                    <FileText className="w-4 h-4" /> Attached: {sampleFileName}
                  </span>
                ) : (
                  'Attach Sample Data File (Optional CSV / JSON)'
                )}
              </div>
              <p className="text-[11px] text-[#6B6585] mt-1 max-w-md">
                Used to automatically detect column schemas and run dry-run verification tests.
              </p>
              {!sampleFileName && (
                <button
                  onClick={() => setSampleFileName('monthly_sales.csv')}
                  className="mt-3 text-xs bg-[#FAF9FD] hover:bg-[#F5F0FF] border border-[#D8D2EB] text-[#6D28D9] font-semibold px-3 py-1.5 rounded-lg transition-all"
                >
                  Use Built-in sample `monthly_sales.csv`
                </button>
              )}
            </div>
          </div>

          {/* Prompt Presets */}
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#6B6585] block mb-2.5">
              Verified Architecture Blueprints
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {EXAMPLE_PROMPTS.map((ex, idx) => (
                <div
                  key={idx}
                  onClick={() => setPromptInput(ex.prompt)}
                  className="p-3.5 border border-[#E6E0F5] hover:border-[#6D28D9] rounded-xl bg-white hover:bg-[#FAF9FD] cursor-pointer transition-all shadow-subtle group"
                >
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-bold text-[#1A1528] group-hover:text-[#6D28D9] transition-colors">
                      {ex.title}
                    </div>
                    <span className="text-[9px] font-bold uppercase bg-[#F5F0FF] text-[#6D28D9] px-1.5 py-0.5 rounded">
                      {ex.tag}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#6B6585] mt-1 line-clamp-2 leading-relaxed">
                    {ex.prompt}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Compilation Error Notice if any */}
          {compilationError && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-xl flex items-start gap-3 text-xs text-red-900 shadow-sm">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">Interpretation Encountered an Issue</div>
                <div className="text-[11px] mt-0.5">{compilationError}</div>
              </div>
            </div>
          )}

          {/* Action Button */}
          <div className="pt-2 flex justify-end">
            <button
              onClick={handleAnalyze}
              disabled={!promptInput.trim() || isCompiling}
              className="flex items-center gap-2 bg-[#6D28D9] hover:bg-[#5B21B6] disabled:opacity-50 text-white px-6 py-3 rounded-xl text-xs font-bold transition-all shadow-md hover:shadow-lg disabled:shadow-none"
            >
              {isCompiling ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Compiling & Validating Idea...</span>
                </>
              ) : (
                <>
                  <span>Analyze & Compile Workflow</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right 1 column: CodeX Architecture Side Card */}
        <div className="border border-[#E6E0F5] rounded-2xl p-6 bg-white shadow-sm flex flex-col justify-between h-fit space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-4 pb-3 border-b border-[#E6E0F5]">
              <Sparkles className="w-4 h-4 text-[#6D28D9]" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#1A1528]">
                Layer 1 Verification Core
              </h3>
            </div>

            <div className="space-y-3.5 text-xs">
              <div className="p-3.5 bg-[#FAF9FD] border border-[#E6E0F5] rounded-xl">
                <div className="text-[10px] text-[#6B6585] uppercase font-bold">Closed Type System</div>
                <div className="text-[#1A1528] font-semibold mt-1">
                  Table, Record, List, Date, Number, File, Report
                </div>
                <p className="text-[11px] text-[#6B6585] mt-1 leading-normal">
                  All edge connections are type-checked at compile time.
                </p>
              </div>

              <div className="p-3.5 bg-[#FAF9FD] border border-[#E6E0F5] rounded-xl">
                <div className="text-[10px] text-[#6B6585] uppercase font-bold">Sandboxed AST Evaluator</div>
                <div className="text-[#1A1528] font-semibold mt-1">
                  Zero Eval • Zero Exec
                </div>
                <p className="text-[11px] text-[#6B6585] mt-1 leading-normal">
                  Private attributes and dunder methods are blocked at parser level.
                </p>
              </div>

              <div className="p-3.5 bg-[#FAF9FD] border border-[#E6E0F5] rounded-xl">
                <div className="text-[10px] text-[#6B6585] uppercase font-bold">Deterministic Replay</div>
                <div className="text-[#1A1528] font-semibold mt-1">
                  Bit-for-Bit Hash Matching
                </div>
                <p className="text-[11px] text-[#6B6585] mt-1 leading-normal">
                  Same input + same workflow version = identical SHA-256 output hash.
                </p>
              </div>

              <div className="p-3.5 bg-[#FAF9FD] border border-[#E6E0F5] rounded-xl">
                <div className="text-[10px] text-[#6B6585] uppercase font-bold">Independent Test Oracle</div>
                <div className="text-[#1A1528] font-semibold mt-1">
                  8 Edge-Case Test Scenarios
                </div>
                <p className="text-[11px] text-[#6B6585] mt-1 leading-normal">
                  Empty file, corrupt types, duplicate rows, missing columns tested automatically.
                </p>
              </div>
            </div>
          </div>

          <div className="p-3 bg-[#F5F0FF] rounded-xl border border-[#D8D2EB] text-center">
            <span className="text-[11px] font-bold text-[#6D28D9]">
              Fast, Safe & 100% Inspectable
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
