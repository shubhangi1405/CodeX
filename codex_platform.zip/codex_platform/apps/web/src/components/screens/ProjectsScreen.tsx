import React, { useEffect, useState } from 'react';
import { Plus, ArrowRight, Clock } from 'lucide-react';
import { useProjectStore } from '../../stores/useProjectStore';
import { Project } from '../../types';
import { API_BASE } from '../../api/config';

export const ProjectsScreen: React.FC = () => {
  const { setCurrentProject, setActiveStep } = useProjectStore();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${API_BASE}/api/projects`)
      .then((res) => (res.ok ? res.json() : []))
      .then((data) => {
        setProjects(data);
        setLoading(false);
      })
      .catch(() => {
        setLoading(false);
      });
  }, []);

  const handleSelect = (project: Project) => {
    setCurrentProject(project);
    setActiveStep('describe');
  };

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-8 pb-4 border-b border-border">
        <div>
          <h2 className="text-xl font-semibold text-text">Workspace Projects</h2>
          <p className="text-sm text-text-muted mt-1">
            Manage your plain-language workflows and inspect built applications.
          </p>
        </div>
        <button
          onClick={() => {
            const newProj: Project = {
              id: 'new-' + Date.now(),
              name: 'New Custom Pipeline',
              prompt: '',
              created_at: new Date().toISOString(),
              status: 'draft',
              current_step: 1,
            };
            setCurrentProject(newProj);
            setActiveStep('describe');
          }}
          className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md text-xs font-medium transition-colors shadow-subtle"
        >
          <Plus className="w-4 h-4" />
          <span>New Workflow Project</span>
        </button>
      </div>

      {loading ? (
        <div className="text-sm text-text-muted py-12 text-center">Loading projects...</div>
      ) : projects.length === 0 ? (
        <div className="p-8 border border-border rounded-lg bg-surface text-center">
          <p className="text-sm text-text-muted">No projects found. Create your first workflow!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {projects.map((proj) => (
            <div
              key={proj.id}
              onClick={() => handleSelect(proj)}
              className="p-5 border border-border rounded-lg bg-white hover:border-primary-500 hover:shadow-subtle cursor-pointer transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold text-text">{proj.name}</h3>
                  <span className="text-[10px] bg-primary-50 text-primary-700 border border-primary-200 px-2 py-0.5 rounded-full font-medium">
                    {proj.status}
                  </span>
                </div>
                <p className="text-xs text-text-muted line-clamp-3 leading-relaxed mb-4">
                  {proj.prompt}
                </p>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-border/60 text-[11px] text-text-muted">
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{new Date(proj.created_at).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-1 text-primary-600 font-medium hover:text-primary-700">
                  <span>Open Pipeline</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
