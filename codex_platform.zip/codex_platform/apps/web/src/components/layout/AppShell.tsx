import React from 'react';
import {
  FileText,
  Activity,
  Layers,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { SidebarStepper } from './SidebarStepper';
import { useProjectStore } from '../../stores/useProjectStore';
import { ProjectsScreen } from '../screens/ProjectsScreen';
import { DescribeScreen } from '../screens/DescribeScreen';
import { UnderstandingScreen } from '../screens/UnderstandingScreen';
import { RecommendationsScreen } from '../screens/RecommendationsScreen';
import { SpecificationScreen } from '../screens/SpecificationScreen';
import { WorkflowScreen } from '../screens/WorkflowScreen';
import { TestsScreen } from '../screens/TestsScreen';
import { BuildScreen } from '../screens/BuildScreen';
import { API_BASE } from '../../api/config';

export const AppShell: React.FC = () => {
  const { activeStep, currentProject } = useProjectStore();

  const getStepTitle = () => {
    switch (activeStep) {
      case 'projects':
        return 'Project Manager';
      case 'describe':
        return 'Step 1 • Plain-English Intent';
      case 'understanding':
        return 'Step 2 • Product Understanding & Rules';
      case 'recommendations':
        return 'Step 3 • Feature Recommendations';
      case 'specification':
        return 'Step 4 • Typed Workflow Specification';
      case 'workflow':
        return 'Step 5 • React Flow DAG Canvas';
      case 'tests':
        return 'Step 6 • Automated 8-Scenario Tests';
      case 'build':
        return 'Step 7 • Complete Built Software';
      default:
        return 'Workflow Builder';
    }
  };

  const renderActiveScreen = () => {
    switch (activeStep) {
      case 'projects':
        return <ProjectsScreen />;
      case 'describe':
        return <DescribeScreen />;
      case 'understanding':
        return <UnderstandingScreen />;
      case 'recommendations':
        return <RecommendationsScreen />;
      case 'specification':
        return <SpecificationScreen />;
      case 'workflow':
        return <WorkflowScreen />;
      case 'tests':
        return <TestsScreen />;
      case 'build':
        return <BuildScreen />;
      default:
        return <DescribeScreen />;
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#FAF9FD]">
      <SidebarStepper />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Modern Top Header Bar */}
        <header className="h-14 bg-white border-b border-[#E6E0F5] px-6 flex items-center justify-between shrink-0 z-10">
          <div className="flex items-center gap-2 text-xs text-[#6B6585] min-w-0">
            <span className="font-semibold text-[#1A1528] flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-[#6D28D9]" />
              <span>CodeX</span>
            </span>
            <ChevronRight className="w-3.5 h-3.5 text-[#9B95B3]" />
            <span className="font-medium truncate max-w-[200px]" title={currentProject?.name}>
              {currentProject?.name || 'Default Project'}
            </span>
            <ChevronRight className="w-3.5 h-3.5 text-[#9B95B3]" />
            <span className="font-semibold text-[#6D28D9] bg-[#F5F0FF] border border-[#D8D2EB] px-2 py-0.5 rounded-md truncate">
              {getStepTitle()}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-1.5 text-xs text-[#15803D] bg-[#F0FDF4] border border-[#BBF7D0] px-2.5 py-1 rounded-md font-medium">
              <Activity className="w-3.5 h-3.5" />
              <span>Layer 1 Engine Ready</span>
            </div>

            <a
              href={`${API_BASE}/docs`}
              target="_blank"
              rel="noreferrer"
              className="text-xs text-[#6B6585] hover:text-[#1A1528] flex items-center gap-1 px-2.5 py-1 rounded-md hover:bg-[#FAF9FD] transition-colors border border-transparent hover:border-[#E6E0F5]"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>API Swagger</span>
              <ExternalLink className="w-3 h-3 text-[#9B95B3]" />
            </a>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-[#FAF9FD] flex flex-col custom-scroll">
          {renderActiveScreen()}
        </main>
      </div>
    </div>
  );
};
