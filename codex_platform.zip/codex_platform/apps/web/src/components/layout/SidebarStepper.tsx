import React from 'react';
import {
  FolderKanban,
  FileEdit,
  Lightbulb,
  Layers,
  FileCode,
  Network,
  CheckCircle2,
  Package,
  Lock,
  ShieldCheck,
} from 'lucide-react';
import { useProjectStore } from '../../stores/useProjectStore';
import { StepId } from '../../types';

interface StepDef {
  id: StepId;
  label: string;
  subtitle: string;
  icon: React.ComponentType<{ className?: string }>;
}

const STEPS: StepDef[] = [
  { id: 'projects', label: 'Projects', subtitle: 'Manage workspaces', icon: FolderKanban },
  { id: 'describe', label: '1. Describe', subtitle: 'Plain English intent', icon: FileEdit },
  { id: 'understanding', label: '2. Understand', subtitle: 'Goal & rules breakdown', icon: Lightbulb },
  { id: 'recommendations', label: '3. Features', subtitle: '4-tier recommendations', icon: Layers },
  { id: 'specification', label: '4. Specification', subtitle: 'Structured JSON spec', icon: FileCode },
  { id: 'workflow', label: '5. Workflow', subtitle: 'Typed React Flow DAG', icon: Network },
  { id: 'tests', label: '6. Tests', subtitle: '8-scenario verification', icon: CheckCircle2 },
  { id: 'build', label: '7. Built App', subtitle: 'Runnable full-stack app', icon: Package },
];

export const SidebarStepper: React.FC = () => {
  const { activeStep, setActiveStep, unlockedSteps, completedSteps, currentProject } = useProjectStore();

  return (
    <aside className="w-72 border-r border-[#E6E0F5] bg-white flex flex-col h-screen select-none shadow-sm z-20">
      {/* Brand Header */}
      <div className="p-5 border-b border-[#E6E0F5] bg-gradient-to-b from-white to-[#FAF9FD]">
        <div className="flex items-center gap-3">
          <div
            aria-label="CodeX Logo"
            className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#5B21B6] to-[#7C3AED] text-white flex items-center justify-center font-bold text-base shadow-sm ring-2 ring-[#7C3AED]/20"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path
                d="M8.5 7L3.5 12L8.5 17"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M15.5 7L20.5 12L15.5 17"
                stroke="#DDD6FE"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <circle cx="12" cy="12" r="2" fill="currentColor" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base font-bold text-[#1A1528] tracking-tight">CodeX</h1>
              <span className="text-[9px] font-bold uppercase bg-[#F5F0FF] text-[#6D28D9] border border-[#D8D2EB] px-1.5 py-0.2 rounded font-mono">
                Core
              </span>
            </div>
            <p className="text-[11px] text-[#6B6585] mt-0.5 font-medium">Describe • Verify • Build</p>
          </div>
        </div>

        {/* Current Project Card */}
        <div className="mt-4 p-2.5 rounded-lg bg-[#FAF9FD] border border-[#E6E0F5] flex items-center justify-between">
          <div className="min-w-0 pr-2">
            <div className="text-[10px] uppercase font-bold text-[#6B6585] tracking-wider">Active Workspace</div>
            <div className="text-xs font-semibold text-[#1A1528] truncate mt-0.5" title={currentProject?.name}>
              {currentProject?.name ?? 'Default Workspace'}
            </div>
          </div>
          <button
            onClick={() => setActiveStep('projects')}
            className="text-[11px] font-semibold text-[#6D28D9] hover:text-[#5B21B6] hover:underline whitespace-nowrap"
          >
            Switch
          </button>
        </div>
      </div>

      {/* Stepper Navigation */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-1 custom-scroll">
        <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-[#9B95B3]">
          Pipeline Stages
        </div>

        {STEPS.map((step, idx) => {
          const isUnlocked = unlockedSteps.has(step.id);
          const isCompleted = completedSteps.has(step.id);
          const isActive = activeStep === step.id;
          const Icon = step.icon;

          return (
            <button
              key={step.id}
              onClick={() => isUnlocked && setActiveStep(step.id)}
              disabled={!isUnlocked}
              className={`w-full group text-left px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all relative flex items-center justify-between ${
                isActive
                  ? 'bg-[#F5F0FF] text-[#5B21B6] font-semibold shadow-sm border border-[#D8D2EB]'
                  : isUnlocked
                  ? 'text-[#2D2640] hover:bg-[#FAF9FD] hover:text-[#1A1528]'
                  : 'text-[#9B95B3] cursor-not-allowed opacity-55'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
                    isActive
                      ? 'bg-[#6D28D9] text-white shadow-sm'
                      : isCompleted
                      ? 'bg-[#F0FDF4] text-[#15803D] border border-[#BBF7D0]'
                      : isUnlocked
                      ? 'bg-[#FAF9FD] text-[#6B6585] border border-[#E6E0F5]'
                      : 'bg-transparent text-[#9B95B3]'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0">
                  <div className="truncate font-semibold text-xs leading-tight">{step.label}</div>
                  <div className="text-[10px] text-[#6B6585] truncate font-normal leading-tight mt-0.5">
                    {step.subtitle}
                  </div>
                </div>
              </div>

              {/* Status Indicator */}
              <div className="flex items-center pl-2">
                {isCompleted ? (
                  <span className="w-5 h-5 rounded-full bg-[#F0FDF4] border border-[#BBF7D0] flex items-center justify-center text-[#15803D]">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </span>
                ) : !isUnlocked ? (
                  <Lock className="w-3.5 h-3.5 text-[#9B95B3]" />
                ) : isActive ? (
                  <span className="w-2 h-2 rounded-full bg-[#6D28D9] animate-pulse" />
                ) : (
                  <span className="text-[10px] text-[#9B95B3] font-mono">0{idx}</span>
                )}
              </div>
            </button>
          );
        })}
      </nav>

      {/* Engine Status Footer */}
      <div className="p-3.5 border-t border-[#E6E0F5] bg-[#FAF9FD] text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#15803D] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#15803D]"></span>
            </span>
            <span className="text-[11px] font-semibold text-[#1A1528] flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#15803D]" />
              <span>Engine: Ready</span>
            </span>
          </div>
          <span className="text-[10px] font-mono bg-white text-[#6D28D9] px-2 py-0.5 rounded border border-[#E6E0F5] font-semibold">
            v1.0.0
          </span>
        </div>
        <p className="text-[10px] text-[#6B6585] mt-1.5 leading-normal">
          Sandboxed AST • Zero Eval • 100% Deterministic
        </p>
      </div>
    </aside>
  );
};
