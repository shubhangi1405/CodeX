import React, { useState, useEffect } from 'react';
import {
  GitCompare,
  Plus,
  RefreshCw,
  CheckCircle2,
  Trash2,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

export interface NodeDiffModel {
  node_id: string;
  change_type: 'added' | 'removed' | 'modified';
  label: string;
  type: string;
  old_config?: Record<string, unknown>;
  new_config?: Record<string, unknown>;
}

export interface EdgeDiffModel {
  edge_id: string;
  change_type: 'added' | 'removed';
  from_node: string;
  from_port: string;
  to_node: string;
  to_port: string;
}

export interface WorkflowDiffModel {
  old_version: number;
  new_version: number;
  added_nodes: NodeDiffModel[];
  removed_nodes: NodeDiffModel[];
  modified_nodes: NodeDiffModel[];
  added_edges: EdgeDiffModel[];
  removed_edges: EdgeDiffModel[];
  summary: string;
}

interface VersionDiffViewProps {
  diff?: WorkflowDiffModel | null;
  onRefreshDiff?: () => void;
}

const FALLBACK_DIFF: WorkflowDiffModel = {
  old_version: 1,
  new_version: 2,
  summary: 'Added positive amount filtering AST rule and expanded required columns to include category.',
  added_nodes: [
    {
      node_id: 'node-filter',
      change_type: 'added',
      label: 'Filter Valid Positive Amounts',
      type: 'transform.filter',
      new_config: { expression: 'amount > 0' },
    },
  ],
  removed_nodes: [],
  modified_nodes: [
    {
      node_id: 'node-req',
      change_type: 'modified',
      label: 'Validate Required Fields',
      type: 'validate.required_fields',
      old_config: { required_columns: ['date', 'amount'] },
      new_config: { required_columns: ['date', 'amount', 'category'] },
    },
  ],
  added_edges: [
    {
      edge_id: 'e-filter-agg',
      change_type: 'added',
      from_node: 'node-filter',
      from_port: 'table',
      to_node: 'node-monthly',
      to_port: 'table',
    },
  ],
  removed_edges: [],
};

export const VersionDiffView: React.FC<VersionDiffViewProps> = ({ diff: propDiff }) => {
  const [activeDiff, setActiveDiff] = useState<WorkflowDiffModel>(propDiff || FALLBACK_DIFF);

  useEffect(() => {
    if (propDiff) {
      setActiveDiff(propDiff);
    }
  }, [propDiff]);

  const totalChanges =
    activeDiff.added_nodes.length +
    activeDiff.modified_nodes.length +
    activeDiff.removed_nodes.length +
    activeDiff.added_edges.length +
    activeDiff.removed_edges.length;

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-border">
        <div>
          <h3 className="text-base font-semibold text-text flex items-center gap-2">
            <GitCompare className="w-4 h-4 text-primary-600" />
            <span>Workflow Version Comparison (v{activeDiff.old_version} → v{activeDiff.new_version})</span>
          </h3>
          <p className="text-xs text-text-muted mt-1">
            Deterministic visual diff highlighting added, modified, and removed nodes across immutable workflow iterations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs bg-primary-50 text-primary-700 border border-primary-200 px-2.5 py-1 rounded font-semibold flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{totalChanges} Total Graph Changes</span>
          </span>
        </div>
      </div>

      {/* Summary Alert */}
      <div className="p-4 rounded-lg bg-surface border border-border flex items-start gap-3">
        <GitCompare className="w-4 h-4 text-primary-600 mt-0.5 shrink-0" />
        <div className="text-xs text-text">
          <span className="font-semibold text-text">Evolution Summary: </span>
          <span className="text-text-muted">{activeDiff.summary}</span>
        </div>
      </div>

      {/* Modified Nodes */}
      {activeDiff.modified_nodes.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-warning flex items-center gap-1.5">
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Modified Nodes ({activeDiff.modified_nodes.length})</span>
          </h4>
          {activeDiff.modified_nodes.map((node) => (
            <div
              key={node.node_id}
              className="p-4 rounded-lg border border-warning/30 bg-warning-bg space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-text">{node.label}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white border border-border text-text-muted">
                    {node.type}
                  </span>
                </div>
                <span className="text-[10px] uppercase font-bold text-warning">Modified</span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-[11px] font-mono pt-1">
                <div className="p-2.5 rounded bg-white/70 border border-warning/20">
                  <div className="text-[9px] uppercase font-semibold text-text-muted mb-1">Previous Config (v{activeDiff.old_version})</div>
                  <pre className="text-text-muted overflow-x-auto">{JSON.stringify(node.old_config || {}, null, 2)}</pre>
                </div>
                <div className="p-2.5 rounded bg-white border border-warning/30">
                  <div className="text-[9px] uppercase font-semibold text-warning mb-1">Updated Config (v{activeDiff.new_version})</div>
                  <pre className="text-text overflow-x-auto font-semibold">{JSON.stringify(node.new_config || {}, null, 2)}</pre>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Added Nodes */}
      {activeDiff.added_nodes.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-success flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5" />
            <span>Added Nodes ({activeDiff.added_nodes.length})</span>
          </h4>
          {activeDiff.added_nodes.map((node) => (
            <div
              key={node.node_id}
              className="p-4 rounded-lg border border-success/30 bg-success-bg flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-success text-white flex items-center justify-center shrink-0">
                  <Plus className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h5 className="text-xs font-semibold text-text">{node.label}</h5>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white border border-border text-text-muted">
                      {node.type}
                    </span>
                  </div>
                  <div className="text-[11px] text-text-muted font-mono mt-1">
                    Config: {JSON.stringify(node.new_config || {})}
                  </div>
                </div>
              </div>
              <span className="text-[10px] uppercase font-bold text-success">Added</span>
            </div>
          ))}
        </div>
      )}

      {/* Removed Nodes */}
      {activeDiff.removed_nodes.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-danger flex items-center gap-1.5">
            <Trash2 className="w-3.5 h-3.5" />
            <span>Removed Nodes ({activeDiff.removed_nodes.length})</span>
          </h4>
          {activeDiff.removed_nodes.map((node) => (
            <div
              key={node.node_id}
              className="p-4 rounded-lg border border-danger/30 bg-danger-bg flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <h5 className="text-xs font-semibold text-text">{node.label}</h5>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white text-text-muted">
                  {node.type}
                </span>
              </div>
              <span className="text-[10px] uppercase font-bold text-danger">Removed</span>
            </div>
          ))}
        </div>
      )}

      {/* Edge Rewirings */}
      {activeDiff.added_edges.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-primary-700 flex items-center gap-1.5">
            <ArrowRight className="w-3.5 h-3.5" />
            <span>Edge Rewirings ({activeDiff.added_edges.length})</span>
          </h4>
          {activeDiff.added_edges.map((edge) => (
            <div
              key={edge.edge_id}
              className="p-3 rounded-lg border border-border bg-white flex items-center justify-between text-xs font-mono"
            >
              <div className="flex items-center gap-2 text-text">
                <span className="font-semibold text-primary-700">{edge.from_node}</span>
                <span className="text-text-muted">({edge.from_port})</span>
                <ArrowRight className="w-3.5 h-3.5 text-text-muted" />
                <span className="font-semibold text-primary-700">{edge.to_node}</span>
                <span className="text-text-muted">({edge.to_port})</span>
              </div>
              <span className="text-[10px] font-bold text-success uppercase">Connected</span>
            </div>
          ))}
        </div>
      )}

      {/* Unchanged Pipeline Nodes */}
      <div className="pt-2">
        <h4 className="text-xs font-semibold text-text-muted uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Core Invariant Pipeline Nodes (Preserved)</span>
        </h4>
        <div className="p-3 rounded-lg border border-border bg-surface text-xs text-text-muted">
          All remaining upstream ingest nodes and downstream report generation nodes remain unchanged and topologically intact.
        </div>
      </div>
    </div>
  );
};
