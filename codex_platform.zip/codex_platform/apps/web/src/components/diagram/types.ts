export type NodeCategory =
  | 'trigger'
  | 'ingest'
  | 'validate'
  | 'transform'
  | 'aggregate'
  | 'branch'
  | 'output'
  | 'quality';

export type NodeExecutionStatus = 'idle' | 'running' | 'success' | 'failed' | 'skipped';

export interface PortData {
  name: string;
  dataType: string;
}

export interface RejectedRowData {
  row: number;
  reason: string;
  data?: Record<string, unknown>;
}

export interface WorkflowNodeData {
  [key: string]: unknown;
  id: string;
  type: string;
  label: string;
  category: NodeCategory;
  config: Record<string, unknown>;
  inputPorts: PortData[];
  outputPorts: PortData[];
  status?: NodeExecutionStatus;
  durationMs?: number;
  rowCountIn?: number;
  rowCountOut?: number;
  rejectedCount?: number;
  rejectedSample?: RejectedRowData[];
  inputsSample?: Array<Record<string, unknown>>;
  outputsSample?: Array<Record<string, unknown>>;
  errorMessage?: string;
  versionChange?: 'added' | 'removed' | 'modified' | 'unchanged';
}

export interface TypedEdgeData {
  [key: string]: unknown;
  dataType: string;
  rowCount?: number;
  schemaDetails?: string;
}

export const CATEGORY_STYLES: Record<
  NodeCategory,
  { bg: string; text: string; border: string; label: string }
> = {
  trigger: {
    bg: 'bg-primary-50',
    text: 'text-primary-900',
    border: 'border-primary-200',
    label: 'Trigger',
  },
  ingest: {
    bg: 'bg-primary-100',
    text: 'text-primary-900',
    border: 'border-primary-300',
    label: 'Ingest',
  },
  validate: {
    bg: 'bg-surface-2',
    text: 'text-text',
    border: 'border-border',
    label: 'Validate',
  },
  transform: {
    bg: 'bg-surface-2',
    text: 'text-primary-700',
    border: 'border-border',
    label: 'Transform',
  },
  aggregate: {
    bg: 'bg-primary-50',
    text: 'text-primary-700',
    border: 'border-primary-200',
    label: 'Aggregate',
  },
  branch: {
    bg: 'bg-surface-2',
    text: 'text-text',
    border: 'border-border',
    label: 'Branch',
  },
  quality: {
    bg: 'bg-primary-100',
    text: 'text-primary-900',
    border: 'border-primary-300',
    label: 'Quality',
  },
  output: {
    bg: 'bg-primary-200',
    text: 'text-primary-900',
    border: 'border-primary-500',
    label: 'Output',
  },
};
