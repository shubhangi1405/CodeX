import React from 'react';
import {
  Globe,
  Server,
  Database,
  Cpu,
  Shield,
} from 'lucide-react';
import { useProjectStore } from '../../stores/useProjectStore';

export const ArchitectureDiagram: React.FC = () => {
  const { currentProject, compiledWorkflow, productUnderstanding } = useProjectStore();

  const wfName = String(compiledWorkflow?.name || currentProject?.name || 'Adaptive Application');
  const rawNodes = Array.isArray(compiledWorkflow?.nodes)
    ? (compiledWorkflow?.nodes as Array<{ id: string; type?: string; label?: string }>)
    : [];
  const triggerType =
    compiledWorkflow?.trigger && typeof compiledWorkflow.trigger === 'object'
      ? String((compiledWorkflow.trigger as { type?: string }).type || 'domain_event')
      : 'domain_event';

  const slug =
    wfName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .split('-')[0] || 'records';

  const outputTitles =
    productUnderstanding?.outputs && productUnderstanding.outputs.length > 0
      ? productUnderstanding.outputs.map((o) => o.title)
      : [`${wfName} Live View`, 'Quarantined Entry Log'];

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-6">
      <div>
        <h3 className="text-base font-semibold text-text">
          Generated Software Architecture — {wfName}
        </h3>
        <p className="text-xs text-text-muted mt-1">
          Topological system map showing {wfName}&apos;s decoupled tiers, trigger ({triggerType}), and {rawNodes.length || 6}-stage deterministic runtime core.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
        {/* Tier 1: Frontend UI */}
        <div className="p-5 rounded-lg border border-border bg-white shadow-subtle space-y-3">
          <div className="flex items-center gap-2 text-primary-700">
            <Globe className="w-4 h-4" />
            <h4 className="text-xs font-semibold uppercase tracking-wider">Adaptive UI</h4>
          </div>
          <div className="text-[11px] text-text-muted space-y-1.5 leading-relaxed">
            <div className="p-2 rounded bg-surface border border-border font-medium text-text">
              React 18 + Domain UI Kit
            </div>
            {outputTitles.slice(0, 3).map((title, idx) => (
              <div key={idx}>• {title}</div>
            ))}
            <div>• Real-time State & Validation</div>
          </div>
        </div>

        {/* Tier 2: Backend API */}
        <div className="p-5 rounded-lg border border-border bg-white shadow-subtle space-y-3">
          <div className="flex items-center gap-2 text-primary-700">
            <Server className="w-4 h-4" />
            <h4 className="text-xs font-semibold uppercase tracking-wider">API Gateway</h4>
          </div>
          <div className="text-[11px] text-text-muted space-y-1.5 leading-relaxed">
            <div className="p-2 rounded bg-surface border border-border font-medium text-text">
              FastAPI + Pydantic v2
            </div>
            <div>• GET/POST /api/{slug}</div>
            <div>• POST /api/workflows/run</div>
            <div>• GET /api/runs/:id/audit</div>
            <div>• Trigger: {triggerType}</div>
          </div>
        </div>

        {/* Tier 3: Workflow Core */}
        <div className="p-5 rounded-lg border border-primary-200 bg-primary-50/50 shadow-subtle space-y-3">
          <div className="flex items-center gap-2 text-primary-700">
            <Cpu className="w-4 h-4" />
            <h4 className="text-xs font-semibold uppercase tracking-wider">
              Workflow DAG ({rawNodes.length || 6} Nodes)
            </h4>
          </div>
          <div className="text-[11px] text-text-muted space-y-1.5 leading-relaxed">
            <div className="p-2 rounded bg-white border border-primary-200 font-medium text-text">
              Deterministic DAG Executor
            </div>
            {rawNodes.length > 0 ? (
              rawNodes.slice(0, 4).map((n) => (
                <div key={n.id} className="truncate" title={n.label || n.type}>
                  • {n.label || n.type}
                </div>
              ))
            ) : (
              <>
                <div>• Schema & Type Validation</div>
                <div>• Sandboxed AST Filter</div>
                <div>• Quality Gate Assertion</div>
                <div>• SHA-256 Replay Guarantee</div>
              </>
            )}
          </div>
        </div>

        {/* Tier 4: Storage */}
        <div className="p-5 rounded-lg border border-border bg-white shadow-subtle space-y-3">
          <div className="flex items-center gap-2 text-primary-700">
            <Database className="w-4 h-4" />
            <h4 className="text-xs font-semibold uppercase tracking-wider">Storage Layer</h4>
          </div>
          <div className="text-[11px] text-text-muted space-y-1.5 leading-relaxed">
            <div className="p-2 rounded bg-surface border border-border font-medium text-text">
              SQLite + SQLAlchemy 2
            </div>
            <div>• Domain Entity Tables ({slug})</div>
            <div>• Step Inspection Snapshots</div>
            <div>• Immutable Workflow Specs</div>
            <div>• SHA-256 Audit Provenance</div>
          </div>
        </div>
      </div>

      {/* Architecture Security & Performance Callout */}
      <div className="p-4 rounded-lg bg-surface border border-border flex items-start gap-3">
        <Shield className="w-5 h-5 text-primary-600 shrink-0 mt-0.5" />
        <div className="text-xs space-y-1">
          <span className="font-semibold text-text">Deterministic Isolation Guarantee</span>
          <p className="text-text-muted leading-relaxed">
            The Engine Core for {wfName} is completely decoupled from web endpoints and database queries. Domain rules run in a sandboxed AST interpreter with zero access to arbitrary Python builtins. Every execution produces an immutable audit record and SHA-256 hash.
          </p>
        </div>
      </div>
    </div>
  );
};
