import React, { memo } from 'react';
import { Handle, Position, NodeProps, Node } from '@xyflow/react';
import {
  FileText,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  BarChart3,
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import { WorkflowNodeData, CATEGORY_STYLES } from './types';

const CATEGORY_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  trigger: Clock,
  ingest: FileText,
  validate: ShieldCheck,
  transform: Filter,
  aggregate: BarChart3,
  branch: Sparkles,
  quality: CheckCircle2,
  output: BarChart3,
};

export const WorkflowNodeComponent: React.FC<NodeProps<Node<WorkflowNodeData>>> = memo(({ data, selected }) => {
  const categoryStyle = CATEGORY_STYLES[data.category] || CATEGORY_STYLES.validate;
  const IconComponent = CATEGORY_ICONS[data.category] || FileText;

  const isSuccess = data.status === 'success';
  const isFailed = data.status === 'failed';
  const isRunning = data.status === 'running';
  const isSkipped = data.status === 'skipped';

  return (
    <div
      className={`w-64 rounded-lg bg-white border transition-all select-none shadow-node ${
        selected
          ? 'border-primary-600 ring-2 ring-primary-100'
          : isFailed
          ? 'border-danger/60 ring-1 ring-danger/30'
          : isSuccess
          ? 'border-success/50'
          : 'border-border hover:border-primary-300'
      }`}
    >
      {/* Target Handle (Left Port) */}
      <Handle
        type="target"
        position={Position.Left}
        className="w-2.5 h-2.5 !bg-primary-600 border border-white"
      />

      {/* Node Header */}
      <div className="p-3">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <span
              className={`text-[9px] uppercase font-semibold tracking-wider px-1.5 py-0.5 rounded border ${categoryStyle.bg} ${categoryStyle.text} ${categoryStyle.border}`}
            >
              {categoryStyle.label}
            </span>
          </div>

          {/* Status Indicator */}
          {isRunning && (
            <span className="text-[10px] text-primary-600 font-medium flex items-center gap-1">
              <RotateCcw className="w-3 h-3 animate-spin" />
              <span>Running</span>
            </span>
          )}
          {isSuccess && (
            <span className="text-[10px] text-success font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              <span>{data.durationMs}ms</span>
            </span>
          )}
          {isFailed && (
            <span className="text-[10px] text-danger font-semibold flex items-center gap-1">
              <XCircle className="w-3 h-3" />
              <span>Failed</span>
            </span>
          )}
          {isSkipped && (
            <span className="text-[10px] text-text-muted font-medium">
              Skipped
            </span>
          )}
        </div>

        {/* Node Label & Icon */}
        <div className="flex items-center gap-2 mt-1">
          <IconComponent className="w-4 h-4 text-primary-600 shrink-0" />
          <h4 className="text-xs font-semibold text-text truncate" title={data.label}>
            {data.label}
          </h4>
        </div>

        {/* Typed Port Indicator */}
        <div className="flex items-center justify-between text-[10px] text-text-muted font-mono pt-2 mt-2 border-t border-border/60">
          <span>in: {data.inputPorts?.[0]?.dataType || 'any'}</span>
          <span>out: {data.outputPorts?.[0]?.dataType || 'any'}</span>
        </div>

        {/* Run Metrics Overlay */}
        {(isSuccess || isFailed) && (
          <div className="mt-2 pt-1.5 border-t border-border/60 text-[10px] grid grid-cols-3 gap-1 text-center bg-surface-2/60 p-1 rounded">
            <div>
              <div className="text-text-muted">In</div>
              <div className="font-semibold text-text">{data.rowCountIn ?? 0}</div>
            </div>
            <div>
              <div className="text-text-muted">Out</div>
              <div className="font-semibold text-text">{data.rowCountOut ?? 0}</div>
            </div>
            <div>
              <div className="text-text-muted">Rej</div>
              <div
                className={`font-semibold ${
                  (data.rejectedCount ?? 0) > 0 ? 'text-danger' : 'text-text-muted'
                }`}
              >
                {data.rejectedCount ?? 0}
              </div>
            </div>
          </div>
        )}

        {/* Error message snippet if failed */}
        {isFailed && data.errorMessage && (
          <div className="mt-1.5 p-1 rounded bg-danger-bg text-danger text-[10px] truncate flex items-center gap-1">
            <AlertTriangle className="w-3 h-3 shrink-0" />
            <span className="truncate">{data.errorMessage}</span>
          </div>
        )}
      </div>

      {/* Source Handle (Right Port) */}
      <Handle
        type="source"
        position={Position.Right}
        className="w-2.5 h-2.5 !bg-primary-600 border border-white"
      />
    </div>
  );
});

WorkflowNodeComponent.displayName = 'WorkflowNodeComponent';
