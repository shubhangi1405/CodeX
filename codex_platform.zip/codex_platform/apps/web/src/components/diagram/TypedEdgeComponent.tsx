import React, { memo, useState } from 'react';
import {
  BaseEdge,
  EdgeLabelRenderer,
  EdgeProps,
  getBezierPath,
  Edge,
} from '@xyflow/react';
import { TypedEdgeData } from './types';

export const TypedEdgeComponent: React.FC<EdgeProps<Edge<TypedEdgeData>>> = memo(
  ({
    id,
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition,
    targetPosition,
    data,
    markerEnd,
  }) => {
    const [isHovered, setIsHovered] = useState(false);

    const [edgePath, labelX, labelY] = getBezierPath({
      sourceX,
      sourceY,
      sourcePosition,
      targetX,
      targetY,
      targetPosition,
    });

    const dataType = data?.dataType || 'table';
    const rowCount = data?.rowCount;

    return (
      <>
        <BaseEdge
          id={id}
          path={edgePath}
          markerEnd={markerEnd}
          style={{
            stroke: isHovered ? '#6D28D9' : '#C4B5FD',
            strokeWidth: isHovered ? 2.5 : 1.5,
            transition: 'stroke 0.15s, stroke-width 0.15s',
          }}
        />

        <EdgeLabelRenderer>
          <div
            style={{
              position: 'absolute',
              transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
              pointerEvents: 'all',
            }}
            className="flex flex-col items-center cursor-pointer select-none"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            <div
              className={`px-1.5 py-0.5 rounded text-[9px] font-mono border transition-all shadow-subtle ${
                isHovered
                  ? 'bg-primary-600 text-white border-primary-600'
                  : 'bg-white text-text-muted border-border'
              }`}
            >
              {dataType}
              {typeof rowCount === 'number' && (
                <span className="ml-1 text-primary-700 font-semibold">
                  ({rowCount}r)
                </span>
              )}
            </div>

            {/* Hover Schema Tooltip */}
            {isHovered && data?.schemaDetails && (
              <div className="absolute top-6 left-1/2 -translate-x-1/2 z-50 p-2 rounded bg-text text-white text-[10px] font-mono shadow-lg whitespace-nowrap">
                {data.schemaDetails}
              </div>
            )}
          </div>
        </EdgeLabelRenderer>
      </>
    );
  }
);

TypedEdgeComponent.displayName = 'TypedEdgeComponent';
