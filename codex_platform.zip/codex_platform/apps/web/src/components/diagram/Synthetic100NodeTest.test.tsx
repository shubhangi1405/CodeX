import { describe, it, expect } from 'vitest';
import { Node, Edge } from '@xyflow/react';
import { getLayoutedElements } from './layout';
import { WorkflowNodeData, TypedEdgeData, NodeCategory } from './types';

describe('Workflow Graph Scalability & Performance', () => {
  it('computes Dagre layout on 100+ synthetic nodes in under 100ms', () => {
    const categories: NodeCategory[] = [
      'ingest',
      'validate',
      'transform',
      'aggregate',
      'quality',
      'output',
    ];

    const syntheticNodes: Node<WorkflowNodeData>[] = [];
    const syntheticEdges: Edge<TypedEdgeData>[] = [];

    // Construct a 100-node DAG
    for (let i = 0; i < 100; i++) {
      syntheticNodes.push({
        id: `node-${i}`,
        type: 'workflowNode',
        position: { x: 0, y: 0 },
        data: {
          id: `node-${i}`,
          type: 'core.process',
          label: `Processing Step ${i + 1}`,
          category: categories[i % categories.length],
          config: { stepIndex: i },
          inputPorts: [{ name: 'in', dataType: 'table' }],
          outputPorts: [{ name: 'out', dataType: 'table' }],
          status: 'idle',
        },
      });

      if (i > 0) {
        syntheticEdges.push({
          id: `edge-${i - 1}-${i}`,
          source: `node-${i - 1}`,
          target: `node-${i}`,
          type: 'typedEdge',
          data: { dataType: 'table' },
        });
      }
    }

    expect(syntheticNodes.length).toBe(100);
    expect(syntheticEdges.length).toBe(99);

    const startTime = performance.now();
    const layouted = getLayoutedElements(syntheticNodes, syntheticEdges, 'LR');
    const duration = performance.now() - startTime;

    // Verify performance budget (<350ms on CI runners)
    expect(duration).toBeLessThan(350);
    expect(layouted.nodes.length).toBe(100);

    // Verify all nodes have assigned positions
    layouted.nodes.forEach((node) => {
      expect(typeof node.position.x).toBe('number');
      expect(typeof node.position.y).toBe('number');
      expect(node.targetPosition).toBe('left');
      expect(node.sourcePosition).toBe('right');
    });

    // Verify topological monotonic progression (x coordinates increase)
    const firstX = layouted.nodes[0].position.x;
    const lastX = layouted.nodes[99].position.x;
    expect(lastX).toBeGreaterThan(firstX);
  });
});
