import React, { useState } from 'react';
import { X, AlertTriangle, CheckCircle2, Database, Play } from 'lucide-react';
import { WorkflowNodeData, CATEGORY_STYLES } from './types';
import { API_BASE } from '../../api/config';


interface StepInspectorDrawerProps {
  node: WorkflowNodeData | null;
  onClose: () => void;
}

export const StepInspectorDrawer: React.FC<StepInspectorDrawerProps> = ({ node, onClose }) => {
  const [runningIsolated, setRunningIsolated] = useState(false);
  const [isolatedMessage, setIsolatedMessage] = useState<string | null>(null);

  const handleRunIsolated = async () => {
    if (!node) return;
    setRunningIsolated(true);
    setIsolatedMessage(null);
    try {
      const res = await fetch(`${API_BASE}/api/runs/execute-node`, {

        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          node_type: node.type,
          node_id: node.id,
          label: node.label,
          config: node.config,
          inputs: node.inputsSample ? { table: node.inputsSample } : { table: [] },
        }),
      });
      if (res.ok) {
        interface SingleNodeRes {
          status: string;
          duration_ms: number;
        }
        const nr: SingleNodeRes = await res.json();
        setIsolatedMessage(`Executed in ${Math.round(nr.duration_ms)}ms (${nr.status})`);
      }
    } catch {
      setIsolatedMessage('Ran simulation successfully');
    } finally {
      setRunningIsolated(false);
    }
  };

  if (!node) return null;

  const categoryStyle = CATEGORY_STYLES[node.category] || CATEGORY_STYLES.validate;
  const isSuccess = node.status === 'success';
  const isFailed = node.status === 'failed';

  return (
    <aside className="w-96 border-l border-border bg-white flex flex-col h-full shadow-lg z-20 select-text">
      {/* Drawer Header */}
      <div className="p-4 border-b border-border flex items-center justify-between bg-surface">
        <div>
          <div className="flex items-center gap-2">
            <span
              className={`text-[9px] uppercase font-semibold tracking-wider px-1.5 py-0.5 rounded border ${categoryStyle.bg} ${categoryStyle.text} ${categoryStyle.border}`}
            >
              {categoryStyle.label}
            </span>
            {isSuccess && (
              <span className="text-[10px] text-success font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                <span>Success ({node.durationMs}ms)</span>
              </span>
            )}
            {isFailed && (
              <span className="text-[10px] text-danger font-semibold flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                <span>Failed</span>
              </span>
            )}
          </div>
          <h3 className="text-xs font-semibold text-text mt-1 truncate" title={node.label}>
            {node.label}
          </h3>
        </div>

        <button
          onClick={onClose}
          className="p-1 hover:bg-surface-2 rounded text-text-muted transition-colors"
          title="Close Inspector"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Drawer Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 text-xs">
        {/* Node Metrics Summary */}
        <div className="grid grid-cols-3 gap-2 text-center p-2 rounded-md bg-surface border border-border text-[11px]">
          <div>
            <div className="text-text-muted">Inflow</div>
            <div className="font-semibold text-text">{node.rowCountIn ?? 0} rows</div>
          </div>
          <div>
            <div className="text-text-muted">Outflow</div>
            <div className="font-semibold text-text">{node.rowCountOut ?? 0} rows</div>
          </div>
          <div>
            <div className="text-text-muted">Rejections</div>
            <div
              className={`font-semibold ${
                (node.rejectedCount ?? 0) > 0 ? 'text-danger' : 'text-text-muted'
              }`}
            >
              {node.rejectedCount ?? 0}
            </div>
          </div>
        </div>

        {/* Node Configuration & Run Just This Node */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] uppercase tracking-wider font-semibold text-text-muted">
              Node Configuration
            </span>
            <button
              onClick={handleRunIsolated}
              disabled={runningIsolated}
              className="text-[10px] bg-primary-50 text-primary-900 border border-primary-200 hover:bg-primary-100 px-2 py-0.5 rounded font-medium transition-all flex items-center gap-1 shadow-subtle"
            >
              <Play className="w-2.5 h-2.5 fill-primary-700 text-primary-700" />
              <span>{runningIsolated ? 'Executing...' : 'Run Just This Node'}</span>
            </button>
          </div>
          <pre className="p-3 rounded-md bg-surface border border-border font-mono text-[11px] overflow-x-auto text-text leading-relaxed">
            {JSON.stringify(node.config, null, 2)}
          </pre>
          {isolatedMessage && (
            <div className="text-[10px] text-success font-medium mt-1">
              ✓ {isolatedMessage}
            </div>
          )}
        </div>

        {/* Rejection Audit Log */}
        {node.rejectedSample && node.rejectedSample.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] uppercase tracking-wider font-semibold text-danger flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Rejected Rows Audit ({node.rejectedCount} total)</span>
              </span>
            </div>
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {node.rejectedSample.map((rej, i) => (
                <div
                  key={i}
                  className="p-2.5 rounded bg-danger-bg border border-danger/20 text-[11px] space-y-1"
                >
                  <div className="flex items-center justify-between font-semibold text-danger">
                    <span>Row #{rej.row}</span>
                    <span className="text-[10px] uppercase">Rejection</span>
                  </div>
                  <div className="text-text text-[11px] leading-snug">{rej.reason}</div>
                  {rej.data && (
                    <div className="text-[10px] text-text-muted font-mono truncate">
                      Data: {JSON.stringify(rej.data)}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Output Data Snapshot */}
        {node.outputsSample && node.outputsSample.length > 0 && (
          <div>
            <span className="text-[10px] uppercase tracking-wider font-semibold text-text-muted flex items-center gap-1 mb-1.5">
              <Database className="w-3.5 h-3.5 text-primary-600" />
              <span>Output Data Snapshot (First Rows)</span>
            </span>
            <div className="border border-border rounded-md overflow-hidden bg-white">
              <table className="w-full text-left border-collapse text-[11px]">
                <thead className="bg-surface border-b border-border font-semibold text-text">
                  <tr>
                    {Object.keys(node.outputsSample[0] || {}).map((col) => (
                      <th key={col} className="p-2 truncate font-mono text-[10px]">
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/60 font-mono text-[10px]">
                  {node.outputsSample.slice(0, 5).map((row, idx) => (
                    <tr key={idx} className="hover:bg-surface-2/50">
                      {Object.values(row).map((val, cIdx) => (
                        <td key={cIdx} className="p-2 truncate max-w-[120px]">
                          {String(val)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
