import React, { useMemo, useCallback } from 'react';
import {
  ReactFlow,
  Controls,
  MiniMap,
  Background,
  BackgroundVariant,
  Node,
  Edge,
  useNodesState,
  useEdgesState,
  NodeMouseHandler,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import { WorkflowNodeComponent } from './WorkflowNodeComponent';
import { TypedEdgeComponent } from './TypedEdgeComponent';
import { WorkflowNodeData, TypedEdgeData } from './types';
import { getLayoutedElements } from './layout';

interface WorkflowGraphProps {
  initialNodes: Node<WorkflowNodeData>[];
  initialEdges: Edge<TypedEdgeData>[];
  onSelectNode: (data: WorkflowNodeData | null) => void;
  selectedNodeId?: string | null;
}

export const WorkflowGraph: React.FC<WorkflowGraphProps> = ({
  initialNodes,
  initialEdges,
  onSelectNode,
  selectedNodeId,
}) => {
  const nodeTypes = useMemo(() => ({ workflowNode: WorkflowNodeComponent }), []);
  const edgeTypes = useMemo(() => ({ typedEdge: TypedEdgeComponent }), []);

  // Compute layouted nodes and edges
  const { nodes: layoutedNodes, edges: layoutedEdges } = useMemo(() => {
    return getLayoutedElements(initialNodes, initialEdges, 'LR');
  }, [initialNodes, initialEdges]);

  // Synchronize selected state into nodes
  const nodesWithSelection = useMemo(() => {
    return layoutedNodes.map((n) => ({
      ...n,
      selected: n.id === selectedNodeId,
    }));
  }, [layoutedNodes, selectedNodeId]);

  const [nodes, , onNodesChange] = useNodesState(nodesWithSelection);
  const [edges, , onEdgesChange] = useEdgesState(layoutedEdges);

  const onNodeClick: NodeMouseHandler = useCallback(
    (_, node) => {
      onSelectNode(node.data as unknown as WorkflowNodeData);
    },
    [onSelectNode]
  );

  const onPaneClick = useCallback(() => {
    onSelectNode(null);
  }, [onSelectNode]);

  return (
    <div className="w-full h-full relative bg-surface">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onNodeClick={onNodeClick}
        onPaneClick={onPaneClick}
        fitView
        minZoom={0.2}
        maxZoom={1.5}
        defaultEdgeOptions={{ type: 'typedEdge' }}
      >
        <Background variant={BackgroundVariant.Dots} gap={16} size={1} color="#E4DFF2" />
        <Controls
          className="!bg-white !border !border-border !rounded-md !shadow-subtle !overflow-hidden"
          showInteractive={false}
        />
        <MiniMap
          nodeStrokeColor="#6D28D9"
          nodeColor="#F3F0FA"
          nodeBorderRadius={4}
          className="!bg-white !border !border-border !rounded-md !shadow-subtle"
          zoomable
          pannable
        />
      </ReactFlow>
    </div>
  );
};
