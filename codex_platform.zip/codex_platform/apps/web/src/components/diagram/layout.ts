import dagre from 'dagre';
import { Node, Edge, Position } from '@xyflow/react';
import { WorkflowNodeData, TypedEdgeData } from './types';

const NODE_WIDTH = 260;
const NODE_HEIGHT = 140;

export function getLayoutedElements(
  nodes: Node<WorkflowNodeData>[],
  edges: Edge<TypedEdgeData>[],
  direction: 'LR' | 'TB' = 'LR'
): { nodes: Node<WorkflowNodeData>[]; edges: Edge<TypedEdgeData>[] } {
  const dagreGraph = new dagre.graphlib.Graph();
  dagreGraph.setDefaultEdgeLabel(() => ({}));

  dagreGraph.setGraph({
    rankdir: direction,
    nodesep: 40,
    ranksep: 70,
  });

  nodes.forEach((node) => {
    dagreGraph.setNode(node.id, { width: NODE_WIDTH, height: NODE_HEIGHT });
  });

  edges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  dagre.layout(dagreGraph);

  const layoutedNodes: Node<WorkflowNodeData>[] = nodes.map((node) => {
    const nodeWithPosition = dagreGraph.node(node.id);
    return {
      ...node,
      targetPosition: direction === 'LR' ? Position.Left : Position.Top,
      sourcePosition: direction === 'LR' ? Position.Right : Position.Bottom,
      position: {
        x: nodeWithPosition.x - NODE_WIDTH / 2,
        y: nodeWithPosition.y - NODE_HEIGHT / 2,
      },
    };
  });

  return { nodes: layoutedNodes, edges };
}
